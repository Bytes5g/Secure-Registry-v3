import { useMemo, useState } from "react";
import { useParams } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Building2, Loader2 } from "lucide-react";
import {
  EntityContentCard,
  EntityProfileHeader,
  EntityRelationsTabs,
} from "@secure-registry/components-ui";
import {
  fetchOrganization,
  fetchOrganizationCover,
  fetchOrganizationLogo,
  type OrgWithDetails,
} from "@/lib/api/org-admin";
import { OrgOverviewTab } from "./_org-profile/OrgOverviewTab";
import { OrgStructureTab } from "./_org-profile/OrgStructureTab";
import { OrgStructureDiagramTab } from "./_org-profile/OrgStructureDiagramTab";
import { OrgBranchesTab } from "./_org-profile/OrgBranchesTab";
import { OrgSubEntitiesTab } from "./_org-profile/OrgSubEntitiesTab";
import { OrgStructureRoleTitlesTab } from "./_org-profile/OrgStructureRoleTitlesTab";
import { OrgProfileHeaderActions } from "./_org-profile/OrgProfileHeaderActions";
import { OrgEmployeesTab } from "./_org-profile/OrgEmployeesTab";

export default function OrgEntityProfilePage() {
  const { id } = useParams<{ id: string }>();
  const orgId = Number(id);
  const enabled = Number.isFinite(orgId) && orgId > 0;
  const [activeTab, setActiveTab] = useState("overview");
  const [diagramRequestNonce, setDiagramRequestNonce] = useState(0);
  const [diagramRequest, setDiagramRequest] = useState<{
    scope: "org" | "branch" | "unit";
    nodeId: number | null;
    showOrgChartStaff: boolean;
  }>({ scope: "branch", nodeId: null, showOrgChartStaff: false });

  const { data: org, isLoading } = useQuery<OrgWithDetails>({
    queryKey: ["org-entity", orgId],
    queryFn: () => fetchOrganization(orgId, true),
    enabled,
  });

  const { data: logo } = useQuery({
    queryKey: ["org-entity-logo", orgId],
    queryFn: () => fetchOrganizationLogo(orgId),
    enabled,
  });

  const { data: cover } = useQuery({
    queryKey: ["org-entity-cover", orgId],
    queryFn: () => fetchOrganizationCover(orgId),
    enabled,
  });

  const headerMeta = useMemo(() => {
    if (!org) return [];
    return [
      { label: "الكود:", value: org.code || "—" },
      { label: "القطاع:", value: org.sector?.nameAr ?? "—" },
      { label: "التصنيف:", value: org.category?.nameAr ?? "—" },
      { label: "الموقع:", value: org.location?.nameAr ?? "—" },
    ];
  }, [org]);

  if (isLoading) {
    return (
      <div className="p-10 flex justify-center" dir="rtl">
        <Loader2 className="animate-spin h-8 w-8" />
      </div>
    );
  }

  if (!org) {
    return (
      <div className="p-8 text-center text-destructive" dir="rtl">
        لم يتم العثور على بيانات الجهة
      </div>
    );
  }

  const openUnitInDiagram = (orgStructureId: number) => {
    setActiveTab("structure-diagram");
    setDiagramRequest({ scope: "unit", nodeId: orgStructureId, showOrgChartStaff: true });
    setDiagramRequestNonce((v) => v + 1);
  };

  const tabs = [
    { value: "overview", label: "نظرة عامة", content: <OrgOverviewTab orgId={orgId} org={org} /> },
    { value: "structure", label: "تهيئة الهيكل", content: <OrgStructureTab orgId={orgId} /> },
    {
      value: "structure-diagram",
      label: "عرض الهيكل",
      content: (
        <OrgStructureDiagramTab
          orgId={orgId}
          requestedScope={diagramRequest.scope}
          requestedNodeId={diagramRequest.nodeId}
          requestedShowOrgChartStaff={diagramRequest.showOrgChartStaff}
          requestNonce={diagramRequestNonce}
        />
      ),
    },
    { value: "branches", label: "الفروع", content: <OrgBranchesTab orgId={orgId} /> },
    {
      value: "employees",
      label: "الموظفون",
      content: <OrgEmployeesTab orgId={orgId} onOpenUnit={openUnitInDiagram} />,
    },
    { value: "structure-roles", label: "مسميات الهيكل", content: <OrgStructureRoleTitlesTab orgId={orgId} /> },
    { value: "sub-entities", label: "الجهات التابعة", content: <OrgSubEntitiesTab orgId={orgId} /> },
  ];

  return (
    <div className="p-6 space-y-4" dir="rtl">
      <EntityProfileHeader
        title={org.name}
        subtitle="إدارة إعدادات الجهة عبر تبويبات متخصصة"
        status={{
          label: org.isActive ? "فعّالة" : "غير فعّالة",
          variant: org.isActive ? "secondary" : "outline",
        }}
        meta={headerMeta}
        showCoverPlaceholder={true}
        coverImageUrl={cover?.filePath || null}
        avatarImageUrl={logo?.filePath || null}
        avatarFallback={<Building2 className="h-5 w-5" />}
        coverHeightClassName="h-44 sm:h-52 md:h-60"
        avatarClassName="h-24 w-24 sm:h-28 sm:w-28"
        avatarOverlapClassName="-mt-12 sm:-mt-14"
        actions={<OrgProfileHeaderActions orgId={orgId} />}
      />

      <EntityContentCard contentClassName="p-6">
        <EntityRelationsTabs
          tabs={tabs}
          value={activeTab}
          onValueChange={setActiveTab}
          direction="rtl"
          className="w-full"
          tabsListClassName="mb-4 w-full overflow-x-auto"
        />
      </EntityContentCard>
    </div>
  );
}
