import { useEffect, useMemo, useState } from "react";
import { useLocation } from "wouter";
import { Eye } from "lucide-react";
import { Button, EntityContentCard, Tabs, TabsContent, TabsList, TabsTrigger, type Column } from "@secure-registry/components-ui";
import { DataTable } from "@secure-registry/components-ui";
import { DynamicForm } from "@/components/forms/DynamicForm";
import { PAGE_CODES } from "@/lib/constants";
import { buildPersonsSearchParams } from "@/lib/search/buildPersonsSearchParams";
import { useUnifiedLookups } from "@/hooks/useUnifiedLookups";
import type { UiPageColumn, UiPageConfig, UiPageFormField } from "@/types/ui";
import { useUiPageDetails } from "@/features/ui-runtime/hooks/useUiPageDetails";
import { useUiPageTabs } from "@/features/ui-runtime/hooks/useUiPageTabs";
import { useUiTabDataSourceCursorList } from "@/features/ui-runtime/hooks/useUiTabDataSourceCursorList";
import { useUiTabDataSourceQuery } from "@/features/ui-runtime/hooks/useUiTabDataSourceQuery";

export function PersonsManagementView() {
  const [, setLocation] = useLocation();
  const { lookups } = useUnifiedLookups();
  const [criteria, setCriteria] = useState<Record<string, any>>({});
  const [statsCriteria, setStatsCriteria] = useState<Record<string, any>>({});

  const pageDetailsQuery = useUiPageDetails<{
    config: UiPageConfig;
    tabs?: any[];
    tabDataSources?: any[];
  }>({ pageCode: PAGE_CODES.PERSONS_SEARCH, entityType: "personsSearch" });

  const { tabs, hasTabs, activeTabKey, setActiveTabKey } = useUiPageTabs(pageDetailsQuery.data as any);

  useEffect(() => {
    setCriteria({});
    setStatsCriteria({});
  }, [activeTabKey]);

  const listRuntime = useUiTabDataSourceCursorList({
    details: pageDetailsQuery.data as any,
    tabKey: activeTabKey,
    purpose: "list",
    criteria,
    fallbackDataSourceKey: "persons_search_inline",
    fallbackBuildParams: buildPersonsSearchParams,
    enabled: !!pageDetailsQuery.data?.config,
    limitDefault: 50,
  });

  const statsRuntime = useUiTabDataSourceQuery({
    details: pageDetailsQuery.data as any,
    tabKey: activeTabKey,
    purpose: "stats",
    criteria: statsCriteria,
    enabled: !!pageDetailsQuery.data?.config,
    limitDefault: 1,
  });

  const effectiveFormFields: UiPageFormField[] = useMemo(() => {
    const config = (pageDetailsQuery.data as any)?.config;
    const fields = Array.isArray(config?.formFields) ? (config.formFields as UiPageFormField[]) : [];
    return fields;
  }, [pageDetailsQuery.data]);

  const columns = useMemo<Column<any>[]>(() => {
    const config = (pageDetailsQuery.data as any)?.config as UiPageConfig | undefined;
    const base = Array.isArray(config?.columns) ? (config?.columns as UiPageColumn[]) : [];
    const mapped = base
      .filter((c) => c.isVisible)
      .sort((a, b) => Number(a.orderIndex ?? 0) - Number(b.orderIndex ?? 0))
      .map((c) => ({
        key: c.fieldCode,
        header: c.nameAr,
        width: c.width || undefined,
        sortable: c.isSortable,
        render: (value: any) => {
          if (value == null || value === "") return "—";
          if (typeof value === "boolean") return value ? "نعم" : "لا";
          if (c.columnType === "date" && value) return new Date(String(value)).toLocaleDateString("ar-SA");
          return value;
        },
      }));

    return [
      ...mapped,
      {
        key: "profile",
        header: "عرض",
        width: "60px",
        render: (_: any, row: any) => (
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setLocation(`/config/persons/${row.id}`)}
            title="فتح بروفايل الشخص"
          >
            <Eye className="h-4 w-4" />
          </Button>
        ),
      },
    ];
  }, [pageDetailsQuery.data, setLocation]);

  const handleSearchSubmit = (values: any) => {
    setCriteria(values || {});
    setStatsCriteria(values || {});
  };

  const isLoading = listRuntime.query.isLoading || listRuntime.loadMore.isPending || pageDetailsQuery.isLoading;

  const statsRow = useMemo(() => {
    const data = Array.isArray(statsRuntime.query.data?.data) ? statsRuntime.query.data?.data : [];
    const first = data[0];
    return first && typeof first === "object" ? (first as Record<string, any>) : null;
  }, [statsRuntime.query.data]);

  const content = (
    <div className="space-y-4">
      <div>
        <div className="text-sm font-semibold mb-2">بحث الأشخاص</div>
        <DynamicForm
          fields={effectiveFormFields}
          lookupTypes={lookups as any}
          initialData={criteria}
          onSubmit={handleSearchSubmit}
          isSubmitting={false}
          readOnly={false}
          submitLabel="بحث"
          submitPendingLabel="جاري البحث..."
        />
      </div>

      {statsRow ? (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {Object.entries(statsRow)
            .slice(0, 8)
            .map(([k, v]) => (
              <div key={k} className="rounded-md border bg-background p-3">
                <div className="text-xs text-muted-foreground">{k}</div>
                <div className="text-sm font-semibold">{v == null || v === "" ? "—" : String(v)}</div>
              </div>
            ))}
        </div>
      ) : null}

      <DataTable
        data={Array.isArray(listRuntime.rows) ? listRuntime.rows : []}
        columns={columns}
        isLoading={isLoading}
        emptyMessage="لا توجد بيانات أشخاص"
      />

      <div className="flex justify-center">
        <Button
          type="button"
          variant="outline"
          disabled={!listRuntime.nextCursor || listRuntime.loadMore.isPending}
          onClick={() => {
            listRuntime.loadMore.mutate();
          }}
        >
          تحميل المزيد
        </Button>
      </div>
    </div>
  );

  return (
    <div className="p-6 space-y-4" dir="rtl">
      <EntityContentCard contentClassName="p-6">
        {hasTabs ? (
          <Tabs value={activeTabKey} onValueChange={setActiveTabKey} dir="rtl">
            <TabsList className="w-full justify-start overflow-x-auto">
              {tabs.map((t: any) => (
                <TabsTrigger key={String(t.tabKey)} value={String(t.tabKey)}>
                  {String(t.labelAr)}
                </TabsTrigger>
              ))}
            </TabsList>
            <TabsContent value={activeTabKey} className="mt-4 space-y-4">
              {content}
            </TabsContent>
          </Tabs>
        ) : (
          content
        )}
      </EntityContentCard>
    </div>
  );
}
