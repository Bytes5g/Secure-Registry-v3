import { PAGE_CODES, SYSTEM_LOOKUP_IDS } from "@/lib/constants";
import type { UiPageConfig } from "@/types/ui";

export const ORG_UNITS_CONFIG: UiPageConfig = {
  id: 0,
  code: PAGE_CODES.ORG_STRUCTURE_TREE,
  nameAr: "إدارة الوحدات",
  entityType: "orgStructureTree",
  layoutType: "list",
  columns: [
    { fieldCode: "name", nameAr: "الاسم", columnType: "text", isVisible: true, isSortable: true, isFilterable: true },
    { fieldCode: "code", nameAr: "الكود", columnType: "text", isVisible: true, isSortable: true, isFilterable: true },
    { fieldCode: "structureId", nameAr: "نوع الوحدة", columnType: "select", lookupTypeId: SYSTEM_LOOKUP_IDS.ORG_STRUCTURE_TYPE, isVisible: true, isSortable: true, isFilterable: true },
    { fieldCode: "level", nameAr: "المستوى", columnType: "number", isVisible: true, isSortable: true, isFilterable: true },
    { fieldCode: "orderIndex", nameAr: "الترتيب", columnType: "number", isVisible: true, isSortable: true, isFilterable: true },
    { fieldCode: "isActive", nameAr: "فعال", columnType: "boolean", isVisible: true, isSortable: true, isFilterable: true },
  ],
  formFields: [
    { fieldCode: "name", nameAr: "الاسم", fieldType: "text", isRequired: true, gridCols: 1, orderIndex: 1 },
    { fieldCode: "code", nameAr: "الكود", fieldType: "text", isRequired: true, gridCols: 1, orderIndex: 2 },
    { fieldCode: "structureId", nameAr: "نوع الوحدة", fieldType: "select", lookupTypeId: SYSTEM_LOOKUP_IDS.ORG_STRUCTURE_TYPE, isRequired: true, gridCols: 1, orderIndex: 3 },
    { fieldCode: "parentId", nameAr: "الأب", fieldType: "select", isRequired: false, gridCols: 1, orderIndex: 4 },
    { fieldCode: "level", nameAr: "المستوى", fieldType: "number", isRequired: false, gridCols: 1, orderIndex: 5, defaultValue: "1", placeholder: "1" },
    { fieldCode: "orderIndex", nameAr: "الترتيب", fieldType: "number", isRequired: false, gridCols: 1, orderIndex: 6, defaultValue: "0", placeholder: "0" },
    { fieldCode: "isActive", nameAr: "فعال", fieldType: "boolean", isRequired: false, gridCols: 1, orderIndex: 7 },
    { fieldCode: "orgId", nameAr: "معرف الجهة", fieldType: "number", isRequired: true, isVisible: false, isEditable: false, orderIndex: 999 },
  ],
  filters: [],
};

export const ORG_BRANCHES_CONFIG: UiPageConfig = {
  id: 0,
  code: PAGE_CODES.BRANCH_MANAGEMENT,
  nameAr: "فروع الجهة",
  entityType: "orgBranches",
  layoutType: "list",
  columns: [
    { fieldCode: "name", nameAr: "الاسم", columnType: "text", isVisible: true, isSortable: true, isFilterable: true },
    { fieldCode: "code", nameAr: "الكود", columnType: "text", isVisible: true, isSortable: true, isFilterable: true },
    { fieldCode: "geoUnitId", nameAr: "الموقع", columnType: "select", lookupTypeId: SYSTEM_LOOKUP_IDS.GEO_UNITS, isVisible: true, isSortable: true, isFilterable: true },
    { fieldCode: "branchScopeLookupId", nameAr: "نطاق الفرع", columnType: "select", lookupTypeId: SYSTEM_LOOKUP_IDS.BRANCH_SCOPE, isVisible: true, isSortable: true, isFilterable: true },
    { fieldCode: "isActive", nameAr: "فعال", columnType: "boolean", isVisible: true, isSortable: true, isFilterable: true },
  ],
  formFields: [
    { fieldCode: "name", nameAr: "الاسم", fieldType: "text", isRequired: true, gridCols: 1, orderIndex: 1 },
    { fieldCode: "code", nameAr: "الكود", fieldType: "text", isRequired: true, gridCols: 1, orderIndex: 2 },
    { fieldCode: "geoUnitId", nameAr: "الوحدة الجغرافية", fieldType: "select", lookupTypeId: SYSTEM_LOOKUP_IDS.GEO_UNITS, isRequired: true, gridCols: 1, orderIndex: 3, config: { enableGeoMapPicker: true } },
    { fieldCode: "branchScopeLookupId", nameAr: "نطاق الفرع", fieldType: "select", lookupTypeId: SYSTEM_LOOKUP_IDS.BRANCH_SCOPE, isRequired: false, gridCols: 1, orderIndex: 4 },
    { fieldCode: "isActive", nameAr: "فعال", fieldType: "boolean", isRequired: false, gridCols: 1, orderIndex: 5 },
  ],
  filters: [],
};

export const ORG_STRUCTURE_ROLE_TITLES_CONFIG: UiPageConfig = {
  id: 0,
  code: PAGE_CODES.ORG_STRUCTURE_ROLE_TITLES,
  nameAr: "مسميات الهيكل",
  entityType: "orgStructureRoleTitles",
  layoutType: "list",
  columns: [
    { fieldCode: "branchScopeLookupId", nameAr: "نطاق الفرع", columnType: "select", lookupTypeId: SYSTEM_LOOKUP_IDS.BRANCH_SCOPE, isVisible: true, isSortable: true, isFilterable: true },
    { fieldCode: "orgStructureId", nameAr: "نوع الوحدة (للعقدة)", columnType: "select", lookupTypeId: SYSTEM_LOOKUP_IDS.ORG_STRUCTURE_TYPE, isVisible: true, isSortable: true, isFilterable: true },
    { fieldCode: "orgStructureCodeId", nameAr: "نوع الوحدة (للمسمى)", columnType: "select", lookupTypeId: SYSTEM_LOOKUP_IDS.ORG_STRUCTURE_TYPE, isVisible: true, isSortable: true, isFilterable: true },
    { fieldCode: "orgRoleTitleId", nameAr: "المسمى", columnType: "select", lookupTypeId: SYSTEM_LOOKUP_IDS.PERSON_LOCATION_ROLE, isVisible: true, isSortable: true, isFilterable: true },
    { fieldCode: "orderIndex", nameAr: "الترتيب", columnType: "number", isVisible: true, isSortable: true, isFilterable: true },
    { fieldCode: "isActive", nameAr: "فعال", columnType: "boolean", isVisible: true, isSortable: true, isFilterable: true },
  ],
  formFields: [
    { fieldCode: "branchScopeLookupId", nameAr: "نطاق الفرع", fieldType: "select", lookupTypeId: SYSTEM_LOOKUP_IDS.BRANCH_SCOPE, isRequired: true, gridCols: 1, orderIndex: 1 },
    { fieldCode: "orgStructureId", nameAr: "نوع الوحدة (للعقدة)", fieldType: "select", lookupTypeId: SYSTEM_LOOKUP_IDS.ORG_STRUCTURE_TYPE, isRequired: true, gridCols: 1, orderIndex: 2 },
    { fieldCode: "orgStructureCodeId", nameAr: "نوع الوحدة (للمسمى)", fieldType: "select", lookupTypeId: SYSTEM_LOOKUP_IDS.ORG_STRUCTURE_TYPE, isRequired: true, gridCols: 1, orderIndex: 3 },
    { fieldCode: "orgRoleTitleId", nameAr: "المسمى", fieldType: "select", lookupTypeId: SYSTEM_LOOKUP_IDS.PERSON_LOCATION_ROLE, isRequired: true, gridCols: 1, orderIndex: 4 },
    { fieldCode: "orderIndex", nameAr: "الترتيب", fieldType: "number", isRequired: false, gridCols: 1, orderIndex: 5, defaultValue: "0", placeholder: "0" },
    { fieldCode: "isActive", nameAr: "فعال", fieldType: "boolean", isRequired: false, gridCols: 1, orderIndex: 6 },
    { fieldCode: "orgId", nameAr: "معرف الجهة", fieldType: "number", isRequired: true, isVisible: false, isEditable: false, orderIndex: 999 },
  ],
  filters: [],
};
