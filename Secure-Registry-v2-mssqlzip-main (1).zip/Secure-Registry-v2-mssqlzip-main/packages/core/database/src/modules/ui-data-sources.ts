import type { SqlExecutor } from "../config/connection";
import { runQuery } from "./helpers";
import { uiRegistryModule } from "./ui-registry";

function isUnsafeSql(text: string): boolean {
  const lowered = text.toLowerCase();
  if (lowered.includes(";")) return true;
  if (/\b(insert|update|delete|merge|drop|alter|create|truncate|grant|revoke|deny)\b/i.test(text)) return true;
  if (/\bexec\b/i.test(text)) return true;
  return false;
}

function clampLimit(value: unknown, fallback = 50): number {
  const parsed = Number(value);
  if (!Number.isFinite(parsed)) return fallback;
  return Math.max(1, Math.min(200, parsed));
}

export type ExecuteUiDataSourceResult = {
  data: Record<string, unknown>[];
  nextCursor: number | null;
};

export type UiDataSourceExecutionActor = {
  userId?: number | null;
  role?: string | null;
  isSuperAdmin?: boolean;
  permissions?: string[];
};

function isAllowedToExecute(actor: UiDataSourceExecutionActor | undefined, ds: any): boolean {
  if (!actor?.userId || !Number.isFinite(Number(actor.userId))) return false;

  const permissions = Array.isArray(actor.permissions) ? actor.permissions.map(String) : [];
  if (actor.isSuperAdmin === true) return true;
  if (permissions.includes("*")) return true;

  const paramsSpec = (ds?.parameters && typeof ds.parameters === "object" ? (ds.parameters as any) : null) as any;
  const allowedRoles: string[] = Array.isArray(paramsSpec?.allowedRoles) ? paramsSpec.allowedRoles.map((v: any) => String(v).toLowerCase()) : [];
  const allowedPermissions: string[] = Array.isArray(paramsSpec?.allowedPermissions) ? paramsSpec.allowedPermissions.map(String) : [];

  const actorRole = actor.role == null ? "" : String(actor.role).toLowerCase();
  if (allowedRoles.length > 0 && allowedRoles.includes(actorRole)) return true;
  if (allowedPermissions.length > 0 && allowedPermissions.some((p) => permissions.includes(p))) return true;

  return false;
}

export class UiDataSourcesModule {
  async executeDataSourceByKey(
    dataSourceKey: string,
    queryParams: Record<string, unknown>,
    actor: UiDataSourceExecutionActor,
    executor?: SqlExecutor,
  ): Promise<ExecuteUiDataSourceResult> {
    const key = String(dataSourceKey || "").trim();
    if (!key) throw new Error("dataSourceKey is required");

    const ds = await uiRegistryModule.getDataSourceByKey(key, executor);
    if (!ds) throw new Error("Data source not found");

    if (!isAllowedToExecute(actor, ds)) {
      throw new Error("Not authorized to execute data source");
    }

    const sourceType = String(ds.sourceType || "").toUpperCase();
    if (sourceType !== "INLINE") {
      throw new Error("Only INLINE data sources are supported currently");
    }

    const sqlText = ds.inlineQuery ? String(ds.inlineQuery).trim() : "";
    if (!sqlText) throw new Error("INLINE query is empty");
    if (isUnsafeSql(sqlText)) throw new Error("INLINE query is not allowed");

    const paramsSpec = (ds.parameters && typeof ds.parameters === "object" ? (ds.parameters as any) : null) as any;
    const allowedParams: string[] = Array.isArray(paramsSpec?.allowedParams) ? paramsSpec.allowedParams.map(String) : [];
    const cursorColumn = String(paramsSpec?.cursorColumn || "id");

    const inputParams: Record<string, unknown> = {};
    for (const k of allowedParams) {
      const raw = (queryParams as any)?.[k];
      if (raw === undefined || raw === null || raw === "") {
        inputParams[k] = null;
        continue;
      }
      if (Array.isArray(raw)) {
        inputParams[k] = raw.length ? String(raw[0]) : null;
        continue;
      }
      inputParams[k] = raw;
    }

    if (Object.prototype.hasOwnProperty.call(inputParams, "limit")) {
      inputParams.limit = clampLimit(inputParams.limit, 50);
    }

    const rows = await runQuery<Record<string, unknown>>(sqlText, inputParams, executor);
    const last = rows.length ? rows[rows.length - 1] : null;
    const nextCursorRaw = last && (last as any)[cursorColumn] != null ? Number((last as any)[cursorColumn]) : null;
    const nextCursor = nextCursorRaw != null && Number.isFinite(nextCursorRaw) ? nextCursorRaw : null;

    return { data: rows, nextCursor };
  }
}

export const uiDataSourcesModule = new UiDataSourcesModule();
