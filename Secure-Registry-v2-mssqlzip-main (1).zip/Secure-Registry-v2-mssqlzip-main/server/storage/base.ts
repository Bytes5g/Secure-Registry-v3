type Callable = (...args: never[]) => unknown;

function collectMethodNames(instance: object): string[] {
  const names = new Set<string>();
  let current: object | null = instance;

  while (current && current !== Object.prototype) {
    for (const name of Object.getOwnPropertyNames(current)) {
      if (name !== "constructor") {
        names.add(name);
      }
    }
    current = Object.getPrototypeOf(current);
  }

  return Array.from(names);
}

export function bindStorageMethods<T extends object>(instance: T): T {
  const boundEntries = collectMethodNames(instance)
    .map((name) => {
      const value = (instance as Record<string, unknown>)[name];
      if (typeof value !== "function") {
        return null;
      }

      return [name, (value as Callable).bind(instance)] as const;
    })
    .filter((entry): entry is readonly [string, Callable] => entry !== null);

  return Object.fromEntries(boundEntries) as T;
}
