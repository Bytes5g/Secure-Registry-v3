import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { useLookupTypesController } from "./useLookupTypesController";
import { useLookupValuesController } from "./useLookupValuesController";
import { useLookupVirtualSeedsController } from "./useLookupVirtualSeedsController";

/**
 * Composer hook: wires the four entity-specific controllers together
 * and returns a flat shape consumed by the lookups admin screen.
 *
 * Each child hook owns its own queries, mutations, dialog state, and
 * submit logic. The composer only owns the cross-cutting concerns
 * (queryClient, toast, invalidateAll).
 */
export function useLookupsAdminController() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const types = useLookupTypesController({
    toast,
    invalidateAll: () => invalidateAll(),
  });

  const sharedDeps = {
    toast,
    invalidateAll: () => invalidateAll(),
    selectedTypeId: types.selectedTypeId,
    selectedType: types.selectedType,
  };

  const values = useLookupValuesController(sharedDeps);
  const virtualSeeds = useLookupVirtualSeedsController(sharedDeps);

  async function invalidateAll() {
    await Promise.all([
      queryClient.invalidateQueries({ queryKey: ["lookup-admin", "types"] }),
      queryClient.invalidateQueries({ queryKey: ["lookup-admin", "values", types.selectedTypeId] }),
      queryClient.invalidateQueries({
        queryKey: ["lookup-admin", "virtual-seeds", types.selectedTypeId],
      }),
      queryClient.invalidateQueries({ queryKey: ["lookupTypes"] }),
      queryClient.invalidateQueries({ queryKey: ["lookupValues"] }),
    ]);
  }

  // Strip selectedTypeId from `types` (internal-only) before merging.
  const { selectedTypeId: _unused, ...typesPublic } = types;

  return {
    ...typesPublic,
    ...values,
    ...virtualSeeds,
  };
}

export type LookupsAdminController = ReturnType<typeof useLookupsAdminController>;
