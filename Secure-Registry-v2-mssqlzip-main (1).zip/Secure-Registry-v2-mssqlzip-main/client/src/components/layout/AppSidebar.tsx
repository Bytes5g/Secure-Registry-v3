import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/lib/mock-auth";
import { cn } from "@/lib/utils";
import { SIDEBAR_MENU, type MenuSection, type MenuItem } from "@/config/menu";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarRail,
  SidebarSeparator,
} from "@secure-registry/components-ui";
import {
  ShieldAlert,
  ChevronDown,
  Loader2,
} from "lucide-react";

interface MenuSectionProps {
  section: MenuSection;
  isOpen: boolean;
  onToggle: () => void;
  location: string;
}

function MenuSectionGroup({ section, isOpen, onToggle, location }: MenuSectionProps) {
  const renderMenuItem = (item: MenuItem) => {
    const Icon = item.icon;
    const isActive = location === item.path || 
                    (item.path !== "/" && location.startsWith(item.path));
    
    return (
      <SidebarMenuItem key={item.path}>
        <SidebarMenuButton
          asChild
          isActive={isActive}
          tooltip={item.title}
          className="justify-start gap-3"
        >
          <Link href={item.path} className="flex w-full items-center gap-2">
            {Icon && <Icon className="h-4 w-4" />}
            <span className="font-medium text-sm">{item.title}</span>
          </Link>
        </SidebarMenuButton>
      </SidebarMenuItem>
    );
  };

  return (
    <Collapsible open={isOpen} onOpenChange={onToggle} className="group/collapsible">
      <SidebarGroup>
        <CollapsibleTrigger asChild>
          <SidebarGroupLabel 
            className="flex items-center justify-between gap-2 cursor-pointer hover:bg-accent/50 rounded-md px-2 py-1.5 transition-colors"
          >
            <div className="flex items-center gap-2">
              <span className="group-data-[collapsible=icon]:hidden font-semibold text-xs">
                {section.title}
              </span>
            </div>
            <ChevronDown 
              className={cn(
                "h-4 w-4 transition-transform duration-200 group-data-[collapsible=icon]:hidden",
                isOpen ? "rotate-0" : "-rotate-90"
              )} 
            />
          </SidebarGroupLabel>
        </CollapsibleTrigger>
        <CollapsibleContent>
          <SidebarGroupContent className="pt-1">
            <SidebarMenu className="gap-0.5">
              {section.items.map(renderMenuItem)}
            </SidebarMenu>
          </SidebarGroupContent>
        </CollapsibleContent>
      </SidebarGroup>
    </Collapsible>
  );
}

export function AppSidebar() {
  const [location] = useLocation();
  const { user, logout } = useAuth();
  
  // Track which sections are open (all open by default)
  const [openSections, setOpenSections] = useState<Record<string, boolean>>({});
  
  // Initialize all sections as open
  const getIsOpen = (title: string) => {
    if (openSections[title] === undefined) {
      return true; // Default to open
    }
    return openSections[title];
  };
  
  const toggleSection = (title: string) => {
    setOpenSections(prev => ({
      ...prev,
      [title]: !getIsOpen(title)
    }));
  };

  return (
    <Sidebar side="right" variant="inset" collapsible="icon" className="order-2">
      <SidebarHeader>
        <div className="flex items-center gap-3 p-2">
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 text-primary">
            <ShieldAlert className="h-6 w-6" />
          </div>
          <div className="grid flex-1 text-right leading-tight group-data-[collapsible=icon]:hidden">
            <span className="font-bold">النظام الأمني</span>
            <span className="text-xs text-muted-foreground">الإصدار الأول</span>
          </div>
        </div>
      </SidebarHeader>
      
      <SidebarSeparator />
      
      <SidebarContent className="gap-1">
        {SIDEBAR_MENU.map((section) => (
          <MenuSectionGroup
            key={section.title}
            section={section}
            isOpen={getIsOpen(section.title)}
            onToggle={() => toggleSection(section.title)}
            location={location}
          />
        ))}
      </SidebarContent>

      <SidebarFooter />
      <SidebarRail />
    </Sidebar>
  );
}
