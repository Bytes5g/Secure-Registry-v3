import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@secure-registry/components-ui";
import { DynamicForm } from "@/components/forms/DynamicForm";
import type { UiPageFormField } from "@/types/ui";
import type { LookupTypeWithValues } from "@shared/schema";
import type { ReactNode } from "react";

export type CrudDialogMode = "create" | "edit" | "view";

interface CrudDialogProps {
  open: boolean;
  mode: CrudDialogMode;
  onOpenChange: (open: boolean) => void;
  titles: Record<CrudDialogMode, string>;
  descriptions?: Partial<Record<CrudDialogMode, string>>;
  fields: UiPageFormField[];
  initialData?: Record<string, unknown>;
  onSubmit: (values: Record<string, unknown>) => void;
  isSubmitting?: boolean;
  serverErrors?: Record<string, string> | null;
  lookupTypes?: LookupTypeWithValues[];
  contentClassName?: string;
  extraContent?: ReactNode;
}

export function CrudDialog({
  open,
  mode,
  onOpenChange,
  titles,
  descriptions,
  fields,
  initialData,
  onSubmit,
  isSubmitting,
  serverErrors,
  lookupTypes,
  contentClassName = "max-w-3xl max-h-[85vh] overflow-y-auto",
  extraContent,
}: CrudDialogProps) {
  const description = descriptions?.[mode];

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className={contentClassName}>
        <DialogHeader>
          <DialogTitle>{titles[mode]}</DialogTitle>
          {description ? <DialogDescription>{description}</DialogDescription> : null}
        </DialogHeader>
        <DynamicForm
          fields={fields}
          initialData={initialData}
          onSubmit={onSubmit}
          isSubmitting={isSubmitting}
          serverErrors={serverErrors ?? null}
          lookupTypes={lookupTypes}
          readOnly={mode === "view"}
        />
        {extraContent}
      </DialogContent>
    </Dialog>
  );
}
