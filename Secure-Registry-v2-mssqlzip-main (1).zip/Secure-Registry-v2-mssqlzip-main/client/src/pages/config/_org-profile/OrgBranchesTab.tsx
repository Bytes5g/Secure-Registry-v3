import { useMemo, useState } from "react";
import { Settings } from "lucide-react";
import { GenericEntityPage } from "@/components/generic/GenericEntityPage";
import BranchStructureBuilder from "@/components/forms/BranchStructureBuilder";
import { PAGE_CODES } from "@/lib/constants";
import {
  Button,
  EntityContentCard,
  type Column,
} from "@secure-registry/components-ui";
import { ORG_BRANCHES_CONFIG } from "./configs";

export function OrgBranchesTab({ orgId }: { orgId: number }) {
  const [structureBuilderOpen, setStructureBuilderOpen] = useState(false);
  const [selectedBranchForStructure, setSelectedBranchForStructure] = useState<any>(null);

  const extraColumns = useMemo<Column<any>[]>(
    () => [
      {
        key: "structure",
        header: "الهيكل",
        width: "50px",
        render: (_, row) => (
          <Button
            variant="ghost"
            size="icon"
            onClick={(e) => {
              e.stopPropagation();
              setSelectedBranchForStructure(row);
              setStructureBuilderOpen(true);
            }}
            title="بناء الهيكل"
          >
            <Settings className="h-4 w-4" />
          </Button>
        ),
      },
    ],
    [],
  );

  return (
    <>
      <EntityContentCard>
        <GenericEntityPage
          entityType="orgBranches"
          pageCode={PAGE_CODES.BRANCH_MANAGEMENT}
          staticConfig={ORG_BRANCHES_CONFIG}
          apiParams={{ orgId }}
          defaultValues={{ orgId }}
          extraColumns={extraColumns}
          hideTitle={true}
        />
      </EntityContentCard>

      {structureBuilderOpen && selectedBranchForStructure ? (
        <BranchStructureBuilder
          open={structureBuilderOpen}
          onOpenChange={setStructureBuilderOpen}
          branch={selectedBranchForStructure}
        />
      ) : null}
    </>
  );
}
