IF OBJECT_ID('dbo.tgn_geo_nodes', 'U') IS NOT NULL
    DROP TABLE dbo.tgn_geo_nodes;
GO

CREATE TABLE dbo.tgn_geo_nodes
(
    admin_unit_id INT NOT NULL,     -- id من الـ VIEW
    parent_id INT NULL,             -- parent_id من الـ VIEW
    country_id INT NULL,
    unit_code NVARCHAR(150) NULL,
    name NVARCHAR(300) NULL,
    name_en NVARCHAR(300) NULL,
    admin_type_ar NVARCHAR(300) NULL,
    admin_type_en NVARCHAR(300) NULL,
    admin_level INT NULL,
    is_active BIT NULL,
    created_at DATETIME2 NULL,
    created_by INT NULL,
    updated_at DATETIME NULL,
    updated_by INT NULL,
    is_deleted BIT NULL,
    work_context_by INT NOT NULL,

    INDEX ix_graphid UNIQUE ($node_id)
)
AS NODE;
GO
DROP TABLE IF EXISTS dbo.tge_geo_edges;
GO

CREATE TABLE dbo.tge_geo_edges
(
    relation_type NVARCHAR(50) NOT NULL DEFAULT 'ParentOf',
    work_context_by INT NOT NULL,
    created_at DATETIME2 NULL,
    created_by INT NULL,

    INDEX ix_graphid UNIQUE ($edge_id),
    INDEX ix_fromid ($from_id, $to_id),
    INDEX ix_toid ($to_id, $from_id)
)
AS EDGE;
GO

ALTER TABLE dbo.tgn_geo_nodes
ADD CONSTRAINT FK_tgn_geo_nodes_work_context_by
FOREIGN KEY (work_context_by) REFERENCES dbo.org_branch_nodes(id);
GO

INSERT INTO dbo.tgn_geo_nodes 
(
    admin_unit_id,
    parent_id,
    country_id,
    unit_code,
    name,
    name_en,
    admin_type_ar,
    admin_type_en,
    admin_level,
    work_context_by,
    is_active,
    created_at,
    created_by
)
SELECT 
      id,
      parent_id,
      country_id,
      unit_code,
      name,
      name_en,
      admin_type_ar,
      admin_type_en,
      admin_level,
      COALESCE(work_context_by, id),
      is_active,
      created_at,
    created_by
FROM dbo.geo_admin_units;



INSERT INTO tge_geo_edges ($from_id, $to_id, relation_type, work_context_by, created_at, created_by)
SELECT p.$node_id, c.$node_id, 'ParentOf', COALESCE(p.work_context_by, p.admin_unit_id), SYSUTCDATETIME(), p.created_by
FROM tgn_geo_nodes AS p
INNER JOIN tgn_geo_nodes AS c ON p.admin_unit_id = c.parent_id;

CREATE INDEX ix_nodes_admin_unit_id
ON tgn_geo_nodes(admin_unit_id);
CREATE INDEX ix_nodes_parent_id
ON tgn_geo_nodes(parent_id);
CREATE INDEX ix_nodes_admin_level
ON tgn_geo_nodes(admin_level);


SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:      Ahmed Al-Naqeeb
-- Description: مزامنة جداول الجراف مع دعم كامل لحقول التدقيق والحذف المنطقي
-- =============================================
CREATE TRIGGER dbo.trg_Sync_Geo_admin_unitsGraph_Advanced
   ON  dbo.geo_admin_units
   AFTER INSERT, DELETE, UPDATE
AS 
BEGIN
    SET NOCOUNT ON;
    IF TRIGGER_NESTLEVEL() > 1 RETURN;

    -- 1. معالجة عمليات الحذف الفيزيائي (Physical DELETE)
    IF EXISTS (SELECT * FROM deleted) AND NOT EXISTS (SELECT * FROM inserted)
    BEGIN
        DELETE FROM dbo.tge_geo_edges 
        WHERE $from_id IN (SELECT $node_id FROM dbo.tgn_geo_nodes WHERE admin_unit_id IN (SELECT id FROM deleted))
           OR $to_id IN (SELECT $node_id FROM dbo.tgn_geo_nodes WHERE admin_unit_id IN (SELECT id FROM deleted));

        DELETE FROM dbo.tgn_geo_nodes WHERE admin_unit_id IN (SELECT id FROM deleted);
    END

    -- 2. معالجة عمليات الإضافة (INSERT)
    IF EXISTS (SELECT * FROM inserted) AND NOT EXISTS (SELECT * FROM deleted)
    BEGIN
        -- إضافة العقدة مع حقول الإنشاء والسياق
        INSERT INTO dbo.tgn_geo_nodes (
            admin_unit_id, parent_id, country_id, unit_code, name, name_en, admin_type_ar, admin_type_en, admin_level,
            is_active, created_at, created_by, updated_at, updated_by, is_deleted, work_context_by
        )
        SELECT id, parent_id, country_id, unit_code, name, name_en, admin_type_ar, admin_type_en, admin_level,
               is_active, created_at, created_by, updated_at, updated_by, is_deleted, COALESCE(work_context_by, id)
        FROM inserted;

        -- إضافة العلاقة (Edge) مع توريث حقول الإنشاء من العقدة
        INSERT INTO dbo.tge_geo_edges ($from_id, $to_id, relation_type, work_context_by, created_at, created_by)
        SELECT p.$node_id, c.$node_id, 'ParentOf', COALESCE(c.work_context_by, c.admin_unit_id), SYSUTCDATETIME(), c.created_by
        FROM dbo.tgn_geo_nodes p
        JOIN dbo.tgn_geo_nodes c ON p.admin_unit_id = c.parent_id
        WHERE c.admin_unit_id IN (SELECT id FROM inserted)
          AND c.parent_id IS NOT NULL
          AND ISNULL(c.is_deleted, 0) = 0 AND ISNULL(c.is_active, 1) = 1
          AND ISNULL(p.is_deleted, 0) = 0 AND ISNULL(p.is_active, 1) = 1;
    END

    -- 3. معالجة عمليات التحديث والحذف المنطقي (UPDATE & Logical Delete)
    IF EXISTS (SELECT * FROM inserted) AND EXISTS (SELECT * FROM deleted)
    BEGIN
        DECLARE @affected TABLE (id INT NOT NULL PRIMARY KEY);
        INSERT INTO @affected (id) SELECT DISTINCT id FROM inserted;

        -- تحديث بيانات العقدة وحقول التعديل والحذف المنطقي
        UPDATE n
        SET n.parent_id = i.parent_id,
            n.country_id = i.country_id,
            n.unit_code = i.unit_code,
            n.name = i.name,
            n.name_en = i.name_en,
            n.admin_type_ar = i.admin_type_ar,
            n.admin_type_en = i.admin_type_en,
            n.admin_level = i.admin_level,
            n.is_active = i.is_active,
            n.created_at = COALESCE(n.created_at, i.created_at),
            n.created_by = COALESCE(n.created_by, i.created_by),
            n.updated_at = i.updated_at,
            n.updated_by = i.updated_by,
            n.is_deleted = i.is_deleted,
            n.work_context_by = COALESCE(i.work_context_by, i.id)
        FROM dbo.tgn_geo_nodes n
        JOIN inserted i ON n.admin_unit_id = i.id;

        -- معالجة تغيير هيكلية العلاقة عند تحديث parent_id
        IF UPDATE(parent_id) OR UPDATE(is_deleted) OR UPDATE(is_active)
        BEGIN
            -- حذف العلاقات القديمة للعقد المحدثة
            DELETE FROM dbo.tge_geo_edges 
            WHERE $to_id IN (SELECT $node_id FROM dbo.tgn_geo_nodes WHERE admin_unit_id IN (SELECT id FROM @affected));

            -- إعادة إنشاء العلاقات بناءً على الأب الجديد مع حقول التدقيق
            INSERT INTO dbo.tge_geo_edges ($from_id, $to_id, relation_type, work_context_by, created_at, created_by)
            SELECT p.$node_id, c.$node_id, 'ParentOf', COALESCE(c.work_context_by, c.admin_unit_id), SYSUTCDATETIME(), c.created_by
            FROM dbo.tgn_geo_nodes p
            JOIN dbo.tgn_geo_nodes c ON p.admin_unit_id = c.parent_id
            WHERE c.admin_unit_id IN (SELECT id FROM @affected) 
              AND c.parent_id IS NOT NULL 
              AND ISNULL(c.is_deleted, 0) = 0 AND ISNULL(c.is_active, 1) = 1
              AND ISNULL(p.is_deleted, 0) = 0 AND ISNULL(p.is_active, 1) = 1;
        END
    END
END
GO
