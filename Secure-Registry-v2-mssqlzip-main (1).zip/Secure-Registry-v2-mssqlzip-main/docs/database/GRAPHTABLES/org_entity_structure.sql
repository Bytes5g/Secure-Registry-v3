
  -- 1. إنشاء جدول العقد للهيكل التنظيمي
IF OBJECT_ID('dbo.tgn_org_entity_structure_nodes', 'U') IS NOT NULL
    DROP TABLE dbo.tgn_org_entity_structure_nodes;
GO

CREATE TABLE dbo.tgn_org_entity_structure_nodes
(
    entity_id INT NOT NULL,       -- id من جدول org_entity_structure
    parent_id INT NULL,
    org_id INT NULL,
    name NVARCHAR(300) NULL,
    code NVARCHAR(150) NULL,
    structure_id INT NULL,
    is_active BIT NULL,
    order_index INT NULL,
    level INT NULL,
    
    -- حقول التدقيق (تأكد من وجودها في الجدول الأصلي)
    created_at DATETIME NULL,
    created_by INT NULL,
    updated_at DATETIME NULL,
    updated_by INT NULL,
    is_deleted BIT NULL,
    work_context_by INT NOT NULL,

    INDEX ix_org_graphid UNIQUE ($node_id)
)
AS NODE;
GO

ALTER TABLE dbo.tgn_org_entity_structure_nodes
ADD CONSTRAINT FK_tgn_org_entity_structure_nodes_work_context_by
FOREIGN KEY (work_context_by) REFERENCES dbo.org_branch_nodes(id);
GO

-- 2. إنشاء جدول الحواف (العلاقات التنظيمية)
IF OBJECT_ID('dbo.tge_org_entity_structure_edges', 'U') IS NOT NULL
    DROP TABLE dbo.tge_org_entity_structure_edges;
GO

CREATE TABLE dbo.tge_org_entity_structure_edges
(
    relation_type NVARCHAR(50) NOT NULL DEFAULT 'ReportsTo',
    
    work_context_by INT NOT NULL,
    created_at DATETIME NULL,
    created_by INT NULL,

    INDEX ix_org_edgeid UNIQUE ($edge_id),
    INDEX ix_org_fromid ($from_id, $to_id),
    INDEX ix_org_toid ($to_id, $from_id)
)
AS EDGE;
GO

-- تعبئة العقد
INSERT INTO dbo.tgn_org_entity_structure_nodes (
  entity_id, parent_id, org_id, name, code, structure_id, is_active, order_index, level,
  created_at, created_by, updated_at, updated_by, is_deleted, work_context_by
)
SELECT
  id, parent_id, org_id, name, code, structure_id, is_active, order_index, level,
  created_at, created_by, updated_at, updated_by, is_deleted, COALESCE(work_context_by, id)
FROM dbo.org_entity_structure;

-- إنشاء العلاقات (الحواف)
INSERT INTO dbo.tge_org_entity_structure_edges ($from_id, $to_id, relation_type, work_context_by, created_at, created_by)
SELECT p.$node_id, c.$node_id, 'ReportsTo', COALESCE(c.work_context_by, c.entity_id), GETDATE(), c.created_by
FROM dbo.tgn_org_entity_structure_nodes AS p
INNER JOIN dbo.tgn_org_entity_structure_nodes AS c ON p.entity_id = c.parent_id;

-- الفهارس لتحسين الأداء
CREATE INDEX ix_org_nodes_entity_id ON tgn_org_entity_structure_nodes(entity_id);
CREATE INDEX ix_org_nodes_parent_id ON tgn_org_entity_structure_nodes(parent_id);

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER TRIGGER dbo.trg_Sync_Org_Entity_StructureGraph_Advanced
   ON  dbo.org_entity_structure
   AFTER INSERT, DELETE, UPDATE
AS 
BEGIN
    SET NOCOUNT ON;
    IF TRIGGER_NESTLEVEL() > 1 RETURN;

    -- 1. الحذف الفيزيائي
    IF EXISTS (SELECT * FROM deleted) AND NOT EXISTS (SELECT * FROM inserted)
    BEGIN
        DELETE FROM dbo.tge_org_entity_structure_edges 
        WHERE $from_id IN (SELECT $node_id FROM dbo.tgn_org_entity_structure_nodes WHERE entity_id IN (SELECT id FROM deleted))
           OR $to_id IN (SELECT $node_id FROM dbo.tgn_org_entity_structure_nodes WHERE entity_id IN (SELECT id FROM deleted));

        DELETE FROM dbo.tgn_org_entity_structure_nodes WHERE entity_id IN (SELECT id FROM deleted);
    END

    -- 2. الإضافة (INSERT)
    IF EXISTS (SELECT * FROM inserted) AND NOT EXISTS (SELECT * FROM deleted)
    BEGIN
        INSERT INTO dbo.tgn_org_entity_structure_nodes (
          entity_id, parent_id, org_id, name, code, structure_id, is_active, order_index, level,
          created_at, created_by, updated_at, updated_by, is_deleted, work_context_by
        )
        SELECT
          id, parent_id, org_id, name, code, structure_id, is_active, order_index, level,
          created_at, created_by, updated_at, updated_by, is_deleted, COALESCE(work_context_by, id)
        FROM inserted;

        INSERT INTO dbo.tge_org_entity_structure_edges ($from_id, $to_id, relation_type, work_context_by, created_at, created_by)
        SELECT p.$node_id, c.$node_id, 'ReportsTo', COALESCE(c.work_context_by, c.entity_id), GETDATE(), c.created_by
        FROM dbo.tgn_org_entity_structure_nodes p
        JOIN dbo.tgn_org_entity_structure_nodes c ON p.entity_id = c.parent_id
        WHERE c.entity_id IN (SELECT id FROM inserted)
          AND c.parent_id IS NOT NULL
          AND ISNULL(c.is_deleted, 0) = 0 AND ISNULL(c.is_active, 1) = 1
          AND ISNULL(p.is_deleted, 0) = 0 AND ISNULL(p.is_active, 1) = 1;
    END

    -- 3. التحديث والحذف المنطقي (UPDATE)
    IF EXISTS (SELECT * FROM inserted) AND EXISTS (SELECT * FROM deleted)
    BEGIN
        DECLARE @affected TABLE (id INT NOT NULL PRIMARY KEY);
        INSERT INTO @affected (id) SELECT DISTINCT id FROM inserted;

        UPDATE n
        SET n.parent_id = i.parent_id,
            n.org_id = i.org_id,
            n.name = i.name,
            n.code = i.code,
            n.structure_id = i.structure_id,
            n.is_active = i.is_active,
            n.order_index = i.order_index,
            n.level = i.level,
            n.created_at = COALESCE(n.created_at, i.created_at),
            n.created_by = COALESCE(n.created_by, i.created_by),
            n.updated_at = i.updated_at,
            n.updated_by = i.updated_by,
            n.is_deleted = i.is_deleted,
            n.work_context_by = COALESCE(i.work_context_by, i.id)
        FROM dbo.tgn_org_entity_structure_nodes n
        JOIN inserted i ON n.entity_id = i.id;

        IF UPDATE(parent_id) OR UPDATE(is_deleted) OR UPDATE(is_active)
        BEGIN
            DELETE FROM dbo.tge_org_entity_structure_edges 
            WHERE $to_id IN (SELECT $node_id FROM dbo.tgn_org_entity_structure_nodes WHERE entity_id IN (SELECT id FROM @affected));

            INSERT INTO dbo.tge_org_entity_structure_edges ($from_id, $to_id, relation_type, work_context_by, created_at, created_by)
            SELECT p.$node_id, c.$node_id, 'ReportsTo', COALESCE(c.work_context_by, c.entity_id), GETDATE(), c.created_by
            FROM dbo.tgn_org_entity_structure_nodes p
            JOIN dbo.tgn_org_entity_structure_nodes c ON p.entity_id = c.parent_id
            WHERE c.entity_id IN (SELECT id FROM @affected)
              AND c.parent_id IS NOT NULL
              AND ISNULL(c.is_deleted, 0) = 0 AND ISNULL(c.is_active, 1) = 1
              AND ISNULL(p.is_deleted, 0) = 0 AND ISNULL(p.is_active, 1) = 1;
        END
    END
END
GO
