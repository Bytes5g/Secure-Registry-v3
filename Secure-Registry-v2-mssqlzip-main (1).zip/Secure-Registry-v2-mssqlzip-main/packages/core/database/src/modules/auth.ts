import { createRequest } from "../config/connection";
import { runQueryOne } from "./helpers";

export interface AuthUserRecord {
  id: number;
  firstName: string | null;
  lastName: string | null;
  email: string | null;
  password: string | null;
  status: string | null;
  roleId: number | null;
  lastAccess: string | null;
}

export interface AuthRoleRecord {
  id: number;
  name: string;
  parent: number | null;
}

function mapUser(row: Record<string, unknown>): AuthUserRecord {
  return {
    id: Number(row.id),
    firstName: row.first_name == null ? null : String(row.first_name),
    lastName: row.last_name == null ? null : String(row.last_name),
    email: row.email == null ? null : String(row.email),
    password: row.password == null ? null : String(row.password),
    status: row.status == null ? null : String(row.status),
    roleId: row.role == null ? null : Number(row.role),
    lastAccess: row.last_access == null ? null : String(row.last_access),
  };
}

function mapRole(row: Record<string, unknown>): AuthRoleRecord {
  return {
    id: Number(row.id),
    name: String(row.name || ""),
    parent: row.parent == null ? null : Number(row.parent),
  };
}

export class AuthModule {
  async findUserByLogin(login: string): Promise<AuthUserRecord | undefined> {
    const row = await runQueryOne<Record<string, unknown>>(
      `SELECT TOP 1 *
       FROM [users]
       WHERE LOWER([email]) = LOWER(@login)
          OR LOWER(
            CASE
              WHEN CHARINDEX('@', [email]) > 0 THEN LEFT([email], CHARINDEX('@', [email]) - 1)
              ELSE [email]
            END
          ) = LOWER(@login)`,
      { login },
    );

    return row ? mapUser(row) : undefined;
  }

  async getRoleById(id: number): Promise<AuthRoleRecord | undefined> {
    const row = await runQueryOne<Record<string, unknown>>(
      "SELECT TOP 1 * FROM [roles] WHERE id = @id",
      { id },
    );

    return row ? mapRole(row) : undefined;
  }

  async updateLastAccess(id: number): Promise<void> {
    const request = await createRequest();
    request.input("id", id);
    await request.query(
      "UPDATE [users] SET [last_access] = SYSUTCDATETIME() WHERE id = @id",
    );
  }
}

export const authModule = new AuthModule();
