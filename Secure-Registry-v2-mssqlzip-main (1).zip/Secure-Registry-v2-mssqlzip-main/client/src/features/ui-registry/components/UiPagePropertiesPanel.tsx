import { useMemo } from "react";
import {
  Button,
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  Checkbox,
  Input,
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@secure-registry/components-ui";

type LookupTypeOption = { id: number; nameAr: string };

type ColumnLike = {
  fieldCode: string;
  nameAr: string;
  columnType: string;
  isVisible: boolean;
  isSortable?: boolean;
  isFilterable?: boolean;
  width?: string;
  lookupTypeId?: number;
};

type FieldLike = {
  fieldCode: string;
  nameAr: string;
  fieldType: string;
  isRequired: boolean;
  isVisible?: boolean;
  gridCols?: number;
  lookupTypeId?: number;
  placeholder?: string;
  isEditable?: boolean;
  config?: Record<string, any>;
};

function asNumberOrUndefined(value: string): number | undefined {
  const raw = String(value ?? "").trim();
  if (!raw) return undefined;
  const n = Number(raw);
  return Number.isFinite(n) ? n : undefined;
}

function parseScalar(value: string): any {
  const raw = String(value ?? "").trim();
  if (!raw) return "";
  if (raw === "true") return true;
  if (raw === "false") return false;
  if (/^-?\d+(\.\d+)?$/.test(raw)) return Number(raw);
  return raw;
}

function toRows(obj: Record<string, any> | undefined | null): Array<{ key: string; value: string }> {
  const o = obj && typeof obj === "object" ? obj : {};
  return Object.entries(o).map(([k, v]) => ({ key: String(k), value: v == null ? "" : String(v) }));
}

function rowsToObject(rows: Array<{ key: string; value: string }>): Record<string, any> {
  const out: Record<string, any> = {};
  for (const r of rows) {
    const k = String(r.key ?? "").trim();
    if (!k) continue;
    const v = String(r.value ?? "").trim();
    if (!v) continue;
    out[k] = parseScalar(v);
  }
  return out;
}

export function UiPagePropertiesPanel(props: {
  selected:
    | { kind: "column"; index: number; value: ColumnLike }
    | { kind: "field"; index: number; value: FieldLike }
    | null;
  lookupTypeOptions: LookupTypeOption[];
  onUpdateSelected: (patch: Partial<ColumnLike> | Partial<FieldLike>) => void;
  onClearSelection: () => void;
}) {
  const lookupTypeItems = useMemo(
    () =>
      (props.lookupTypeOptions ?? [])
        .map((t) => ({ value: String(t.id), label: `${t.id} - ${t.nameAr}` }))
        .sort((a, b) => a.label.localeCompare(b.label, "ar")),
    [props.lookupTypeOptions],
  );

  if (!props.selected) {
    return (
      <Card className="h-full">
        <CardHeader>
          <CardTitle>الخصائص</CardTitle>
        </CardHeader>
        <CardContent className="text-sm text-muted-foreground">اختر عموداً أو حقلاً من القائمة لعرض خصائصه</CardContent>
      </Card>
    );
  }

  const isColumn = props.selected.kind === "column";
  const value: any = props.selected.value as any;
  const lookupValue = value.lookupTypeId == null ? "none" : String(value.lookupTypeId);
  const showLookup = isColumn ? String(value.columnType ?? "") === "select" : String(value.fieldType ?? "") === "select";

  const fieldConfig = !isColumn && value?.config && typeof value.config === "object" ? (value.config as Record<string, any>) : {};
  const remoteOptionsConfig = !isColumn ? (fieldConfig?.remoteOptions ?? null) : null;
  const variants: any[] = Array.isArray(remoteOptionsConfig?.variants) ? remoteOptionsConfig.variants : [];
  const v0 = variants[0] && typeof variants[0] === "object" ? variants[0] : null;
  const v0QueryRows = toRows(v0?.query);
  const v0OnSelectSetRows = toRows(v0?.onSelectSet);

  const updateFieldConfig = (patch: Record<string, any>) => {
    const current = fieldConfig && typeof fieldConfig === "object" ? fieldConfig : {};
    props.onUpdateSelected({ config: { ...current, ...patch } } as any);
  };

  const updateRemoteVariant0 = (patch: Record<string, any>) => {
    const current = fieldConfig && typeof fieldConfig === "object" ? fieldConfig : {};
    const ro = current.remoteOptions && typeof current.remoteOptions === "object" ? current.remoteOptions : { variants: [] };
    const currentVariants = Array.isArray((ro as any).variants) ? (ro as any).variants : [];
    const baseV0 = currentVariants[0] && typeof currentVariants[0] === "object" ? currentVariants[0] : {};
    const nextV0 = { ...baseV0, ...patch };
    const nextVariants = [nextV0, ...currentVariants.slice(1)];
    props.onUpdateSelected({ config: { ...current, remoteOptions: { ...ro, variants: nextVariants } } } as any);
  };

  const setFieldConfigSection = (section: string) => {
    const current = fieldConfig && typeof fieldConfig === "object" ? fieldConfig : {};
    if (!section) {
      const next = { ...current };
      delete (next as any).section;
      props.onUpdateSelected({ config: next } as any);
      return;
    }
    props.onUpdateSelected({ config: { ...current, section } } as any);
  };

  return (
    <Card className="h-full">
      <CardHeader className="flex-row items-center justify-between">
        <CardTitle>الخصائص</CardTitle>
        <Button type="button" variant="outline" size="sm" onClick={props.onClearSelection}>
          إلغاء التحديد
        </Button>
      </CardHeader>
      <CardContent className="space-y-4" dir="rtl">
        <div className="text-sm text-muted-foreground">
          {isColumn ? "عمود" : "حقل"} #{props.selected.index + 1}
        </div>

        <Tabs defaultValue="basic" dir="rtl">
          <TabsList className="w-full justify-start overflow-x-auto">
            <TabsTrigger value="basic">الأساسيات</TabsTrigger>
            <TabsTrigger value="styles">الأنماط</TabsTrigger>
            {!isColumn ? <TabsTrigger value="data">المصدر</TabsTrigger> : null}
          </TabsList>

          <TabsContent value="basic" className="mt-4 space-y-4">
            <div className="grid gap-3">
              <div className="space-y-1">
                <div className="text-xs text-muted-foreground">fieldCode</div>
                <Input value={String(value.fieldCode ?? "")} onChange={(e) => props.onUpdateSelected({ fieldCode: e.target.value } as any)} />
              </div>

              <div className="space-y-1">
                <div className="text-xs text-muted-foreground">الاسم</div>
                <Input value={String(value.nameAr ?? "")} onChange={(e) => props.onUpdateSelected({ nameAr: e.target.value } as any)} />
              </div>

              <div className="space-y-1">
                <div className="text-xs text-muted-foreground">{isColumn ? "النوع" : "نوع الحقل"}</div>
                <Select
                  value={String(isColumn ? value.columnType ?? "text" : value.fieldType ?? "text")}
                  onValueChange={(v) => props.onUpdateSelected((isColumn ? { columnType: v } : { fieldType: v }) as any)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="اختر..." />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="text">نص</SelectItem>
                    {!isColumn ? <SelectItem value="textarea">نص متعدد</SelectItem> : null}
                    <SelectItem value="number">رقم</SelectItem>
                    <SelectItem value="boolean">نعم/لا</SelectItem>
                    <SelectItem value="select">اختيار</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-1">
                <div className="text-xs text-muted-foreground">Lookup</div>
                <Select
                  value={lookupValue}
                  onValueChange={(v) => props.onUpdateSelected({ lookupTypeId: v === "none" ? undefined : Number(v) } as any)}
                  disabled={!showLookup}
                >
                  <SelectTrigger>
                    <SelectValue placeholder={showLookup ? "اختر..." : "غير متاح"} />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">بدون</SelectItem>
                    {lookupTypeItems.map((opt) => (
                      <SelectItem key={opt.value} value={opt.value}>
                        {opt.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {isColumn ? (
                <div className="space-y-1">
                  <div className="text-xs text-muted-foreground">العرض</div>
                  <Input
                    value={String(value.width ?? "")}
                    onChange={(e) => props.onUpdateSelected({ width: e.target.value || undefined } as any)}
                    placeholder="120px"
                  />
                </div>
              ) : (
                <>
                  <div className="space-y-1">
                    <div className="text-xs text-muted-foreground">gridCols</div>
                    <Input
                      value={value.gridCols == null ? "" : String(value.gridCols)}
                      onChange={(e) => props.onUpdateSelected({ gridCols: asNumberOrUndefined(e.target.value) } as any)}
                      placeholder="6"
                    />
                  </div>
                  <div className="space-y-1">
                    <div className="text-xs text-muted-foreground">placeholder</div>
                    <Input
                      value={String(value.placeholder ?? "")}
                      onChange={(e) => props.onUpdateSelected({ placeholder: e.target.value || undefined } as any)}
                      placeholder="مثال..."
                    />
                  </div>
                </>
              )}
            </div>

            <div className="flex flex-wrap gap-6">
              <label className="flex items-center gap-2 text-sm">
                <Checkbox
                  checked={Boolean(isColumn ? value.isVisible : value.isVisible !== false)}
                  onCheckedChange={(v) => props.onUpdateSelected({ isVisible: Boolean(v) } as any)}
                />
                ظاهر
              </label>

              {isColumn ? (
                <>
                  <label className="flex items-center gap-2 text-sm">
                    <Checkbox checked={Boolean(value.isSortable)} onCheckedChange={(v) => props.onUpdateSelected({ isSortable: Boolean(v) } as any)} />
                    قابل للفرز
                  </label>
                  <label className="flex items-center gap-2 text-sm">
                    <Checkbox checked={Boolean(value.isFilterable)} onCheckedChange={(v) => props.onUpdateSelected({ isFilterable: Boolean(v) } as any)} />
                    قابل للتصفية
                  </label>
                </>
              ) : (
                <>
                  <label className="flex items-center gap-2 text-sm">
                    <Checkbox checked={Boolean(value.isRequired)} onCheckedChange={(v) => props.onUpdateSelected({ isRequired: Boolean(v) } as any)} />
                    مطلوب
                  </label>
                  <label className="flex items-center gap-2 text-sm">
                    <Checkbox checked={value.isEditable !== false} onCheckedChange={(v) => props.onUpdateSelected({ isEditable: Boolean(v) } as any)} />
                    قابل للتعديل
                  </label>
                </>
              )}
            </div>
          </TabsContent>

          <TabsContent value="styles" className="mt-4 space-y-4">
            {isColumn ? (
              <div className="space-y-2">
                <div className="text-sm font-medium">عرض العمود</div>
                <div className="flex flex-wrap gap-2">
                  <Button type="button" variant="outline" onClick={() => props.onUpdateSelected({ width: "80px" } as any)}>
                    ضيق
                  </Button>
                  <Button type="button" variant="outline" onClick={() => props.onUpdateSelected({ width: "120px" } as any)}>
                    متوسط
                  </Button>
                  <Button type="button" variant="outline" onClick={() => props.onUpdateSelected({ width: "180px" } as any)}>
                    عريض
                  </Button>
                  <Button type="button" variant="outline" onClick={() => props.onUpdateSelected({ width: "minmax(140px, 1fr)" } as any)}>
                    مرن
                  </Button>
                  <Button type="button" variant="outline" onClick={() => props.onUpdateSelected({ width: undefined } as any)}>
                    افتراضي
                  </Button>
                </div>
              </div>
            ) : (
              <>
                <div className="space-y-2">
                  <div className="text-sm font-medium">تخطيط الحقل (gridCols)</div>
                  <div className="flex flex-wrap gap-2">
                    <Button type="button" variant="outline" onClick={() => props.onUpdateSelected({ gridCols: 4 } as any)}>
                      3 في الصف
                    </Button>
                    <Button type="button" variant="outline" onClick={() => props.onUpdateSelected({ gridCols: 6 } as any)}>
                      2 في الصف
                    </Button>
                    <Button type="button" variant="outline" onClick={() => props.onUpdateSelected({ gridCols: 12 } as any)}>
                      1 في الصف
                    </Button>
                  </div>
                </div>
                <div className="space-y-2">
                  <div className="text-sm font-medium">تبويب الحقل</div>
                  <Select
                    value={String(fieldConfig?.section ?? "basic")}
                    onValueChange={(v) => setFieldConfigSection(v === "basic" ? "" : v)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="اختر..." />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="basic">بحث</SelectItem>
                      <SelectItem value="advanced">خيارات متقدمة</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </>
            )}
          </TabsContent>

          {!isColumn ? (
            <TabsContent value="data" className="mt-4 space-y-4">
              <label className="flex items-center gap-2 text-sm">
                <Checkbox
                  checked={Boolean(remoteOptionsConfig)}
                  onCheckedChange={(v) => {
                    if (Boolean(v)) {
                      updateFieldConfig({
                        remoteOptions: {
                          variants: [
                            {
                              path: "/api/",
                              response: "paged",
                              valueKey: "id",
                              labelKey: "name",
                              query: { page: 1, limit: 200, isDeleted: 0, isActive: 1 },
                            },
                          ],
                        },
                      });
                      return;
                    }
                    const next = { ...(fieldConfig as any) };
                    delete next.remoteOptions;
                    props.onUpdateSelected({ config: next } as any);
                  }}
                />
                تفعيل Remote Options
              </label>

              {remoteOptionsConfig ? (
                <div className="space-y-4">
                  <div className="grid gap-3">
                    <div className="space-y-1">
                      <div className="text-xs text-muted-foreground">path</div>
                      <Input value={String(v0?.path ?? "")} onChange={(e) => updateRemoteVariant0({ path: e.target.value })} placeholder="/api/..." />
                    </div>
                    <div className="space-y-1">
                      <div className="text-xs text-muted-foreground">response</div>
                      <Select value={String(v0?.response ?? "paged")} onValueChange={(vv) => updateRemoteVariant0({ response: vv })}>
                        <SelectTrigger>
                          <SelectValue placeholder="اختر..." />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="paged">paged</SelectItem>
                          <SelectItem value="array">array</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-1">
                      <div className="text-xs text-muted-foreground">valueKey</div>
                      <Input value={String(v0?.valueKey ?? "id")} onChange={(e) => updateRemoteVariant0({ valueKey: e.target.value })} placeholder="id" />
                    </div>
                    <div className="space-y-1">
                      <div className="text-xs text-muted-foreground">labelKey</div>
                      <Input value={String(v0?.labelKey ?? "name")} onChange={(e) => updateRemoteVariant0({ labelKey: e.target.value })} placeholder="name" />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="text-sm font-medium">query</div>
                    <div className="space-y-2">
                      {v0QueryRows.map((row, idx) => (
                        <div key={`${row.key}-${idx}`} className="grid grid-cols-5 gap-2 items-center">
                          <Input
                            value={row.key}
                            onChange={(e) => {
                              const next = [...v0QueryRows];
                              next[idx] = { ...next[idx], key: e.target.value };
                              updateRemoteVariant0({ query: rowsToObject(next) });
                            }}
                            placeholder="param"
                          />
                          <div className="col-span-3">
                            <Input
                              value={row.value}
                              onChange={(e) => {
                                const next = [...v0QueryRows];
                                next[idx] = { ...next[idx], value: e.target.value };
                                updateRemoteVariant0({ query: rowsToObject(next) });
                              }}
                              placeholder="value (مثال: 1 أو {orgId})"
                            />
                          </div>
                          <Button
                            type="button"
                            variant="outline"
                            onClick={() => {
                              const next = v0QueryRows.filter((_, i) => i !== idx);
                              updateRemoteVariant0({ query: rowsToObject(next) });
                            }}
                          >
                            حذف
                          </Button>
                        </div>
                      ))}
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => {
                          const next = [...v0QueryRows, { key: "", value: "" }];
                          updateRemoteVariant0({ query: rowsToObject(next) });
                        }}
                      >
                        إضافة
                      </Button>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="text-sm font-medium">onSelectSet</div>
                    <div className="space-y-2">
                      {v0OnSelectSetRows.map((row, idx) => (
                        <div key={`${row.key}-${idx}`} className="grid grid-cols-5 gap-2 items-center">
                          <Input
                            value={row.key}
                            onChange={(e) => {
                              const next = [...v0OnSelectSetRows];
                              next[idx] = { ...next[idx], key: e.target.value };
                              updateRemoteVariant0({ onSelectSet: rowsToObject(next) });
                            }}
                            placeholder="targetField"
                          />
                          <div className="col-span-3">
                            <Input
                              value={row.value}
                              onChange={(e) => {
                                const next = [...v0OnSelectSetRows];
                                next[idx] = { ...next[idx], value: e.target.value };
                                updateRemoteVariant0({ onSelectSet: rowsToObject(next) });
                              }}
                              placeholder="recordKey"
                            />
                          </div>
                          <Button
                            type="button"
                            variant="outline"
                            onClick={() => {
                              const next = v0OnSelectSetRows.filter((_, i) => i !== idx);
                              updateRemoteVariant0({ onSelectSet: rowsToObject(next) });
                            }}
                          >
                            حذف
                          </Button>
                        </div>
                      ))}
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => {
                          const next = [...v0OnSelectSetRows, { key: "", value: "" }];
                          updateRemoteVariant0({ onSelectSet: rowsToObject(next) });
                        }}
                      >
                        إضافة
                      </Button>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="text-sm text-muted-foreground">فعّل Remote Options أولاً</div>
              )}
            </TabsContent>
          ) : null}
        </Tabs>
      </CardContent>
    </Card>
  );
}
