import { useMemo, useState } from "react";
import {
  Button,
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
  EntityContentCard,
  EntityProfileHeader,
  EntityRelationsTabs,
  Sheet,
  SheetContent,
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
  UiPageColumnsEditor,
  UiPageFormFieldsEditor,
} from "@secure-registry/components-ui";
import { useUnifiedLookups } from "@/hooks/useUnifiedLookups";
import { MoreHorizontal, Settings2 } from "lucide-react";
import { Panel, PanelGroup, PanelResizeHandle } from "react-resizable-panels";
import { UiPageOverridesSelector } from "./components/UiPageOverridesSelector";
import { UiPageConfigPreview } from "./components/UiPageConfigPreview";
import { useUiPageOverridesEditor } from "./hooks/useUiPageOverridesEditor";
import { UiPagePropertiesPanel } from "./components/UiPagePropertiesPanel";

export default function UiPageOverridesAdminPage(props?: {
  initialPageCode?: string;
  initialEntityType?: string;
  autoLoad?: boolean;
  onBack?: () => void;
}) {
  const { lookups: lookupTypes } = useUnifiedLookups();
  const [activeTab, setActiveTab] = useState("edit");
  const [selectedColumnIndex, setSelectedColumnIndex] = useState<number | null>(null);
  const [selectedFieldIndex, setSelectedFieldIndex] = useState<number | null>(null);
  const [isPropsOpen, setIsPropsOpen] = useState(false);

  const editor = useUiPageOverridesEditor({
    initialPageCode: props?.initialPageCode,
    initialEntityType: props?.initialEntityType,
    autoLoad: props?.autoLoad,
  });
  const lookupTypeOptions = useMemo(
    () =>
      (Array.isArray(lookupTypes) ? lookupTypes : [])
        .map((t: any) => ({ id: Number(t.id), nameAr: String(t.nameAr ?? t.name_ar ?? "") }))
        .filter((t) => Number.isFinite(t.id)),
    [lookupTypes],
  );

  return (
    <div className="p-6 space-y-4" dir="rtl">
      <EntityProfileHeader
        title="UI Page Overrides"
        subtitle="تهيئة الأعمدة وحقول النماذج مع معاينة مباشرة"
        status={{
          label: editor.isBusy ? "جاري التنفيذ" : editor.isDirty ? "تعديلات غير محفوظة" : editor.isLoaded ? "جاهز" : "غير محمّل",
          variant: editor.isBusy ? "outline" : editor.isDirty ? "destructive" : "secondary",
        }}
        icon={<Settings2 className="h-5 w-5" />}
        showCoverPlaceholder={false}
        coverImageUrl={null}
        avatarImageUrl={null}
        meta={[
          { label: "pageCode:", value: editor.pageCode || "—" },
          { label: "entityType:", value: editor.entityType || "—" },
          { label: "DB override:", value: editor.loadedOverride ? "نعم" : "لا" },
        ]}
        actions={
          <div className="flex flex-wrap gap-2">
            {props?.onBack ? (
              <Button type="button" variant="outline" onClick={props.onBack} disabled={editor.isBusy}>
                رجوع
              </Button>
            ) : null}
            <Button type="button" onClick={editor.loadAll} disabled={!editor.canLoad || editor.isBusy}>
              تحميل
            </Button>
            <Button type="button" variant="outline" onClick={editor.sanitizeDraft} disabled={!editor.isLoaded || editor.isBusy}>
              تنظيف تلقائي
            </Button>
            <Button type="button" variant="outline" onClick={editor.resetToBase} disabled={!editor.canLoad || !editor.isLoaded || editor.isBusy}>
              إعادة ضبط
            </Button>
            <Button type="button" onClick={editor.save} disabled={!editor.canLoad || !editor.isLoaded || editor.isBusy || !editor.isValid}>
              حفظ
            </Button>
            <Button type="button" variant="destructive" onClick={editor.clear} disabled={!editor.canLoad || editor.isBusy}>
              حذف override
            </Button>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button type="button" variant="outline" size="icon" disabled={!editor.canLoad || editor.isBusy}>
                  <MoreHorizontal className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onSelect={() => editor.loadOverrideOnly()}>تحميل override فقط</DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onSelect={() => editor.seed({ force: false, scope: "all" })} disabled={editor.isSeeding}>
                  توليد override
                </DropdownMenuItem>
                <DropdownMenuItem onSelect={() => editor.seed({ force: true, scope: "all" })} disabled={editor.isSeeding}>
                  إعادة توليد
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onSelect={() => editor.seed({ force: false, scope: "columns" })} disabled={editor.isSeeding}>
                  توليد الأعمدة
                </DropdownMenuItem>
                <DropdownMenuItem onSelect={() => editor.seed({ force: true, scope: "columns" })} disabled={editor.isSeeding}>
                  إعادة توليد الأعمدة
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onSelect={() => editor.seed({ force: false, scope: "formFields" })} disabled={editor.isSeeding}>
                  توليد الحقول
                </DropdownMenuItem>
                <DropdownMenuItem onSelect={() => editor.seed({ force: true, scope: "formFields" })} disabled={editor.isSeeding}>
                  إعادة توليد الحقول
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        }
      />

      <EntityContentCard contentClassName="p-6">
        <UiPageOverridesSelector
          pageCode={editor.pageCode}
          setPageCode={editor.setPageCode}
          entityType={editor.entityType}
          setEntityType={editor.setEntityType}
          canLoad={editor.canLoad}
          isBusy={editor.isBusy}
          onLoadAll={editor.loadAll}
          onLoadOverrideOnly={editor.loadOverrideOnly as any}
          onResetToBase={editor.resetToBase}
          onSave={editor.save}
          onClear={editor.clear}
          hasBaseConfig={editor.isLoaded}
          isValid={editor.isValid}
          validationErrors={editor.validationErrors as any}
          showActions={false}
        />

        <Sheet
          open={isPropsOpen}
          onOpenChange={(open) => {
            setIsPropsOpen(open);
            if (!open) {
              setSelectedColumnIndex(null);
              setSelectedFieldIndex(null);
            }
          }}
        >
          <SheetContent side="right" className="p-0">
            <div className="p-6">
              {editor.draft ? (
                <UiPagePropertiesPanel
                  selected={
                    selectedColumnIndex != null && (editor.draft.columns?.[selectedColumnIndex] as any)
                      ? { kind: "column", index: selectedColumnIndex, value: editor.draft.columns?.[selectedColumnIndex] as any }
                      : selectedFieldIndex != null && (editor.draft.formFields?.[selectedFieldIndex] as any)
                        ? { kind: "field", index: selectedFieldIndex, value: editor.draft.formFields?.[selectedFieldIndex] as any }
                        : null
                  }
                  lookupTypeOptions={lookupTypeOptions}
                  onUpdateSelected={(patch) => {
                    if (!editor.draft) return;
                    if (selectedColumnIndex != null) {
                      const cols = Array.isArray(editor.draft.columns) ? [...editor.draft.columns] : [];
                      cols[selectedColumnIndex] = { ...(cols[selectedColumnIndex] as any), ...(patch as any) };
                      editor.setDraft({ ...(editor.draft as any), columns: cols });
                      return;
                    }
                    if (selectedFieldIndex != null) {
                      const fields = Array.isArray(editor.draft.formFields) ? [...editor.draft.formFields] : [];
                      fields[selectedFieldIndex] = { ...(fields[selectedFieldIndex] as any), ...(patch as any) };
                      editor.setDraft({ ...(editor.draft as any), formFields: fields });
                    }
                  }}
                  onClearSelection={() => {
                    setSelectedColumnIndex(null);
                    setSelectedFieldIndex(null);
                    setIsPropsOpen(false);
                  }}
                />
              ) : (
                <div className="text-sm text-muted-foreground">قم بتحميل الصفحة أولاً</div>
              )}
            </div>
          </SheetContent>
        </Sheet>

        <EntityRelationsTabs
          tabs={[
            {
              value: "edit",
              label: "التهيئة",
              content: editor.draft ? (
                <PanelGroup direction="horizontal" className="w-full rounded-xl border">
                  <Panel defaultSize={40} minSize={28} className="p-4">
                    <Tabs defaultValue="columns" dir="rtl" className="flex-1">
                      <TabsList className="w-full justify-start overflow-x-auto">
                        <TabsTrigger value="columns">الأعمدة</TabsTrigger>
                        <TabsTrigger value="fields">الحقول</TabsTrigger>
                      </TabsList>
                      <TabsContent value="columns" className="mt-4">
                        <UiPageColumnsEditor
                          value={editor.draft.columns ?? []}
                          onChange={(next) => editor.setDraft({ ...(editor.draft as any), columns: next })}
                          lookupTypeOptions={lookupTypeOptions}
                          selectedIndex={selectedColumnIndex}
                          onSelectIndex={(idx) => {
                            setSelectedColumnIndex(idx);
                            setSelectedFieldIndex(null);
                            if (idx != null) setIsPropsOpen(true);
                          }}
                        />
                      </TabsContent>
                      <TabsContent value="fields" className="mt-4">
                        <UiPageFormFieldsEditor
                          value={editor.draft.formFields ?? []}
                          onChange={(next) => editor.setDraft({ ...(editor.draft as any), formFields: next })}
                          lookupTypeOptions={lookupTypeOptions}
                          selectedIndex={selectedFieldIndex}
                          onSelectIndex={(idx) => {
                            setSelectedFieldIndex(idx);
                            setSelectedColumnIndex(null);
                            if (idx != null) setIsPropsOpen(true);
                          }}
                        />
                      </TabsContent>
                    </Tabs>
                  </Panel>
                  <PanelResizeHandle className="w-2 bg-muted hover:bg-muted/70 transition-colors" />
                  <Panel defaultSize={40} minSize={25} className="p-4">
                    <UiPageConfigPreview
                      config={editor.draft}
                      lookupTypes={(Array.isArray(lookupTypes) ? lookupTypes : []) as any}
                      selectedColumnCode={
                        selectedColumnIndex != null ? String((editor.draft.columns?.[selectedColumnIndex] as any)?.fieldCode ?? "") : null
                      }
                      selectedFieldCode={
                        selectedFieldIndex != null ? String((editor.draft.formFields?.[selectedFieldIndex] as any)?.fieldCode ?? "") : null
                      }
                      onSelectColumn={(fieldCode) => {
                        const cols = Array.isArray(editor.draft?.columns) ? editor.draft!.columns : [];
                        const idx = cols.findIndex((c: any) => String(c?.fieldCode ?? "") === String(fieldCode));
                        if (idx >= 0) {
                          setSelectedColumnIndex(idx);
                          setSelectedFieldIndex(null);
                          setIsPropsOpen(true);
                        }
                      }}
                      onSelectField={(fieldCode) => {
                        const fields = Array.isArray(editor.draft?.formFields) ? editor.draft!.formFields : [];
                        const idx = fields.findIndex((f: any) => String(f?.fieldCode ?? "") === String(fieldCode));
                        if (idx >= 0) {
                          setSelectedFieldIndex(idx);
                          setSelectedColumnIndex(null);
                          setIsPropsOpen(true);
                        }
                      }}
                    />
                  </Panel>
                </PanelGroup>
              ) : (
                <div className="text-sm text-muted-foreground">قم بتحميل الصفحة أولاً</div>
              ),
            },
            {
              value: "preview",
              label: "المعاينة",
              content: editor.draft ? (
                <UiPageConfigPreview config={editor.draft} lookupTypes={(Array.isArray(lookupTypes) ? lookupTypes : []) as any} />
              ) : (
                <div className="text-sm text-muted-foreground">قم بتحميل الصفحة أولاً</div>
              ),
            },
          ]}
          value={activeTab}
          onValueChange={setActiveTab}
          direction="rtl"
          className="w-full"
          tabsListClassName="mt-4 mb-4 w-full overflow-x-auto"
        />
      </EntityContentCard>
    </div>
  );
}
