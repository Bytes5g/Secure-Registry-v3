import { createRequest } from "../config/connection";

export type SchemaDictionaryColumn = {
  databaseName: string;
  schemaName: string;
  objectName: string;
  formattedTableName: string | null;
  objectDescription: string | null;
  columnId: number | null;
  columnName: string;
  formattedName: string | null;
  uiColumnType: string | null;
  dataType: string;
  length: number | null;
  precision: number | null;
  scale: number | null;
  isNullable: boolean;
  isIdentity: boolean;
  isComputed: boolean;
  isPrimaryKey: boolean;
  primaryKeyOrdinal: number | null;
  isForeignKey: boolean;
  foreignKeyCount: number | null;
  foreignKeyName: string | null;
  referencedSchema: string | null;
  referencedObject: string | null;
  referencedColumn: string | null;
  outgoingReferenceRelationshipsJson: string | null;
  isReferencedByForeignKey: boolean;
  incomingReferenceCount: number | null;
  incomingReferenceRelationshipsJson: string | null;
  isUnique: boolean;
  isIndexed: boolean;
  defaultDefinition: string | null;
  columnDescription: string | null;
};

export async function getSchemaDictionaryColumns(input: {
  schemaName: string;
  objectName: string;
}): Promise<SchemaDictionaryColumn[]> {
  const request = await createRequest();
  request.input("schemaName", input.schemaName);
  request.input("objectName", input.objectName);

  const result = await request.query<{
    database_name: string;
    schema_name: string;
    object_name: string;
    formatted_table_name: string | null;
    object_description: string | null;
    column_id: number | null;
    column_name: string;
    formatted_name: string | null;
    ui_column_type: string | null;
    data_type: string;
    length: string | number | null;
    precision: string | number | null;
    scale: string | number | null;
    is_nullable: boolean;
    is_identity: boolean;
    is_computed: boolean;
    is_primary_key: boolean;
    primary_key_ordinal: string | number | null;
    is_foreign_key: boolean;
    foreign_key_count: string | number | null;
    foreign_key_name: string | null;
    referenced_schema: string | null;
    referenced_object: string | null;
    referenced_column: string | null;
    outgoing_reference_relationships_json: string | null;
    is_referenced_by_foreign_key: boolean;
    incoming_reference_count: string | number | null;
    incoming_reference_relationships_json: string | null;
    is_unique: boolean;
    is_indexed: boolean;
    default_definition: string | null;
    column_description: string | null;
  }>(
    `
      SELECT
        database_name,
        schema_name,
        object_name,
        formatted_table_name,
        object_description,
        column_id,
        column_name,
        formatted_name,
        ui_column_type,
        data_type,
        length,
        precision,
        scale,
        is_nullable,
        is_identity,
        is_computed,
        is_primary_key,
        primary_key_ordinal,
        is_foreign_key,
        foreign_key_count,
        foreign_key_name,
        referenced_schema,
        referenced_object,
        referenced_column,
        outgoing_reference_relationships_json,
        is_referenced_by_foreign_key,
        incoming_reference_count,
        incoming_reference_relationships_json,
        is_unique,
        is_indexed,
        default_definition,
        column_description
      FROM dbo.v_schema_dictionary_columns
      WHERE database_name = DB_NAME()
        AND schema_name = @schemaName
        AND object_name = @objectName
      ORDER BY column_id
    `,
  );

  return result.recordset.map((row) => ({
    databaseName: String(row.database_name),
    schemaName: String(row.schema_name),
    objectName: String(row.object_name),
    formattedTableName: row.formatted_table_name == null ? null : String(row.formatted_table_name),
    objectDescription: row.object_description == null ? null : String(row.object_description),
    columnId: row.column_id == null ? null : Number(row.column_id),
    columnName: String(row.column_name),
    formattedName: row.formatted_name == null ? null : String(row.formatted_name),
    uiColumnType: row.ui_column_type == null ? null : String(row.ui_column_type),
    dataType: String(row.data_type),
    length: row.length == null ? null : Number(row.length),
    precision: row.precision == null ? null : Number(row.precision),
    scale: row.scale == null ? null : Number(row.scale),
    isNullable: Boolean(row.is_nullable),
    isIdentity: Boolean(row.is_identity),
    isComputed: Boolean(row.is_computed),
    isPrimaryKey: Boolean(row.is_primary_key),
    primaryKeyOrdinal: row.primary_key_ordinal == null ? null : Number(row.primary_key_ordinal),
    isForeignKey: Boolean(row.is_foreign_key),
    foreignKeyCount: row.foreign_key_count == null ? null : Number(row.foreign_key_count),
    foreignKeyName: row.foreign_key_name == null ? null : String(row.foreign_key_name),
    referencedSchema: row.referenced_schema == null ? null : String(row.referenced_schema),
    referencedObject: row.referenced_object == null ? null : String(row.referenced_object),
    referencedColumn: row.referenced_column == null ? null : String(row.referenced_column),
    outgoingReferenceRelationshipsJson: row.outgoing_reference_relationships_json == null
      ? null
      : String(row.outgoing_reference_relationships_json),
    isReferencedByForeignKey: Boolean(row.is_referenced_by_foreign_key),
    incomingReferenceCount: row.incoming_reference_count == null ? null : Number(row.incoming_reference_count),
    incomingReferenceRelationshipsJson: row.incoming_reference_relationships_json == null
      ? null
      : String(row.incoming_reference_relationships_json),
    isUnique: Boolean(row.is_unique),
    isIndexed: Boolean(row.is_indexed),
    defaultDefinition: row.default_definition == null ? null : String(row.default_definition),
    columnDescription: row.column_description == null ? null : String(row.column_description),
  }));
}

