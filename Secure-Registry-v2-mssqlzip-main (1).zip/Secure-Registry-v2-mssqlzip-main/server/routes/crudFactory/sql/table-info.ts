import { getObjectTableInfo } from "@core/database";
import type { TableDescriptor, TableInfo } from "../types";

// هذه الدالة تُرجع TableInfo عبر طبقة database لتكون مصدر الحقيقة لتوصيف الأعمدة (بدلاً من تكرار منطق introspection داخل السيرفر)
export async function getTableInfo(descriptor: TableDescriptor): Promise<TableInfo> {
  const info = await getObjectTableInfo({
    schemaName: descriptor.schemaName,
    objectName: descriptor.tableName,
    propToDb: descriptor.propToDb,
  });

  return {
    tableName: info.tableName,
    schemaName: info.schemaName,
    columns: info.columns,
    columnMap: info.columnMap,
  };
}
