import type { CSSProperties } from "react"
import {
  BaseEdge,
  EdgeLabelRenderer,
  getSmoothStepPath,
  type EdgeProps,
} from "@xyflow/react"

export type FlowLabeledEdgeData = {
  label?: string
  color?: string
  dashed?: boolean
  labelBgColor?: string
  strokeWidth?: number
}

function renderEdge(
  props: EdgeProps,
  defaults: { color?: string; dashed?: boolean; strokeWidth?: number; labelBgColor?: string } = {},
) {
  const data = props.data as unknown as FlowLabeledEdgeData | undefined
  const color = data?.color ?? defaults.color ?? (props.style as CSSProperties | undefined)?.stroke
  const strokeWidth = data?.strokeWidth ?? defaults.strokeWidth ?? (props.style as CSSProperties | undefined)?.strokeWidth ?? 2

  const [edgePath, labelX, labelY] = getSmoothStepPath({
    sourceX: props.sourceX,
    sourceY: props.sourceY,
    sourcePosition: props.sourcePosition,
    targetX: props.targetX,
    targetY: props.targetY,
    targetPosition: props.targetPosition,
    borderRadius: 16,
  })

  const style: CSSProperties = {
    ...((props.style as CSSProperties | undefined) ?? null),
    stroke: color,
    strokeWidth,
    ...((data?.dashed ?? defaults.dashed) ? { strokeDasharray: "6 4" } : null),
  }

  return (
    <>
      <BaseEdge path={edgePath} markerEnd={props.markerEnd} style={style} />
      {data?.label ? (
        <EdgeLabelRenderer>
          <div
            style={{
              position: "absolute",
              transform: `translate(-50%, -50%) translate(${labelX}px, ${labelY}px)`,
              pointerEvents: "none",
              background: data.labelBgColor ?? defaults.labelBgColor ?? "rgba(255,255,255,0.85)",
              borderRadius: 6,
              padding: "2px 8px",
              fontSize: 12,
              color: "#0f172a",
              border: "1px solid rgba(15, 23, 42, 0.12)",
              whiteSpace: "nowrap",
            }}
          >
            {data.label}
          </div>
        </EdgeLabelRenderer>
      ) : null}
    </>
  )
}

export function FlowLabeledEdge(props: EdgeProps) {
  return renderEdge(props)
}

export function FlowHierarchyEdge(props: EdgeProps) {
  return renderEdge(props, { color: "#334155", dashed: false, strokeWidth: 2 })
}

export function FlowCoverageEdge(props: EdgeProps) {
  return renderEdge(props, { color: "#f97316", dashed: true, strokeWidth: 2 })
}

export function FlowDependencyEdge(props: EdgeProps) {
  return renderEdge(props, { color: "#7c3aed", dashed: true, strokeWidth: 1.75, labelBgColor: "rgba(245,243,255,0.92)" })
}
