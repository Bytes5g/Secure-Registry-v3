
type ApiRequestOptions = RequestInit & {
  data?: unknown;
};

export class ApiClient {
  private static instance: ApiClient;
  private baseURL: string;

  private constructor() {
    this.baseURL = window.location.origin;
  }

  public static getInstance(): ApiClient {
    if (!ApiClient.instance) {
      ApiClient.instance = new ApiClient();
    }
    return ApiClient.instance;
  }

  public async request<T>(method: string, endpoint: string, options: ApiRequestOptions = {}): Promise<T> {
    const { data, headers, ...customConfig } = options;
    
    const config: RequestInit = {
      method,
      headers: {
        ...(data ? { "Content-Type": "application/json" } : {}),
        ...headers,
      },
      body: data ? JSON.stringify(data) : undefined,
      credentials: "include", // maintain session
      ...customConfig,
    };

    // Ensure endpoint starts with / if not present (unless it's a full URL)
    const url = endpoint.startsWith('http') 
      ? endpoint 
      : `${this.baseURL}${endpoint.startsWith('/') ? '' : '/'}${endpoint}`;

    try {
      const response = await fetch(url, config);

      // Handle 401 Unauthorized globally
      if (response.status === 401) {
        window.location.href = '/login';
        throw new Error("جلسة العمل انتهت");
      }

      if (!response.ok) {
        const rawText = await response.text().catch(() => "");
        const errorData = (() => {
          try {
            return rawText ? JSON.parse(rawText) : {};
          } catch {
            return rawText ? { error: rawText } : {};
          }
        })();

        const message =
          typeof (errorData as any)?.error === "string"
            ? (errorData as any).error
            : (errorData as any)?.error?.message ??
              (errorData as any)?.message ??
              "حدث خطأ غير معروف";

        const code = (errorData as any)?.error?.code ?? (errorData as any)?.code;
        const details = (errorData as any)?.details ?? (errorData as any)?.error?.details;

        throw {
          status: response.status,
          message,
          code,
          details,
          raw: errorData,
        };
      }

      // Handle empty responses (e.g. 204 No Content)
      if (response.status === 204) {
        return {} as T;
      }

      return await response.json();
    } catch (error) {
      throw error;
    }
  }

  public get<T>(endpoint: string, options?: ApiRequestOptions): Promise<T> {
    return this.request<T>("GET", endpoint, options);
  }

  public post<T>(endpoint: string, data?: unknown, options?: ApiRequestOptions): Promise<T> {
    return this.request<T>("POST", endpoint, { ...options, data });
  }

  public put<T>(endpoint: string, data?: unknown, options?: ApiRequestOptions): Promise<T> {
    return this.request<T>("PUT", endpoint, { ...options, data });
  }

  public delete<T>(endpoint: string, options?: ApiRequestOptions): Promise<T> {
    return this.request<T>("DELETE", endpoint, options);
  }
}

export const apiClient = ApiClient.getInstance();
