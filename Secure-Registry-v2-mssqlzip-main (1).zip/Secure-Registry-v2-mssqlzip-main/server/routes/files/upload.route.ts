import { Router } from "express";
import { filesModule, settingsModule } from "@core/database";
import {
  assertDetectedMime,
  buildPublicFileUrl,
  deleteAbsoluteFileSafely,
  getLocalStorage,
} from "../../files/storage";
import { asyncHandler } from "../../utils/asyncHandler";
import { ensureFolderExists } from "./helpers";
import { createUpload } from "./upload-middleware";
import { requireWriteContext } from "../_internals";

const router = Router();
const localStorage = getLocalStorage();

router.post(
  "/upload",
  asyncHandler(async (req, res, next) => {
    const settings = await settingsModule.getFileUploadSettings();
    const maxBytes = Math.max(1, Math.min(settings.maxFileSizeMB, 2048)) * 1024 * 1024;
    const uploader = createUpload(maxBytes).single("file");
    uploader(req, res, (err: any) => {
      if (err) return next(err);
      (req as any).__fileUploadSettings = settings;
      next();
    });
  }),
  asyncHandler(async (req, res) => {
    const uploadSettings =
      ((req as any).__fileUploadSettings as Awaited<
        ReturnType<typeof settingsModule.getFileUploadSettings>
      >) ?? (await settingsModule.getFileUploadSettings());

    if (!req.file) return res.status(400).json({ error: "No file uploaded" });

    const folderIdRaw =
      req.body.folder == null || req.body.folder === "" ? null : Number(req.body.folder);
    const folderId = folderIdRaw == null ? uploadSettings.defaultFolderId : folderIdRaw;
    if (folderId != null && !Number.isFinite(folderId)) {
      await deleteAbsoluteFileSafely(req.file.path);
      return res.status(400).json({ error: "Invalid folder id" });
    }

    try {
      await ensureFolderExists(folderId);

      const mime = await assertDetectedMime(
        req.file.path,
        uploadSettings.allowedMimeTypes,
        req.file.mimetype,
      );

      const relativeDirectory = uploadSettings.relativeDirectory || "files";
      const folderKey = folderId != null ? `folder-${folderId}` : "root";
      await localStorage.ensureDirectory(`${relativeDirectory}/${folderKey}`);

      const storedRelativePath = `${relativeDirectory}/${folderKey}/${req.file.filename}`;
      await localStorage.moveFromTemp(req.file.path, storedRelativePath);

      const writeCtx = await requireWriteContext(req as any);
      const created = await filesModule.createFile({
        storage: "local",
        filenameDisk: storedRelativePath,
        filenameDownload: req.file.originalname,
        title: req.body.title ?? req.file.originalname,
        type: mime,
        folder: folderId,
        uploadedBy: null,
        modifiedBy: null,
        charset: null,
        filesize: req.file.size,
        width: null,
        height: null,
        duration: null,
        embed: null,
        description: req.body.description ?? null,
        location: buildPublicFileUrl(storedRelativePath),
        tags: req.body.tags ?? null,
        metadata: null,
        focalPointX: null,
        focalPointY: null,
        tusId: null,
        tusData: null,
        uploadedOn: new Date().toISOString(),
        workContextBy: writeCtx.workContextBy,
        createdBy: writeCtx.userId,
        isActive: true,
        isDeleted: false,
      });

      res.status(201).json(created);
    } catch (error) {
      await deleteAbsoluteFileSafely(req.file.path);
      throw error;
    }
  }),
);

export default router;
