import { z } from "zod";

export const mapProviderSchema = z.object({
  id: z.number().int(),
  providerName: z.string().min(1),
  providerType: z.string().min(1),
  tileUrl: z.string().min(1),
  isOverlay: z.boolean().default(false),
  orderIndex: z.number().int().default(0),
});

export type MapProvider = z.infer<typeof mapProviderSchema>;

