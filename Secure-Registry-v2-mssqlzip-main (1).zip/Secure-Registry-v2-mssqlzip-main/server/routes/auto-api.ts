import { Router } from "express";
import { getMetaColumnsForObject, getSchemaDictionaryColumns } from "@core/database";
import { insertLookupTypeSchema, insertLookupValueSchema } from "@shared/schema";
import { storage } from "../storage";
import { createCrudRouter, createReadOnlyRouter, type TableDescriptor } from "./crudFactory";
import { getTableInfo } from "./crudFactory/sql/table-info";

const router = Router();
const descriptorMap = new Map<string, TableDescriptor>();

function toKebabCase(value: string): string {
  return value.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase();
}

export function resolveTableDescriptor(key: string): TableDescriptor | undefined {
  return descriptorMap.get(key) ?? descriptorMap.get(toKebabCase(key));
}

function parseOptionalTypeId(value: unknown): number | undefined {
  if (value == null || value === "") {
    return undefined;
  }

  const parsed = parseInt(String(value), 10);
  return Number.isFinite(parsed) ? parsed : undefined;
}

function isAmbiguousLookupError(error: unknown): error is Error {
  const message = error instanceof Error ? error.message : String(error);
  return message.includes("Pass typeId explicitly.");
}

const tableDescriptors: TableDescriptor[] = [
  { exportName: "unifiedGeoLocations", tableName: "unified_geo_locations", readOnly: true },
  {
    exportName: "geoAdminUnits",
    tableName: "geo_admin_units",
    readOnly: true,
    propToDb: {
      countryId: "country_id",
      parentId: "parent_id",
      level: "admin_level",
      codes: "unit_code",
      nameEn: "name_en",
      adminTypeAr: "admin_type_ar",
      adminTypeEn: "admin_type_en",
      isActive: "is_active",
      geometryType: "geometry_type",
      latitude: "latitude",
      longitude: "longitude",
      bboxMinLon: "bbox_min_lon",
      bboxMinLat: "bbox_min_lat",
      bboxMaxLon: "bbox_max_lon",
      bboxMaxLat: "bbox_max_lat",
      geometryAreaSqm: "geometry_area_sqm",
      geometryPerimeterM: "geometry_perimeter_m",
      geometryJson: "geometry_json",
      numVertices: "num_vertices",
      isValid: "is_valid",
      createdAt: "created_at",
    },
  },
  { exportName: "organizationalStructure", tableName: "org_entities", readOnly: true },
  { exportName: "orgStructureTree", tableName: "org_entity_structure", readOnly: true },
  { exportName: "orgBranches", tableName: "org_branches", readOnly: true },
  {
    exportName: "orgBranchNodes",
    tableName: "org_branch_nodes",
    readOnly: true,
    propToDb: { orgStructureNodeId: "org_structure_node_id" },
  },
  { exportName: "orgStructureRoleTitles", tableName: "org_structure_role_titles", readOnly: true },
  {
    exportName: "users",
    tableName: "users",
    readOnly: true,
    propToDb: {
      firstName: "first_name",
      lastName: "last_name",
      tfaSecret: "tfa_secret",
      lastAccess: "last_access",
      lastPage: "last_page",
      externalIdentifier: "external_identifier",
      authData: "auth_data",
      emailNotifications: "email_notifications",
      themeDark: "theme_dark",
      themeLight: "theme_light",
      themeLightOverrides: "theme_light_overrides",
      themeDarkOverrides: "theme_dark_overrides",
      textDirection: "text_direction",
    },
  },
  { exportName: "roles", tableName: "roles", readOnly: true },
  { exportName: "personsSearch", tableName: "vm_persons", readOnly: true },
];

function registerRoute(routeName: string, aliasName: string, tableName: string, handler: Router) {
  router.use(`/${routeName}`, handler);
  if (aliasName !== routeName) {
    router.use(`/${aliasName}`, handler);
  }
}

function createLookupTypesRouter() {
  const lookupRouter = Router();
  lookupRouter.use((req, res, next) => {
    const method = (req.method || "").toUpperCase();
    if (method === "GET" || method === "HEAD" || method === "OPTIONS") return next();
    return res.status(403).json({
      error: "تم إيقاف الكتابة عبر /api/lookup-types. استخدم /api/lookups/types للكتابة.",
    });
  });

  function getErrorMessage(error: unknown, fallback: string): string {
    return error instanceof Error && error.message ? error.message : fallback;
  }

  lookupRouter.get("/", async (_req, res) => {
    try {
      const types = await storage.getAllLookupTypes();
      res.json({ data: types });
    } catch (error: any) {
      res.status(500).json({ error: error.message ?? "Failed to fetch lookup types" });
    }
  });

  lookupRouter.get("/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id, 10);
      const type = await storage.getLookupType(id);
      if (!type) {
        return res.status(404).json({ error: "Lookup type not found" });
      }
      res.json(type);
    } catch (error: any) {
      res.status(500).json({ error: error.message ?? "Failed to fetch lookup type" });
    }
  });

  lookupRouter.post("/", async (req, res) => {
    const parsed = insertLookupTypeSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: "Invalid lookup type data", details: parsed.error });
    }
    try {
      const type = await storage.createLookupType(parsed.data);
      res.status(201).json(type);
    } catch (error: any) {
      res.status(500).json({ error: getErrorMessage(error, "Failed to create lookup type") });
    }
  });

  lookupRouter.put("/:id", async (req, res) => {
    const parsed = insertLookupTypeSchema.partial().safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: "Invalid lookup type data", details: parsed.error });
    }
    try {
      const id = parseInt(req.params.id, 10);
      const type = await storage.updateLookupType(id, parsed.data);
      if (!type) {
        return res.status(404).json({ error: "Lookup type not found" });
      }
      res.json(type);
    } catch (error: any) {
      res.status(500).json({ error: getErrorMessage(error, "Failed to update lookup type") });
    }
  });

  lookupRouter.delete("/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id, 10);
      const success = await storage.deleteLookupType(id);
      if (!success) {
        return res.status(404).json({ error: "Lookup type not found" });
      }
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ error: getErrorMessage(error, "Failed to delete lookup type") });
    }
  });

  return lookupRouter;
}

function createLookupValuesRouter() {
  const lookupRouter = Router();
  lookupRouter.use((req, res, next) => {
    const method = (req.method || "").toUpperCase();
    if (method === "GET" || method === "HEAD" || method === "OPTIONS") return next();
    return res.status(403).json({
      error: "تم إيقاف الكتابة عبر /api/lookup-values. استخدم /api/lookups/values للكتابة.",
    });
  });

  lookupRouter.get("/", async (req, res) => {
    try {
      const typeId = req.query.typeId == null ? undefined : parseInt(String(req.query.typeId), 10);
      if (typeId != null && Number.isFinite(typeId)) {
        return res.json({ data: await storage.getLookupValuesByTypeId(typeId) });
      }
      const types = await storage.getAllLookupTypesWithValues();
      const values = types.flatMap((type) => type.values ?? []);
      res.json({ data: values });
    } catch (error: any) {
      res.status(500).json({ error: error.message ?? "Failed to fetch lookup values" });
    }
  });

  lookupRouter.get("/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id, 10);
      const typeId = parseOptionalTypeId(req.query.typeId);
      const value = await storage.getLookupValue(id, typeId);
      if (!value) {
        return res.status(404).json({ error: "Lookup value not found" });
      }
      res.json(value);
    } catch (error: any) {
      if (isAmbiguousLookupError(error)) {
        return res.status(400).json({ error: error.message });
      }
      res.status(500).json({ error: error.message ?? "Failed to fetch lookup value" });
    }
  });

  lookupRouter.post("/", async (req, res) => {
    const body = { ...req.body };
    if (body.parentId === "" || body.parentId === "null") body.parentId = null;
    if (typeof body.orderIndex === "string" && body.orderIndex.trim() === "") delete body.orderIndex;
    if (typeof body.orderIndex === "string" && /^\d+$/.test(body.orderIndex)) body.orderIndex = parseInt(body.orderIndex, 10);
    const parsed = insertLookupValueSchema.safeParse(body);
    if (!parsed.success) {
      return res.status(400).json({ error: "Invalid lookup value data", details: parsed.error });
    }
    try {
      const value = await storage.createLookupValue(parsed.data);
      res.status(201).json(value);
    } catch (error: any) {
      if (typeof error?.message === "string" && (error.message.includes("read-only") || error.message.includes("not writable"))) {
        return res.status(403).json({ error: error.message });
      }
      res.status(500).json({ error: error.message ?? "Failed to create lookup value" });
    }
  });

  lookupRouter.put("/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id, 10);
      const body = { ...req.body };
      body.typeId = parseOptionalTypeId(body.typeId ?? req.query.typeId);
      if (body.parentId === "" || body.parentId === "null") body.parentId = null;
      if (typeof body.orderIndex === "string" && body.orderIndex.trim() === "") delete body.orderIndex;
      if (typeof body.orderIndex === "string" && /^\d+$/.test(body.orderIndex)) body.orderIndex = parseInt(body.orderIndex, 10);
      const value = await storage.updateLookupValue(id, body, body.typeId);
      if (!value) {
        return res.status(404).json({ error: "Lookup value not found" });
      }
      res.json(value);
    } catch (error: any) {
      if (isAmbiguousLookupError(error)) {
        return res.status(400).json({ error: error.message });
      }
      if (typeof error?.message === "string" && (error.message.includes("read-only") || error.message.includes("not writable"))) {
        return res.status(403).json({ error: error.message });
      }
      res.status(500).json({ error: error.message ?? "Failed to update lookup value" });
    }
  });

  lookupRouter.delete("/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id, 10);
      const typeId = parseOptionalTypeId(req.query.typeId);
      const success = await storage.deleteLookupValue(id, typeId);
      if (!success) {
        return res.status(404).json({ error: "Lookup value not found" });
      }
      res.json({ success: true });
    } catch (error: any) {
      if (isAmbiguousLookupError(error)) {
        return res.status(400).json({ error: error.message });
      }
      if (typeof error?.message === "string" && (error.message.includes("read-only") || error.message.includes("not writable"))) {
        return res.status(403).json({ error: error.message });
      }
      res.status(500).json({ error: error.message ?? "Failed to delete lookup value" });
    }
  });

  return lookupRouter;
}

console.log("Auto-API: Registering MSSQL-backed routes...");
for (const descriptor of tableDescriptors) {
  const routeName = toKebabCase(descriptor.exportName);
  const routeHandler = descriptor.readOnly ? createReadOnlyRouter(descriptor) : createCrudRouter(descriptor);
  console.log(`Registering auto-API route: /${routeName} for table: ${descriptor.tableName}`);
  descriptorMap.set(routeName, descriptor);
  // هذه الإضافة تدعم entityType بصيغة snake_case (مثل persons_search) عبر تسجيل alias ثالث في descriptorMap
  descriptorMap.set(routeName.replace(/-/g, "_"), descriptor);
  descriptorMap.set(descriptor.exportName, descriptor);
  registerRoute(routeName, descriptor.exportName, descriptor.tableName, routeHandler);
}

descriptorMap.set("lookup-types", { exportName: "lookupTypes", tableName: "lookup_types_virtual", readOnly: true });
descriptorMap.set("lookupTypes", { exportName: "lookupTypes", tableName: "lookup_types_virtual", readOnly: true });
descriptorMap.set("lookup-values", { exportName: "lookupValues", tableName: "lookup_values_virtual", readOnly: true });
descriptorMap.set("lookupValues", { exportName: "lookupValues", tableName: "lookup_values_virtual", readOnly: true });

registerRoute("lookup-types", "lookupTypes", "lookup_types_virtual", createLookupTypesRouter());
registerRoute("lookup-values", "lookupValues", "lookup_values_virtual", createLookupValuesRouter());

// Metadata endpoint to fetch table schema information
router.get("/meta/v2/:table", async (req, res) => {
  try {
    const routeParam = req.params.table;
    const descriptor = resolveTableDescriptor(routeParam);
    if (!descriptor) {
      return res.status(404).json({ error: `Table '${routeParam}' not found in schema registry` });
    }

    if (descriptor.tableName.endsWith("_virtual")) {
      return res.json([]);
    }

    const info = await getTableInfo(descriptor);
    const dictionaryColumns = await getSchemaDictionaryColumns({
      schemaName: info.schemaName,
      objectName: info.tableName,
    });

    const dictionaryByName = new Map(dictionaryColumns.map((c) => [c.columnName, c]));
    const columns = info.columns.map((column) => {
      const dict = dictionaryByName.get(column.dbKey);
      return {
        ...column,
        formattedName: dict?.formattedName ?? null,
        columnDescription: dict?.columnDescription ?? null,
        uiColumnType: dict?.uiColumnType ?? null,
        isPrimaryKey: dict?.isPrimaryKey ?? false,
        primaryKeyOrdinal: dict?.primaryKeyOrdinal ?? null,
        isForeignKey: dict?.isForeignKey ?? false,
        referencedSchema: dict?.referencedSchema ?? null,
        referencedObject: dict?.referencedObject ?? null,
        referencedColumn: dict?.referencedColumn ?? null,
        isUnique: dict?.isUnique ?? false,
        isIndexed: dict?.isIndexed ?? false,
        defaultDefinition: dict?.defaultDefinition ?? null,
      };
    });

    res.json({
      schemaName: info.schemaName,
      tableName: info.tableName,
      formattedTableName: dictionaryColumns[0]?.formattedTableName ?? null,
      objectDescription: dictionaryColumns[0]?.objectDescription ?? null,
      columns,
    });
  } catch (error: any) {
    console.error(`Error fetching meta v2 for table ${req.params.table}:`, error);
    res.status(500).json({ error: error.message });
  }
});

// هذا المسار يُرجع توصيف الأعمدة اعتماداً على Dictionary (بدلاً من information_schema) لاستخدامه في صفحات الاستكشاف العامة
router.get("/meta/:table", async (req, res) => {
  try {
    const routeParam = req.params.table;
    const descriptor = resolveTableDescriptor(routeParam);
    if (!descriptor) {
      return res.status(404).json({ error: `Table '${routeParam}' not found in schema registry` });
    }

    if (descriptor.tableName.endsWith("_virtual")) {
      return res.json([]);
    }

    const info = await getTableInfo(descriptor);
    const columns = await getMetaColumnsForObject({ schemaName: info.schemaName, objectName: info.tableName });
    res.json(columns);
  } catch (error: any) {
    console.error(`Error fetching meta for table ${req.params.table}:`, error);
    res.status(500).json({ error: error.message });
  }
});

export default router;
