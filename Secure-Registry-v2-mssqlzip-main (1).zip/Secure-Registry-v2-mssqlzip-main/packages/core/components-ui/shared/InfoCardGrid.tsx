import { InfoCard } from "./InfoCard";

interface InfoCardGridItem {
  label: string;
  value: string;
}

interface InfoCardGridProps {
  items: InfoCardGridItem[];
}

export function InfoCardGrid({ items }: InfoCardGridProps) {
  return (
    <div className="grid gap-3 md:grid-cols-2">
      {items.map((item) => (
        <InfoCard key={item.label} label={item.label} value={item.value} />
      ))}
    </div>
  );
}
