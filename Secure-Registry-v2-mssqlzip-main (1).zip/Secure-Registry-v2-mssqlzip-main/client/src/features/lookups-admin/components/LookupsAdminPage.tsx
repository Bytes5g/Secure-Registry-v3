import { useMemo } from "react";
import { Badge, Button, Card, CardContent, CardDescription, CardHeader, CardTitle } from "@secure-registry/components-ui";
import { DataTable, type Column } from "@secure-registry/components-ui";
import { PAGE_CODES } from "@/lib/constants";
import type { LookupType, LookupValue, LookupVirtualValue } from "@shared/schema";
import { EntityRelationsTabs, InfoCardGrid, type EntityRelationsTab } from "@/components/shared";
import { LookupAdminDialogStack } from "./LookupAdminDialogStack";
import { useLookupsAdminController } from "../hooks/useLookupsAdminController";

function renderActiveState(value: unknown) {
  return value ? "مفعل" : "معطل";
}

function renderAliasesList(aliases: string[]) {
  return aliases.length > 0 ? aliases.join(", ") : "لا يوجد";
}

function renderDateTime(value: unknown) {
  return value ? new Date(String(value)).toLocaleString("ar-SA") : "-";
}

function renderOptionalNumber(value: unknown) {
  return value == null ? "-" : String(value);
}

function createActiveColumn<T extends { isActive: boolean }>(): Column<T> {
  return {
    key: "isActive",
    header: "الحالة",
    render: renderActiveState,
  };
}

function createManagedTableTab<T extends Record<string, any>>({
  value,
  label,
  panelTitle,
  panelDescription,
  actionLabel,
  onAction,
  data,
  columns,
  isLoading,
  onEdit,
  onDelete,
  emptyMessage,
}: {
  value: string;
  label: string;
  panelTitle: string;
  panelDescription: string;
  actionLabel?: string;
  onAction?: () => void;
  data: T[];
  columns: Column<T>[];
  isLoading: boolean;
  onEdit?: (row: T) => void;
  onDelete?: (row: T) => void;
  emptyMessage: string;
}): EntityRelationsTab {
  return {
    value,
    label,
    panel: {
      title: panelTitle,
      description: panelDescription,
      actionLabel,
      onAction,
    },
    content: (
      <DataTable
        data={data}
        columns={columns}
        isLoading={isLoading}
        onEdit={onEdit}
        onDelete={onDelete}
        emptyMessage={emptyMessage}
      />
    ),
  };
}

export function LookupsAdminPage() {
  const controller = useLookupsAdminController();

  const lookupTypeColumns = useMemo<Column<LookupType>[]>(
    () => [
      { key: "code", header: "الكود", sortable: true },
      { key: "nameAr", header: "الاسم", sortable: true },
      {
        key: "tableName",
        header: "مصدر الجدول",
        render: (_, row) => row.tableName || row.valueProviderKey || "افتراضي",
      },
      {
        key: "aliases",
        header: "الأسماء البديلة",
        render: (_, row) => renderAliasesList(row.aliases),
      },
      createActiveColumn<LookupType>(),
    ],
    [],
  );

  const valueColumns = useMemo<Column<LookupValue>[]>(
    () => [
      { key: "code", header: "الكود", sortable: true },
      { key: "nameAr", header: "الاسم", sortable: true },
      { key: "orderIndex", header: "الترتيب", sortable: true },
      {
        key: "parentId",
        header: "الأب",
        render: renderOptionalNumber,
      },
      createActiveColumn<LookupValue>(),
    ],
    [],
  );

  const virtualSeedColumns = useMemo<Column<LookupVirtualValue>[]>(
    () => [
      { key: "valueId", header: "المعرف", sortable: true },
      { key: "code", header: "الكود", sortable: true },
      { key: "nameAr", header: "الاسم", sortable: true },
      { key: "orderIndex", header: "الترتيب", sortable: true },
      {
        key: "aliases",
        header: "الأسماء البديلة",
        render: (_, row) => renderAliasesList(row.aliases),
      },
      createActiveColumn<LookupVirtualValue>(),
    ],
    [],
  );

  const selectedTypeTabs = controller.selectedType
    ? [
        {
          value: "metadata",
          label: "البيانات الوصفية",
          content: (
            <>
              <InfoCardGrid
                items={[
                  { label: "قاعدة البيانات", value: controller.selectedType.databaseName || "-" },
                  { label: "المخطط", value: controller.selectedType.schemaName || "-" },
                  { label: "الجدول", value: controller.selectedType.tableName || "-" },
                  { label: "حقل الاسم", value: controller.selectedType.nameColumn || "-" },
                  { label: "حقل الترتيب", value: controller.selectedType.orderColumn || "-" },
                  { label: "حقل الأب", value: controller.selectedType.parentColumn || "-" },
                  { label: "حقل الإنشاء", value: controller.selectedType.createdAtColumn || "-" },
                  { label: "مفتاح المزود", value: controller.selectedType.valueProviderKey || "-" },
                  { label: "استراتيجية المزود", value: controller.selectedType.providerStrategy },
                  { label: "قابل للكتابة", value: controller.selectedType.writable ? "نعم" : "لا" },
                ]}
              />
              <div className="rounded-md border p-4">
                <p className="mb-2 font-medium">المرادفات الأساسية</p>
                <div className="flex flex-wrap gap-2">
                  {controller.selectedType.aliases.length > 0 ? (
                    controller.selectedType.aliases.map((alias) => (
                      <Badge key={alias} variant="secondary">
                        {alias}
                      </Badge>
                    ))
                  ) : (
                    <span className="text-sm text-muted-foreground">لا توجد مرادفات مضمّنة.</span>
                  )}
                </div>
              </div>
            </>
          ),
        },
        createManagedTableTab({
          value: "values",
          label: "القيم",
          panelTitle: "القيم الفعلية",
          panelDescription: controller.canManageValues
            ? "إدارة القيم في الجدول المرتبط مباشرة عندما يكون النوع قابلاً للكتابة."
            : "القيم المعروضة هنا للقراءة فقط لأن النوع الحالي يعتمد على مزود قيم أو جدول غير قابل للكتابة.",
          actionLabel: controller.canManageValues ? "إضافة قيمة" : undefined,
          onAction: controller.canManageValues ? controller.openCreateValueDialog : undefined,
          data: controller.lookupValues,
          columns: valueColumns,
          isLoading: controller.lookupValuesLoading,
          onEdit: controller.canManageValues ? controller.openEditValueDialog : undefined,
          onDelete: controller.canManageValues ? controller.setValueToDelete : undefined,
          emptyMessage: "لا توجد قيم لهذا النوع",
        }),
        createManagedTableTab({
          value: "virtual-seeds",
          label: "البذور الافتراضية",
          panelTitle: "البذور الافتراضية",
          panelDescription: "تهيئة قيم افتراضية للأنواع الافتراضية أو المزودة عبر provider.",
          actionLabel: "إضافة بذرة",
          onAction: controller.openCreateVirtualSeedDialog,
          data: controller.virtualSeeds,
          columns: virtualSeedColumns,
          isLoading: controller.virtualSeedsLoading,
          onEdit: controller.openEditVirtualSeedDialog,
          onDelete: controller.setVirtualSeedToDelete,
          emptyMessage: "لا توجد بذور افتراضية لهذا النوع",
        }),
      ]
    : [];

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-3 md:flex-row md:items-start md:justify-between">
        <div className="space-y-1">
          <h1 className="text-2xl font-bold">إدارة القوائم المرجعية</h1>
          <p className="text-muted-foreground">
            واجهة إدارية موسعة لإدارة {PAGE_CODES.LOOKUPS} وحقول metadata والمرادفات والبذور الافتراضية.
          </p>
        </div>
        <Button onClick={controller.openCreateTypeDialog}>إضافة نوع قائمة</Button>
      </div>

      <div className="grid gap-6 xl:grid-cols-[1.1fr_1.4fr]">
        <Card>
          <CardHeader>
            <CardTitle>أنواع القوائم</CardTitle>
            <CardDescription>تعريف الأنواع وتحديد الجدول أو مزود القيم وربطها بالأسماء البديلة.</CardDescription>
          </CardHeader>
          <CardContent>
            <DataTable
              data={controller.lookupTypes}
              columns={lookupTypeColumns}
              isLoading={controller.lookupTypesLoading}
              onRowClick={(row) => controller.setSelectedType(row)}
              onEdit={controller.openEditTypeDialog}
              onDelete={(row) => controller.setLookupToDelete(row)}
              emptyMessage="لا توجد أنواع معرفة بعد"
            />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="gap-3">
            <div className="flex flex-col gap-3 md:flex-row md:items-start md:justify-between">
              <div className="space-y-1">
                <CardTitle>تفاصيل النوع</CardTitle>
                <CardDescription>{controller.selectedTypeSummary}</CardDescription>
              </div>
              {controller.selectedType ? (
                <div className="flex flex-wrap gap-2">
                  <Badge variant={controller.selectedType.isActive ? "default" : "secondary"}>
                    {controller.selectedType.isActive ? "مفعل" : "معطل"}
                  </Badge>
                  <Badge variant="outline">
                    {controller.selectedType.tableName ? "جدول فعلي" : "مزود افتراضي"}
                  </Badge>
                </div>
              ) : null}
            </div>
          </CardHeader>
          <CardContent>
            {controller.selectedType ? (
              <EntityRelationsTabs tabs={selectedTypeTabs} defaultValue="metadata" />
            ) : (
              <div className="flex min-h-[420px] items-center justify-center rounded-md border border-dashed text-muted-foreground">
                اختر نوع قائمة من الجدول المجاور لعرض بياناته وإدارة السجلات التابعة له.
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <LookupAdminDialogStack controller={controller} />
    </div>
  );
}
