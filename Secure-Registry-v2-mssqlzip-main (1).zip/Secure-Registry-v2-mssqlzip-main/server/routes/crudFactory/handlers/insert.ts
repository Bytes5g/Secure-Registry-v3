import type { Router } from "express";
import { executeInsert, pickBodyColumns } from "@core/database";
import type { TableDescriptor } from "../types";
import { getTableInfo } from "../sql/table-info";
import { runWrite } from "../run-write";
import { getAfterWriteHook } from "../../crudHooks";
import { applyWriteContextToBody } from "../../_internals";

export function registerInsertHandler(router: Router, descriptor: TableDescriptor) {
  const hook = getAfterWriteHook(descriptor);

  router.post("/", async (req, res) => {
    try {
      // Force a transaction so multi-statement insert strategies that rely on
      // `WITH (UPDLOCK, HOLDLOCK)` (notably MAX(id)+1 for non-identity IDs)
      // remain atomic even when no after-write hook is registered.
      const created = await runWrite(hook, "insert", async (executor) => {
        const tableInfo = await getTableInfo(descriptor);
        const { columnMap } = tableInfo;
        const body = (req.body || {}) as Record<string, unknown>;
        await applyWriteContextToBody(req, body, columnMap, "insert");
        const idColumn = columnMap.get("id");
        const excludeKeys = ["createdAt", ...(idColumn?.isIdentity ? ["id"] : [])];
        const values = pickBodyColumns(body, columnMap, excludeKeys);
        if (values.length === 0) throw new Error("Empty body");
        const row = await executeInsert({ tableInfo, values, body, executor });
        if (!row) throw new Error("Insert did not return a row");
        return row;
      }, { forceTransaction: true });

      res.status(201).json(created);
    } catch (e: any) {
      console.error(`Error in POST /api/${descriptor.exportName}:`, e);
      res.status(400).json({ error: e.message });
    }
  });
}
