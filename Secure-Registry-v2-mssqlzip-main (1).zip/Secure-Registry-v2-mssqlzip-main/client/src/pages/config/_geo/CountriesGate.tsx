import { Globe2 } from "lucide-react";
import { Badge, Button, EntityContentCard, Input } from "@secure-registry/components-ui";
import { DataTable, type Column } from "@secure-registry/components-ui";
import type { GeoCountry } from "@/lib/api/geo-admin";
import { updateGeoCountryOrderIndex } from "@/lib/api/geo-admin";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";

interface CountriesGateProps {
  countries: GeoCountry[];
  isLoading: boolean;
  onEnter: (country: GeoCountry) => void;
}

export function CountriesGate({ countries, isLoading, onEnter }: CountriesGateProps) {
  const queryClient = useQueryClient();
  const [editingValues, setEditingValues] = useState<Record<number, string>>({});

  const updateOrder = useMutation({
    mutationFn: async (payload: { id: number; orderIndex: number }) =>
      updateGeoCountryOrderIndex(payload.id, payload.orderIndex),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["geo", "countries"] });
    },
  });

  const columns: Column<GeoCountry>[] = [
    { key: "name", header: "اسم الدولة", sortable: true },
    { key: "code", header: "الكود", sortable: true },
    { key: "isoAlpha2", header: "ISO2" },
    {
      key: "orderIndex",
      header: "الترتيب",
      width: "110px",
      render: (_, row) => {
        const value = editingValues[row.id] ?? String(row.orderIndex ?? 0);
        return (
          <Input
            type="number"
            value={value}
            onChange={(e) =>
              setEditingValues((prev) => ({ ...prev, [row.id]: e.target.value }))
            }
            onBlur={() => {
              const raw = (editingValues[row.id] ?? String(row.orderIndex ?? 0)).trim();
              const parsed = raw === "" ? 0 : Number(raw);
              if (!Number.isFinite(parsed)) return;
              if (parsed === (row.orderIndex ?? 0)) return;
              updateOrder.mutate({ id: row.id, orderIndex: parsed });
            }}
            className="h-8"
          />
        );
      },
    },
    {
      key: "isActive",
      header: "الحالة",
      render: (value) => (
        <Badge variant={value ? "default" : "secondary"}>{value ? "نعم" : "لا"}</Badge>
      ),
    },
    {
      key: "open",
      header: "الدخول",
      render: (_, row) => (
        <Button variant="ghost" className="text-primary hover:underline" onClick={() => onEnter(row)}>
          الدخول
        </Button>
      ),
    },
  ];

  return (
    <EntityContentCard className="bg-card shadow-sm" contentClassName="p-4">
      <div className="mb-4 flex items-center gap-2">
        <Globe2 className="h-5 w-5 text-primary" />
        <div>
          <h2 className="text-lg font-semibold">الدول</h2>
          <p className="text-sm text-muted-foreground">
            اختر الدولة أولاً، ثم ستظهر لك وحداتها الجغرافية وتفرعاتها.
          </p>
        </div>
      </div>

      <DataTable
        data={countries}
        columns={columns}
        isLoading={isLoading}
        searchPlaceholder="ابحث عن دولة..."
        emptyMessage="لا توجد دول متاحة"
      />
    </EntityContentCard>
  );
}
