import { LookupDialogInputField } from "./LookupDialogFields";
import { LookupDialogScaffold } from "./LookupDialogScaffold";
import type { AliasFormState } from "../models/lookups-admin-models";

interface LookupAliasDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  value: AliasFormState;
  onChange: (value: AliasFormState) => void;
  onSubmit: () => void;
  isSubmitting: boolean;
  isEditing: boolean;
}

export function LookupAliasDialog({
  open,
  onOpenChange,
  value,
  onChange,
  onSubmit,
  isSubmitting,
  isEditing,
}: LookupAliasDialogProps) {
  return (
    <LookupDialogScaffold
      title={isEditing ? "تعديل مرادف" : "إضافة مرادف"}
      description="إدارة اسم بديل واحد وربطه بنوع القائمة المحدد."
      open={open}
      onOpenChange={onOpenChange}
      onSubmit={onSubmit}
      isSubmitting={isSubmitting}
      activeDescription="يبقى صالحاً للاستعلام وربط الكود."
      isActive={value.isActive}
      onActiveChange={(isActive) => onChange({ ...value, isActive })}
    >
      <LookupDialogInputField
        id="alias-code"
        label="الاسم البديل"
        value={value.aliasCode}
        onChange={(aliasCode) => onChange({ ...value, aliasCode })}
      />
    </LookupDialogScaffold>
  );
}
