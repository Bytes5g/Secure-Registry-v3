export const stopPropagation = (e: { stopPropagation: () => void }) => e.stopPropagation();

export function asNumberOrUndefined(value: string): number | undefined {
  const raw = String(value ?? "").trim();
  if (!raw) return undefined;
  const n = Number(raw);
  return Number.isFinite(n) ? n : undefined;
}

export function normalizeOrder<T extends { orderIndex?: number }>(items: T[]): T[] {
  return items.map((item, idx) => ({ ...item, orderIndex: idx + 1 }));
}

export function moveItem<T>(items: T[], fromIndex: number, toIndex: number): T[] {
  const next = [...items];
  const [removed] = next.splice(fromIndex, 1);
  next.splice(toIndex, 0, removed);
  return next;
}

