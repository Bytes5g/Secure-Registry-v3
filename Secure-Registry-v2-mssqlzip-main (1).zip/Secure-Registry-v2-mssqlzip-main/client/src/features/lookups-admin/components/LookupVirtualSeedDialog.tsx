import { TextListField } from "@/components/shared";
import { LookupDialogInputField } from "./LookupDialogFields";
import { LookupDialogScaffold } from "./LookupDialogScaffold";
import type { VirtualSeedFormState } from "../models/lookups-admin-models";

interface LookupVirtualSeedDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  value: VirtualSeedFormState;
  onChange: (value: VirtualSeedFormState) => void;
  onSubmit: () => void;
  isSubmitting: boolean;
  isEditing: boolean;
}

export function LookupVirtualSeedDialog({
  open,
  onOpenChange,
  value,
  onChange,
  onSubmit,
  isSubmitting,
  isEditing,
}: LookupVirtualSeedDialogProps) {
  return (
    <LookupDialogScaffold
      title={isEditing ? "تعديل بذرة افتراضية" : "إضافة بذرة افتراضية"}
      description="تعريف قيمة افتراضية ضمن `lookup_virtual_values`."
      open={open}
      onOpenChange={onOpenChange}
      onSubmit={onSubmit}
      isSubmitting={isSubmitting}
      activeDescription="يُستخدم في نتائج المزود الافتراضي."
      isActive={value.isActive}
      onActiveChange={(isActive) => onChange({ ...value, isActive })}
    >
      <div className="grid gap-4 md:grid-cols-2">
        <LookupDialogInputField
          id="seed-value-id"
          label="معرف القيمة"
          type="number"
          value={value.valueId}
          onChange={(valueId) => onChange({ ...value, valueId })}
        />
        <LookupDialogInputField
          id="seed-code"
          label="الكود"
          value={value.code}
          onChange={(code) => onChange({ ...value, code })}
        />
        <LookupDialogInputField
          id="seed-name"
          label="الاسم العربي"
          value={value.nameAr}
          className="md:col-span-2"
          onChange={(nameAr) => onChange({ ...value, nameAr })}
        />
        <LookupDialogInputField
          id="seed-order"
          label="الترتيب"
          type="number"
          value={String(value.orderIndex)}
          onChange={(orderIndex) => onChange({ ...value, orderIndex: Number(orderIndex) || 0 })}
        />
      </div>

      <TextListField
        label="أسماء بديلة للبذرة"
        value={value.aliases}
        onChange={(aliases) => onChange({ ...value, aliases })}
      />
    </LookupDialogScaffold>
  );
}
