import { AppSidebar } from '@/components/layout/AppSidebar';
import {
  Avatar,
  AvatarFallback,
  Badge,
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  Separator,
  SidebarInset,
  SidebarProvider,
  SidebarTrigger,
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from '@secure-registry/components-ui';
import { useAuth } from '@/lib/mock-auth';
import { Bell } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import { useLocation } from 'wouter';
import type { UiPageConfigWithDetails } from '@/types/ui';

interface LayoutProps {
  children: React.ReactNode;
  title?: string;
  description?: string;
}

export default function Layout({ children, title, description }: LayoutProps) {
  const [location] = useLocation();
  const { user, logout } = useAuth();

  const routeToPageCode: Record<string, string> = {
    '/config/org-entities': 'org_entities',
    '/config/org-entities/:id': 'org_entities_profile',
    '/config/geo': 'geo_management',
  };

  const pageCode = routeToPageCode[location];

  const layoutCfg = {};
  const sidebarDefaultOpen = true;
  const showNotifications = true;
  const showFooter = false;
  const footerText = '© المنظومة الأمنية الشامة';

  return (
    <SidebarProvider defaultOpen={sidebarDefaultOpen}>
      <AppSidebar />
      <SidebarInset className="order-1">
        <header className="flex h-16 shrink-0 items-center border-b px-4" dir="rtl">
          <div className="flex w-full items-center justify-between">
            <div className="flex items-center gap-2">
              <SidebarTrigger className="-mr-1" />
              <Separator orientation="vertical" className="mr-2 h-4" />
              <div className="font-medium">المنظومة الأمنية الشامة</div>
            </div>
            <div className="flex items-center gap-3">
              {showNotifications && (
                <Tooltip>
                  <TooltipTrigger asChild>
                    <div className="relative">
                      <Bell className="h-5 w-5 text-muted-foreground" />
                      <Badge variant="secondary" className="absolute -top-2 -left-2">0</Badge>
                    </div>
                  </TooltipTrigger>
                  <TooltipContent side="bottom">لا توجد إشعارات حالياً</TooltipContent>
                </Tooltip>
              )}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <button className="flex items-center gap-3 rounded-md border px-3 py-1.5 text-sm">
                    <Avatar>
                      <AvatarFallback>{user?.name?.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div className="text-right leading-tight">
                      <div className="font-semibold truncate max-w-[140px]">{user?.name}</div>
                      <div className="text-xs text-muted-foreground">
                        {user?.role === 'admin' ? 'مدير النظام' : 'محقق'}
                      </div>
                    </div>
                  </button>
                </DropdownMenuTrigger>
                <DropdownMenuContent side="bottom" align="start">
                  <DropdownMenuItem onClick={logout}>تسجيل الخروج</DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </header>
        <div className="flex flex-1 flex-col gap-4 p-4" dir="rtl">
          {(title || description) && (
            <div className="mb-2">
              {title && <h1 className="text-2xl font-bold">{title}</h1>}
              {description && <p className="text-muted-foreground">{description}</p>}
            </div>
          )}
          <div className="min-h-[100vh] flex-1 rounded-xl bg-muted/50 md:min-h-min p-4">
            {children}
          </div>
          {showFooter && (
            <footer className="border-t pt-3 text-xs text-muted-foreground text-center" dir="rtl">
              {footerText}
            </footer>
          )}
        </div>
      </SidebarInset>
    </SidebarProvider>
  );
}
