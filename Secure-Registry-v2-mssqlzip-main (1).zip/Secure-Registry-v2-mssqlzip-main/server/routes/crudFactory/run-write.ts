import { withTransaction, type SqlExecutor } from "@core/database";
import type { CrudAfterWriteHook, CrudWriteAction } from "../crudHooks";

interface RunWriteOptions {
  /**
   * Force the write to run inside an explicit transaction even when no
   * after-write hook is registered. Required for write paths that rely on
   * `WITH (UPDLOCK, HOLDLOCK)` or other multi-statement atomicity (e.g., the
   * non-identity ID `MAX(id)+1` insert strategy).
   */
  forceTransaction?: boolean;
}

/**
 * Executes a write operation, optionally inside a transaction so the
 * after-write hook can observe and extend the same transactional scope.
 *
 * `fn` is the pure data-write function (single code path for hook/no-hook).
 */
export async function runWrite(
  hook: CrudAfterWriteHook | null,
  action: CrudWriteAction,
  fn: (executor: SqlExecutor | undefined) => Promise<Record<string, unknown> | undefined>,
  options: RunWriteOptions = {},
): Promise<Record<string, unknown> | undefined> {
  if (!hook && !options.forceTransaction) return fn(undefined);
  return withTransaction(async (tx) => {
    const row = await fn(tx);
    if (row && hook) await hook(action, row, tx);
    return row;
  });
}
