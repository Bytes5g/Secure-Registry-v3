import { Router } from "express";
import type { TableDescriptor } from "./types";
import { registerListHandler } from "./handlers/list";
import { registerGetByIdHandler } from "./handlers/get-by-id";
import { registerInsertHandler } from "./handlers/insert";
import { registerUpdateHandler } from "./handlers/update";
import { registerDeleteHandler } from "./handlers/delete";

export type { TableDescriptor, ColumnInfo, TableInfo } from "./types";

function buildRouter(descriptor: TableDescriptor, readOnly: boolean) {
  const router = Router();
  if (readOnly) {
    router.use((req, res, next) => {
      const method = (req.method || "").toUpperCase();
      if (method === "GET" || method === "HEAD" || method === "OPTIONS") return next();
      return res.status(403).json({
        error: "هذه الوجهة للقراءة فقط. استخدم المسارات المخصصة للكتابة بدل Auto API.",
        table: descriptor.tableName,
      });
    });
  }
  registerListHandler(router, descriptor);
  registerGetByIdHandler(router, descriptor);
  if (!readOnly) {
    registerInsertHandler(router, descriptor);
    registerUpdateHandler(router, descriptor);
    registerDeleteHandler(router, descriptor);
  }
  return router;
}

export const createCrudRouter = (descriptor: TableDescriptor) => buildRouter(descriptor, false);
export const createReadOnlyRouter = (descriptor: TableDescriptor) => buildRouter(descriptor, true);
