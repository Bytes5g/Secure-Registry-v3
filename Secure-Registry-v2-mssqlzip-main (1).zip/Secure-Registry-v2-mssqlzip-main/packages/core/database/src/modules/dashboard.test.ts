import { beforeEach, describe, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => ({
  runQuery: vi.fn(),
}));

vi.mock("./helpers", () => ({
  runQuery: mocks.runQuery,
}));

import { getSystemDashboardStatistics } from "./dashboard";

describe("getSystemDashboardStatistics", () => {
  beforeEach(() => {
    mocks.runQuery.mockReset();
  });

  it("queries vw_system_dashboard_statistics", async () => {
    mocks.runQuery.mockResolvedValueOnce([
      {
        id: 1,
        parent_id: null,
        database_name: "db",
        schema_name: "dbo",
        object_name: "x",
        display_name: "X",
        is_active: 1,
        order_index: 1,
        object_description: null,
        column_count: 2,
        row_count: 3,
        notes: null,
      },
    ]);

    const rows = await getSystemDashboardStatistics();
    expect(rows[0].id).toBe(1);
    const [sql] = mocks.runQuery.mock.calls[0];
    expect(String(sql)).toContain("vw_system_dashboard_statistics");
  });
});

