import type { ReactNode } from "react"
import { Card, CardContent } from "../ui/card"
import { cn } from "../lib/utils"

interface EntityContentCardProps {
  children: ReactNode
  className?: string
  contentClassName?: string
}

export function EntityContentCard({ children, className, contentClassName }: EntityContentCardProps) {
  return (
    <Card className={className}>
      <CardContent className={cn("p-6", contentClassName)}>{children}</CardContent>
    </Card>
  )
}

