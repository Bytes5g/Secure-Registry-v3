import { ConfirmDialog } from "../ui/confirm-dialog"

interface EntityDeleteDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  title: string
  description: string
  onConfirm: () => void
  isSubmitting?: boolean
}

export function EntityDeleteDialog({
  open,
  onOpenChange,
  title,
  description,
  onConfirm,
  isSubmitting = false,
}: EntityDeleteDialogProps) {
  return (
    <ConfirmDialog
      open={open}
      onOpenChange={onOpenChange}
      title={title}
      description={description}
      confirmLabel={isSubmitting ? "جاري الحذف..." : "حذف"}
      variant="destructive"
      onConfirm={onConfirm}
    />
  )
}

