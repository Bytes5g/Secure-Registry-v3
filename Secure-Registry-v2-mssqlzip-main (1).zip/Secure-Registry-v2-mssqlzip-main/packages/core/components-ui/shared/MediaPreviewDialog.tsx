import { useMemo, useState } from "react"
import { ExternalLink } from "lucide-react"
import { cn } from "../lib/utils"
import { Button } from "../ui/button"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "../ui/dialog"
import { ScrollArea } from "../ui/scroll-area"
import { Separator } from "../ui/separator"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../ui/tabs"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "../ui/tooltip"

export type MediaPreviewKind = "auto" | "image" | "video"

export interface MediaPreviewItem {
  url: string
  title?: string
  kind?: MediaPreviewKind
  mimeType?: string | null
}

function resolvePreviewKind(item: MediaPreviewItem): Exclude<MediaPreviewKind, "auto"> {
  if (item.kind === "image" || item.kind === "video") return item.kind

  const mime = (item.mimeType ?? "").toLowerCase()
  if (mime.startsWith("video/")) return "video"
  if (mime.startsWith("image/")) return "image"

  const url = item.url.toLowerCase()
  const ext = url.split("?")[0]?.split("#")[0]?.split(".").pop() ?? ""
  if (["mp4", "webm", "ogg", "mov"].includes(ext)) return "video"
  return "image"
}

// هذا الـ Hook وظيفته توفير معاينة وسائط (صورة/فيديو) داخل Dialog بدون فتح تبويب جديد
export function useMediaPreviewDialog() {
  const [item, setItem] = useState<MediaPreviewItem | null>(null)
  const open = (next: MediaPreviewItem) => setItem(next)
  const close = () => setItem(null)
  const isOpen = Boolean(item)

  const dialog = (
    <MediaPreviewDialog
      open={isOpen}
      item={item}
      onOpenChange={(v) => {
        if (!v) close()
      }}
    />
  )

  return { open, close, isOpen, dialog, item }
}

interface MediaPreviewDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  item: MediaPreviewItem | null
}

// هذه الدالة/المكوّن وظيفته عرض وسائط داخل نافذة منبثقة بطريقة قابلة لإعادة الاستخدام
export function MediaPreviewDialog({ open, onOpenChange, item }: MediaPreviewDialogProps) {
  const kind = useMemo(() => (item ? resolvePreviewKind(item) : "image"), [item])
  const title = item?.title ?? "معاينة"
  const url = item?.url ?? ""

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl p-0 overflow-hidden">
        <DialogHeader className="p-4">
          <div className="flex items-center justify-between gap-3">
            <DialogTitle className="truncate">{title}</DialogTitle>
            {url ? (
              <div className="flex items-center gap-2">
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button asChild variant="outline" size="sm">
                        <a href={url} target="_blank" rel="noreferrer">
                          <ExternalLink className="h-4 w-4" />
                        </a>
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent>فتح في تبويب</TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              </div>
            ) : null}
          </div>
        </DialogHeader>
        <Separator />

        <div className="grid grid-cols-1 lg:grid-cols-[1fr_320px]">
          <div className="bg-black">
            <div className="min-h-[260px] max-h-[70vh] flex items-center justify-center">
              {url ? (
                kind === "video" ? (
                  <video className="max-h-[70vh] w-full" controls src={url} />
                ) : (
                  <img className="max-h-[70vh] w-full object-contain" src={url} alt="" />
                )
              ) : (
                <div className="p-6 text-sm text-white/70">لا يوجد رابط للمعاينة</div>
              )}
            </div>
          </div>

          <div className="bg-background">
            <Tabs defaultValue="details" className="w-full">
              <TabsList className={cn("w-full rounded-none justify-start", "border-b")}>
                <TabsTrigger value="details">تفاصيل</TabsTrigger>
                <TabsTrigger value="link">الرابط</TabsTrigger>
              </TabsList>
              <TabsContent value="details" className="m-0">
                <ScrollArea className="h-[220px] lg:h-[70vh]">
                  <div className="p-4 space-y-2 text-sm">
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-muted-foreground">النوع</span>
                      <span className="font-medium">{kind === "video" ? "فيديو" : "صورة"}</span>
                    </div>
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-muted-foreground">MIME</span>
                      <span className="font-medium">{item?.mimeType ?? "—"}</span>
                    </div>
                  </div>
                </ScrollArea>
              </TabsContent>
              <TabsContent value="link" className="m-0">
                <ScrollArea className="h-[220px] lg:h-[70vh]">
                  <div className="p-4 space-y-3">
                    <div className="text-xs text-muted-foreground">انسخ الرابط أو افتحه</div>
                    <div className="break-all rounded-md border p-3 text-sm">{url || "—"}</div>
                    {url ? (
                      <Button asChild variant="secondary">
                        <a href={url} target="_blank" rel="noreferrer">
                          فتح في تبويب
                        </a>
                      </Button>
                    ) : null}
                  </div>
                </ScrollArea>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}

