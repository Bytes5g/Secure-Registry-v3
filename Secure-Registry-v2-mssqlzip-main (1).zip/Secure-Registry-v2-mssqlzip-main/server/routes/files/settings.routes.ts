import { Router } from "express";
import { settingsModule } from "@core/database";
import { asyncHandler } from "../../utils/asyncHandler";
import { fileSettingsSchema } from "./helpers";

const router = Router();

router.get(
  "/settings",
  asyncHandler(async (_req, res) => {
    const settings = await settingsModule.getFileUploadSettings();
    res.json({ data: settings });
  }),
);

router.put(
  "/settings",
  asyncHandler(async (req, res) => {
    const parsed = fileSettingsSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: "Invalid settings payload", details: parsed.error });
    }
    const updated = await settingsModule.updateFileUploadSettings(parsed.data);
    res.json({ data: updated });
  }),
);

export default router;
