import { useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import {
  createLookupValue,
  deleteLookupValue,
  fetchLookupValues,
  updateLookupValue,
} from "@/lib/api/lookups-admin";
import type { InsertLookupValue, LookupType, LookupValue } from "@shared/schema";
import {
  createEmptyValueForm,
  createValueFormFromRecord,
  mapValuePayload,
  type ValueFormState,
} from "../models/lookups-admin-models";
import {
  createMutationFeedbackHandlers,
  ensureRequiredValueFields,
  openCreateDialog,
  openEditDialog,
  submitNestedEntity,
  type SharedDeps,
} from "./_internals/shared";

interface ValuesArgs extends SharedDeps {
  selectedTypeId: number | null;
  selectedType: LookupType | null;
}

export function useLookupValuesController({
  toast,
  invalidateAll,
  selectedTypeId,
  selectedType,
}: ValuesArgs) {
  const [valueDialogOpen, setValueDialogOpen] = useState(false);
  const [editingValue, setEditingValue] = useState<LookupValue | null>(null);
  const [valueForm, setValueForm] = useState<ValueFormState>(createEmptyValueForm());
  const [valueToDelete, setValueToDelete] = useState<LookupValue | null>(null);

  const { data: lookupValues = [], isLoading: lookupValuesLoading } = useQuery({
    queryKey: ["lookup-admin", "values", selectedTypeId],
    queryFn: () => fetchLookupValues(selectedTypeId!),
    enabled: selectedTypeId != null,
  });

  const createValueMutation = useMutation({
    mutationFn: (payload: InsertLookupValue) => createLookupValue(payload),
    ...createMutationFeedbackHandlers({
      invalidate: invalidateAll,
      toast,
      successTitle: "تمت إضافة قيمة جديدة",
      errorTitle: "تعذر حفظ القيمة",
      onSuccess: () => setValueDialogOpen(false),
    }),
  });

  const updateValueMutation = useMutation({
    mutationFn: ({ id, payload }: { id: number; payload: Partial<InsertLookupValue> }) =>
      updateLookupValue(id, payload),
    ...createMutationFeedbackHandlers({
      invalidate: invalidateAll,
      toast,
      successTitle: "تم تحديث القيمة",
      errorTitle: "تعذر تحديث القيمة",
      onSuccess: () => setValueDialogOpen(false),
    }),
  });

  const deleteValueMutation = useMutation({
    mutationFn: (id: number) => deleteLookupValue(id),
    ...createMutationFeedbackHandlers({
      invalidate: invalidateAll,
      toast,
      successTitle: "تم حذف القيمة",
      errorTitle: "تعذر حذف القيمة",
      onSuccess: () => setValueToDelete(null),
    }),
  });

  const openCreateValueDialog = () => {
    openCreateDialog({
      setEditing: setEditingValue,
      setForm: setValueForm,
      createEmptyForm: createEmptyValueForm,
      setOpen: setValueDialogOpen,
    });
  };

  const openEditValueDialog = (record: LookupValue) => {
    openEditDialog({
      record,
      setEditing: setEditingValue,
      setForm: setValueForm,
      mapRecordToForm: createValueFormFromRecord,
      setOpen: setValueDialogOpen,
    });
  };

  const submitValue = () => {
    submitNestedEntity({
      selectedType,
      form: valueForm,
      editingRecord: editingValue,
      mapPayload: mapValuePayload,
      validate: ensureRequiredValueFields,
      create: (payload) => createValueMutation.mutate(payload),
      update: (record, payload) => updateValueMutation.mutate({ id: record.id, payload }),
      toast,
    });
  };

  return {
    lookupValues,
    lookupValuesLoading,
    valueDialogOpen,
    setValueDialogOpen,
    editingValue,
    valueForm,
    setValueForm,
    valueToDelete,
    setValueToDelete,
    openCreateValueDialog,
    openEditValueDialog,
    submitValue,
    createValueMutation,
    updateValueMutation,
    deleteValueMutation,
  };
}
