import { Router, type Request, type Response } from "express";
import { entityFilesModule, personsModule } from "@core/database";
import { insertPersonSchema } from "@shared/schema";
import personPhotoRouter from "./persons/photo";
import { getWriteContext, normalizeNulls } from "./_internals";

const router = Router();

router.use("/:id/photo", personPhotoRouter);

router.get("/", async (req: Request, res: Response) => {
  try {
    const search = req.query.search == null ? null : String(req.query.search);
    const limitRaw = req.query.limit == null ? undefined : Number(req.query.limit);
    const limit = Number.isFinite(limitRaw as number) ? Number(limitRaw) : undefined;
    const data = await personsModule.listPersons({ search, limit });
    res.json({ data });
  } catch (error) {
    console.error("Error listing persons:", error);
    res.status(500).json({ error: "فشل في جلب الأشخاص" });
  }
});

router.get("/search", async (req: Request, res: Response) => {
  try {
    const q = req.query.q == null ? null : String(req.query.q).trim();
    const firstName = req.query.firstName == null ? null : String(req.query.firstName).trim();
    const familyName = req.query.familyName == null ? null : String(req.query.familyName).trim();
    const personIdRaw = req.query.personId ?? req.query.id;
    const orgIdRaw = req.query.orgId;
    const branchIdRaw = req.query.branchId;
    const orgStructureIdRaw = req.query.orgStructureId;
    const genderIdRaw = req.query.genderId;
    const nationalityIdRaw = req.query.nationalityId;
    const maritalStatusIdRaw = req.query.maritalStatusId;
    const isActiveRaw = req.query.isActive;
    const cursorRaw = req.query.cursor;
    const limitRaw = req.query.limit;

    const personId = personIdRaw == null || personIdRaw === "" ? null : Number(personIdRaw);
    const orgId = orgIdRaw == null || orgIdRaw === "" ? null : Number(orgIdRaw);
    const branchId = branchIdRaw == null || branchIdRaw === "" ? null : Number(branchIdRaw);
    const orgStructureId = orgStructureIdRaw == null || orgStructureIdRaw === "" ? null : Number(orgStructureIdRaw);
    const genderId = genderIdRaw == null || genderIdRaw === "" ? null : Number(genderIdRaw);
    const nationalityId = nationalityIdRaw == null || nationalityIdRaw === "" ? null : Number(nationalityIdRaw);
    const maritalStatusId = maritalStatusIdRaw == null || maritalStatusIdRaw === "" ? null : Number(maritalStatusIdRaw);
    const isActive =
      isActiveRaw == null || isActiveRaw === ""
        ? null
        : String(isActiveRaw).trim().toLowerCase() === "true" || String(isActiveRaw).trim() === "1";
    const cursor = cursorRaw == null || cursorRaw === "" ? null : Number(cursorRaw);
    const limit = limitRaw == null || limitRaw === "" ? 50 : Math.max(1, Math.min(200, Number(limitRaw)));

    if (personId != null && Number.isFinite(personId)) {
      const person = await personsModule.getPersonById(personId);
      const nextCursor = null;
      return res.json({ data: person ? [person] : [], nextCursor });
    }

    const data = await personsModule.searchPersons(
      {
        q,
        firstName,
        familyName,
        orgId: Number.isFinite(orgId as number) ? (orgId as number) : null,
        branchId: Number.isFinite(branchId as number) ? (branchId as number) : null,
        orgStructureId: Number.isFinite(orgStructureId as number) ? (orgStructureId as number) : null,
        genderId: Number.isFinite(genderId as number) ? (genderId as number) : null,
        nationalityId: Number.isFinite(nationalityId as number) ? (nationalityId as number) : null,
        maritalStatusId: Number.isFinite(maritalStatusId as number) ? (maritalStatusId as number) : null,
        isActive,
        cursor: Number.isFinite(cursor as number) ? (cursor as number) : null,
        limit,
      },
    );

    const lastId = data.length ? Number((data[data.length - 1] as any).id) : null;
    const nextCursor = data.length && Number.isFinite(lastId) ? lastId : null;
    res.json({ data, nextCursor });
  } catch (error) {
    console.error("Error searching persons:", error);
    res.status(500).json({ error: "فشل في البحث عن الأشخاص" });
  }
});

router.get("/:id", async (req: Request, res: Response) => {
  try {
    const id = parseInt(req.params.id, 10);
    if (!Number.isFinite(id)) return res.status(400).json({ error: "معرف غير صالح" });
    const person = await personsModule.getPersonById(id);
    if (!person) return res.status(404).json({ error: "الشخص غير موجود" });
    res.json(person);
  } catch (error) {
    console.error("Error fetching person:", error);
    res.status(500).json({ error: "فشل في جلب بيانات الشخص" });
  }
});

router.patch("/:id", async (req: Request, res: Response) => {
  const parsed = insertPersonSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: "بيانات غير صالحة", details: parsed.error });
  }

  try {
    const id = parseInt(req.params.id, 10);
    if (!Number.isFinite(id)) return res.status(400).json({ error: "معرف غير صالح" });

    const { userId, workContextBy } = await getWriteContext(req);
    if (!userId) return res.status(401).json({ error: "غير مصرح" });

    const payload = normalizeNulls(parsed.data, [
      "fatherName",
      "grandfatherName",
      "greatGfName",
      "greatGreatGfName",
      "familyName",
      "dateOfBirth",
      "genderId",
      "nationalityId",
      "maritalStatusId",
    ]);

    const updated = await personsModule.updatePerson(
      id,
      payload,
      {
        workContextBy,
        updatedBy: userId,
      },
    );

    if (!updated) return res.status(404).json({ error: "الشخص غير موجود" });
    res.json(updated);
  } catch (error) {
    console.error("Error updating person:", error);
    res.status(500).json({ error: "فشل في تحديث بيانات الشخص" });
  }
});

router.get("/:id/contacts", async (req: Request, res: Response) => {
  try {
    const id = parseInt(req.params.id, 10);
    if (!Number.isFinite(id)) return res.status(400).json({ error: "معرف غير صالح" });
    const rows = await personsModule.getPersonContacts(id);
    res.json({ data: rows });
  } catch (error) {
    console.error("Error fetching person contacts:", error);
    res.status(500).json({ error: "فشل في جلب بيانات التواصل" });
  }
});

router.get("/:id/assignments", async (req: Request, res: Response) => {
  try {
    const id = parseInt(req.params.id, 10);
    if (!Number.isFinite(id)) return res.status(400).json({ error: "معرف غير صالح" });
    const rows = await personsModule.getPersonAssignments(id);
    res.json({ data: rows });
  } catch (error) {
    console.error("Error fetching person assignments:", error);
    res.status(500).json({ error: "فشل في جلب بيانات التعيينات" });
  }
});

router.post("/:id/assignments", async (req: Request, res: Response) => {
  try {
    const id = parseInt(req.params.id, 10);
    if (!Number.isFinite(id)) return res.status(400).json({ error: "معرف غير صالح" });

    const orgId = Number(req.body?.orgId);
    const branchId = Number(req.body?.branchId);
    const orgStructureId = Number(req.body?.orgStructureId);
    const isManager = !!req.body?.isManager;
    if (!Number.isFinite(orgId) || !Number.isFinite(branchId) || !Number.isFinite(orgStructureId)) {
      return res.status(400).json({ error: "بيانات التعيين غير مكتملة" });
    }

    const { userId, workContextBy } = await getWriteContext(req);
    if (!userId) return res.status(401).json({ error: "غير مصرح: الرجاء تسجيل الدخول" });

    const created = await personsModule.createPersonAssignment(
      id,
      { orgId, branchId, orgStructureId, isManager },
      { workContextBy, createdBy: userId },
    );

    res.status(201).json(created);
  } catch (error) {
    console.error("Error creating person assignment:", error);
    res.status(500).json({ error: "فشل في إنشاء تعيين وظيفي" });
  }
});

router.get("/:id/files", async (req: Request, res: Response) => {
  try {
    const id = parseInt(req.params.id, 10);
    if (!Number.isFinite(id)) return res.status(400).json({ error: "معرف غير صالح" });
    const role = req.query.role == null ? undefined : String(req.query.role);
    const rows = await entityFilesModule.getLinkedFiles("persons", id, role);
    res.json({
      data: rows.map((r) => ({
        id: r.link.id,
        role: r.link.role,
        isPrimary: r.link.isPrimary,
        createdAt: r.link.createdAt,
        file: {
          id: r.file.id,
          filePath: r.file.location ?? "",
          fileName: r.file.filenameDownload ?? null,
          title: r.file.title ?? null,
          mimeType: r.file.type ?? null,
          size: r.file.filesize ?? null,
          description: r.file.description ?? null,
          uploadedOn: r.file.uploadedOn ?? null,
        },
      })),
    });
  } catch (error) {
    console.error("Error fetching person files:", error);
    res.status(500).json({ error: "فشل في جلب ملفات الشخص" });
  }
});

export default router;
