import { useMemo } from "react";
import { Button, DataTable, type Column, EntityPageHeader, Tabs, TabsContent, TabsList, TabsTrigger } from "@secure-registry/components-ui";
import type { UiPageConfig, UiPageColumn, UiPageFormField } from "@/types/ui";
import { DynamicForm } from "@/components/forms/DynamicForm";
import type { LookupTypeWithValues, LookupValue } from "@shared/schema";

function getDuplicateCodes(items: Array<{ fieldCode: string }>): string[] {
  const counts = new Map<string, number>();
  for (const it of items) {
    const k = String(it?.fieldCode ?? "").trim();
    if (!k) continue;
    counts.set(k, (counts.get(k) ?? 0) + 1);
  }
  return Array.from(counts.entries())
    .filter(([, cnt]) => cnt > 1)
    .map(([k]) => k);
}

function uniqueByFieldCode<T extends { fieldCode: string }>(items: T[]): T[] {
  const seen = new Set<string>();
  const out: T[] = [];
  for (const it of items) {
    const k = String(it?.fieldCode ?? "").trim();
    if (!k) continue;
    if (seen.has(k)) continue;
    seen.add(k);
    out.push(it);
  }
  return out;
}

function sampleValueForColumn(col: UiPageColumn): any {
  if (col.lookupTypeId) return 1;
  const t = String(col.columnType || "").toLowerCase();
  if (t === "number") return 123;
  if (t === "boolean") return true;
  if (t === "date") return new Date().toISOString();
  return "مثال";
}

function buildSampleRows(config: UiPageConfig): any[] {
  const cols = Array.isArray(config.columns) ? config.columns : [];
  const visible = cols.filter((c) => c.isVisible);
  const row1: any = {};
  const row2: any = {};
  for (const col of visible) {
    row1[col.fieldCode] = sampleValueForColumn(col);
    row2[col.fieldCode] = sampleValueForColumn(col);
  }
  row2.id = row2.id ?? 456;
  return [row1, row2];
}

function buildTableColumns(config: UiPageConfig, lookupTypes: LookupTypeWithValues[]): Column<any>[] {
  const cols = Array.isArray(config.columns) ? config.columns : [];
  return cols
    .filter((c) => c.isVisible)
    .sort((a, b) => (a.orderIndex ?? 0) - (b.orderIndex ?? 0))
    .map((col: UiPageColumn) => ({
      key: col.fieldCode,
      header: col.nameAr,
      width: col.width || undefined,
      sortable: col.isSortable,
      render: (value: any) => {
        if (typeof value === "boolean") return value ? "نعم" : "لا";
        if (col.lookupTypeId) {
          const lookupType = lookupTypes.find((lt: LookupTypeWithValues) => lt.id === col.lookupTypeId);
          const lookupValue = lookupType?.values.find((v: LookupValue) => v.id == value || v.code == value);
          return lookupValue ? lookupValue.nameAr : value;
        }
        if (String(col.columnType || "").toLowerCase() === "date" && value) {
          try {
            return new Date(value).toLocaleDateString("ar-SA");
          } catch {
            return value;
          }
        }
        return value;
      },
    }));
}

function buildFormPreviewData(fields: UiPageFormField[]): Record<string, any> {
  const result: Record<string, any> = {};
  for (const field of fields) {
    const t = String(field.fieldType || "").toLowerCase();
    if (field.lookupTypeId) {
      result[field.fieldCode] = 1;
      continue;
    }
    if (t === "number") result[field.fieldCode] = 123;
    else if (t === "boolean") result[field.fieldCode] = false;
    else result[field.fieldCode] = "";
  }
  return result;
}

export function UiPageConfigPreview({
  config,
  lookupTypes,
  onSelectColumn,
  onSelectField,
  selectedColumnCode,
  selectedFieldCode,
}: {
  config: UiPageConfig;
  lookupTypes: LookupTypeWithValues[];
  onSelectColumn?: (fieldCode: string) => void;
  onSelectField?: (fieldCode: string) => void;
  selectedColumnCode?: string | null;
  selectedFieldCode?: string | null;
}) {
  const safeConfig = config;
  const visibleColumns = useMemo(() => {
    const cols = (Array.isArray(safeConfig.columns) ? safeConfig.columns : [])
      .filter((c) => c.isVisible)
      .sort((a, b) => (a.orderIndex ?? 0) - (b.orderIndex ?? 0));
    return uniqueByFieldCode(cols);
  }, [safeConfig]);

  const visibleFields = useMemo(() => {
    const fields = (Array.isArray(safeConfig.formFields) ? safeConfig.formFields : [])
      .filter((f) => f.isVisible !== false)
      .sort((a, b) => (a.orderIndex ?? 0) - (b.orderIndex ?? 0));
    return uniqueByFieldCode(fields);
  }, [safeConfig]);

  const columnDuplicates = useMemo(() => getDuplicateCodes(Array.isArray(safeConfig.columns) ? safeConfig.columns : []), [safeConfig]);
  const fieldDuplicates = useMemo(() => getDuplicateCodes(Array.isArray(safeConfig.formFields) ? safeConfig.formFields : []), [safeConfig]);

  const sampleRows = useMemo(() => buildSampleRows({ ...safeConfig, columns: visibleColumns } as any), [safeConfig, visibleColumns]);
  const tableColumns = useMemo(() => {
    const base = buildTableColumns({ ...safeConfig, columns: visibleColumns } as any, lookupTypes);
    return base.map((c: any) => {
      const fieldCode = String(c.key);
      const isSelected = selectedColumnCode != null && String(selectedColumnCode) === fieldCode;
      return {
        ...c,
        sortable: false,
        header: (
          <Button
            type="button"
            variant="ghost"
            className={`h-auto p-0 ${isSelected ? "underline font-semibold" : ""}`}
            onClick={() => onSelectColumn?.(fieldCode)}
          >
            {c.header}
          </Button>
        ),
      };
    });
  }, [safeConfig, lookupTypes, visibleColumns, onSelectColumn, selectedColumnCode]);
  const formInitialData = useMemo(() => buildFormPreviewData(visibleFields), [visibleFields]);

  return (
    <div className="space-y-4" dir="rtl">
      <EntityPageHeader title={safeConfig.nameAr} description={safeConfig.description} />
      {columnDuplicates.length > 0 || fieldDuplicates.length > 0 ? (
        <div className="text-sm text-destructive">
          {columnDuplicates.length > 0 ? `تكرار أعمدة: ${columnDuplicates.join("، ")}` : null}
          {columnDuplicates.length > 0 && fieldDuplicates.length > 0 ? " | " : null}
          {fieldDuplicates.length > 0 ? `تكرار حقول: ${fieldDuplicates.join("، ")}` : null}
        </div>
      ) : null}
      <Tabs defaultValue="list" dir="rtl">
        <TabsList className="w-full justify-start overflow-x-auto">
          <TabsTrigger value="list">القائمة</TabsTrigger>
          <TabsTrigger value="form">النموذج</TabsTrigger>
        </TabsList>
        <TabsContent value="list" className="mt-4">
          <DataTable data={sampleRows} columns={tableColumns} searchable={false} className="text-start" />
        </TabsContent>
        <TabsContent value="form" className="mt-4">
          <DynamicForm
            fields={visibleFields}
            lookupTypes={lookupTypes}
            initialData={formInitialData}
            onSubmit={() => undefined}
            isSubmitting={false}
            serverErrors={null}
            zodSchema={safeConfig.zodSchema}
            readOnly
            onFieldClick={onSelectField}
            selectedFieldCode={selectedFieldCode ?? null}
          />
        </TabsContent>
      </Tabs>
    </div>
  );
}
