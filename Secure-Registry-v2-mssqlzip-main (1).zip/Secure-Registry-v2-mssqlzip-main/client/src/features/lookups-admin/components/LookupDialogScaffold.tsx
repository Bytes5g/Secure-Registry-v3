import type { ReactNode } from "react";
import { EntityFormDialog, ToggleCard } from "@/components/shared";

interface LookupDialogScaffoldProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title: string;
  description: string;
  onSubmit: () => void;
  isSubmitting: boolean;
  activeDescription: string;
  isActive: boolean;
  onActiveChange: (checked: boolean) => void;
  children: ReactNode;
}

export function LookupDialogScaffold({
  open,
  onOpenChange,
  title,
  description,
  onSubmit,
  isSubmitting,
  activeDescription,
  isActive,
  onActiveChange,
  children,
}: LookupDialogScaffoldProps) {
  return (
    <EntityFormDialog
      title={title}
      description={description}
      open={open}
      onOpenChange={onOpenChange}
      onSubmit={onSubmit}
      isSubmitting={isSubmitting}
    >
      {children}
      <ToggleCard
        title="مفعل"
        description={activeDescription}
        checked={isActive}
        onCheckedChange={onActiveChange}
      />
    </EntityFormDialog>
  );
}
