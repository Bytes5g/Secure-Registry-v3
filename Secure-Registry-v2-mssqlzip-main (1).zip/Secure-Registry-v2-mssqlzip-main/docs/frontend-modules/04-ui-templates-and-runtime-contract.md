# معيار القوالب (Templates) + Runtime Contract

## المحتويات

- [1) الهدف](#1-الهدف)
- [2) ما الذي يُدار من DB وما الذي يبقى كود](#2-ما-الذي-يُدار-من-db-وما-الذي-يبقى-كود)
- [3) مفاتيح القوالب (Template Keys)](#3-مفاتيح-القوالب-المقترحة-template-keys)
- [4) معيار mapping_json](#4-معيار-mapping_json-ui_tab_data_sourcesmapping_json)
- [5) Runtime Hooks (Client)](#5-runtime-hooks-client)
- [6) ربط الصفحة بالقالب (Page ↔ Template Binding)](#6-ربط-الصفحة-بالقالب-page--template-binding)
- [7) Template Registry (Code)](#7-template-registry-code)
- [8) المصطلحات (Glossary)](#8-المصطلحات-glossary)
- [9) Task: تنفيذ UiRuntimePage + ترحيل الشاشات](#9-task-تنفيذ-uiruntimepage--ترحيل-الشاشات)

## 1) الهدف

توحيد بناء شاشات الإدارة بحيث:

- تعتمد كل صفحة على نفس القوالب المشتركة (Page Templates / Form Templates / Table Templates) بدل إنشاء صفحات مخصصة لكل دومين.
- تعتمد التهيئة على قاعدة البيانات كمصدر حقيقة (tabs + data sources + mapping) مع أقل قدر ممكن من hardcoding.
- تُركّب الصفحات داخل التخطيط العام (Global Layout) دون تعديل على الـ layout من داخل الصفحة.

## 2) ما الذي يُدار من DB وما الذي يبقى كود

### 2.1 ما يُدار من DB (Source of Truth)

- `ui_page_tabs.tab_options_json`
  - مفاتيح تعريف الصفحة (اسمها/نوعها/قالبها).
- `ui_tab_data_sources.mapping_json`
  - mapping للـ params + static params + pagination + تحويلات الأنواع.
- `ui_page_columns` و`ui_page_form_fields`
  - أعمدة العرض وحقول النماذج (بما في ذلك `remoteOptions`).

### 2.2 ما يبقى كود (Registry)

- القوالب نفسها هي React Components داخل `packages/core/components-ui` و`client/src/features/*`.
- DB يحدد “مفتاح القالب” وليس “كود القالب”.

السبب: القالب هو UI behavior/rendering ويحتاج build/versioning؛ بينما DB تُحدد الاختيار والتهيئة.

## 3) مفاتيح القوالب المقترحة (Template Keys)

هذه مفاتيح (Keys) تُخزّن في JSON داخل `ui_page_tabs.tab_options_json`:

- `pageTemplateKey`
  - أمثلة: `crud`, `search_table`, `profile_tabs`, `registry_builder`
- `searchTemplateKey` (اختياري)
  - أمثلة: `dynamic_form_basic_advanced`
- `tableTemplateKey` (اختياري)
  - أمثلة: `data_table_cursor`
- `statsTemplateKey` (اختياري)
  - أمثلة: `stats_grid`

المبدأ: مفتاح القالب يحدد “كيف نركب الصفحة”، بينما `UiPageConfig` يحدد “ماذا نعرض”.

## 4) معيار mapping_json (ui_tab_data_sources.mapping_json)

الغرض: ربط معايير البحث (criteria) بالـ query params المطلوبة لتنفيذ DataSource، بشكل موحد لكل tabs.

### 4.1 Schema مقترح

```json
{
  "params": { "q": "fullName", "orgId": "orgId" },
  "staticParams": { "includeUnassigned": 1 },
  "paramTypes": { "q": "trimmedString", "orgId": "number", "includeUnassigned": "boolean" },
  "limit": 50,
  "limitParam": "limit",
  "cursorParam": "cursor"
}
```

### 4.2 الحقول

- `params`: ربط `paramName` إلى `criteriaKey` (من قيم نموذج البحث).
- `staticParams`: قيم تُحقن دائماً مع الطلب.
- `paramTypes`: تحويلات اختيارية:
  - `number` → Number
  - `boolean` → 1/undefined
  - `string` → String
  - `trimmedString` → String.trim() أو undefined
- `limit/limitParam`: توحيد limit.
- `cursorParam`: توحيد cursor.

## 5) Runtime Hooks (Client)

الهدف: منع تكرار منطق “تحميل تفاصيل الصفحة/إدارة التبويبات/تنفيذ data sources”.

- `useUiPageDetails` لقراءة `/api/ui/pages/:pageCode/details`
- `useUiPageTabs` لاختيار `activeTabKey` (default tab + controlled state)
- `useUiTabDataSourceCursorList` لتنفيذ list مع cursor + load more
- `useUiTabDataSourceQuery` لتنفيذ stats/summary (query بسيط)

## 6) ربط الصفحة بالقالب (Page ↔ Template Binding)

المبدأ: الصفحة تُعرّف في DB (tabs + dataSources + config)، والقالب يُعرّف في الكود، والربط بينهما يتم عبر مفاتيح داخل `ui_page_tabs.tab_options_json`.

### 6.1 الحقول الأساسية داخل tab_options_json

- `pageNameAr`: اسم الصفحة (للـ registry UI)
- `entityType`: كود الـ entityType المستخدم في `/api/ui/pages/:pageCode/*`
- `pageTemplateKey`: مفتاح القالب (Page Template)

مثال:

```json
{
  "pageNameAr": "القوائم المرجعية",
  "entityType": "lookups",
  "pageTemplateKey": "search_table"
}
```

### 6.2 متطلبات القالب search_table (Contract)

- وجود `ui_page_columns` و`ui_page_form_fields` (أو توليدها من القاموس عبر `/api/ui/pages/:pageCode`)
- وجود DataSource للغرض `list` داخل `ui_tab_data_sources` للتبويب النشط
- اختيارياً: DataSource للغرض `stats` لنفس التبويب
- إذا لم توجد تهيئة DB: يجب أن يكون هناك fallback في الصفحة لتفادي كسر التشغيل

## 7) Template Registry (Code)

الهدف: منع الفوضى في أسماء القوالب وضمان أن أي `pageTemplateKey` معروف ومُدار كـ allowlist داخل الكود.

- Template Registry هو جدول مفاتيح داخل الكود (لا DB) يربط `pageTemplateKey` بمكوّن React.
- DB لا يخزّن “مسار ملف القالب” ولا “كود القالب”، فقط المفتاح.

## 8) المصطلحات (Glossary)

- Registry: مجموعة الجداول/الـ views التي تُعرّف صفحات UI (tabs/columns/formFields/dataSources) مع أي endpoints مساعدة.
- Templates: قوالب تركيب الصفحات (Page Templates) وقوالب فرعية (search/table/stats) تُعرّف في الكود ويُشار لها بمفاتيح.
- Runtime: طبقة تشغيل في العميل تستهلك تفاصيل الصفحة من API وتُنفّذ data sources وتُمرر النتائج للقوالب (Hooks + Renderer).
- mapping_json: JSON داخل `ui_tab_data_sources.mapping_json` يربط criteria بالـ params ويحدد التحويلات/pagination.

## 9) Task: تنفيذ UiRuntimePage + ترحيل الشاشات

### 9.1 الهدف التنفيذي

تأسيس Page Renderer عام (UiRuntimePage) يقرأ `pageTemplateKey` ويختار PageTemplate مناسب، ثم:

- يحمّل details/config من API
- يطبق runtime hooks
- يمرر النتائج إلى Page Template

### 9.2 نطاق البداية (Recommended)

- البداية بـ template واحد: `search_table`
- ثم ترحيل صفحات `/config` التي تتشابه:
  - `/config/lookups`
  - `/config/geo`
  - `/config/org-entities`
  - `/config/persons`
  - `/config/ui-page-overrides` (قالب خاص)

### 9.3 مخرجات قابلة للتحقق

- صفحات /config تعمل بنفس الشكل العام (Header/Tabs/Search/Table) بدون تكرار.
- أي اختلاف بين الشاشات يأتي من DB (tabs + config + mapping_json) وليس من hardcoding داخل الصفحة.
