import { createRequest, withTransaction, type SqlExecutor } from "../config/connection";
import {
  runQueryOne,
  selectRows,
  type SqlRow,
  type TableReference,
} from "./helpers";

export interface LookupConfig {
  id: number;
  code: string;
  aliasCode: string | null;
  nameAr: string;
  description: string | null;
  isActive: boolean;
  databaseName: string | null;
  schemaName: string | null;
  tableName: string | null;
  nameColumn: string | null;
  orderColumn: string | null;
  parentColumn: string | null;
  createdAtColumn: string | null;
  writable: boolean;
  valueProviderKey: string | null;
  providerStrategy: "override" | "fallback";
  createdAt: string | null;
  updatedAt: string | null;
  aliases: string[];
}

export interface LookupVirtualValue {
  id: number;
  typeId: number;
  valueId: number;
  code: string;
  nameAr: string;
  orderIndex: number;
  aliases: string[];
  createdAt: string | null;
}

export interface LookupConfigMutation {
  code: string;
  aliasCode?: string | null;
  nameAr: string;
  description?: string | null;
  isActive?: boolean;
  databaseName?: string | null;
  schemaName?: string | null;
  tableName?: string | null;
  nameColumn?: string | null;
  orderColumn?: string | null;
  parentColumn?: string | null;
  createdAtColumn?: string | null;
  writable?: boolean;
  valueProviderKey?: string | null;
  providerStrategy?: "override" | "fallback";
  aliases?: string[];
  workContextBy?: number | null;
  createdBy?: number | null;
  updatedBy?: number | null;
  isDeleted?: boolean | null;
}

interface LookupRegistrySnapshot {
  items: LookupConfig[];
  byId: Map<number, LookupConfig>;
  byCode: Map<string, LookupConfig>;
}

const LOOKUP_TYPES_TABLE: TableReference = {
  schemaName: "dbo",
  tableName: "lookup_types",
};

const lookup_virtual_value_TABLE: TableReference = {
  schemaName: "dbo",
  tableName: "lookup_virtual_values",
};

const REGISTRY_CACHE_TTL_MS = 60_000;
let registryCache: { snapshot: Promise<LookupRegistrySnapshot>; loadedAt: number } | null = null;

function normalizeLookupCode(code: string): string {
  return code.trim().toUpperCase();
}

function normalizeAliasCode(value: unknown, code: string): string | null {
  const alias = asOptionalText(value);
  if (!alias) {
    return null;
  }

  return normalizeLookupCode(alias);
}

function asOptionalText(value: unknown): string | null {
  if (value == null) {
    return null;
  }

  const text = String(value).trim();
  return text.length > 0 ? text : null;
}

function asBoolean(value: unknown): boolean {
  return Boolean(value);
}

function normalizeProviderStrategy(value: unknown): "override" | "fallback" {
  return String(value ?? "override").toLowerCase() === "fallback"
    ? "fallback"
    : "override";
}

function parseAliases(value: unknown): string[] {
  if (typeof value !== "string" || value.trim().length === 0) {
    return [];
  }

  try {
    const parsed = JSON.parse(value);
    if (!Array.isArray(parsed)) {
      return [];
    }

    return parsed
      .map((entry) => asOptionalText(entry))
      .filter((entry): entry is string => Boolean(entry));
  } catch {
    return [];
  }
}

function mapLookupConfig(row: SqlRow): LookupConfig {
  const code = String(row.code || "");
  const aliasCode = normalizeAliasCode(row.alias_code, code);
  const aliases = aliasCode && normalizeLookupCode(aliasCode) !== normalizeLookupCode(code) ? [aliasCode] : [];

  return {
    id: Number(row.id),
    code,
    aliasCode,
    nameAr: String(row.name_ar || ""),
    description: asOptionalText(row.description),
    isActive: asBoolean(row.is_active),
    databaseName: asOptionalText(row.database_name),
    schemaName: asOptionalText(row.schema_name),
    tableName: asOptionalText(row.table_name),
    nameColumn: asOptionalText(row.name_column),
    orderColumn: asOptionalText(row.order_column),
    parentColumn: asOptionalText(row.parent_column),
    createdAtColumn: asOptionalText(row.created_at_column),
    writable: asBoolean(row.writable),
    valueProviderKey: asOptionalText(row.value_provider_key),
    providerStrategy: normalizeProviderStrategy(row.provider_strategy),
    createdAt: row.created_at == null ? null : String(row.created_at),
    updatedAt: row.updated_at == null ? null : String(row.updated_at),
    aliases,
  };
}

function createRegistrySnapshot(items: LookupConfig[]): LookupRegistrySnapshot {
  const byId = new Map<number, LookupConfig>();
  const byCode = new Map<string, LookupConfig>();

  for (const item of items) {
    byId.set(item.id, item);
    byCode.set(normalizeLookupCode(item.code), item);

    for (const alias of item.aliases) {
      byCode.set(normalizeLookupCode(alias), item);
    }
  }

  return { items, byId, byCode };
}

async function loadRegistrySnapshot(): Promise<LookupRegistrySnapshot> {
  const rows = await selectRows<SqlRow>(LOOKUP_TYPES_TABLE, {
    columns: `
      t.id,
      t.code,
      t.alias_code,
      t.name_ar,
      t.description,
      t.is_active,
      t.database_name,
      t.schema_name,
      t.table_name,
      t.name_column,
      t.order_column,
      t.parent_column,
      t.created_at_column,
      t.writable,
      t.value_provider_key,
      t.provider_strategy,
      t.created_at,
      t.updated_at
    `,
    whereClause: "AS t WHERE (t.is_deleted = 0 OR t.is_deleted IS NULL)",
    orderByClause: "ORDER BY t.id",
  });

  return createRegistrySnapshot(rows.map(mapLookupConfig));
}

async function getLookupRegistrySnapshot(): Promise<LookupRegistrySnapshot> {
  if (!registryCache || Date.now() - registryCache.loadedAt > REGISTRY_CACHE_TTL_MS) {
    registryCache = { snapshot: loadRegistrySnapshot(), loadedAt: Date.now() };
  }
  return registryCache.snapshot;
}

export function clearLookupRegistryCache(): void {
  registryCache = null;
}

function toDbLookupPayload(
  payload: LookupConfigMutation,
): Required<Omit<LookupConfigMutation, "aliases">> & { aliasCode: string | null } {
  const code = normalizeLookupCode(payload.code);
  const tableName = asOptionalText(payload.tableName);
  const aliasCandidate = payload.aliasCode ?? payload.aliases?.[0] ?? null;

  return {
    code,
    aliasCode: normalizeAliasCode(aliasCandidate, code),
    nameAr: payload.nameAr.trim(),
    description: asOptionalText(payload.description),
    isActive: payload.isActive ?? true,
    databaseName: asOptionalText(payload.databaseName),
    schemaName: asOptionalText(payload.schemaName) ?? (tableName ? "dbo" : null),
    tableName,
    nameColumn: tableName ? asOptionalText(payload.nameColumn) ?? "name" : null,
    orderColumn: tableName ? asOptionalText(payload.orderColumn) : null,
    parentColumn: tableName ? asOptionalText(payload.parentColumn) : null,
    createdAtColumn: tableName ? asOptionalText(payload.createdAtColumn) ?? "created_at" : null,
    writable: payload.writable ?? true,
    valueProviderKey: asOptionalText(payload.valueProviderKey),
    providerStrategy: payload.providerStrategy ?? "override",
    workContextBy: payload.workContextBy ?? null,
    createdBy: payload.createdBy ?? null,
    updatedBy: payload.updatedBy ?? null,
    isDeleted: payload.isDeleted ?? null,
  };
}

function mergeLookupMutation(
  current: LookupConfig,
  patch: Partial<LookupConfigMutation>,
): LookupConfigMutation {
  return {
    code: patch.code ?? current.code,
    aliasCode: patch.aliasCode ?? current.aliasCode,
    nameAr: patch.nameAr ?? current.nameAr,
    description: patch.description ?? current.description,
    isActive: patch.isActive ?? current.isActive,
    databaseName: patch.databaseName ?? current.databaseName,
    schemaName: patch.schemaName ?? current.schemaName,
    tableName: patch.tableName ?? current.tableName,
    nameColumn: patch.nameColumn ?? current.nameColumn,
    orderColumn: patch.orderColumn ?? current.orderColumn,
    parentColumn: patch.parentColumn ?? current.parentColumn,
    createdAtColumn: patch.createdAtColumn ?? current.createdAtColumn,
    writable: patch.writable ?? current.writable,
    valueProviderKey: patch.valueProviderKey ?? current.valueProviderKey,
    providerStrategy: patch.providerStrategy ?? current.providerStrategy,
    aliases: patch.aliases ?? current.aliases,
    workContextBy: patch.workContextBy,
    createdBy: patch.createdBy,
    updatedBy: patch.updatedBy,
    isDeleted: patch.isDeleted,
  };
}

async function getNextLookupTypeId(executor?: SqlExecutor): Promise<number> {
  try {
    const seq = await runQueryOne<{ next_id: number }>(
      "SELECT NEXT VALUE FOR dbo.seq_lookup_types_id AS next_id",
      {},
      executor,
    );
    const nextId = Number(seq?.next_id);
    if (Number.isFinite(nextId) && nextId > 0) return nextId;
  } catch {
    // ignore
  }

  const row = await runQueryOne<{ next_id: number }>(
    "SELECT ISNULL(MAX(id), 0) + 1 AS next_id FROM dbo.lookup_types WITH (UPDLOCK, HOLDLOCK)",
    {},
    executor,
  );
  return Number(row?.next_id ?? 1);
}

export async function getLookupConfigs(): Promise<LookupConfig[]> {
  const snapshot = await getLookupRegistrySnapshot();
  return snapshot.items;
}

export async function getLookupConfigById(id: number): Promise<LookupConfig | undefined> {
  const snapshot = await getLookupRegistrySnapshot();
  return snapshot.byId.get(id);
}

export async function getLookupConfigByCode(code: string): Promise<LookupConfig | undefined> {
  const snapshot = await getLookupRegistrySnapshot();
  return snapshot.byCode.get(normalizeLookupCode(code));
}

export function getLookupTableReference(config: LookupConfig): TableReference | undefined {
  if (!config.tableName) {
    return undefined;
  }

  return {
    databaseName: config.databaseName,
    schemaName: config.schemaName,
    tableName: config.tableName,
  };
}

export async function getLookupVirtualValues(typeId: number): Promise<LookupVirtualValue[]> {
  const rows = await selectRows<SqlRow>(lookup_virtual_value_TABLE, {
    whereClause: "WHERE lookup_type_id = @typeId AND (is_deleted = 0 OR is_deleted IS NULL) AND is_active = 1",
    orderByClause: "ORDER BY order_index, value_id",
    params: { typeId },
  });

  return rows.map((row) => ({
    id: Number(row.id),
    typeId: Number(row.lookup_type_id),
    valueId: Number(row.value_id),
    code: String(row.code || ""),
    nameAr: String(row.name_ar || ""),
    orderIndex: Number(row.order_index || 0),
    aliases: parseAliases(row.aliases_json),
    createdAt: row.created_at == null ? null : String(row.created_at),
  }));
}

export async function createLookupConfig(
  payload: LookupConfigMutation,
): Promise<LookupConfig> {
  const normalized = toDbLookupPayload(payload);

  await withTransaction(async (tx) => {
    const id = await getNextLookupTypeId(tx);
    const request = await createRequest(tx);
    request.input("id", id);
    request.input("code", normalized.code);
    request.input("aliasCode", normalized.aliasCode);
    request.input("nameAr", normalized.nameAr);
    request.input("description", normalized.description);
    request.input("isActive", normalized.isActive);
    request.input("databaseName", normalized.databaseName);
    request.input("schemaName", normalized.schemaName);
    request.input("tableName", normalized.tableName);
    request.input("nameColumn", normalized.nameColumn);
    request.input("orderColumn", normalized.orderColumn);
    request.input("parentColumn", normalized.parentColumn);
    request.input("createdAtColumn", normalized.createdAtColumn);
    request.input("writable", normalized.writable);
    request.input("valueProviderKey", normalized.valueProviderKey);
    request.input("providerStrategy", normalized.providerStrategy);
    request.input("workContextBy", normalized.workContextBy);
    request.input("createdBy", normalized.createdBy);
    request.input("isDeleted", normalized.isDeleted ?? false);

    await request.query(
      `INSERT INTO dbo.lookup_types
       (
         id, code, alias_code, name_ar, description, is_active,
         database_name, schema_name, table_name,
         name_column, order_column, parent_column, created_at_column,
         writable, value_provider_key, provider_strategy,
         work_context_by, created_by, is_deleted
       )
       VALUES
       (
         @id, @code, @aliasCode, @nameAr, @description, @isActive,
         @databaseName, @schemaName, @tableName,
         @nameColumn, @orderColumn, @parentColumn, @createdAtColumn,
         @writable, @valueProviderKey, @providerStrategy,
         @workContextBy, @createdBy, @isDeleted
       )`,
    );
  });

  clearLookupRegistryCache();
  return (await getLookupConfigByCode(normalized.code)) as LookupConfig;
}

export async function updateLookupConfig(
  id: number,
  patch: Partial<LookupConfigMutation>,
): Promise<LookupConfig | undefined> {
  const current = await getLookupConfigById(id);
  if (!current) {
    return undefined;
  }

  const normalized = toDbLookupPayload(mergeLookupMutation(current, patch));

  await withTransaction(async (tx) => {
    const request = await createRequest(tx);
    request.input("id", id);
    request.input("code", normalized.code);
    request.input("aliasCode", normalized.aliasCode);
    request.input("nameAr", normalized.nameAr);
    request.input("description", normalized.description);
    request.input("isActive", normalized.isActive);
    request.input("databaseName", normalized.databaseName);
    request.input("schemaName", normalized.schemaName);
    request.input("tableName", normalized.tableName);
    request.input("nameColumn", normalized.nameColumn);
    request.input("orderColumn", normalized.orderColumn);
    request.input("parentColumn", normalized.parentColumn);
    request.input("createdAtColumn", normalized.createdAtColumn);
    request.input("writable", normalized.writable);
    request.input("valueProviderKey", normalized.valueProviderKey);
    request.input("providerStrategy", normalized.providerStrategy);
    request.input("workContextBy", normalized.workContextBy);
    request.input("updatedBy", normalized.updatedBy);
    request.input("isDeleted", normalized.isDeleted);

    await request.query(
      `UPDATE dbo.lookup_types
       SET
         code = @code,
         alias_code = @aliasCode,
         name_ar = @nameAr,
         description = @description,
         is_active = @isActive,
         database_name = @databaseName,
         schema_name = @schemaName,
         table_name = @tableName,
         name_column = @nameColumn,
         order_column = @orderColumn,
         parent_column = @parentColumn,
         created_at_column = @createdAtColumn,
         writable = @writable,
         value_provider_key = @valueProviderKey,
         provider_strategy = @providerStrategy,
         work_context_by = COALESCE(@workContextBy, work_context_by),
         updated_by = COALESCE(@updatedBy, updated_by),
         is_deleted = COALESCE(@isDeleted, is_deleted),
         updated_at = SYSUTCDATETIME()
       WHERE id = @id`,
    );
  });

  clearLookupRegistryCache();
  return getLookupConfigById(id);
}

export async function deleteLookupConfig(id: number, context?: { workContextBy?: number | null; updatedBy?: number | null }): Promise<boolean> {
  const current = await getLookupConfigById(id);
  if (!current) {
    return false;
  }

  await withTransaction(async (tx) => {
    const request = await createRequest(tx);
    request.input("lookupTypeId", id);
    request.input("workContextBy", context?.workContextBy ?? null);
    request.input("updatedBy", context?.updatedBy ?? null);

    await request.query(`
      UPDATE dbo.lookup_virtual_values
      SET
        is_deleted = 1,
        is_active = 0,
        work_context_by = COALESCE(@workContextBy, work_context_by),
        updated_by = COALESCE(@updatedBy, updated_by),
        updated_at = SYSUTCDATETIME()
      WHERE lookup_type_id = @lookupTypeId;

      UPDATE dbo.lookup_types
      SET
        is_deleted = 1,
        is_active = 0,
        work_context_by = COALESCE(@workContextBy, work_context_by),
        updated_by = COALESCE(@updatedBy, updated_by),
        updated_at = SYSUTCDATETIME()
      WHERE id = @lookupTypeId;
    `);
  });

  clearLookupRegistryCache();
  return true;
}
