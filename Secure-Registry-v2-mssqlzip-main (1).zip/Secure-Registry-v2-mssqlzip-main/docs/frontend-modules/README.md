# فهرس توثيق تطوير الواجهات وتقسيم الوحدات

هذا المجلد مخصص لتوثيق تطوير الواجهة الأمامية وتقسيم الوحدات حسب الفئات التشغيلية وأنواع الوحدات.

## المحتويات

1. [01-frontend-segmentation.md](./01-frontend-segmentation.md)
   - تقسيم الوحدات والواجهات حسب فئات المستخدمين وأنواع الوحدات.
2. [02-frontend-builder-and-governance.md](./02-frontend-builder-and-governance.md)
   - تصور واجهة ديناميكية قابلة للبناء والربط مع الصلاحيات والـ metadata.
3. [03-dynamic-ui-libraries-and-components.md](./03-dynamic-ui-libraries-and-components.md)
   - مرجع المكتبات والمكونات المقترحة/المعتمدة للبناء الديناميكي، مع توضيح مسارات الاستدعاء من packages والواجهة.
4. [04-ui-templates-and-runtime-contract.md](./04-ui-templates-and-runtime-contract.md)
   - معيار القوالب (Template Keys) + Runtime hooks + mapping_json contract.

## المبدأ الحاكم

الواجهة يجب أن تصبح مستهلكاً لبيانات التهيئة والصلاحيات، لا مكاناً لتعريف القواعد والسياسات بشكل ثابت.
