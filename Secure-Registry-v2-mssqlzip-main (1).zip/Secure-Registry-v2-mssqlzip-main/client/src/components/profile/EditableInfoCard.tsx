import type { ReactNode } from "react";
import { Check, Loader2, Pencil } from "lucide-react";
import { Button } from "@secure-registry/components-ui";

export interface EditableInfoCardProps {
  title: string;
  isEditing: boolean;
  isSaving?: boolean;
  errorMessage?: string | null;
  onEdit: () => void;
  onSave: () => void;
  onCancel: () => void;
  saveLabel?: string;
  cancelLabel?: string;
  editLabel?: string;
  children: ReactNode;
  /** Extra controls shown beside the edit button when not editing. */
  headerExtra?: ReactNode;
  className?: string;
  bodyClassName?: string;
}

/**
 * Generic shell for any editable info card on a profile page (org, user, person...).
 * Owns the header (title + edit/save/cancel toolbar) and error display.
 * Body content is fully pluggable through `children` — no entity-specific knowledge.
 */
export function EditableInfoCard({
  title,
  isEditing,
  isSaving = false,
  errorMessage,
  onEdit,
  onSave,
  onCancel,
  saveLabel = "حفظ",
  cancelLabel = "إلغاء",
  editLabel = "تعديل",
  children,
  headerExtra,
  className = "",
  bodyClassName = "p-4",
}: EditableInfoCardProps) {
  return (
    <div className={`rounded-lg border bg-card ${className}`}>
      <div className="flex items-center justify-between p-4 border-b">
        <h3 className="text-sm font-semibold">{title}</h3>
        <div className="flex items-center gap-2">
          {headerExtra}
          {!isEditing ? (
            <Button variant="ghost" size="sm" onClick={onEdit}>
              <Pencil className="h-3.5 w-3.5 ms-1" />
              {editLabel}
            </Button>
          ) : (
            <div className="flex gap-2">
              <Button variant="ghost" size="sm" onClick={onCancel} disabled={isSaving}>
                {cancelLabel}
              </Button>
              <Button size="sm" onClick={onSave} disabled={isSaving}>
                {isSaving ? (
                  <Loader2 className="h-3.5 w-3.5 animate-spin ms-1" />
                ) : (
                  <Check className="h-3.5 w-3.5 ms-1" />
                )}
                {saveLabel}
              </Button>
            </div>
          )}
        </div>
      </div>
      <div className={bodyClassName}>{children}</div>
      {errorMessage ? (
        <div className="px-4 pb-3 text-xs text-destructive">{errorMessage}</div>
      ) : null}
    </div>
  );
}
