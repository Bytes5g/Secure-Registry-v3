import { Router } from "express";
import settingsRouter from "./settings.routes";
import foldersRouter from "./folders.routes";
import filesRouter from "./files.routes";
import uploadRouter from "./upload.route";

const router = Router();

// Order matters: settings + folders + upload first so their specific
// paths are matched before the catch-all "/:id" in filesRouter.
router.use(settingsRouter);
router.use(foldersRouter);
router.use(uploadRouter);
router.use(filesRouter);

export default router;
