# دليل الوثائق للوكلاء (Docs Map)

هذا الملف بوابة منظمة لقراءة وثائق المشروع بدون تكرار محتواها. الهدف: توجيه أي وكيل/مطور إلى "مصدر الحقيقة" الصحيح بسرعة.

## 1) اقرأ بهذا الترتيب

1. صورة المشروع والواقع الحالي: [01-project-analysis.md](./01-project-analysis.md)
2. تدقيق البنية والتكرارات والقرارات: [02-structure-audit.md](./02-structure-audit.md)
3. تصور الصلاحيات والحوكمة: [03-permissions-governance-blueprint.md](./03-permissions-governance-blueprint.md)
4. معايير البيانات والحقول القياسية: [04-data-governance-and-temporal-standards.md](./04-data-governance-and-temporal-standards.md)
5. خارطة التنفيذ المرحلية: [05-execution-roadmap.md](./05-execution-roadmap.md)

## 2) وثائق الواجهة (Frontend Modules)

- فهرس: [frontend-modules/README.md](./frontend-modules/README.md)
- تقسيم وحدات الواجهة والفئات: [01-frontend-segmentation.md](./frontend-modules/01-frontend-segmentation.md)
- بناء الواجهة الديناميكي والحوكمة: [02-frontend-builder-and-governance.md](./frontend-modules/02-frontend-builder-and-governance.md)
- المكتبات والمكونات وسياسة الاستيراد: [03-dynamic-ui-libraries-and-components.md](./frontend-modules/03-dynamic-ui-libraries-and-components.md)

## 3) ملاحظات تنفيذ (Work Notes)

- UI Registry/Builder: [ui-registry-builder-notes.md](./work-notes/ui-registry-builder-notes.md)
- سجل الإنجاز (Progress): [progress.md](./work-notes/progress.md)

## 4) قواعد تشغيل الوكيل (اختصار)

هذه القواعد التشغيلية تُدار في الملف الجذري لأنها "سياسة تنفيذ" وليست وثيقة تحليل:

- قواعد العمل والمنهجية والمعايير التنفيذية: [AGENTS.md](../AGENTS.md)

ملاحظة: أي تفاصيل تشغيلية تظهر أثناء التطوير (قرارات حوكمة، تغييرات نماذج، سياسات تشغيل) يجب تثبيتها في:
- `AGENTS.md` إن كانت قاعدة تنفيذ لازمة لأي وكيل
- أو داخل إحدى الوثائق أعلاه إن كانت تحليل/تصميم/خطة
