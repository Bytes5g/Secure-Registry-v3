import { Router, type Request, type Response } from "express";
import { z } from "zod";
import { insertOrganizationalStructureSchema } from "@shared/schema";
import { storage } from "../../storage";
import orgLogoRouter from "./logo";
import orgCoverRouter from "./cover";
import { normalizeInputTypes, normalizeNulls, requireWriteContext } from "../_internals";

const router = Router();

router.use("/organizations/:id/logo", orgLogoRouter);
router.use("/organizations/:id/cover", orgCoverRouter);

// هذا الراوتر يوفّر CRUD للجهات (org_entities) مع حقن workContextBy وحقول التدقيق عند عمليات الكتابة
router.get("/organizations", async (req: Request, res: Response) => {
  try {
    const withDetails = req.query.details === "true";
    const includeInactive = req.query.includeInactive === "1" || req.query.includeInactive === "true";
    const organizations = withDetails
      ? await storage.getAllOrganizationsWithDetails({ includeInactive })
      : await storage.getAllOrganizations({ includeInactive });
    res.json(organizations);
  } catch (error) {
    console.error("Error fetching organizations:", error);
    res.status(500).json({ error: "فشل في جلب الجهات" });
  }
});

router.get("/organizations/:id", async (req: Request, res: Response) => {
  try {
    const id = parseInt((req.params as any).id);
    if (isNaN(id)) {
      return res.status(400).json({ error: "معرف غير صالح" });
    }

    const withDetails = req.query.details === "true";
    const organization = withDetails
      ? await storage.getOrganizationWithDetails(id)
      : await storage.getOrganization(id);

    if (!organization) {
      return res.status(404).json({ error: "الجهة غير موجودة" });
    }

    res.json(organization);
  } catch (error) {
    console.error("Error fetching organization:", error);
    res.status(500).json({ error: "فشل في جلب الجهة" });
  }
});

router.get("/organizations/:orgId/employees", async (req: Request, res: Response) => {
  try {
    const orgId = parseInt(req.params.orgId);
    if (isNaN(orgId)) {
      return res.status(400).json({ error: "معرف غير صالح" });
    }

    const employees = await storage.getOrgEmployees(orgId);
    res.json(employees);
  } catch (error) {
    console.error("Error fetching org employees:", error);
    res.status(500).json({ error: "فشل في جلب موظفي الجهة" });
  }
});

router.get("/organizations/children/:parentId", async (req: Request, res: Response) => {
  try {
    const parentId = (req.params as any).parentId === "null" ? null : parseInt((req.params as any).parentId);
    if (parentId !== null && isNaN(parentId)) {
      return res.status(400).json({ error: "معرف غير صالح" });
    }

    const includeInactive = req.query.includeInactive === "1" || req.query.includeInactive === "true";
    const children = await storage.getOrganizationsByParentId(parentId, { includeInactive });
    res.json(children);
  } catch (error) {
    console.error("Error fetching organization children:", error);
    res.status(500).json({ error: "فشل في جلب الجهات الفرعية" });
  }
});

router.post("/organizations", async (req: Request, res: Response) => {
  try {
    const body = normalizeNulls(req.body, ["sectorId", "locationId", "categoryId", "parentId"]);
    const normalized = normalizeInputTypes(body, {
      intFields: ["sectorId", "locationId", "categoryId", "parentId", "orderIndex"],
      boolFields: ["isActive"],
    });
    const validated = insertOrganizationalStructureSchema.parse(normalized);
    const ctx = await requireWriteContext(req);
    const organization = await storage.createOrganization({
      ...validated,
      workContextBy: ctx.workContextBy,
      createdBy: ctx.userId,
    } as any);
    res.status(201).json(organization);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ error: "بيانات غير صالحة", details: error.errors });
    }
    console.error("Error creating organization:", error);
    res.status(500).json({ error: "فشل في إنشاء الجهة" });
  }
});

router.patch("/organizations/:id", async (req: Request, res: Response) => {
  try {
    const id = parseInt((req.params as any).id);
    if (isNaN(id)) {
      return res.status(400).json({ error: "معرف غير صالح" });
    }

    const body = normalizeNulls(req.body, ["sectorId", "locationId", "categoryId", "parentId"]);
    const normalized = normalizeInputTypes(body, {
      intFields: ["sectorId", "locationId", "categoryId", "parentId", "orderIndex"],
      boolFields: ["isActive"],
    });
    const ctx = await requireWriteContext(req);
    const organization = await storage.updateOrganization(id, {
      ...normalized,
      workContextBy: (normalized as any).workContextBy ?? ctx.workContextBy,
      updatedBy: ctx.userId,
      updatedAt: new Date(),
    } as any);
    if (!organization) {
      return res.status(404).json({ error: "الجهة غير موجودة" });
    }

    res.json(organization);
  } catch (error) {
    console.error("Error updating organization:", error);
    res.status(500).json({ error: "فشل في تحديث الجهة" });
  }
});

router.delete("/organizations/:id", async (req: Request, res: Response) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ error: "معرف غير صالح" });
    }

    const ctx = await requireWriteContext(req);
    const updated = await storage.updateOrganization(id, {
      isDeleted: true,
      isActive: false,
      workContextBy: ctx.workContextBy,
      updatedBy: ctx.userId,
      updatedAt: new Date(),
    } as any);
    if (!updated) {
      return res.status(404).json({ error: "الجهة غير موجودة" });
    }

    res.status(204).send();
  } catch (error) {
    console.error("Error deleting organization:", error);
    res.status(500).json({ error: "فشل في حذف الجهة" });
  }
});

export default router;
