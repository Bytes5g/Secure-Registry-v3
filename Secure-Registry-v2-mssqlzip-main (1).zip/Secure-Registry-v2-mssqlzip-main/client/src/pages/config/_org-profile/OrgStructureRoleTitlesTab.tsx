import { GenericEntityPage } from "@/components/generic/GenericEntityPage";
import { EntityContentCard } from "@secure-registry/components-ui";
import { PAGE_CODES } from "@/lib/constants";
import { ORG_STRUCTURE_ROLE_TITLES_CONFIG } from "./configs";

export function OrgStructureRoleTitlesTab({ orgId }: { orgId: number }) {
  return (
    <EntityContentCard>
      <GenericEntityPage
        entityType="orgStructureRoleTitles"
        pageCode={PAGE_CODES.ORG_STRUCTURE_ROLE_TITLES}
        staticConfig={ORG_STRUCTURE_ROLE_TITLES_CONFIG}
        apiParams={{ orgId }}
        defaultValues={{ orgId }}
        hideTitle={true}
      />
    </EntityContentCard>
  );
}
