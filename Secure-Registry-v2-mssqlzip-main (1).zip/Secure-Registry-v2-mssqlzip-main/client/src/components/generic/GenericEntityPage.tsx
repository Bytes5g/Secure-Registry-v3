import { useGenericEntity } from "@/hooks/useGenericEntity";
import { GenericEntityDialogStack } from "@secure-registry/components-ui";
import { Button, DataTable, type Column, EntityPageHeader } from "@secure-registry/components-ui";
import { useMemo, type ReactNode } from "react";
import { Loader2, Plus } from "lucide-react";
import type { UiPageColumn, UiPageConfig } from "@/types/ui";
import type { LookupTypeWithValues, LookupValue } from "@shared/schema";
import { DynamicForm } from "@/components/forms/DynamicForm";
import { useQuery } from "@tanstack/react-query";
import { genericApi } from "@/lib/api/generic";
import { buildGenericEntityTableColumns, buildRuntimeConfig } from "./genericEntityPageUtils";

interface GenericEntityPageProps {
  entityType: string;
  pageCode: string;
  title?: string;
  description?: string;
  formCode?: string; // Optional: if the page uses a specific form variant
  extraColumns?: Column<any>[]; // For custom actions or computed columns
  children?: ReactNode; // For extra dialogs or components
  apiParams?: Record<string, any>; // Optional: filter parameters for the API
  defaultValues?: Record<string, any>; // Default values for new items
  onMutationSuccess?: (data: any) => void; // Callback after successful create/update/delete
  hideTitle?: boolean; // Whether to hide the page title
  onAddClick?: () => void; // Custom handler for add button
  onEditClick?: (item: any) => void; // Custom handler for edit action
  disableAdd?: boolean; // Hide add button
  disableDelete?: boolean; // Hide delete action
  staticConfig?: UiPageConfig; // Static configuration to bypass DB fetch
}

export function GenericEntityPage({
  entityType,
  pageCode,
  title,
  description,
  formCode = "default",
  extraColumns = [],
  children,
  apiParams,
  defaultValues,
  onMutationSuccess,
  hideTitle = false,
  onAddClick,
  onEditClick,
  disableAdd = false,
  disableDelete = false,
  staticConfig,
  extraLookups = []
}: GenericEntityPageProps & { extraLookups?: LookupTypeWithValues[] }) {
  const pageConfigQuery = useQuery({
    queryKey: ["ui-page-config", pageCode, entityType, formCode],
    enabled: !staticConfig,
    queryFn: () => genericApi.getUiPageConfig(pageCode, entityType),
  });

  const resolvedConfig = staticConfig ?? (pageConfigQuery.data as UiPageConfig | undefined);

  const {
    entities,
    dbMeta,
    isLoading,
    lookupTypes: systemLookups,
    isDialogOpen,
    setIsDialogOpen,
    isDeleteDialogOpen,
    setIsDeleteDialogOpen,
    selectedItem,
    setSelectedItem,
    serverErrors,
    createMutation,
    updateMutation,
    deleteMutation,
  } = useGenericEntity({
    entityType,
    apiParams,
    defaultValues,
    onMutationSuccess,
    staticConfig: resolvedConfig,
  });

  const allLookups = [...systemLookups, ...extraLookups];

  const orgIdForTree = useMemo(() => {
    const raw = apiParams?.orgId ?? defaultValues?.orgId ?? null;
    const parsed = Number(raw);
    return Number.isFinite(parsed) ? parsed : null;
  }, [apiParams?.orgId, defaultValues?.orgId]);

  const { data: orgStructureAllNodes = [] } = useQuery({
    queryKey: ["orgStructureTree", "options", orgIdForTree],
    enabled: entityType === "orgStructureTree" && orgIdForTree != null,
    queryFn: () => genericApi.getAll("orgStructureTree", { orgId: orgIdForTree }),
  });

  const config = resolvedConfig;

  const runtimeConfig = config
    ? buildRuntimeConfig({
        entityType,
        config,
        entities,
        orgStructureAllNodes: orgStructureAllNodes as any,
      })
    : null;

  // Handlers
  const handleAdd = () => {
    if (onAddClick) {
      onAddClick();
      return;
    }
    setSelectedItem(defaultValues || {});
    setIsDialogOpen(true);
  };

  const handleEdit = (item: any) => {
    if (onEditClick) {
      onEditClick(item);
      return;
    }
    setSelectedItem(item);
    setIsDialogOpen(true);
  };

  const handleDelete = (item: any) => {
    setSelectedItem(item);
    setIsDeleteDialogOpen(true);
  };

  const handleConfirmDelete = () => {
    if (selectedItem?.id) {
      deleteMutation.mutate(selectedItem.id);
    }
  };

  const handleSubmit = (formData: any) => {
    if (selectedItem?.id) {
      updateMutation.mutate({ id: selectedItem.id, data: formData });
    } else {
      createMutation.mutate(formData);
    }
  };

  // Helper to map UI columns to DataTable columns
  const getTableColumns = () =>
    buildGenericEntityTableColumns({ config, dbMeta, allLookups, extraColumns });

  const isPageLoading = isLoading || (!staticConfig && pageConfigQuery.isLoading);

  if (isPageLoading) {
    return (
      <div className="flex items-center justify-center h-full min-h-[400px]">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (!runtimeConfig && pageConfigQuery.isError) {
    return (
      <div className="text-center p-8 text-destructive">
        فشل تحميل إعدادات الصفحة ({pageCode})
      </div>
    );
  }

  if (!runtimeConfig) {
    return (
      <div className="text-center p-8 text-destructive">
        فشل تحميل إعدادات الصفحة ({pageCode})
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <EntityPageHeader
        title={title || runtimeConfig.nameAr}
        description={description || runtimeConfig.description}
        hideTitle={hideTitle}
        actions={
          !disableAdd ? (
            <Button onClick={handleAdd}>
              <Plus className="me-2 h-4 w-4" />
              إضافة جديد
            </Button>
          ) : null
        }
      />

      <DataTable
        data={entities}
        columns={getTableColumns()}
        searchable={true}
        onEdit={handleEdit}
        onDelete={disableDelete ? undefined : handleDelete}
        isLoading={isLoading}
        className="text-start"
      />

      <GenericEntityDialogStack
        open={isDialogOpen}
        onOpenChange={setIsDialogOpen}
        isEditing={Boolean(selectedItem?.id)}
        deleteOpen={isDeleteDialogOpen}
        onDeleteOpenChange={setIsDeleteDialogOpen}
        onConfirmDelete={handleConfirmDelete}
        isDeleting={deleteMutation.isPending}
      >
        <DynamicForm
          fields={runtimeConfig.formFields}
          lookupTypes={allLookups}
          initialData={selectedItem || {}}
          onSubmit={handleSubmit}
          isSubmitting={createMutation.isPending || updateMutation.isPending}
          serverErrors={serverErrors}
          zodSchema={runtimeConfig.zodSchema}
        />
      </GenericEntityDialogStack>
      
      {children}
    </div>
  );
}
