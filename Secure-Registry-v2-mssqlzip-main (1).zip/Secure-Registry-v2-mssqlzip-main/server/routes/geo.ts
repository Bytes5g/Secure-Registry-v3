import { Router, type Request } from "express";
import { z } from "zod";
import { storage } from "../storage";
import { insertGeoAdminUnitSchema } from "@shared/schema";
import { requireWriteContext } from "./_internals";

const router = Router();

// هذه الدالة توحّد أخطاء الكتابة الشائعة القادمة من قاعدة البيانات إلى استجابات API مفهومة للواجهة
function getGeoWriteErrorResponse(error: unknown) {
  const message = error instanceof Error ? error.message : String(error);

  if (message.includes("FK_geo_admin_units_admin_level")) {
    return {
      status: 400,
      body: { error: "Invalid geo level. Use an existing id from /api/geo/levels." },
    };
  }

  if (message.includes("FOREIGN KEY constraint")) {
    return {
      status: 400,
      body: { error: "Invalid geo reference data." },
    };
  }

  if (message.includes("REFERENCE constraint")) {
    return {
      status: 409,
      body: { error: "Cannot delete geo admin unit because related records exist." },
    };
  }

  return undefined;
}

const paginationSchema = z.object({
  page: z.coerce.number().int().positive().default(1),
  limit: z.coerce.number().int().min(1).max(500).default(20),
  search: z.string().optional(),
  level: z.coerce.number().int().optional(),
  parentId: z.union([z.coerce.number().int(), z.literal("null")]).optional(),
  countryId: z.coerce.number().int().optional(),
});

router.get("/countries", async (_req, res) => {
  try {
    const countries = await storage.getGeoCountries();
    res.json(countries);
  } catch (error) {
    console.error("Error fetching geo countries:", error);
    res.status(500).json({ error: "Failed to fetch geo countries" });
  }
});

const updateCountryOrderSchema = z.object({
  orderIndex: z.coerce.number().int(),
});

router.patch("/countries/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id, 10);
    if (!Number.isFinite(id)) {
      return res.status(400).json({ error: "Invalid id parameter" });
    }
    const parsed = updateCountryOrderSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: "Invalid payload", details: parsed.error });
    }

    const updated = await storage.updateGeoCountryOrderIndex(id, parsed.data.orderIndex);
    if (!updated) {
      return res.status(404).json({ error: "Country not found" });
    }
    res.json(updated);
  } catch (error) {
    console.error("Error updating geo country order:", error);
    res.status(500).json({ error: "Failed to update geo country order" });
  }
});

// Get all geo admin units with pagination and filtering
router.get("/units", async (req, res) => {
  try {
    const params = paginationSchema.safeParse(req.query);
    if (!params.success) {
      return res.status(400).json({ error: "Invalid query parameters", details: params.error });
    }
    
    const { page, limit, search, level, parentId, countryId } = params.data;
    const pid = parentId === undefined ? undefined : parentId === "null" ? null : parentId;
    const result = await storage.queryGeoAdminUnits({
      page,
      limit,
      search,
      level,
      parentId: pid,
      countryId,
    });
    
    res.json({
      data: result.data,
      pagination: {
        page,
        limit,
        total: result.total,
        totalPages: Math.ceil(result.total / limit),
      }
    });
  } catch (error) {
    console.error("Error fetching geo admin units:", error);
    res.status(500).json({ error: "Failed to fetch geo admin units" });
  }
});

// Get geo admin units by level
router.get("/units/level/:level", async (req, res) => {
  try {
    const level = parseInt((req.params as any).level);
    if (isNaN(level)) {
      return res.status(400).json({ error: "Invalid level parameter" });
    }
    const units = await storage.getGeoAdminUnitsByLevel(level);
    res.json(units);
  } catch (error) {
    console.error("Error fetching geo admin units by level:", error);
    res.status(500).json({ error: "Failed to fetch geo admin units" });
  }
});

// Get geo admin units by parent
router.get("/units/children/:parentId", async (req, res) => {
  try {
    const parentId = (req.params as any).parentId === "null" ? null : parseInt((req.params as any).parentId);
    if ((req.params as any).parentId !== "null" && isNaN(parentId as number)) {
      return res.status(400).json({ error: "Invalid parentId parameter" });
    }
    const units = await storage.getGeoAdminUnitsByParentId(parentId);
    res.json(units);
  } catch (error) {
    console.error("Error fetching geo admin units children:", error);
    res.status(500).json({ error: "Failed to fetch geo admin units" });
  }
});

// Get single geo admin unit
router.get("/units/:id", async (req, res) => {
  try {
    const id = parseInt((req.params as any).id);
    if (isNaN(id)) {
      return res.status(400).json({ error: "Invalid id parameter" });
    }
    const unit = await storage.getGeoAdminUnit(id);
    if (!unit) {
      return res.status(404).json({ error: "Geo admin unit not found" });
    }
    res.json(unit);
  } catch (error) {
    console.error("Error fetching geo admin unit:", error);
    res.status(500).json({ error: "Failed to fetch geo admin unit" });
  }
});

// هذا المسار ينشئ وحدة إدارية ويحقن workContextBy و createdBy من session
router.post("/units", async (req, res) => {
  try {
    const parsed = insertGeoAdminUnitSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: "Invalid unit data", details: parsed.error });
    }
    const ctx = await requireWriteContext(req);
    const unit = await storage.createGeoAdminUnit({
      ...(parsed.data as any),
      workContextBy: ctx.workContextBy,
      createdBy: ctx.userId,
    } as any);
    res.status(201).json(unit);
  } catch (error) {
    const mappedError = getGeoWriteErrorResponse(error);
    if (mappedError) {
      return res.status(mappedError.status).json(mappedError.body);
    }
    console.error("Error creating geo admin unit:", error);
    res.status(500).json({ error: "Failed to create geo admin unit" });
  }
});

// هذا المسار يحدّث وحدة إدارية ويضمن حقن workContextBy و updatedBy من session مع السماح بتجاوز workContextBy فقط إن توفر في body
router.patch("/units/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ error: "Invalid id parameter" });
    }
    const partialSchema = insertGeoAdminUnitSchema.partial();
    const parsed = partialSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: "Invalid unit data", details: parsed.error });
    }
    const ctx = await requireWriteContext(req);
    const unit = await storage.updateGeoAdminUnit(id, {
      ...(parsed.data as any),
      workContextBy: (parsed.data as any).workContextBy ?? ctx.workContextBy,
      updatedBy: ctx.userId,
      updatedAt: new Date(),
    } as any);
    if (!unit) {
      return res.status(404).json({ error: "Geo admin unit not found" });
    }
    res.json(unit);
  } catch (error) {
    const mappedError = getGeoWriteErrorResponse(error);
    if (mappedError) {
      return res.status(mappedError.status).json(mappedError.body);
    }
    console.error("Error updating geo admin unit:", error);
    res.status(500).json({ error: "Failed to update geo admin unit" });
  }
});

// هذا المسار يحذف منطقياً (Soft-delete) وحدة إدارية ويحقن workContextBy و updatedBy من session
router.delete("/units/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ error: "Invalid id parameter" });
    }
    const ctx = await requireWriteContext(req);
    const updated = await storage.updateGeoAdminUnit(id, {
      isDeleted: true,
      isActive: false,
      workContextBy: ctx.workContextBy,
      updatedBy: ctx.userId,
      updatedAt: new Date(),
    } as any);
    if (!updated) {
      return res.status(404).json({ error: "Geo admin unit not found" });
    }
    res.status(204).send();
  } catch (error) {
    const mappedError = getGeoWriteErrorResponse(error);
    if (mappedError) {
      return res.status(mappedError.status).json(mappedError.body);
    }
    console.error("Error deleting geo admin unit:", error);
    res.status(500).json({ error: "Failed to delete geo admin unit" });
  }
});

// Get geo level types from geo_codes
router.get("/levels", async (req, res) => {
  try {
    const levels = await storage.getGeoLevels();
    res.json(levels);
  } catch (error) {
    console.error("Error fetching geo levels:", error);
    res.status(500).json({ error: "Failed to fetch geo levels" });
  }
});

// هذا المسار ينفذ إدخال جماعي لوحدات إدارية مع حقن workContextBy و createdBy من session
router.post("/units/bulk", async (req, res) => {
  try {
    const schema = z.array(insertGeoAdminUnitSchema);
    const parsed = schema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: "Invalid units data", details: parsed.error });
    }
    const ctx = await requireWriteContext(req);
    const units = await storage.createManyGeoAdminUnits(
      parsed.data.map((u) => ({
        ...(u as any),
        workContextBy: ctx.workContextBy,
        createdBy: ctx.userId,
      })) as any,
    );
    res.status(201).json({ created: units.length, units });
  } catch (error) {
    const mappedError = getGeoWriteErrorResponse(error);
    if (mappedError) {
      return res.status(mappedError.status).json(mappedError.body);
    }
    console.error("Error bulk creating geo admin units:", error);
    res.status(500).json({ error: "Failed to bulk create geo admin units" });
  }
});

export default router;
