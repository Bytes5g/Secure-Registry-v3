import { useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Badge, Button, EntityContentCard, type Column } from "@secure-registry/components-ui";
import { DataTable } from "@secure-registry/components-ui";
import { createPersonAssignment, fetchPersonAssignments, type PersonAssignmentItem } from "@/lib/api/persons-admin";
import { DynamicForm } from "@/components/forms/DynamicForm";
import type { UiPageFormField } from "@/types/ui";
import { useToast } from "@/hooks/use-toast";

function formatDateTime(value: unknown) {
  return value ? new Date(String(value)).toLocaleString("ar-SA") : "—";
}

export function PersonAssignmentsTab({ personId }: { personId: number }) {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [initialData, setInitialData] = useState<any>({});
  const { data = [], isLoading } = useQuery<PersonAssignmentItem[]>({
    queryKey: ["person-assignments", personId],
    queryFn: () => fetchPersonAssignments(personId),
    enabled: Number.isFinite(personId) && personId > 0,
  });

  const createMutation = useMutation({
    mutationFn: async (values: any) => {
      const orgId = Number(values?.orgId);
      const branchId = Number(values?.branchId);
      const orgStructureId = Number(values?.orgStructureId);
      const isManager = !!values?.isManager;
      return createPersonAssignment(personId, { orgId, branchId, orgStructureId, isManager });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["person-assignments", personId] });
      setInitialData({});
    },
    onError: (error: any) => {
      toast({
        title: "فشل في إضافة التعيين",
        description: String(error?.message ?? "تعذر تنفيذ العملية"),
        variant: "destructive",
      });
    },
  });

  const formFields = useMemo<UiPageFormField[]>(
    () => [
      {
        fieldCode: "orgId",
        nameAr: "الجهة",
        fieldType: "select",
        isRequired: true,
        isVisible: true,
        orderIndex: 1,
        gridCols: 4,
        config: {
          clearOnChange: ["branchId", "orgStructureId"],
          remoteOptions: {
            variants: [
              {
                path: "/api/org/organizations",
                response: "array",
                valueKey: "id",
                labelKey: "name",
                query: { includeInactive: 1 },
              },
            ],
          },
        },
      },
      {
        fieldCode: "branchId",
        nameAr: "الفرع",
        fieldType: "select",
        isRequired: true,
        isVisible: true,
        orderIndex: 2,
        gridCols: 4,
        config: {
          clearOnChange: ["orgStructureId"],
          remoteOptions: {
            variants: [
              {
                when: { field: "orgId", op: "notEmpty" },
                path: "/api/branches",
                response: "array",
                valueKey: "id",
                labelKey: "name",
                clientFilter: { field: "orgId", recordKey: "orgId" },
              },
            ],
          },
        },
      },
      {
        fieldCode: "orgStructureId",
        nameAr: "الوحدة",
        fieldType: "select",
        isRequired: true,
        isVisible: true,
        orderIndex: 3,
        gridCols: 4,
        config: {
          remoteOptions: {
            variants: [
              {
                path: "/api/org/organizations/{orgId}/tree/flat",
                response: "array",
                valueKey: "id",
                labelKey: "name",
                query: { includeInactive: 1 },
              },
            ],
          },
        },
      },
      { fieldCode: "isManager", nameAr: "مسؤول", fieldType: "boolean", isRequired: false, isVisible: true, orderIndex: 4, gridCols: 4 },
    ],
    [],
  );

  const columns = useMemo<Column<PersonAssignmentItem>[]>(
    () => [
      { key: "orgName", header: "الجهة", sortable: true, render: (_, row) => row.orgName ?? `#${row.orgId}` },
      { key: "branchName", header: "الفرع", sortable: true, render: (_, row) => row.branchName ?? `#${row.branchId}` },
      { key: "orgStructureName", header: "الوحدة", sortable: true, render: (_, row) => row.orgStructureName ?? `#${row.orgStructureId}` },
      {
        key: "isManager",
        header: "مسؤول",
        width: "80px",
        render: (_, row) => (row.isManager ? <Badge>نعم</Badge> : <Badge variant="secondary">لا</Badge>),
      },
      { key: "createdAt", header: "تاريخ التعيين", render: (_, row) => formatDateTime(row.createdAt) },
    ],
    [],
  );

  return (
    <EntityContentCard>
      <div className="p-4 border-b" dir="rtl">
        <div className="flex items-center justify-between mb-3">
          <div className="font-semibold text-sm">إضافة تعيين وظيفي</div>
          <Button type="button" variant="outline" onClick={() => setInitialData({})}>
            تفريغ
          </Button>
        </div>
        <DynamicForm
          fields={formFields}
          initialData={initialData}
          onSubmit={(values) => createMutation.mutate(values)}
          isSubmitting={createMutation.isPending}
          readOnly={false}
          submitLabel="إضافة"
          submitPendingLabel="جاري الإضافة..."
        />
      </div>
      <DataTable
        data={Array.isArray(data) ? data : []}
        columns={columns}
        isLoading={isLoading}
        emptyMessage="لا توجد تعيينات وظيفية لهذا الشخص"
      />
    </EntityContentCard>
  );
}
