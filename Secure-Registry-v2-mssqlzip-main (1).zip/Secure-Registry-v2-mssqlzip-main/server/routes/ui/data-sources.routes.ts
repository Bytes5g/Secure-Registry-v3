import { Router } from "express";
import { uiDataSourcesModule } from "@core/database";

const router = Router();

router.get("/:dataSourceKey/execute", async (req, res) => {
  try {
    // @ts-ignore
    const user = req.session?.user;
    if (!user?.id) return res.status(401).json({ error: "Unauthorized" });
    const userId = Number(user.id);
    if (!Number.isFinite(userId)) return res.status(400).json({ error: "Invalid user id" });

    const result = await uiDataSourcesModule.executeDataSourceByKey(
      req.params.dataSourceKey,
      req.query as any,
      {
        userId,
        role: user.role ?? null,
        isSuperAdmin: Boolean(user.isSuperAdmin),
        permissions: Array.isArray(user.permissions) ? user.permissions : [],
      },
    );
    res.json(result);
  } catch (error: any) {
    console.error("Error executing UI data source:", error);
    const message = error?.message ?? "Failed to execute data source";
    if (String(message).includes("not found")) return res.status(404).json({ error: message });
    if (String(message).includes("Not authorized")) return res.status(403).json({ error: message });
    if (String(message).includes("required") || String(message).includes("INLINE")) return res.status(400).json({ error: message });
    res.status(500).json({ error: message });
  }
});

export default router;
