// هذه الدالة تبني Query Params لبحث الأشخاص دون تمرير حقول سياق الإدخال (يتم حقن سياق الكتابة من السيرفر عند الحاجة)
export function buildPersonsSearchParams(input: Record<string, any>, cursor?: number | null, limit = 50) {
  const params: Record<string, any> = { limit };
  const fullName = input.fullName ?? input.name ?? input.q ?? "";
  const id = input.id ?? input.personId ?? null;
  const orgId = input.orgId ?? null;
  const branchId = input.branchId ?? null;
  const orgStructureId = input.orgStructureId ?? null;
  const includeUnassigned = input.includeUnassigned ?? input.include_unassigned ?? null;
  const createdBy = input.createdBy ?? input.created_by ?? null;

  if (fullName && String(fullName).trim()) params.q = String(fullName).trim();
  if (id != null && String(id).trim()) {
    const parsed = Number(id);
    if (Number.isFinite(parsed)) params.personId = parsed;
  }
  if (orgId != null && String(orgId).trim()) {
    const parsed = Number(orgId);
    if (Number.isFinite(parsed)) params.orgId = parsed;
  }
  if (branchId != null && String(branchId).trim()) {
    const parsed = Number(branchId);
    if (Number.isFinite(parsed)) params.branchId = parsed;
  }
  if (orgStructureId != null && String(orgStructureId).trim()) {
    const parsed = Number(orgStructureId);
    if (Number.isFinite(parsed)) params.orgStructureId = parsed;
  }
  if (includeUnassigned === true || includeUnassigned === 1 || includeUnassigned === "1" || includeUnassigned === "true") {
    params.includeUnassigned = 1;
  }
  if (createdBy != null && String(createdBy).trim()) {
    const parsed = Number(createdBy);
    if (Number.isFinite(parsed)) params.createdBy = parsed;
  }
  if (cursor != null) params.cursor = cursor;

  return params;
}
