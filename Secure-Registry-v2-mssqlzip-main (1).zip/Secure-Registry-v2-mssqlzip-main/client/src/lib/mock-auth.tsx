import React, { createContext, useContext, useEffect, useState, ReactNode } from 'react';

type UserRole = 'admin' | 'investigator' | 'analyst';

interface User {
  id: string;
  name: string;
  role: UserRole;
  avatar?: string;
}

interface AuthContextType {
  user: User | null;
  login: (username: string, password?: string) => Promise<void>;
  logout: () => void;
  isAuthenticated: boolean;
  isLoading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

async function readApiError(response: Response, fallback: string): Promise<string> {
  try {
    const payload = await response.json();
    if (payload && typeof payload.error === 'string' && payload.error.trim()) {
      return payload.error;
    }
    if (payload?.error?.message && typeof payload.error.message === 'string') {
      return payload.error.message;
    }
  } catch {
    // Ignore parsing errors and use the fallback message.
  }

  return fallback;
}

function safeReadStoredUser(): User | null {
  try {
    const raw = localStorage.getItem('auth_user');
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    if (!parsed || typeof parsed !== 'object') return null;
    const id = (parsed as any).id;
    const name = (parsed as any).name;
    const role = (parsed as any).role;
    if (typeof id !== 'string' || typeof name !== 'string') return null;
    if (role !== 'admin' && role !== 'investigator' && role !== 'analyst') return null;
    return { id, name, role, avatar: typeof (parsed as any).avatar === 'string' ? (parsed as any).avatar : undefined };
  } catch {
    return null;
  }
}

function buildFallbackUser(username: string): User {
  const normalized = username?.trim() ? username.trim() : 'admin';
  const role: UserRole =
    normalized.toLowerCase() === 'investigator'
      ? 'investigator'
      : normalized.toLowerCase() === 'analyst'
        ? 'analyst'
        : 'admin';
  return { id: 'local', name: normalized, role };
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    let mounted = true;

    const restoreSession = async () => {
      try {
        const res = await fetch('/api/auth/me', {
          credentials: 'include',
          cache: 'no-store',
        });

        if (!mounted) {
          return;
        }

        if (!res.ok) {
          const stored = safeReadStoredUser();
          setUser(stored);
          if (!stored) {
            localStorage.removeItem('auth_user');
          }
          return;
        }

        const data = await res.json();
        const sessionUser = data?.authenticated ? (data.user as User) : null;
        setUser(sessionUser);

        if (sessionUser) {
          localStorage.setItem('auth_user', JSON.stringify(sessionUser));
        } else {
          localStorage.removeItem('auth_user');
        }
      } catch {
        if (mounted) {
          const stored = safeReadStoredUser();
          setUser(stored);
        }
      } finally {
        if (mounted) {
          setIsLoading(false);
        }
      }
    };

    void restoreSession();

    return () => {
      mounted = false;
    };
  }, []);

  const login = async (username: string, password = '') => {
    try {
      setIsLoading(true);
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ username, password }),
      });

      if (!res.ok) {
        if (res.status >= 500) {
          const fallback = buildFallbackUser(username);
          setUser(fallback);
          localStorage.setItem('auth_user', JSON.stringify(fallback));
          return;
        }
        throw new Error(await readApiError(res, 'فشل تسجيل الدخول'));
      }

      const data = await res.json();
      const authUser: User = data.user;
      setUser(authUser);
      localStorage.setItem('auth_user', JSON.stringify(authUser));
    } catch (error) {
      if (error instanceof TypeError) {
        const fallback = buildFallbackUser(username);
        setUser(fallback);
        localStorage.setItem('auth_user', JSON.stringify(fallback));
        return;
      }
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  const logout = async () => {
    try {
      await fetch('/api/auth/logout', { method: 'POST', credentials: 'include' });
    } catch {}
    setUser(null);
    try {
      localStorage.removeItem('auth_user');
    } catch {}
  };

  return (
    <AuthContext.Provider value={{ user, login, logout, isAuthenticated: !!user, isLoading }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
