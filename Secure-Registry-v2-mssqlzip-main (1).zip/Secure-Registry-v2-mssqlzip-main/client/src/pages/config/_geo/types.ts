import type { GeoAdminUnit, LookupValue } from "@shared/schema";
import type { TreeNode } from "@secure-registry/components-ui";
import type { CrudDialogMode } from "@/components/data-explorer";
import { LOCAL_LEVEL_MAX } from "./useGeoFormFields";

export type GeoTreeNode = TreeNode & { level: number | null; countryId: number };

export type DialogState = { open: boolean; mode: CrudDialogMode; unit: GeoAdminUnit | null };

export const CLOSED_DIALOG: DialogState = { open: false, mode: "create", unit: null };

export function mapToTreeNode(unit: GeoAdminUnit): GeoTreeNode {
  return {
    id: unit.id,
    name: unit.name,
    parentId: unit.parentId,
    level: unit.level,
    countryId: unit.countryId,
    hasChildren: (unit.level ?? 0) < LOCAL_LEVEL_MAX,
    childrenCount: undefined,
  };
}

export function getLevelName(levelId: number | null | undefined, levels: LookupValue[]) {
  if (levelId == null) return "غير محدد";
  return levels.find((l) => l.id === levelId)?.nameAr ?? `المستوى ${levelId}`;
}

export function normalizeNullableNumber(value: unknown): number | null {
  if (value === "" || value === undefined || value === null || value === "null") return null;
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : null;
}
