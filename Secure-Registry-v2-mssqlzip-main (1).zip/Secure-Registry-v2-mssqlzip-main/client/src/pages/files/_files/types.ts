export type UploadFormState = {
  title: string;
  description: string;
  tags: string;
  folder: string;
  file: File | null;
};

export type FileUploadSettings = {
  relativeDirectory: string;
  maxFileSizeMB: number;
  allowedMimeTypes: string[];
  defaultFolderId: number | null;
};

export type FileUploadSettingsResponse = { data: FileUploadSettings };

export type SettingsFormState = {
  relativeDirectory: string;
  maxFileSizeMB: string;
  defaultFolderId: string;
  allowedMimeTypesText: string;
};

export type BrowseFolder = {
  id: number;
  name: string;
  parent: number | null;
};

export type BrowseFile = {
  id: number;
  title: string | null;
  filenameDownload: string;
  type: string | null;
  filesize: number | null;
};

export type BrowseResponse = {
  data: {
    folder: number | null;
    breadcrumbs: BrowseFolder[];
    folders: BrowseFolder[];
    files: BrowseFile[];
  };
};
