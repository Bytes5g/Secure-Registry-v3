import { useEffect, useMemo } from "react";
import { useLocation, useParams } from "wouter";
import { useQuery } from "@tanstack/react-query";
import UiPageOverridesAdminPage from "./UiPageOverridesAdminPage";
import { genericApi } from "@/lib/api/generic";

function getEntityTypeFromSearch(): string | null {
  try {
    const params = new URLSearchParams(window.location.search);
    const v = params.get("entityType");
    return v && v.trim() ? v.trim() : null;
  } catch {
    return null;
  }
}

export default function UiPageOverridesDetailsPage() {
  const { pageCode } = useParams<{ pageCode: string }>();
  const [, setLocation] = useLocation();

  const registryInfoQuery = useQuery({
    queryKey: ["ui-page-registry-info", pageCode],
    enabled: Boolean(pageCode && pageCode.trim()),
    queryFn: async () => genericApi.getUiPageRegistryInfo(pageCode) as Promise<any>,
  });

  const entityTypeFromRegistry = useMemo(() => {
    const v = (registryInfoQuery.data as any)?.entityType;
    return v == null ? null : String(v);
  }, [registryInfoQuery.data]);

  const entityTypeFromSearch = useMemo(() => getEntityTypeFromSearch(), [pageCode]);
  const entityTypeReady = entityTypeFromSearch ?? entityTypeFromRegistry;
  const entityType = useMemo(() => entityTypeReady ?? pageCode, [entityTypeReady, pageCode]);

  useEffect(() => {
    if (!pageCode || !pageCode.trim()) {
      setLocation("/config/ui-page-overrides");
    }
  }, [pageCode, setLocation]);

  if (!entityTypeFromSearch && registryInfoQuery.isLoading) {
    return (
      <div className="p-6 text-sm text-muted-foreground" dir="rtl">
        جاري التحميل...
      </div>
    );
  }

  return (
    <UiPageOverridesAdminPage
      key={`${pageCode}__${entityType}`}
      initialPageCode={pageCode}
      initialEntityType={entityType}
      autoLoad={true}
      onBack={() => setLocation("/config/ui-page-overrides")}
    />
  );
}
