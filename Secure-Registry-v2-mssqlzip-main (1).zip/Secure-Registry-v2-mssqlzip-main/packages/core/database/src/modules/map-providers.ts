import type { SqlExecutor } from "../config/connection";
import { mapRows, runQuery } from "./helpers";

export interface MapProviderRecord {
  id: number;
  providerName: string;
  providerType: string;
  host: string;
  port: number;
  urlPath: string;
  defaultExtension: string;
  basePath: string;
  tileTemplate: string;
  fullUrl: string | null;
  variables: string | null;
  isOverlay: boolean;
  orderIndex: number;
  isEnabled: boolean;
  createdAt: string | null;
}

function isInvalidObjectNameError(error: unknown): boolean {
  const message = String((error as { message?: unknown } | null)?.message ?? error ?? "");
  return message.toLowerCase().includes("invalid object name");
}

function mapProvider(row: MapProviderRecord): MapProviderRecord {
  return {
    ...row,
    id: Number(row.id),
    providerName: String(row.providerName ?? ""),
    providerType: String(row.providerType ?? ""),
    host: String(row.host ?? ""),
    port: Number(row.port),
    urlPath: String(row.urlPath ?? ""),
    defaultExtension: String(row.defaultExtension ?? ""),
    basePath: String(row.basePath ?? ""),
    tileTemplate: String(row.tileTemplate ?? ""),
    fullUrl: row.fullUrl == null ? null : String(row.fullUrl),
    variables: row.variables == null ? null : String(row.variables),
    isOverlay: Boolean(row.isOverlay),
    orderIndex: Number(row.orderIndex ?? 0),
    isEnabled: Boolean(row.isEnabled),
    createdAt: row.createdAt == null ? null : String(row.createdAt),
  };
}

export class MapProvidersModule {
  async getAll(executor?: SqlExecutor): Promise<MapProviderRecord[]> {
    try {
      const rows = await runQuery(
        `
          SELECT
            id,
            provider_name,
            provider_type,
            host,
            port,
            url_path,
            default_extension,
            base_path,
            tile_template,
            full_url,
            variables,
            is_overlay,
            order_index,
            is_enabled,
            created_at
          FROM dbo.map_providers
          ORDER BY order_index ASC, id ASC
        `,
        {},
        executor,
      );
      return mapRows<MapProviderRecord>(rows).map(mapProvider);
    } catch (error) {
      if (isInvalidObjectNameError(error)) {
        return [];
      }
      throw error;
    }
  }

  async getEnabled(executor?: SqlExecutor): Promise<MapProviderRecord[]> {
    const providers = await this.getAll(executor);
    return providers.filter((p) => p.isEnabled);
  }
}

export const mapProvidersModule = new MapProvidersModule();

