import FilesManagementPage from "./FilesManagementPage";

export default FilesManagementPage;

