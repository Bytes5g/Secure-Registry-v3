export type LookupTypeOption = { id: number; nameAr: string };

export type UiPageColumnLike = {
  fieldCode: string;
  nameAr: string;
  columnType: string;
  isVisible: boolean;
  isSortable?: boolean;
  isFilterable?: boolean;
  width?: string;
  orderIndex?: number;
  lookupTypeId?: number;
};

export type UiPageFormFieldLike = {
  fieldCode: string;
  nameAr: string;
  fieldType: string;
  isRequired: boolean;
  isVisible?: boolean;
  gridCols?: number;
  orderIndex?: number;
  lookupTypeId?: number;
  placeholder?: string;
  isEditable?: boolean;
};

