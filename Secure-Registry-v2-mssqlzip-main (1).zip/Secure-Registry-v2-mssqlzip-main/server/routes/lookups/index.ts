import { Router } from "express";
import typesRouter from "./types.routes";
import aliasesRouter from "./aliases.routes";
import virtualSeedsRouter from "./virtual-seeds.routes";
import valuesRouter from "./values.routes";

const router = Router();

router.use(typesRouter);
router.use(aliasesRouter);
router.use(virtualSeedsRouter);
router.use(valuesRouter);

export default router;
