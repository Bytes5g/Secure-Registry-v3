import { useEffect, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { LookupPicker, type LookupPickerTreeOption } from "@secure-registry/components-ui";
import { fetchLookupValuesByTypeCode } from "@/lib/api/lookups";

interface LookupValuePickerProps {
  typeCode: string;
  value?: number | null;
  onValueChange: (value: number | null) => void;
  placeholder?: string;
  disabled?: boolean;
  className?: string;
  dialogTitle?: string;
  /** When true (default) only active values are listed. */
  activeOnly?: boolean;
  /** When true, options are stripped of parentId so the picker renders flat. */
  flat?: boolean;
  /** Auto-clear stale value when options no longer contain it. Default true. */
  clearStaleValue?: boolean;
}

export function LookupValuePicker({
  typeCode,
  value,
  onValueChange,
  placeholder = "اختر...",
  disabled,
  className,
  dialogTitle = "اختيار قيمة",
  activeOnly = true,
  flat = false,
  clearStaleValue = true,
}: LookupValuePickerProps) {
  const { data, isFetched } = useQuery({
    queryKey: ["lookups", "by-code", typeCode, "values"],
    queryFn: () => fetchLookupValuesByTypeCode(typeCode),
    enabled: !!typeCode,
  });

  const options = useMemo<LookupPickerTreeOption[]>(() => {
    const values = data ?? [];
    return values
      .filter((v) => (activeOnly ? v.isActive !== false : true))
      .sort((a, b) => (a.orderIndex ?? 0) - (b.orderIndex ?? 0))
      .map((v) => ({
        value: String(v.id),
        label: v.nameAr,
        parentValue: flat || v.parentId == null ? null : String(v.parentId),
      }));
  }, [data, activeOnly, flat]);

  useEffect(() => {
    if (!clearStaleValue || !isFetched || value == null) return;
    const stillValid = options.some((o) => o.value === String(value));
    if (!stillValid) onValueChange(null);
  }, [clearStaleValue, isFetched, options, value, onValueChange]);

  return (
    <LookupPicker
      value={value != null ? String(value) : ""}
      onValueChange={(next) => onValueChange(next ? Number(next) : null)}
      options={options}
      placeholder={placeholder}
      disabled={disabled}
      className={className}
      dialogTitle={dialogTitle}
    />
  );
}
