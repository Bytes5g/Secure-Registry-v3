import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@secure-registry/components-ui";
import { FileText, AlertTriangle, Activity } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { apiClient } from "@/lib/api/client";
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, PieChart, Pie, Cell } from "recharts";

type DashboardStatistic = {
  id: number;
  parent_id: number | null;
  database_name: string | null;
  schema_name: string | null;
  object_name: string | null;
  display_name: string | null;
  is_active: boolean | null;
  order_index: number | null;
  object_description: string | null;
  column_count: number | null;
  row_count: string | number | null;
  notes: string | null;
};

type DashboardStatisticsResponse = {
  data: DashboardStatistic[];
};

function toNumber(value: unknown): number | null {
  if (value == null) return null;
  if (typeof value === "number" && Number.isFinite(value)) return value;
  const parsed = Number(String(value));
  return Number.isFinite(parsed) ? parsed : null;
}

function formatCount(value: number | undefined): string {
  return typeof value === "number" ? String(value) : "—";
}

export default function Dashboard() {
  const { data, isLoading } = useQuery({
    queryKey: ["dashboard-summary"],
    queryFn: async () => apiClient.get<DashboardStatisticsResponse>("/api/dashboard/summary"),
  });

  const rows = data?.data ?? [];
  const rowsByParent = new Map<number | null, DashboardStatistic[]>();
  for (const row of rows) {
    const key = row.parent_id ?? null;
    const list = rowsByParent.get(key) ?? [];
    list.push(row);
    rowsByParent.set(key, list);
  }

  const rootRows = rowsByParent.get(null) ?? [];
  rootRows.sort((a, b) => (a.order_index ?? 0) - (b.order_index ?? 0));

  const cardRows = rootRows.slice(0, 4);
  const rootChartRows = rootRows
    .map((r) => ({
      id: r.id,
      label: (r.display_name ?? r.object_name ?? "—").toString(),
      value: toNumber(r.row_count) ?? 0,
    }))
    .filter((r) => r.value > 0)
    .slice(0, 12);

  const pieColors = ["#0ea5e9", "#22c55e", "#f97316", "#a855f7", "#ef4444", "#14b8a6", "#eab308", "#6366f1"];

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold tracking-tight text-primary">لوحة القيادة</h2>
          <p className="text-muted-foreground">إحصائيات ورسومات من قاعدة البيانات</p>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {isLoading ? (
          <>
            <Card><CardHeader /><CardContent><div className="text-sm text-muted-foreground">جاري التحميل…</div></CardContent></Card>
            <Card><CardHeader /><CardContent><div className="text-sm text-muted-foreground">جاري التحميل…</div></CardContent></Card>
            <Card><CardHeader /><CardContent><div className="text-sm text-muted-foreground">جاري التحميل…</div></CardContent></Card>
            <Card><CardHeader /><CardContent><div className="text-sm text-muted-foreground">جاري التحميل…</div></CardContent></Card>
          </>
        ) : (
          cardRows.map((row, index) => {
            const icon = index === 0 ? FileText : index === 1 ? Activity : index === 2 ? FileText : AlertTriangle;
            const Icon = icon;
            const count = toNumber(row.row_count);
            return (
              <Card key={row.id}>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">{row.display_name ?? row.object_name ?? "—"}</CardTitle>
                  <Icon className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{formatCount(count ?? undefined)}</div>
                  <div className="text-xs text-muted-foreground">
                    {row.column_count != null ? `عدد الأعمدة: ${row.column_count}` : "—"}
                  </div>
                </CardContent>
              </Card>
            );
          })
        )}
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
        <Card className="col-span-4">
          <CardHeader>
            <CardTitle>توزيع السجلات حسب الكيانات</CardTitle>
            <CardDescription>مصدر البيانات: vw_system_dashboard_statistics</CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="text-sm text-muted-foreground">جاري التحميل…</div>
            ) : rootChartRows.length === 0 ? (
              <div className="text-sm text-muted-foreground">لا توجد بيانات</div>
            ) : (
              <ChartContainer
                className="h-[320px] w-full"
                config={{
                  value: { label: "عدد السجلات", color: "hsl(var(--chart-1))" },
                }}
              >
                <BarChart data={rootChartRows} margin={{ left: 8, right: 8, top: 8, bottom: 8 }}>
                  <CartesianGrid vertical={false} />
                  <XAxis dataKey="label" tickLine={false} axisLine={false} interval={0} height={80} angle={-20} textAnchor="end" />
                  <YAxis tickLine={false} axisLine={false} width={40} />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <Bar dataKey="value" radius={[6, 6, 0, 0]} fill="var(--color-value)" />
                </BarChart>
              </ChartContainer>
            )}
          </CardContent>
        </Card>

        <Card className="col-span-3">
          <CardHeader>
            <CardTitle>نسبة التوزيع</CardTitle>
            <CardDescription>حسب row_count للصفوف الجذرية</CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="text-sm text-muted-foreground">جاري التحميل…</div>
            ) : rootChartRows.length === 0 ? (
              <div className="text-sm text-muted-foreground">لا توجد بيانات</div>
            ) : (
              <ChartContainer
                className="h-[320px] w-full"
                config={{
                  value: { label: "عدد السجلات", color: "hsl(var(--chart-2))" },
                }}
              >
                <PieChart>
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <Pie data={rootChartRows} dataKey="value" nameKey="label" innerRadius={70} outerRadius={110} paddingAngle={2}>
                    {rootChartRows.map((entry, index) => (
                      <Cell key={`${entry.id}`} fill={pieColors[index % pieColors.length]} />
                    ))}
                  </Pie>
                </PieChart>
              </ChartContainer>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
