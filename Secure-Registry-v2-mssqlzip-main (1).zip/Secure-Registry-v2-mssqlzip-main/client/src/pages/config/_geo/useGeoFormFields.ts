import { useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import type { GeoAdminUnit, LookupValue } from "@shared/schema";
import { fetchGeoUnits } from "@/lib/api/geo-admin";
import type { UiPageFormField } from "@/types/ui";

export const LOCAL_LEVEL_MIN = 5;
export const LOCAL_LEVEL_MAX = 7;

interface Args {
  countryId: number | undefined;
  geoLevels: LookupValue[];
  selectedNodeId: number | null | undefined;
  selectedNodeLevel: number | null | undefined;
  editingUnit: GeoAdminUnit | null;
}

export function useGeoFormFields({
  countryId,
  geoLevels,
  selectedNodeId,
  selectedNodeLevel,
  editingUnit,
}: Args) {
  const dialogLevel =
    editingUnit?.level ??
    (selectedNodeLevel != null ? selectedNodeLevel + 1 : LOCAL_LEVEL_MIN);
  const parentLevel = dialogLevel > LOCAL_LEVEL_MIN ? dialogLevel - 1 : null;

  const { data: parentOptionsData = [] } = useQuery({
    queryKey: ["geo", "parent-options", countryId, parentLevel],
    enabled: countryId != null && parentLevel !== null,
    queryFn: async () => {
      const result = await fetchGeoUnits({
        countryId,
        level: parentLevel ?? undefined,
        limit: 500,
      });
      return result.data;
    },
  });

  const localLevels = useMemo(
    () => geoLevels.filter((l) => l.id >= LOCAL_LEVEL_MIN && l.id <= LOCAL_LEVEL_MAX),
    [geoLevels],
  );

  const levelOptions = useMemo(
    () =>
      localLevels
        .filter((l) => l.id === dialogLevel)
        .map((l) => ({ label: l.nameAr, value: String(l.id) })),
    [localLevels, dialogLevel],
  );

  const parentFieldOptions = useMemo(
    () =>
      parentLevel === null
        ? [{ label: "بدون أب", value: "null" }]
        : parentOptionsData.map((u) => ({ label: u.name, value: String(u.id) })),
    [parentLevel, parentOptionsData],
  );

  const fields = useMemo<UiPageFormField[]>(
    () => [
      { fieldCode: "name", nameAr: "الاسم", fieldType: "text", isRequired: true, gridCols: 1, orderIndex: 1, placeholder: "اسم الوحدة الجغرافية" },
      { fieldCode: "nameEn", nameAr: "الاسم بالإنجليزية", fieldType: "text", isRequired: false, gridCols: 1, orderIndex: 2 },
      { fieldCode: "codes", nameAr: "الكود", fieldType: "text", isRequired: false, gridCols: 1, orderIndex: 3 },
      { fieldCode: "level", nameAr: "نوع الوحدة", fieldType: "select", isRequired: true, gridCols: 1, orderIndex: 4, options: levelOptions },
      { fieldCode: "parentId", nameAr: "الأب", fieldType: "select", isRequired: parentLevel !== null, gridCols: 1, orderIndex: 5, options: parentFieldOptions },
      { fieldCode: "adminTypeAr", nameAr: "الوصف الإداري", fieldType: "text", isRequired: false, gridCols: 1, orderIndex: 6 },
      { fieldCode: "adminTypeEn", nameAr: "الوصف الإداري بالإنجليزية", fieldType: "text", isRequired: false, gridCols: 1, orderIndex: 7 },
      { fieldCode: "isActive", nameAr: "فعال", fieldType: "boolean", isRequired: false, gridCols: 1, orderIndex: 8 },
    ],
    [levelOptions, parentFieldOptions, parentLevel],
  );

  const initialData = useMemo<Record<string, unknown>>(() => {
    if (editingUnit) {
      return {
        ...editingUnit,
        level: editingUnit.level != null ? String(editingUnit.level) : "",
        parentId:
          editingUnit.parentId == null
            ? parentLevel === null
              ? "null"
              : ""
            : String(editingUnit.parentId),
      };
    }
    return {
      countryId,
      level: dialogLevel ? String(dialogLevel) : "",
      parentId: selectedNodeId != null ? String(selectedNodeId) : "null",
      isActive: true,
    };
  }, [editingUnit, parentLevel, countryId, dialogLevel, selectedNodeId]);

  return { fields, initialData, dialogLevel, parentLevel, localLevels };
}
