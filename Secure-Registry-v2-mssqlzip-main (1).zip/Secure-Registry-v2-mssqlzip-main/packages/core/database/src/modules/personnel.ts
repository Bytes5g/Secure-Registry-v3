import { runQuery } from "./helpers";

export interface OrgEmployeeRecord {
  assignmentId: number;
  personId: number;
  fullName: string;
  isManager: boolean;
  orgId: number;
  branchId: number;
  branchName: string | null;
  orgStructureId: number;
  orgStructureName: string | null;
  roleTitleName: string | null;
  assignmentCreatedAt: string | null;
}

function mapOrgEmployee(row: Record<string, unknown>): OrgEmployeeRecord {
  return {
    assignmentId: Number(row.assignment_id),
    personId: Number(row.person_id),
    fullName: String(row.full_name ?? ""),
    isManager: Boolean(row.is_manager),
    orgId: Number(row.org_id),
    branchId: Number(row.branch_id),
    branchName: row.branch_name == null ? null : String(row.branch_name),
    orgStructureId: Number(row.org_structure_id),
    orgStructureName: row.org_structure_name == null ? null : String(row.org_structure_name),
    roleTitleName: row.role_title_name == null ? null : String(row.role_title_name),
    assignmentCreatedAt: row.assignment_created_at == null ? null : String(row.assignment_created_at),
  };
}

export class PersonnelModule {
  async getOrgEmployees(orgId: number): Promise<OrgEmployeeRecord[]> {
    const rows = await runQuery<Record<string, unknown>>(
      `
      SELECT *
      FROM dbo.vw_org_employees
      WHERE org_id = @orgId
      ORDER BY is_manager DESC, full_name ASC, assignment_id ASC
      `,
      { orgId },
    );
    return rows.map(mapOrgEmployee);
  }
}

export const personnelModule = new PersonnelModule();
