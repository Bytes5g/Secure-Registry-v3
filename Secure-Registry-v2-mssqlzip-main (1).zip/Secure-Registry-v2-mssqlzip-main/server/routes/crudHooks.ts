import type { SqlExecutor } from "@core/database";
import type { TableDescriptor } from "./crudFactory";

export type CrudWriteAction = "insert" | "update" | "delete";
export type CrudAfterWriteHook = (action: CrudWriteAction, row: Record<string, unknown>, executor: SqlExecutor) => Promise<void>;

export function getAfterWriteHook(descriptor: TableDescriptor): CrudAfterWriteHook | null {
  return null;
}
