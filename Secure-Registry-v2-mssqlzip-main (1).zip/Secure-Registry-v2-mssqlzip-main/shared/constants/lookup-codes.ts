/**
 * Single source of truth for lookup type codes referenced from both
 * client (Pickers) and server (storage/lookup-id resolution).
 *
 * Adding a new code here? Make sure the matching row exists in
 * `lookup_types` (see migrations) before referencing it from the UI.
 */
export const LOOKUP_CODES = {
  org: {
    structure: "STRUCTURE_CODES",
    sector: "ORG_SECTOR_TYPE",
    location: "ORG_LOCATION_TYPE",
    category: "ORG_CATEGORY_TYPE",
  },
} as const;

export type OrgLookupCodeKey = keyof typeof LOOKUP_CODES.org;
