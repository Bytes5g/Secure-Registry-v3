# React Flow (xyflow) — دليل بالعربية

هذا المستند ترجمة عربية مختصرة ومُنظّمة لملف README الخاص بحزمة `@xyflow/react` (React Flow).

## ما هي React Flow؟
مكوّن React قابل للتخصيص لبناء رسوم بيانية تفاعلية (Graphs) ومحررات تعتمد على العقد (Node-based editors).

## أهم المزايا
- سهل الاستخدام: تكبير/تصغير وتحريك سلس، تحديد عنصر واحد أو عدة عناصر، واختصارات لوحة مفاتيح.
- قابل للتخصيص: أنواع متعددة للعُقد (Nodes) والخطوط (Edges)، ودعم عقد مخصصة مع Handles متعددة وخطوط مخصصة.
- أداء سريع: يعيد رندر العناصر التي تغيّرت فقط.
- Hooks و Utilities: أدوات للتعامل مع حالات العقد والخطوط والـ viewport ووظائف مساعدة.
- مكوّنات إضافية جاهزة: Background و MiniMap و Controls.
- موثوق: مكتوب بـ TypeScript ومختبر.

## التثبيت
باستخدام npm:

```bash
npm install @xyflow/react
```

## مثال سريع (Quickstart)
مثال أساسي يُظهر طريقة إنشاء عقدتين وخط بينهما مع تحكم وخلفية وخريطة مصغرة:

```tsx
import { useCallback } from "react";
import {
  ReactFlow,
  MiniMap,
  Controls,
  Background,
  useNodesState,
  useEdgesState,
  addEdge,
} from "@xyflow/react";

import "@xyflow/react/dist/style.css";

const initialNodes = [
  { id: "1", position: { x: 0, y: 0 }, data: { label: "1" } },
  { id: "2", position: { x: 0, y: 100 }, data: { label: "2" } },
];

const initialEdges = [{ id: "e1-2", source: "1", target: "2" }];

export default function Flow() {
  const [nodes, setNodes, onNodesChange] = useNodesState(initialNodes);
  const [edges, setEdges, onEdgesChange] = useEdgesState(initialEdges);

  const onConnect = useCallback(
    (params: any) => setEdges((eds) => addEdge(params, eds)),
    [setEdges]
  );

  return (
    <ReactFlow
      nodes={nodes}
      edges={edges}
      onNodesChange={onNodesChange}
      onEdgesChange={onEdgesChange}
      onConnect={onConnect}
    >
      <MiniMap />
      <Controls />
      <Background />
    </ReactFlow>
  );
}
```

## نقاط مهمة لفهم “ظهور الخطوط”
- حتى تظهر الخطوط بشكل صحيح مع عقد مخصصة، يجب أن تحتوي العقدة على `Handle` على الأقل:
  - `type="source"` لإرسال الخط
  - `type="target"` لاستقبال الخط

## التطوير محلياً (Development)
- تأكد من وجود pnpm.
- ثم نفّذ:

```bash
pnpm install
```

## الاختبارات (Testing)
يُستخدم Cypress للاختبارات في مشروع React Flow نفسه:

```bash
pnpm test
```

## الروابط المفيدة
- الدليل: https://reactflow.dev/learn
- مرجع API: https://reactflow.dev/api-reference/react-flow
- الأمثلة: https://reactflow.dev/examples/overview
