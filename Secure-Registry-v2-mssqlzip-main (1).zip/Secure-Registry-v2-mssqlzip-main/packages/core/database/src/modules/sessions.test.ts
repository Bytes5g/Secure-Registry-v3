import { beforeEach, describe, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => ({
  runQuery: vi.fn(),
  runQueryOne: vi.fn(),
}));

vi.mock("./helpers", () => ({
  runQuery: mocks.runQuery,
  runQueryOne: mocks.runQueryOne,
}));

import { deleteSession, getSessionPayload, touchSession, upsertSession } from "./sessions";

describe("sessions module", () => {
  beforeEach(() => {
    mocks.runQuery.mockReset();
    mocks.runQueryOne.mockReset();
  });

  it("getSessionPayload returns null when no row", async () => {
    mocks.runQueryOne.mockResolvedValueOnce(undefined);
    const res = await getSessionPayload("a");
    expect(res).toBeNull();
  });

  it("getSessionPayload returns payload when present", async () => {
    mocks.runQueryOne.mockResolvedValueOnce({ user_agent: "{\"x\":1}", expires: null });
    const res = await getSessionPayload("a");
    expect(res?.payload).toBe("{\"x\":1}");
    const [sql, params] = mocks.runQueryOne.mock.calls[0];
    expect(String(sql)).toContain("FROM [sessions]");
    expect(params).toEqual({ sid: "a" });
  });

  it("upsertSession uses MERGE", async () => {
    mocks.runQuery.mockResolvedValueOnce([]);
    await upsertSession({ sid: "a", userId: 1, expires: new Date("2020-01-01"), payload: "{}" });
    const [sql, params] = mocks.runQuery.mock.calls[0];
    expect(String(sql)).toContain("MERGE [sessions]");
    expect(params.sid).toBe("a");
    expect(params.userId).toBe(1);
  });

  it("deleteSession uses DELETE", async () => {
    mocks.runQuery.mockResolvedValueOnce([]);
    await deleteSession("a");
    const [sql, params] = mocks.runQuery.mock.calls[0];
    expect(String(sql)).toContain("DELETE FROM [sessions]");
    expect(params).toEqual({ sid: "a" });
  });

  it("touchSession updates expires", async () => {
    mocks.runQuery.mockResolvedValueOnce([]);
    await touchSession("a", new Date("2020-01-01"));
    const [sql, params] = mocks.runQuery.mock.calls[0];
    expect(String(sql)).toContain("UPDATE [sessions] SET [expires]");
    expect(params.sid).toBe("a");
  });
});

