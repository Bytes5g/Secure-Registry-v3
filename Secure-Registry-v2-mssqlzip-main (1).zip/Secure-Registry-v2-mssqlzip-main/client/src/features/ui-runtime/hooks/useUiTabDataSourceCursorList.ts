import { useEffect, useMemo, useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { genericApi } from "@/lib/api/generic";
import { buildUiDataSourceParams, getTabDataSource, type UiPageDetailsLike } from "@/lib/ui/uiTabDataSources";

export function useUiTabDataSourceCursorList(args: {
  details: UiPageDetailsLike | undefined | null;
  tabKey: string;
  purpose?: string;
  criteria: Record<string, any>;
  fallbackDataSourceKey: string;
  fallbackBuildParams?: (criteria: Record<string, any>, cursor?: number | null) => Record<string, any>;
  enabled?: boolean;
  limitDefault?: number;
}) {
  const purpose = args.purpose ?? "list";
  const resolved = useMemo(() => getTabDataSource(args.details, args.tabKey, purpose), [args.details, args.tabKey, purpose]);
  const dataSourceKey = resolved?.dataSourceKey ?? args.fallbackDataSourceKey;

  const [rows, setRows] = useState<any[]>([]);
  const [nextCursor, setNextCursor] = useState<number | null>(null);

  useEffect(() => {
    setRows([]);
    setNextCursor(null);
  }, [dataSourceKey, args.criteria]);

  const query = useQuery<{ data: any[]; nextCursor: number | null }>({
    queryKey: ["ui-tab-ds", dataSourceKey, purpose, args.criteria],
    enabled: Boolean(args.enabled ?? true),
    queryFn: async () => {
      const params =
        resolved?.mapping != null
          ? buildUiDataSourceParams({ criteria: args.criteria, mapping: resolved.mapping, limitDefault: args.limitDefault ?? 50 })
          : args.fallbackBuildParams
            ? args.fallbackBuildParams(args.criteria, null)
            : buildUiDataSourceParams({ criteria: args.criteria, mapping: null, limitDefault: args.limitDefault ?? 50 });
      return genericApi.executeUiDataSource(String(dataSourceKey), params);
    },
  });

  useEffect(() => {
    const data = Array.isArray(query.data?.data) ? query.data?.data : [];
    setRows(data);
    setNextCursor(query.data?.nextCursor ?? null);
  }, [query.data]);

  const loadMore = useMutation({
    mutationFn: async () => {
      if (!nextCursor) return null;
      const params =
        resolved?.mapping != null
          ? buildUiDataSourceParams({
              criteria: args.criteria,
              mapping: resolved.mapping,
              cursor: nextCursor,
              limitDefault: args.limitDefault ?? 50,
            })
          : args.fallbackBuildParams
            ? args.fallbackBuildParams(args.criteria, nextCursor)
            : buildUiDataSourceParams({ criteria: args.criteria, mapping: null, cursor: nextCursor, limitDefault: args.limitDefault ?? 50 });
      return genericApi.executeUiDataSource(String(dataSourceKey), params);
    },
    onSuccess: (result: any) => {
      if (!result) return;
      const data = Array.isArray(result.data) ? result.data : [];
      setRows((prev) => [...prev, ...data]);
      setNextCursor(result.nextCursor ?? null);
    },
  });

  return {
    dataSourceKey,
    mapping: resolved?.mapping ?? null,
    rows,
    nextCursor,
    query,
    loadMore,
  };
}

