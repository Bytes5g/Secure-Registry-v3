import { Router } from "express";
import { asyncHandler } from "../../utils/asyncHandler";
import { cleanupTempFile, createPersonMediaFileFromRequest, createPersonMediaUploader, deletePrimaryPersonMedia, getPrimaryPersonMedia, parsePersonId, setPrimaryPersonMediaFromRequest } from "./media-utils";

const router = Router({ mergeParams: true });

router.get("/", asyncHandler(async (req, res) => {
  const personId = parsePersonId(req);
  const current = await getPrimaryPersonMedia(personId, "photo");
  if (!current) return res.json(null);

  res.json({
    id: current.link.id,
    fileId: current.file.id,
    personId,
    filePath: current.file.location ?? "",
    fileName: current.file.filenameDownload ?? null,
    mimeType: current.file.type ?? null,
    size: current.file.filesize ?? null,
    isPrimary: current.link.isPrimary,
    description: current.file.description ?? null,
    createdAt: current.link.createdAt,
  });
}));

router.post(
  "/",
  asyncHandler(async (req, res, next) => {
    if (!req.is("application/json")) return next();
    const personId = parsePersonId(req);
    const fileId = Number((req.body as any)?.fileId);
    if (!Number.isInteger(fileId) || fileId <= 0) return res.status(400).json({ error: "Invalid fileId" });

    const link = await setPrimaryPersonMediaFromRequest(req, personId, "photo", fileId);
    const current = await getPrimaryPersonMedia(personId, "photo");
    if (!current) throw new Error("Failed to set photo");

    res.status(200).json({
      id: link.id,
      fileId: current.file.id,
      personId,
      filePath: current.file.location ?? "",
      fileName: current.file.filenameDownload ?? null,
      mimeType: current.file.type ?? null,
      size: current.file.filesize ?? null,
      isPrimary: true,
      description: current.file.description ?? null,
      createdAt: link.createdAt,
    });
  }),
);

router.post(
  "/",
  createPersonMediaUploader(5 * 1024 * 1024, "photo"),
  asyncHandler(async (req, res) => {
    const personId = parsePersonId(req);
    if (!req.file) throw new Error("No file uploaded");

    try {
      const created = await createPersonMediaFileFromRequest(req, {
        personId,
        kind: "photo",
        absoluteTempFilePath: req.file.path,
        originalName: req.file.originalname,
        declaredMime: req.file.mimetype,
        size: req.file.size,
        description: req.body.description,
      });

      const link = await setPrimaryPersonMediaFromRequest(req, personId, "photo", created.fileId);
      const current = await getPrimaryPersonMedia(personId, "photo");
      if (!current) throw new Error("Failed to set photo");

      res.status(201).json({
        id: link.id,
        fileId: current.file.id,
        personId,
        filePath: current.file.location ?? created.publicUrl,
        fileName: current.file.filenameDownload ?? null,
        mimeType: current.file.type ?? null,
        size: current.file.filesize ?? null,
        isPrimary: true,
        description: current.file.description ?? null,
        createdAt: link.createdAt,
      });
    } catch (error) {
      await cleanupTempFile(req.file?.path);
      throw error;
    }
  }),
);

router.delete("/", asyncHandler(async (req, res) => {
  const personId = parsePersonId(req);
  await deletePrimaryPersonMedia(personId, "photo");
  res.sendStatus(204);
}));

export default router;
