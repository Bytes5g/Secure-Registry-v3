import { useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { Badge, EntityContentCard, type Column } from "@secure-registry/components-ui";
import { DataTable } from "@secure-registry/components-ui";
import { fetchPersonContacts, type PersonContactItem } from "@/lib/api/persons-admin";

function formatDateTime(value: unknown) {
  return value ? new Date(String(value)).toLocaleString("ar-SA") : "—";
}

export function PersonContactsTab({ personId }: { personId: number }) {
  const { data = [], isLoading } = useQuery<PersonContactItem[]>({
    queryKey: ["person-contacts", personId],
    queryFn: () => fetchPersonContacts(personId),
    enabled: Number.isFinite(personId) && personId > 0,
  });

  const columns = useMemo<Column<PersonContactItem>[]>(
    () => [
      { key: "categoryName", header: "الفئة", render: (_, row) => row.categoryName ?? `#${row.categoryId}` },
      { key: "typeName", header: "النوع", render: (_, row) => row.typeName ?? `#${row.typeId}` },
      { key: "providerName", header: "المزوّد", render: (_, row) => row.providerName ?? "—" },
      { key: "contactValue", header: "القيمة", sortable: true, render: (_, row) => row.contactValue || "—" },
      {
        key: "isWorkRelated",
        header: "عمل",
        width: "70px",
        render: (_, row) => (row.isWorkRelated ? <Badge>نعم</Badge> : <Badge variant="secondary">لا</Badge>),
      },
      { key: "createdAt", header: "تاريخ الإضافة", render: (_, row) => formatDateTime(row.createdAt) },
    ],
    [],
  );

  return (
    <EntityContentCard>
      <DataTable
        data={Array.isArray(data) ? data : []}
        columns={columns}
        isLoading={isLoading}
        emptyMessage="لا توجد بيانات تواصل لهذا الشخص"
      />
    </EntityContentCard>
  );
}
