import { Router, type Request, type Response } from "express";
import { z } from "zod";
import { orgStructureRoleTitlesModule } from "@core/database";
import { requireWriteContext } from "../_internals";
import { ApiError } from "../../utils/response";

const router = Router();

const orgStructureRoleTitleSchema = z.object({
  orgId: z.coerce.number().int(),
  branchScopeLookupId: z.coerce.number().int(),
  orgStructureId: z.coerce.number().int(),
  orgStructureCodeId: z.coerce.number().int(),
  orgRoleTitleId: z.coerce.number().int(),
  orderIndex: z.coerce.number().int().optional(),
  isActive: z.boolean().optional(),
});

// هذا الراوتر يوفّر CRUD لمسميات الهيكل مع حقن سياق الإدخال entry_* وحقول التدقيق
router.get("/structure-role-titles", async (req: Request, res: Response) => {
  try {
    const orgIdRaw = req.query.orgId;
    const orgId = orgIdRaw == null ? NaN : Number(orgIdRaw);
    if (!Number.isFinite(orgId)) {
      return res.status(400).json({ error: "orgId مطلوب" });
    }
    const rows = await orgStructureRoleTitlesModule.getByOrgId(orgId);
    res.json(rows);
  } catch (error) {
    console.error("Error fetching org structure role titles:", error);
    res.status(500).json({ error: "فشل في جلب مسميات الهيكل" });
  }
});

router.get("/structure-role-titles/:id", async (req: Request, res: Response) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) return res.status(400).json({ error: "معرف غير صالح" });
    const row = await orgStructureRoleTitlesModule.getById(id);
    if (!row) return res.status(404).json({ error: "السجل غير موجود" });
    res.json(row);
  } catch (error) {
    console.error("Error fetching org structure role title:", error);
    res.status(500).json({ error: "فشل في جلب السجل" });
  }
});

router.post("/structure-role-titles", async (req: Request, res: Response) => {
  try {
    const validated = orgStructureRoleTitleSchema.parse(req.body);
    const ctx = await requireWriteContext(req);
    const created = await orgStructureRoleTitlesModule.create({
      ...(validated as any),
      orderIndex: validated.orderIndex ?? 0,
      isActive: validated.isActive ?? true,
      workContextBy: ctx.workContextBy,
      createdBy: ctx.userId,
    });
    res.status(201).json(created);
  } catch (error) {
    if (error instanceof ApiError) {
      return res.status(error.statusCode).json({ error: error.message, details: error.details });
    }
    if (error instanceof z.ZodError) {
      return res.status(400).json({ error: "بيانات غير صالحة", details: error.errors });
    }
    console.error("Error creating org structure role title:", error);
    res.status(500).json({ error: "فشل في إنشاء السجل" });
  }
});

router.patch("/structure-role-titles/:id", async (req: Request, res: Response) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) return res.status(400).json({ error: "معرف غير صالح" });
    const validated = orgStructureRoleTitleSchema.partial().parse(req.body);
    const ctx = await requireWriteContext(req);
    const updated = await orgStructureRoleTitlesModule.update(id, {
      ...(validated as any),
      workContextBy: (validated as any).workContextBy ?? ctx.workContextBy,
      updatedBy: ctx.userId,
      updatedAt: new Date(),
    } as any);
    if (!updated) return res.status(404).json({ error: "السجل غير موجود" });
    res.json(updated);
  } catch (error) {
    if (error instanceof ApiError) {
      return res.status(error.statusCode).json({ error: error.message, details: error.details });
    }
    if (error instanceof z.ZodError) {
      return res.status(400).json({ error: "بيانات غير صالحة", details: error.errors });
    }
    console.error("Error updating org structure role title:", error);
    res.status(500).json({ error: "فشل في تحديث السجل" });
  }
});

router.delete("/structure-role-titles/:id", async (req: Request, res: Response) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) return res.status(400).json({ error: "معرف غير صالح" });
    const ctx = await requireWriteContext(req);
    const success = await orgStructureRoleTitlesModule.softDelete(id, {
      workContextBy: ctx.workContextBy,
      updatedBy: ctx.userId,
    });
    if (!success) return res.status(404).json({ error: "السجل غير موجود" });
    res.status(204).send();
  } catch (error) {
    if (error instanceof ApiError) {
      return res.status(error.statusCode).json({ error: error.message, details: error.details });
    }
    console.error("Error deleting org structure role title:", error);
    res.status(500).json({ error: "فشل في حذف السجل" });
  }
});

export default router;
