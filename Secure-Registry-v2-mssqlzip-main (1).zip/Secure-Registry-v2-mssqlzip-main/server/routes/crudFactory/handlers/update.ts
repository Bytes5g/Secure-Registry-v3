import type { Router } from "express";
import { executeUpdate, pickBodyColumns, resolveIdCondition } from "@core/database";
import type { TableDescriptor } from "../types";
import { getTableInfo } from "../sql/table-info";
import { runWrite } from "../run-write";
import { getAfterWriteHook } from "../../crudHooks";
import { applyWriteContextToBody } from "../../_internals";

export function registerUpdateHandler(router: Router, descriptor: TableDescriptor) {
  const hook = getAfterWriteHook(descriptor);

  router.put("/:id", async (req, res) => {
    try {
      const updated = await runWrite(hook, "update", async (executor) => {
        const tableInfo = await getTableInfo(descriptor);
        const { columnMap } = tableInfo;
        const { clause, params } = resolveIdCondition(req.params.id, columnMap);
        const body = (req.body || {}) as Record<string, unknown>;
        await applyWriteContextToBody(req, body, columnMap, "update");
        const values = pickBodyColumns(body, columnMap, ["id", "createdAt"]);
        if (values.length === 0) throw new Error("Empty body");
        return executeUpdate({ tableInfo, clause, params, values, executor });
      });

      if (!updated) return res.status(404).json({ error: "Not found" });
      res.json(updated);
    } catch (e: any) {
      if (e.message.startsWith("Invalid ID") || e.message.startsWith("Table does not have")) {
        return res.status(400).json({ error: e.message });
      }
      console.error(`Error in PUT /api/${descriptor.exportName}/${req.params.id}:`, e);
      res.status(400).json({ error: e.message });
    }
  });
}
