import type { SqlExecutor } from "../config/connection";
import { runQuery, runQueryOne } from "./helpers";

export async function getSessionPayload(
  sid: string,
  executor?: SqlExecutor,
): Promise<{ payload: string; expires: Date | null } | null> {
  const row = await runQueryOne<{ user_agent: string | null; expires: Date | null }>(
    `SELECT TOP 1 [user_agent], [expires]
     FROM [sessions]
     WHERE [token] = @sid AND [expires] > SYSUTCDATETIME()`,
    { sid },
    executor,
  );

  if (!row?.user_agent) return null;
  return { payload: String(row.user_agent), expires: row.expires ?? null };
}

export async function upsertSession(
  input: {
    sid: string;
    userId: number | null;
    expires: Date;
    payload: string;
    workContextBy: number;
    createdBy: number;
  },
  executor?: SqlExecutor,
): Promise<void> {
  await runQuery(
    `MERGE [sessions] AS target
     USING (SELECT @sid AS token) AS source
     ON target.[token] = source.[token]
     WHEN MATCHED THEN
       UPDATE SET
         [user] = @userId,
         [expires] = @expires,
         [user_agent] = @payload,
         [work_context_by] = @workContextBy,
         [updated_at] = GETDATE(),
         [updated_by] = @createdBy
     WHEN NOT MATCHED THEN
       INSERT (
         [token],
         [user],
         [expires],
         [user_agent],
         [share],
         [origin],
         [next_token],
         [ip],
         [work_context_by],
         [created_by]
       )
       VALUES (
         @sid,
         @userId,
         @expires,
         @payload,
         NULL,
         NULL,
         NULL,
         NULL,
         @workContextBy,
         @createdBy
       );`,
    {
      sid: input.sid,
      userId: input.userId,
      expires: input.expires,
      payload: input.payload,
      workContextBy: input.workContextBy,
      createdBy: input.createdBy,
    },
    executor,
  );
}

export async function deleteSession(sid: string, executor?: SqlExecutor): Promise<void> {
  await runQuery(
    "DELETE FROM [sessions] WHERE [token] = @sid",
    { sid },
    executor,
  );
}

export async function touchSession(sid: string, expires: Date, executor?: SqlExecutor): Promise<void> {
  await runQuery(
    "UPDATE [sessions] SET [expires] = @expires WHERE [token] = @sid",
    { sid, expires },
    executor,
  );
}
