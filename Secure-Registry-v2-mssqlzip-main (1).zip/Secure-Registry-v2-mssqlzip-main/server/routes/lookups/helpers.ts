export function parseOptionalTypeId(value: unknown): number | undefined {
  if (value == null || value === "") return undefined;
  const parsed = parseInt(String(value), 10);
  return Number.isFinite(parsed) ? parsed : undefined;
}

export function isAmbiguousLookupError(error: unknown): error is Error {
  const message = error instanceof Error ? error.message : String(error);
  return message.includes("Pass typeId explicitly.");
}

export function isReadOnlyLookupError(error: unknown): error is Error {
  const message = error instanceof Error ? error.message : String(error);
  return message.includes("read-only") || message.includes("not writable");
}

export function getErrorMessage(error: unknown, fallback: string): string {
  return error instanceof Error && error.message ? error.message : fallback;
}

export function isInvalidObjectNameError(error: unknown): boolean {
  const message = error instanceof Error ? error.message : String(error ?? "");
  return message.toLowerCase().includes("invalid object name");
}

export function parseInteger(value: unknown): number | undefined {
  if (value == null || value === "") return undefined;
  const parsed = parseInt(String(value), 10);
  return Number.isFinite(parsed) ? parsed : undefined;
}

export function normalizeAliasArray(value: unknown): string[] | undefined {
  if (value == null) return undefined;
  if (Array.isArray(value)) return value.map(String);
  if (typeof value === "string") {
    return value
      .split(/[,\n]/)
      .map((entry) => entry.trim())
      .filter(Boolean);
  }
  return undefined;
}

export function normalizeLookupAliasBody(body: Record<string, unknown>, typeId?: number) {
  return {
    lookupTypeId: typeId ?? parseInteger(body.lookupTypeId),
    aliasCode: typeof body.aliasCode === "string" ? body.aliasCode : undefined,
    isActive: body.isActive == null ? undefined : Boolean(body.isActive),
  };
}

export function normalizeVirtualSeedBody(body: Record<string, unknown>, typeId?: number) {
  return {
    lookupTypeId: typeId ?? parseInteger(body.lookupTypeId),
    valueId: parseInteger(body.valueId),
    code: typeof body.code === "string" ? body.code : undefined,
    nameAr: typeof body.nameAr === "string" ? body.nameAr : undefined,
    orderIndex: Object.prototype.hasOwnProperty.call(body, "orderIndex")
      ? (parseInteger(body.orderIndex) ?? 0)
      : undefined,
    aliases: normalizeAliasArray(body.aliases),
    isActive: body.isActive == null ? undefined : Boolean(body.isActive),
  };
}

export function normalizeLookupValueBody(input: Record<string, unknown>): Record<string, unknown> {
  const body = { ...input };
  if (body.parentId === "" || body.parentId === "null") body.parentId = null;
  if (typeof body.orderIndex === "string" && body.orderIndex.trim() === "") delete body.orderIndex;
  if (typeof body.orderIndex === "string" && /^\d+$/.test(body.orderIndex)) {
    body.orderIndex = parseInt(body.orderIndex);
  }
  return body;
}
