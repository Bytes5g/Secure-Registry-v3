import type {
  InsertLookupType,
  InsertLookupTypeAlias,
  InsertLookupValue,
  InsertLookupVirtualValue,
  LookupType,
  LookupTypeAlias,
  LookupValue,
  LookupVirtualValue,
} from "@shared/schema";

async function readApiError(response: Response, fallback: string): Promise<string> {
  try {
    const payload = await response.json();
    if (payload && typeof payload.error === "string" && payload.error.trim().length > 0) {
      return payload.error;
    }
  } catch {
    // Ignore parsing failures and fall back to the default message.
  }

  return fallback;
}

export async function fetchAllLookupTypes(): Promise<LookupType[]> {
  const response = await fetch("/api/lookups/types");
  if (!response.ok) throw new Error(await readApiError(response, "Failed to fetch lookup types"));
  return response.json();
}

export async function createLookupType(data: InsertLookupType): Promise<LookupType> {
  const response = await fetch("/api/lookups/types", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
  if (!response.ok) throw new Error(await readApiError(response, "Failed to create lookup type"));
  return response.json();
}

export async function updateLookupType(id: number, data: Partial<InsertLookupType>): Promise<LookupType> {
  const response = await fetch(`/api/lookups/types/${id}`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
  if (!response.ok) throw new Error(await readApiError(response, "Failed to update lookup type"));
  return response.json();
}

export async function deleteLookupType(id: number): Promise<void> {
  const response = await fetch(`/api/lookups/types/${id}`, { method: "DELETE" });
  if (!response.ok) throw new Error(await readApiError(response, "Failed to delete lookup type"));
}

export async function fetchLookupTypeAliases(typeId: number): Promise<LookupTypeAlias[]> {
  const response = await fetch(`/api/lookups/types/${typeId}/aliases`);
  if (!response.ok) throw new Error(await readApiError(response, "Failed to fetch lookup aliases"));
  return response.json();
}

export async function createLookupTypeAlias(
  typeId: number,
  data: InsertLookupTypeAlias,
): Promise<LookupTypeAlias> {
  const response = await fetch(`/api/lookups/types/${typeId}/aliases`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
  if (!response.ok) throw new Error(await readApiError(response, "Failed to create lookup alias"));
  return response.json();
}

export async function updateLookupTypeAlias(
  id: number,
  data: Partial<InsertLookupTypeAlias>,
): Promise<LookupTypeAlias> {
  const response = await fetch(`/api/lookups/aliases/${id}`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
  if (!response.ok) throw new Error(await readApiError(response, "Failed to update lookup alias"));
  return response.json();
}

export async function deleteLookupTypeAlias(id: number): Promise<void> {
  const response = await fetch(`/api/lookups/aliases/${id}`, { method: "DELETE" });
  if (!response.ok) throw new Error(await readApiError(response, "Failed to delete lookup alias"));
}

export async function fetchLookupVirtualValues(typeId: number): Promise<LookupVirtualValue[]> {
  const response = await fetch(`/api/lookups/types/${typeId}/virtual-seeds`);
  if (!response.ok) throw new Error(await readApiError(response, "Failed to fetch lookup virtual seeds"));
  return response.json();
}

export async function createLookupVirtualValue(
  typeId: number,
  data: InsertLookupVirtualValue,
): Promise<LookupVirtualValue> {
  const response = await fetch(`/api/lookups/types/${typeId}/virtual-seeds`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
  if (!response.ok) throw new Error(await readApiError(response, "Failed to create lookup virtual seed"));
  return response.json();
}

export async function updateLookupVirtualValue(
  id: number,
  data: Partial<InsertLookupVirtualValue>,
): Promise<LookupVirtualValue> {
  const response = await fetch(`/api/lookups/virtual-seeds/${id}`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
  if (!response.ok) throw new Error(await readApiError(response, "Failed to update lookup virtual seed"));
  return response.json();
}

export async function deleteLookupVirtualValue(id: number): Promise<void> {
  const response = await fetch(`/api/lookups/virtual-seeds/${id}`, { method: "DELETE" });
  if (!response.ok) throw new Error(await readApiError(response, "Failed to delete lookup virtual seed"));
}

export async function fetchLookupValues(typeId: number): Promise<LookupValue[]> {
  const response = await fetch(`/api/lookups/types/${typeId}/values`);
  if (!response.ok) throw new Error(await readApiError(response, "Failed to fetch lookup values"));
  return response.json();
}

export async function createLookupValue(data: InsertLookupValue): Promise<LookupValue> {
  const response = await fetch("/api/lookups/values", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
  if (!response.ok) throw new Error(await readApiError(response, "Failed to create lookup value"));
  return response.json();
}

export async function updateLookupValue(id: number, data: Partial<InsertLookupValue>): Promise<LookupValue> {
  const response = await fetch(`/api/lookups/values/${id}`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
  if (!response.ok) throw new Error(await readApiError(response, "Failed to update lookup value"));
  return response.json();
}

export async function deleteLookupValue(id: number): Promise<void> {
  const response = await fetch(`/api/lookups/values/${id}`, { method: "DELETE" });
  if (!response.ok) throw new Error(await readApiError(response, "Failed to delete lookup value"));
}
