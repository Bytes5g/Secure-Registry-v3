import type { ReactNode } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../ui/tabs"
import { cn } from "../lib/utils"
import { RelatedRecordsPanel } from "./RelatedRecordsPanel"

interface EntityRelationsTabPanel {
  title: string
  description?: string
  actionLabel?: string
  onAction?: () => void
}

export interface EntityRelationsTab {
  value: string
  label: string
  content: ReactNode
  panel?: EntityRelationsTabPanel
}

interface EntityRelationsTabsProps {
  tabs: EntityRelationsTab[]
  defaultValue?: string
  value?: string
  onValueChange?: (value: string) => void
  className?: string
  tabsListClassName?: string
  contentClassName?: string
  direction?: "rtl" | "ltr"
}

export function EntityRelationsTabs({
  tabs,
  defaultValue,
  value,
  onValueChange,
  className,
  tabsListClassName,
  contentClassName,
  direction,
}: EntityRelationsTabsProps) {
  if (tabs.length === 0) {
    return null
  }

  const initialValue = defaultValue ?? tabs[0]?.value
  const isControlled = value !== undefined

  return (
    <Tabs
      {...(isControlled ? { value, onValueChange } : { defaultValue: initialValue })}
      className={cn("space-y-4", className)}
      dir={direction}
    >
      <TabsList
        className={cn(
          tabsListClassName,
          direction === "rtl" ? "justify-start" : undefined,
        )}
        dir={direction}
      >
        {tabs.map((tab) => (
          <TabsTrigger key={tab.value} value={tab.value}>
            {tab.label}
          </TabsTrigger>
        ))}
      </TabsList>

      {tabs.map((tab) => (
        <TabsContent key={tab.value} value={tab.value} className={cn("space-y-4", contentClassName)}>
          {tab.panel ? (
            <RelatedRecordsPanel
              title={tab.panel.title}
              description={tab.panel.description}
              actionLabel={tab.panel.actionLabel}
              onAction={tab.panel.onAction}
            >
              {tab.content}
            </RelatedRecordsPanel>
          ) : (
            tab.content
          )}
        </TabsContent>
      ))}
    </Tabs>
  )
}
