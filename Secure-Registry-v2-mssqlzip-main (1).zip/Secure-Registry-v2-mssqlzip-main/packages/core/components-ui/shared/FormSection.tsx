import type { ReactNode } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../ui/card";
import { cn } from "../lib/utils";

interface FormSectionProps {
  title: string;
  description?: string;
  className?: string;
  contentClassName?: string;
  children: ReactNode;
}

export function FormSection({
  title,
  description,
  className,
  contentClassName,
  children,
}: FormSectionProps) {
  return (
    <Card className={cn("border-border/70", className)}>
      <CardHeader className="pb-4">
        <CardTitle className="text-base">{title}</CardTitle>
        {description ? <CardDescription>{description}</CardDescription> : null}
      </CardHeader>
      <CardContent className={cn("space-y-4", contentClassName)}>
        {children}
      </CardContent>
    </Card>
  );
}
