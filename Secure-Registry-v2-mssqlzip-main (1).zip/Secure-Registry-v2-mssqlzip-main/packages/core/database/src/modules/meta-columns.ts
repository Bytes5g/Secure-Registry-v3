import { getSchemaDictionaryColumns } from "./schema-dictionary";
import { standardFieldsModule } from "./standard-fields";

export type MetaColumn = {
  column_name: string;
  data_type: string;
  is_nullable: boolean;
  column_default: string | null;
  character_maximum_length: number | null;
  column_description: string | null;
  formatted_name: string | null;
  ui_column_type: string | null;
};

// هذه الدالة تُرجع توصيف الأعمدة اعتماداً على v_schema_dictionary_columns مع إثراء الاسم/الوصف من standard_field_dictionary عند توفره
export async function getMetaColumnsForObject(input: {
  schemaName: string;
  objectName: string;
}): Promise<MetaColumn[]> {
  const [dictionaryColumns, standardFieldMap] = await Promise.all([
    getSchemaDictionaryColumns({ schemaName: input.schemaName, objectName: input.objectName }),
    standardFieldsModule.getFieldDefinitionMap(),
  ]);

  return dictionaryColumns.map((col) => {
    const key1 = String(col.columnName ?? "").trim().toLowerCase();
    const key2 = String(col.formattedName ?? "").trim().toLowerCase();
    const std = (key1 && standardFieldMap.get(key1)) || (key2 && standardFieldMap.get(key2)) || null;

    const formattedName = std?.nameAr ?? col.formattedName ?? null;
    const description = std?.description ?? col.columnDescription ?? null;
    const uiColumnType = std?.uiColumnType ?? col.uiColumnType ?? null;

    return {
      column_name: col.columnName,
      data_type: col.dataType,
      is_nullable: col.isNullable,
      column_default: col.defaultDefinition ?? null,
      character_maximum_length: col.length ?? null,
      column_description: description,
      formatted_name: formattedName,
      ui_column_type: uiColumnType,
    };
  });
}

