import type { Express } from "express";
import type { Server } from "http";
import { registerRoutes as registerApiRoutes } from "./routes/index";

export async function registerRoutes(httpServer: Server, app: Express): Promise<void> {
  // Register all API routes from the new modular structure
  await registerApiRoutes(app);
}
