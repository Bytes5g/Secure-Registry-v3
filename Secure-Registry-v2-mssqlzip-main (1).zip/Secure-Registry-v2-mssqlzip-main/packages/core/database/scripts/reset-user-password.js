#!/usr/bin/env node
import { randomBytes, scrypt as _scrypt } from "node:crypto";
import { promisify } from "node:util";
import { connect } from "./_config.js";

const scrypt = promisify(_scrypt);

async function hashPassword(password) {
  const salt = randomBytes(16).toString("hex");
  const derivedKey = await scrypt(password, salt, 64);
  return `${salt}:${Buffer.from(derivedKey).toString("hex")}`;
}

const pool = await connect();
const login = process.argv[2] || "admin";
const newPassword = process.argv[3] || "Admin@2026";

const r = await pool.request().input("login", login).query(
  `SELECT TOP 1 id, email, status, role
     FROM [users]
     WHERE LOWER([email]) = LOWER(@login)
        OR LOWER(CASE WHEN CHARINDEX('@',[email])>0
                      THEN LEFT([email], CHARINDEX('@',[email])-1)
                      ELSE [email] END) = LOWER(@login)`
);

if (!r.recordset.length) {
  console.error(`✗ no user found for login=${login}`);
  await pool.close();
  process.exit(1);
}

const user = r.recordset[0];
const hash = await hashPassword(newPassword);

await pool
  .request()
  .input("id", user.id)
  .input("hash", hash)
  .input("updatedBy", user.id)
  .query(
    `UPDATE [users]
     SET [password]=@hash, [updated_at]=getdate(), [updated_by]=@updatedBy
     WHERE [id]=@id`
  );

await pool.close();
console.log(`✅ password updated for id=${user.id} email=${user.email}`);
console.log(`   credentials: ${login} / ${newPassword}`);

