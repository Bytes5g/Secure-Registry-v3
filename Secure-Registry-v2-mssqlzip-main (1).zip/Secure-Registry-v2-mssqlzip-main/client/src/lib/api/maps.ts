import type { MapProvider } from "@shared/schema";

export async function fetchMapProviders(): Promise<MapProvider[]> {
  const response = await fetch("/api/maps/providers");
  if (!response.ok) throw new Error("Failed to fetch map providers");
  return response.json();
}

