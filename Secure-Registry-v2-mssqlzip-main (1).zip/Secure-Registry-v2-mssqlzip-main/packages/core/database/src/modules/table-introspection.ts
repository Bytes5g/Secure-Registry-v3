import { createRequest } from "../config/connection";

export type IntrospectedColumnInfo = {
  columnName: string;
  dataType: string;
  isNullable: boolean;
  maxLength: number | null;
  precision: number | null;
  scale: number | null;
  isIdentity: boolean;
  hasDefault: boolean;
};

const cache = new Map<string, Promise<IntrospectedColumnInfo[]>>();

export async function getObjectColumns(input: {
  schemaName: string;
  objectName: string;
}): Promise<IntrospectedColumnInfo[]> {
  const cacheKey = `${input.schemaName}.${input.objectName}`;
  const cached = cache.get(cacheKey);
  if (cached) return cached;

  const pending = (async () => {
    const request = await createRequest();
    request.input("schemaName", input.schemaName);
    request.input("objectName", input.objectName);

    const result = await request.query<{
      column_name: string;
      data_type: string;
      is_nullable: boolean;
      max_length: number | null;
      precision: number | null;
      scale: number | null;
      is_identity: number | null;
      has_default: number | null;
    }>(
      `SELECT
         c.name AS column_name,
         ty.name AS data_type,
         CONVERT(bit, c.is_nullable) AS is_nullable,
         CONVERT(int, c.max_length) AS max_length,
         CONVERT(int, c.precision) AS precision,
         CONVERT(int, c.scale) AS scale,
         COLUMNPROPERTY(c.object_id, c.name, 'IsIdentity') AS is_identity,
         CASE WHEN dc.object_id IS NULL THEN 0 ELSE 1 END AS has_default
       FROM sys.columns c
       INNER JOIN sys.objects o ON o.object_id = c.object_id AND o.type IN ('U', 'V')
       INNER JOIN sys.schemas s ON s.schema_id = o.schema_id
       INNER JOIN sys.types ty
         ON ty.user_type_id = c.user_type_id
       LEFT JOIN sys.default_constraints dc
         ON dc.parent_object_id = c.object_id
         AND dc.parent_column_id = c.column_id
       WHERE o.name = @objectName
         AND s.name = @schemaName
       ORDER BY c.column_id`,
    );

    return result.recordset.map((row) => ({
      columnName: String(row.column_name),
      dataType: String(row.data_type || ""),
      isNullable: Boolean(row.is_nullable),
      maxLength: row.max_length == null ? null : Number(row.max_length),
      precision: row.precision == null ? null : Number(row.precision),
      scale: row.scale == null ? null : Number(row.scale),
      isIdentity: Boolean(row.is_identity),
      hasDefault: Boolean(row.has_default),
    }));
  })();

  cache.set(cacheKey, pending);
  return pending;
}

