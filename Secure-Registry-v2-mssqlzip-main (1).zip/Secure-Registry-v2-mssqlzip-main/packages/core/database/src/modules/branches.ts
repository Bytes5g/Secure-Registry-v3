import { withTransaction, type SqlExecutor } from "../config/connection";
import { deleteRow, insertRow, runQuery, runQueryOne, updateRow } from "./helpers";

export interface BranchRecord {
  id: number;
  orgId: number;
  geoUnitId: number | null;
  branchScopeLookupId: number | null;
  parentBranchId: number | null;
  name: string;
  code: string | null;
  isActive: boolean;
  metadata: unknown;
  createdAt: string | null;
  standardId: number | null;
  workContextBy?: number | null;
  createdBy?: number | null;
  updatedAt?: string | null;
  updatedBy?: number | null;
  isDeleted?: boolean | null;
}

export interface BranchNodeRecord {
  id: number;
  orgId: number;
  orgStructureNodeId: number;
  branchId: number;
  isActive: boolean;
  createdAt: string | null;
  workContextBy?: number | null;
  createdBy?: number | null;
  updatedAt?: string | null;
  updatedBy?: number | null;
  isDeleted?: boolean | null;
}

function mapBranch(row: Record<string, unknown>): BranchRecord {
  return {
    id: Number(row.id),
    orgId: Number(row.org_id),
    geoUnitId: row.geo_unit_id == null ? null : Number(row.geo_unit_id),
    branchScopeLookupId: row.branch_scope_lookup_id == null ? null : Number(row.branch_scope_lookup_id),
    parentBranchId: row.parent_branch_id == null ? null : Number(row.parent_branch_id),
    name: String(row.name || ""),
    code: row.code == null ? null : String(row.code),
    isActive: Boolean(row.is_active),
    metadata: row.metadata ?? null,
    createdAt: row.created_at == null ? null : String(row.created_at),
    standardId: row.standard_id == null ? null : Number(row.standard_id),
    workContextBy: row.work_context_by == null ? null : Number(row.work_context_by),
    createdBy: row.created_by == null ? null : Number(row.created_by),
    updatedAt: row.updated_at == null ? null : String(row.updated_at),
    updatedBy: row.updated_by == null ? null : Number(row.updated_by),
    isDeleted: row.is_deleted == null ? null : Boolean(row.is_deleted),
  };
}

function mapBranchNode(row: Record<string, unknown>): BranchNodeRecord {
  return {
    id: Number(row.id),
    orgId: Number(row.org_id),
    orgStructureNodeId: Number(row.org_structure_node_id),
    branchId: Number(row.branch_id),
    isActive: Boolean(row.is_active),
    createdAt: row.created_at == null ? null : String(row.created_at),
    workContextBy: row.work_context_by == null ? null : Number(row.work_context_by),
    createdBy: row.created_by == null ? null : Number(row.created_by),
    updatedAt: row.updated_at == null ? null : String(row.updated_at),
    updatedBy: row.updated_by == null ? null : Number(row.updated_by),
    isDeleted: row.is_deleted == null ? null : Boolean(row.is_deleted),
  };
}

function isInvalidObjectNameError(error: unknown): boolean {
  const message = String((error as { message?: unknown } | null)?.message ?? error ?? "");
  return message.toLowerCase().includes("invalid object name");
}

export class BranchesModule {
  async getAll(): Promise<BranchRecord[]> {
    const rows = await runQuery<Record<string, unknown>>(
      "SELECT * FROM [org_branches] ORDER BY id",
    );
    return rows.map(mapBranch);
  }

  async getById(id: number): Promise<BranchRecord | undefined> {
    const row = await runQueryOne<Record<string, unknown>>(
      "SELECT TOP 1 * FROM [org_branches] WHERE id = @id",
      { id },
    );
    return row ? mapBranch(row) : undefined;
  }

  async create(payload: Omit<BranchRecord, "id" | "createdAt">, executor?: SqlExecutor): Promise<BranchRecord> {
    if (!executor) {
      return withTransaction((tx) => this.create(payload, tx));
    }

    const row = await insertRow<Record<string, unknown>>(
      "org_branches",
      {
        org_id: payload.orgId,
        geo_unit_id: payload.geoUnitId,
        branch_scope_lookup_id: payload.branchScopeLookupId,
        parent_branch_id: payload.parentBranchId,
        name: payload.name,
        code: payload.code,
        is_active: payload.isActive,
        metadata: payload.metadata,
        standard_id: payload.standardId,
        work_context_by: payload.workContextBy,
        created_by: payload.createdBy,
      },
      executor,
    );
    const branch = mapBranch(row);
    return branch;
  }

  async update(id: number, payload: Partial<BranchRecord>, executor?: SqlExecutor): Promise<BranchRecord | undefined> {
    if (!executor) {
      return withTransaction((tx) => this.update(id, payload, tx));
    }

    const mappings: Array<[keyof BranchRecord, string]> = [
      ["orgId", "org_id"],
      ["geoUnitId", "geo_unit_id"],
      ["branchScopeLookupId", "branch_scope_lookup_id"],
      ["parentBranchId", "parent_branch_id"],
      ["name", "name"],
      ["code", "code"],
      ["isActive", "is_active"],
      ["metadata", "metadata"],
      ["standardId", "standard_id"],
      ["workContextBy", "work_context_by"],
      ["updatedAt", "updated_at"],
      ["updatedBy", "updated_by"],
      ["isDeleted", "is_deleted"],
    ];

    const updatePayload: Record<string, unknown> = {};
    for (const [key, column] of mappings) {
      if (payload[key] !== undefined) {
        updatePayload[column] = payload[key] as unknown;
      }
    }

    const row = await updateRow<Record<string, unknown>>(
      "org_branches",
      id,
      updatePayload,
      executor,
    );
    if (!row) {
      return undefined;
    }

    const branch = mapBranch(row);
    return branch;
  }

  async delete(id: number, executor?: SqlExecutor): Promise<boolean> {
    if (!executor) {
      return withTransaction((tx) => this.delete(id, tx));
    }

    const deleted = await deleteRow("org_branches", id, executor);
    return deleted;
  }

  async getNodesByBranchId(branchId: number) {
    try {
      return await runQuery<Record<string, unknown>>(
        `SELECT
           id,
           branch_id,
           org_structure_node_id,
           name,
           code,
           structure_id,
           parent_id,
           node_type,
           node_type_code,
           org_structure_code_id,
           org_role_title_id,
           role_title_name
         FROM dbo.vw_org_branch_structure_nodes
         WHERE branch_id = @branchId
         ORDER BY org_structure_node_id, id`,
        { branchId },
      );
    } catch (error) {
      if (!isInvalidObjectNameError(error)) {
        throw error;
      }

      return await runQuery<Record<string, unknown>>(
        `SELECT
           bn.id,
           bn.branch_id,
           bn.org_structure_node_id,
           s.name,
           s.code,
           s.structure_id,
           s.parent_id,
           COALESCE(vr.structure_name, lv.name) AS node_type,
           vr.structure_code AS node_type_code,
           vr.org_structure_code_id,
           vr.org_role_title_id,
           vr.role_title_name
         FROM dbo.org_branch_nodes bn
         INNER JOIN dbo.org_entity_structure s ON s.id = bn.org_structure_node_id
         LEFT JOIN dbo.org_structure_codes lv ON s.structure_id = lv.id
         INNER JOIN dbo.org_branches b ON b.id = bn.branch_id AND b.org_id = bn.org_id
         OUTER APPLY (
           SELECT TOP (1)
             r.mapping_id,
             r.org_structure_code_id,
             r.structure_name,
             r.structure_code,
             r.org_role_title_id,
             r.role_title_name,
             r.order_index
           FROM dbo.vw_org_structure_roles r
           WHERE r.org_id = s.org_id
             AND r.branch_scope_id = b.branch_scope_lookup_id
             AND r.org_structure_id = s.structure_id
             AND r.is_active = 1
           ORDER BY ISNULL(r.order_index, 0), r.mapping_id
         ) vr
         WHERE bn.branch_id = @branchId
         ORDER BY s.level, s.order_index, s.name`,
        { branchId },
      );
    }
  }

  async getSourceTreeByBranchId(branchId: number) {
    try {
      return await runQuery<Record<string, unknown>>(
        `SELECT
           id,
           parent_id,
           org_id,
           name,
           code,
           structure_id,
           is_active,
           order_index,
           level,
           created_at,
           node_type
         FROM dbo.vw_org_structure_tree_by_branch
         WHERE branch_id = @branchId
         ORDER BY level, order_index, name`,
        { branchId },
      );
    } catch (error) {
      if (!isInvalidObjectNameError(error)) {
        throw error;
      }

      return await runQuery<Record<string, unknown>>(
        `SELECT
           child.id,
           child.parent_id,
           child.org_id,
           child.name,
           child.code,
           child.structure_id,
           child.is_active,
           child.order_index,
           child.level,
           child.created_at,
           lv.name AS node_type
         FROM dbo.org_entity_structure child
         LEFT JOIN dbo.org_structure_codes lv ON child.structure_id = lv.id
         WHERE child.org_id = (SELECT TOP 1 CAST(org_id AS INT) FROM dbo.org_branches WHERE id = @branchId)
           AND child.is_active = 1
         ORDER BY child.level, child.order_index, child.name`,
        { branchId },
      );
    }
  }

  async replaceBranchNodes(
    branchId: number,
    orgId: number,
    nodeIds: number[],
    writeContext?: { userId?: number | null; workContextBy?: number | null },
    executor?: SqlExecutor,
  ): Promise<void> {
    if (!executor) {
      await withTransaction((tx) => this.replaceBranchNodes(branchId, orgId, nodeIds, writeContext, tx));
      return;
    }

    // هذه الدالة تُزامن عقد الفرع في org_branch_nodes بدون حذف فعلي لتجنب كسر المراجع (FK) على work_context_by
    const normalizedNodeIds = Array.from(
      new Set(
        (Array.isArray(nodeIds) ? nodeIds : [])
          .map((v) => Number(v))
          .filter((v) => Number.isFinite(v) && v > 0),
      ),
    );

    const existingRows = await runQuery<Record<string, unknown>>(
      `
        SELECT
          id,
          org_structure_node_id,
          is_active,
          is_deleted
        FROM dbo.org_branch_nodes
        WHERE branch_id = @branchId
          AND org_id = @orgId
      `,
      { branchId, orgId },
      executor,
    );

    const existingByNodeId = new Map<number, { id: number; isActive: boolean; isDeleted: boolean }>();
    for (const row of existingRows) {
      const nodeId = Number((row as any).org_structure_node_id);
      if (!Number.isFinite(nodeId)) continue;
      existingByNodeId.set(nodeId, {
        id: Number((row as any).id),
        isActive: Boolean((row as any).is_active),
        isDeleted: Boolean((row as any).is_deleted),
      });
    }

    const desired = new Set(normalizedNodeIds);
    const toDeactivate: number[] = [];
    const toActivate: number[] = [];
    const toInsert: number[] = [];

    existingByNodeId.forEach((info, existingNodeId) => {
      if (!desired.has(existingNodeId) && !info.isDeleted && info.isActive) {
        toDeactivate.push(existingNodeId);
      }
      if (desired.has(existingNodeId) && (info.isDeleted || !info.isActive)) {
        toActivate.push(existingNodeId);
      }
    });

    for (const nodeId of normalizedNodeIds) {
      if (!existingByNodeId.has(nodeId)) {
        toInsert.push(nodeId);
      }
    }

    const workContextByRaw = writeContext?.workContextBy ?? null;
    const workContextBy = workContextByRaw == null ? NaN : Number(workContextByRaw);
    if (!Number.isFinite(workContextBy)) {
      throw new Error("workContextBy is required for replaceBranchNodes");
    }

    const updatedBy = writeContext?.userId ?? null;
    const updatedAt = new Date();

    const buildInParams = (ids: number[], prefix: string) => {
      const params: Record<string, unknown> = {};
      const tokens: string[] = [];
      ids.forEach((id, i) => {
        const key = `${prefix}${i}`;
        params[key] = id;
        tokens.push(`@${key}`);
      });
      return { params, inList: tokens.join(", ") };
    };

    if (toDeactivate.length) {
      const { params, inList } = buildInParams(toDeactivate, "d");
      await runQuery(
        `
          UPDATE dbo.org_branch_nodes
          SET
            is_active = 0,
            work_context_by = @workContextBy,
            updated_by = @updatedBy,
            updated_at = @updatedAt
          WHERE branch_id = @branchId
            AND org_id = @orgId
            AND is_deleted = 0
            AND org_structure_node_id IN (${inList})
        `,
        { branchId, orgId, workContextBy, updatedBy, updatedAt, ...params },
        executor,
      );
    }

    if (toActivate.length) {
      const { params, inList } = buildInParams(toActivate, "a");
      await runQuery(
        `
          UPDATE dbo.org_branch_nodes
          SET
            is_active = 1,
            is_deleted = 0,
            work_context_by = @workContextBy,
            updated_by = @updatedBy,
            updated_at = @updatedAt
          WHERE branch_id = @branchId
            AND org_id = @orgId
            AND org_structure_node_id IN (${inList})
        `,
        { branchId, orgId, workContextBy, updatedBy, updatedAt, ...params },
        executor,
      );
    }

    for (const nodeId of toInsert) {
      await runQuery(
        `
          INSERT INTO dbo.org_branch_nodes
            (org_id, org_structure_node_id, branch_id, is_active, is_deleted, work_context_by, created_by)
          VALUES
            (@orgId, @nodeId, @branchId, 1, 0, @workContextBy, @createdBy)
        `,
        {
          orgId,
          nodeId,
          branchId,
          workContextBy,
          createdBy: writeContext?.userId ?? null,
        },
        executor,
      );
    }
  }

  async getBranchNodesLinks(branchId: number): Promise<BranchNodeRecord[]> {
    const rows = await runQuery<Record<string, unknown>>(
      "SELECT * FROM [org_branch_nodes] WHERE branch_id = @branchId AND is_deleted = 0 AND is_active = 1 ORDER BY id",
      { branchId },
    );
    return rows.map(mapBranchNode);
  }

  async getBranchesByStructureNodeId(orgStructureNodeId: number): Promise<BranchRecord[]> {
    const rows = await runQuery<Record<string, unknown>>(
      `SELECT DISTINCT b.*
       FROM dbo.org_branch_nodes bn
       INNER JOIN dbo.org_branches b ON b.id = bn.branch_id
       WHERE bn.org_structure_node_id = @orgStructureNodeId
         AND (bn.is_active = 1 OR bn.is_active IS NULL)
         AND (b.is_active = 1 OR b.is_active IS NULL)
       ORDER BY b.id`,
      { orgStructureNodeId },
    );
    return rows.map(mapBranch);
  }
}

export const branchesModule = new BranchesModule();
