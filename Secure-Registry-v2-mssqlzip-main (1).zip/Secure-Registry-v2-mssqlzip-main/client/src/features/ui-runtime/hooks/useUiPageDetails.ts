import { useQuery } from "@tanstack/react-query";
import { genericApi } from "@/lib/api/generic";

export function useUiPageDetails<TDetails extends { config?: unknown }>(args: {
  pageCode: string;
  entityType: string;
  ignoreOverride?: boolean;
}) {
  return useQuery({
    queryKey: ["ui-page-details", args.pageCode, args.entityType, args.ignoreOverride ? 1 : 0],
    queryFn: async () => genericApi.getUiPageDetails(args.pageCode, args.entityType, { ignoreOverride: args.ignoreOverride }) as Promise<TDetails>,
  });
}

