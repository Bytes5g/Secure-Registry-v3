import { useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Building2, Check, GitBranch, Network, Users, X } from "lucide-react";
import { Badge, Card, CardContent, CardDescription, CardHeader, CardTitle, Input, Switch } from "@secure-registry/components-ui";
import {
  EditableInfoCard,
  InfoRow,
  ProfileOverviewTemplate,
  type StatCardProps,
} from "@/components/profile";
import { LocationTypePicker } from "@/components/lookups/LocationTypePicker";
import {
  fetchOrganizationChildren,
  fetchOrgTreeFlat,
  updateOrganization,
  type OrgWithDetails,
} from "@/lib/api/org-admin";
import { apiRequest } from "@/lib/queryClient";
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart";
import { Bar, BarChart, CartesianGrid, Cell, Pie, PieChart, XAxis, YAxis } from "recharts";

interface OrgOverviewTabProps {
  orgId: number;
  org: OrgWithDetails;
}

function formatArabicDate(value: unknown): string {
  if (!value) return "—";
  const d = new Date(value as any);
  if (Number.isNaN(d.getTime())) return "—";
  return d.toLocaleDateString("ar", { year: "numeric", month: "long", day: "numeric" });
}

export function OrgOverviewTab({ orgId, org }: OrgOverviewTabProps) {
  const queryClient = useQueryClient();
  const [isEditing, setIsEditing] = useState(false);
  const [draft, setDraft] = useState({
    name: org.name ?? "",
    code: org.code ?? "",
    isActive: !!org.isActive,
    locationId: (org.locationId ?? null) as number | null,
  });

  const { data: subOrgs = [] } = useQuery({
    queryKey: ["org-entity-children", orgId],
    queryFn: () => fetchOrganizationChildren(orgId),
    enabled: Number.isFinite(orgId) && orgId > 0,
  });

  const { data: treeNodes = [] } = useQuery<any[]>({
    queryKey: ["org-entity-tree-flat-overview", orgId],
    queryFn: () => fetchOrgTreeFlat(orgId),
    enabled: Number.isFinite(orgId) && orgId > 0,
  });

  const { data: allBranches = [] } = useQuery<any[]>({
    queryKey: ["branches-all-overview"],
    queryFn: () => apiRequest("GET", "/api/branches"),
  });

  const { data: orgEmployees = [], isLoading: employeesLoading } = useQuery<any[]>({
    queryKey: ["org-employees-overview", orgId],
    queryFn: () => apiRequest("GET", `/api/org/organizations/${orgId}/employees`),
    enabled: Number.isFinite(orgId) && orgId > 0,
  });

  const { data: structureCodes = [] } = useQuery<any[]>({
    queryKey: ["org-structure-codes-overview"],
    queryFn: () => apiRequest("GET", "/api/org-structure-codes"),
  });

  const stats = useMemo(() => {
    const units = Array.isArray(treeNodes) ? treeNodes : [];
    const branches = (Array.isArray(allBranches) ? allBranches : []).filter(
      (b) => Number(b?.orgId ?? b?.org_id) === orgId,
    );
    const employees = Array.isArray(orgEmployees) ? orgEmployees : [];
    const managers = employees.filter((r) => Boolean(r?.isManager ?? r?.is_manager));
    const uniquePersons = new Set(
      employees
        .map((r) => r?.personId ?? r?.person_id ?? null)
        .map((v) => Number(v))
        .filter((v) => Number.isFinite(v)),
    );
    return {
      units: units.length,
      activeUnits: units.filter((n) => n?.isActive ?? n?.is_active).length,
      branches: branches.length,
      activeBranches: branches.filter((b) => b?.isActive ?? b?.is_active).length,
      subOrgs: subOrgs.length,
      maxLevel: units.reduce((m, n) => Math.max(m, Number(n?.level ?? 0)), 0),
      employees: employees.length,
      managers: managers.length,
      persons: uniquePersons.size,
    };
  }, [treeNodes, allBranches, orgEmployees, subOrgs, orgId]);

  const employeesByBranch = useMemo(() => {
    const employees = Array.isArray(orgEmployees) ? orgEmployees : [];
    const by = new Map<string, { label: string; staff: number; managers: number }>();
    for (const e of employees) {
      const branchName = String(e?.branchName ?? e?.branch_name ?? "—");
      const isManager = Boolean(e?.isManager ?? e?.is_manager);
      const current = by.get(branchName) ?? { label: branchName, staff: 0, managers: 0 };
      if (isManager) current.managers += 1;
      else current.staff += 1;
      by.set(branchName, current);
    }
    const list = Array.from(by.values());
    list.sort((a, b) => (b.staff + b.managers) - (a.staff + a.managers));
    return list.slice(0, 12);
  }, [orgEmployees]);

  const unitsByStructure = useMemo(() => {
    const units = Array.isArray(treeNodes) ? treeNodes : [];
    const codes = Array.isArray(structureCodes) ? structureCodes : [];
    const structureNameById = new Map<number, string>();
    for (const c of codes) {
      const id = Number(c?.id);
      if (!Number.isFinite(id)) continue;
      const name = String(c?.name ?? c?.nameAr ?? c?.structure_name ?? "—");
      structureNameById.set(id, name);
    }

    const counts = new Map<string, number>();
    for (const u of units) {
      const structureId = u?.structureId ?? u?.structure_id ?? null;
      const id = structureId == null ? null : Number(structureId);
      const label =
        id != null && Number.isFinite(id) ? (structureNameById.get(id) ?? `#${id}`) : "غير محدد";
      counts.set(label, (counts.get(label) ?? 0) + 1);
    }

    const list = Array.from(counts.entries())
      .map(([label, value]) => ({ label, value }))
      .sort((a, b) => b.value - a.value);

    const top = list.slice(0, 8);
    const rest = list.slice(8);
    const restTotal = rest.reduce((sum, r) => sum + r.value, 0);
    return restTotal > 0 ? [...top, { label: "أخرى", value: restTotal }] : top;
  }, [structureCodes, treeNodes]);

  const pieColors = ["#0ea5e9", "#22c55e", "#f97316", "#a855f7", "#ef4444", "#14b8a6", "#eab308", "#6366f1"];

  const statItems: StatCardProps[] = [
    {
      icon: <Network className="h-5 w-5" />,
      label: "الوحدات التنظيمية",
      value: stats.units,
      hint: `${stats.activeUnits} فعّالة`,
      tone: "accent",
    },
    {
      icon: <GitBranch className="h-5 w-5" />,
      label: "الفروع",
      value: stats.branches,
      hint: `${stats.activeBranches} فعّال`,
    },
    { icon: <Building2 className="h-5 w-5" />, label: "جهات تابعة", value: stats.subOrgs },
    {
      icon: <Users className="h-5 w-5" />,
      label: "الموظفون",
      value: employeesLoading ? "—" : stats.employees,
      hint: employeesLoading ? "جاري التحميل…" : `${stats.managers} مسؤول`,
      tone: "muted",
    },
    {
      icon: <Users className="h-5 w-5" />,
      label: "الأشخاص",
      value: employeesLoading ? "—" : stats.persons,
      hint: "عدد الأشخاص الفريد",
      tone: "muted",
    },
    {
      icon: <Users className="h-5 w-5" />,
      label: "عمق الهيكل",
      value: stats.maxLevel || "—",
      hint: "أقصى مستوى",
      tone: "muted",
    },
    {
      icon: org.isActive ? (
        <Check className="h-5 w-5 text-green-600" />
      ) : (
        <X className="h-5 w-5 text-destructive" />
      ),
      label: "حالة التشغيل",
      value: org.isActive ? "فعّالة" : "موقوفة",
      tone: org.isActive ? "accent" : "warning",
    },
  ];

  const updateMutation = useMutation({
    mutationFn: (patch: Partial<{ name: string; code: string; isActive: boolean; locationId: number | null }>) =>
      updateOrganization(orgId, patch),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["org-entity", orgId] });
      setIsEditing(false);
    },
  });

  const handleSave = () => {
    const patch: Record<string, unknown> = {};
    if (draft.name !== org.name) patch.name = draft.name;
    if (draft.code !== org.code) patch.code = draft.code;
    if (draft.isActive !== !!org.isActive) patch.isActive = draft.isActive;
    if ((draft.locationId ?? null) !== (org.locationId ?? null)) patch.locationId = draft.locationId;
    if (Object.keys(patch).length === 0) {
      setIsEditing(false);
      return;
    }
    updateMutation.mutate(patch);
  };

  const handleCancel = () => {
    setDraft({
      name: org.name ?? "",
      code: org.code ?? "",
      isActive: !!org.isActive,
      locationId: (org.locationId ?? null) as number | null,
    });
    setIsEditing(false);
  };

  const basicInfoCard = (
    <EditableInfoCard
      title="البيانات الأساسية"
      isEditing={isEditing}
      isSaving={updateMutation.isPending}
      errorMessage={updateMutation.isError ? "تعذّر الحفظ. الرجاء المحاولة مرة أخرى." : null}
      onEdit={() => setIsEditing(true)}
      onSave={handleSave}
      onCancel={handleCancel}
    >
      <div className="grid md:grid-cols-2 gap-x-8">
        <div>
          <InfoRow label="الاسم">
            {isEditing ? (
              <Input
                value={draft.name}
                onChange={(e) => setDraft({ ...draft, name: e.target.value })}
                className="h-8"
              />
            ) : (
              org.name || "—"
            )}
          </InfoRow>
          <InfoRow label="الكود">
            {isEditing ? (
              <Input
                value={draft.code}
                onChange={(e) => setDraft({ ...draft, code: e.target.value })}
                className="h-8"
              />
            ) : (
              org.code || "—"
            )}
          </InfoRow>
          <InfoRow label="القطاع">
            <Badge variant="outline">{org.sector?.nameAr ?? "—"}</Badge>
          </InfoRow>
        </div>
        <div>
          <InfoRow label="التصنيف">
            <Badge variant="outline">{org.category?.nameAr ?? "—"}</Badge>
          </InfoRow>
          <InfoRow label="الموقع">
            {isEditing ? (
              <LocationTypePicker
                value={draft.locationId}
                onValueChange={(v) => setDraft({ ...draft, locationId: v })}
                className="h-8"
              />
            ) : (
              <Badge variant="outline">{org.location?.nameAr ?? "—"}</Badge>
            )}
          </InfoRow>
          <InfoRow label="معرّف الجهة">
            <span className="tabular-nums text-muted-foreground">#{org.id}</span>
          </InfoRow>
          <InfoRow label="تاريخ الإنشاء">
            <span className="text-muted-foreground">{formatArabicDate(org.createdAt)}</span>
          </InfoRow>
          <InfoRow label="الحالة">
            {isEditing ? (
              <Switch
                checked={draft.isActive}
                onCheckedChange={(v) => setDraft({ ...draft, isActive: v })}
              />
            ) : (
              <Badge variant={org.isActive ? "secondary" : "outline"}>
                {org.isActive ? "فعّالة" : "موقوفة"}
              </Badge>
            )}
          </InfoRow>
        </div>
      </div>
    </EditableInfoCard>
  );

  const chartsSection = (
    <div className="grid gap-4 md:grid-cols-2">
      <Card>
        <CardHeader>
          <CardTitle>الموظفون حسب الفرع</CardTitle>
          <CardDescription>مصدر البيانات: vw_org_employees</CardDescription>
        </CardHeader>
        <CardContent>
          {employeesLoading ? (
            <div className="text-sm text-muted-foreground">جاري التحميل…</div>
          ) : employeesByBranch.length === 0 ? (
            <div className="text-sm text-muted-foreground">لا توجد بيانات</div>
          ) : (
            <ChartContainer
              className="h-[320px] w-full"
              config={{
                staff: { label: "الموظفون", color: "hsl(var(--chart-1))" },
                managers: { label: "المسؤولون", color: "hsl(var(--chart-2))" },
              }}
            >
              <BarChart data={employeesByBranch} margin={{ left: 8, right: 8, top: 8, bottom: 8 }}>
                <CartesianGrid vertical={false} />
                <XAxis dataKey="label" tickLine={false} axisLine={false} interval={0} height={80} angle={-20} textAnchor="end" />
                <YAxis tickLine={false} axisLine={false} width={40} />
                <ChartTooltip content={<ChartTooltipContent />} />
                <Bar dataKey="staff" stackId="a" radius={[0, 0, 0, 0]} fill="var(--color-staff)" />
                <Bar dataKey="managers" stackId="a" radius={[6, 6, 0, 0]} fill="var(--color-managers)" />
              </BarChart>
            </ChartContainer>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>توزيع الوحدات حسب النوع</CardTitle>
          <CardDescription>مصدر البيانات: org_entity_structure + org_structure_codes</CardDescription>
        </CardHeader>
        <CardContent>
          {unitsByStructure.length === 0 ? (
            <div className="text-sm text-muted-foreground">لا توجد بيانات</div>
          ) : (
            <ChartContainer
              className="h-[320px] w-full"
              config={{
                value: { label: "عدد الوحدات", color: "hsl(var(--chart-3))" },
              }}
            >
              <PieChart>
                <ChartTooltip content={<ChartTooltipContent />} />
                <Pie data={unitsByStructure} dataKey="value" nameKey="label" innerRadius={70} outerRadius={110} paddingAngle={2}>
                  {unitsByStructure.map((entry, index) => (
                    <Cell key={`${entry.label}`} fill={pieColors[index % pieColors.length]} />
                  ))}
                </Pie>
              </PieChart>
            </ChartContainer>
          )}
        </CardContent>
      </Card>
    </div>
  );

  return (
    <ProfileOverviewTemplate
      stats={statItems}
      statsTitle="إحصائيات الجهة"
      sections={
        <>
          {basicInfoCard}
          {chartsSection}
        </>
      }
    />
  );
}
