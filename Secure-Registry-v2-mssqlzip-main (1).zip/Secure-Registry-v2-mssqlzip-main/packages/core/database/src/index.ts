export {
  buildDbConfig,
  closePool,
  createRequest,
  type DbConfigOverrides,
  getPool,
  pingDb,
  sql,
  type SqlExecutor,
  withTransaction,
} from "./config/connection";

export { getEnv, getEnvBool, getEnvInt } from "./config/env";

export {
  lookupModule,
  type LookupTypeRecord,
  type LookupValueRecord,
} from "./modules/lookups";

export {
  geoModule,
  type GeoAdminUnitRecord,
} from "./modules/geo";

export {
  orgModule,
  type OrganizationRecord,
  type TreeNodeRecord,
} from "./modules/org";

export {
  authModule,
  type AuthRoleRecord,
  type AuthUserRecord,
} from "./modules/auth";

export {
  branchesModule,
  type BranchNodeRecord,
  type BranchRecord,
} from "./modules/branches";

export {
  foldersModule,
  type FolderRecord,
} from "./modules/folders";

export {
  filesModule,
  type FileRecord,
} from "./modules/files";

export {
  settingsModule,
  type FileUploadSettings,
} from "./modules/settings";

export {
  uiRegistryModule,
  type UiPageOverridePayload,
  type UiPageColumnOverride,
  type UiPageFormFieldOverride,
  type UiPageRegistryRecord,
} from "./modules/ui-registry";

export {
  entityFilesModule,
  type EntityFileLinkRecord,
} from "./modules/entity-files";

export {
  mapProvidersModule,
  type MapProviderRecord,
} from "./modules/map-providers";

export {
  personnelModule,
  type OrgEmployeeRecord,
} from "./modules/personnel";

export {
  personsModule,
  type PersonAssignmentRecord,
  type PersonContactRecord,
  type PersonDetailsRecord,
  type PersonListRecord,
} from "./modules/persons";

export {
  userContextModule,
  type UserWorkContextRecord,
} from "./modules/user-context";

export {
  orgStructureRoleTitlesModule,
  type OrgStructureRoleTitleRecord,
  type OrgStructureRoleTitleMutation,
} from "./modules/org-structure-role-titles";

export {
  standardFieldsModule,
  type StandardFieldDefinition,
} from "./modules/standard-fields";

export {
  getSchemaDictionaryColumns,
  type SchemaDictionaryColumn,
} from "./modules/schema-dictionary";

export {
  getObjectColumns,
  type IntrospectedColumnInfo,
} from "./modules/table-introspection";

export {
  getObjectTableInfo,
  type ObjectTableInfo,
  type ObjectTableColumnInfo,
} from "./modules/object-table-info";

export {
  getInformationSchemaColumns,
  type InformationSchemaColumn,
} from "./modules/information-schema";

export {
  getMetaColumnsForObject,
  type MetaColumn,
} from "./modules/meta-columns";

export {
  uiDataSourcesModule,
  type ExecuteUiDataSourceResult,
  type UiDataSourceExecutionActor,
} from "./modules/ui-data-sources";

export {
  getSystemDashboardStatistics,
  type SystemDashboardStatisticRecord,
} from "./modules/dashboard";

export {
  bindValues as crudBindValues,
  buildInsertPlan as crudBuildInsertPlan,
  buildWhereFromQuery,
  executeGetById,
  executeInsert,
  executeList,
  executeSoftDelete,
  executeUpdate,
  pickBodyColumns,
  resolveIdCondition,
  type CrudColumnInfo,
  type CrudTableInfo,
  type PickedColumn,
} from "./modules/crud-factory";

export {
  deleteSession,
  getSessionPayload,
  touchSession,
  upsertSession,
} from "./modules/sessions";
