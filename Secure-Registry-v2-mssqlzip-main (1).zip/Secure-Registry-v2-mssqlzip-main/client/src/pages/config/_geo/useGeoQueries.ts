import { useQuery } from "@tanstack/react-query";
import {
  fetchGeoCountries,
  fetchGeoLevels,
  fetchGeoUnits,
  type GeoCountry,
} from "@/lib/api/geo-admin";
import { fetchMapProviders } from "@/lib/api/maps";
import { mapToTreeNode } from "./types";

export function useGeoQueries(selectedCountry: GeoCountry | null, selectedNodeId: number | null) {
  const countries = useQuery({
    queryKey: ["geo", "countries"],
    queryFn: fetchGeoCountries,
  });

  const geoLevels = useQuery({
    queryKey: ["geo", "levels"],
    queryFn: fetchGeoLevels,
  });

  const mapProviders = useQuery({
    queryKey: ["maps", "providers"],
    queryFn: fetchMapProviders,
  });

  const rootNodes = useQuery({
    queryKey: ["geo", "tree-root", selectedCountry?.id],
    enabled: !!selectedCountry,
    queryFn: async () => {
      const result = await fetchGeoUnits({
        countryId: selectedCountry!.id,
        parentId: "null",
        limit: 500,
      });
      return result.data.map(mapToTreeNode);
    },
  });

  const units = useQuery({
    queryKey: ["geo", "units", selectedCountry?.id, selectedNodeId ?? "root"],
    enabled: !!selectedCountry,
    queryFn: () =>
      fetchGeoUnits({
        countryId: selectedCountry!.id,
        parentId: selectedNodeId ?? "null",
        limit: 500,
      }),
  });

  return { countries, geoLevels, mapProviders, rootNodes, units };
}
