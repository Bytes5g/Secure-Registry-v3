import { useCallback, useState } from "react";
import { Map } from "lucide-react";
import type { GeoAdminUnit, InsertGeoAdminUnit } from "@shared/schema";
import { TreeNavigationPanel } from "@/components/shared";
import type { TreeNode } from "@secure-registry/components-ui";
import { useToast } from "@/hooks/use-toast";
import { fetchGeoUnits, type GeoCountry } from "@/lib/api/geo-admin";
import { MasterDetailBrowser } from "@/components/data-explorer";
import { CountriesGate } from "./_geo/CountriesGate";
import { LOCAL_LEVEL_MAX, useGeoFormFields } from "./_geo/useGeoFormFields";
import {
  CLOSED_DIALOG,
  type DialogState,
  type GeoTreeNode,
  mapToTreeNode,
  normalizeNullableNumber,
} from "./_geo/types";
import { useGeoQueries } from "./_geo/useGeoQueries";
import { useGeoMutations } from "./_geo/useGeoMutations";
import { useGeoUnitColumns } from "./_geo/useGeoUnitColumns";
import { GeoDetailPane } from "./_geo/GeoDetailPane";
import { GeoDialogs } from "./_geo/GeoDialogs";

export default function GeoManagement() {
  const { toast } = useToast();
  const [selectedCountry, setSelectedCountry] = useState<GeoCountry | null>(null);
  const [selectedNode, setSelectedNode] = useState<GeoTreeNode | null>(null);
  const [dialogState, setDialogState] = useState<DialogState>(CLOSED_DIALOG);
  const [deleteTarget, setDeleteTarget] = useState<GeoAdminUnit | null>(null);

  const { countries, geoLevels, mapProviders, rootNodes, units } = useGeoQueries(
    selectedCountry,
    selectedNode?.id ?? null,
  );

  const { fields, initialData, localLevels } = useGeoFormFields({
    countryId: selectedCountry?.id,
    geoLevels: geoLevels.data ?? [],
    selectedNodeId: selectedNode?.id,
    selectedNodeLevel: selectedNode?.level,
    editingUnit: dialogState.unit,
  });

  const { create, update, remove } = useGeoMutations({
    onCreateSuccess: () => setDialogState(CLOSED_DIALOG),
    onUpdateSuccess: () => setDialogState(CLOSED_DIALOG),
    onDeleteSuccess: () => {
      if (deleteTarget && selectedNode?.id === deleteTarget.id) setSelectedNode(null);
      setDeleteTarget(null);
    },
  });

  const openCreate = () => {
    if (!selectedCountry) return;
    if (selectedNode && (selectedNode.level ?? 0) >= LOCAL_LEVEL_MAX) {
      toast({
        title: "لا يمكن الإضافة هنا",
        description: "تم الوصول إلى آخر مستوى إداري داخل الدولة المحددة.",
        variant: "destructive",
      });
      return;
    }
    setDialogState({ open: true, mode: "create", unit: null });
  };

  const loadChildren = useCallback(
    async (parentId: number): Promise<TreeNode[]> => {
      if (!selectedCountry) return [];
      const result = await fetchGeoUnits({ countryId: selectedCountry.id, parentId, limit: 500 });
      return result.data.map(mapToTreeNode);
    },
    [selectedCountry],
  );

  const handleSubmit = (values: Record<string, unknown>) => {
    if (!selectedCountry) return;
    const payload: InsertGeoAdminUnit = {
      countryId: selectedCountry.id,
      parentId: normalizeNullableNumber(values.parentId),
      level: normalizeNullableNumber(values.level),
      codes: values.codes ? String(values.codes) : null,
      name: String(values.name || "").trim(),
      nameEn: values.nameEn ? String(values.nameEn) : null,
      adminTypeAr: values.adminTypeAr ? String(values.adminTypeAr) : null,
      adminTypeEn: values.adminTypeEn ? String(values.adminTypeEn) : null,
      isActive: Boolean(values.isActive),
    };
    if (dialogState.mode === "edit" && dialogState.unit) {
      update.mutate({ id: dialogState.unit.id, data: payload });
      return;
    }
    create.mutate(payload);
  };

  const columns = useGeoUnitColumns({
    localLevels,
    onView: (unit) => setDialogState({ open: true, mode: "view", unit }),
    onSelectNode: setSelectedNode,
  });

  if (!selectedCountry) {
    return (
      <CountriesGate
        countries={countries.data ?? []}
        isLoading={countries.isLoading}
        onEnter={(c) => {
          setSelectedCountry(c);
          setSelectedNode(null);
        }}
      />
    );
  }

  return (
    <>
      <MasterDetailBrowser
        master={
          <TreeNavigationPanel
            title={`هيكل ${selectedCountry.name}`}
            icon={<Map className="h-5 w-5 text-primary" />}
            rootNodes={rootNodes.data ?? []}
            selectedNodeId={selectedNode?.id}
            onSelectNode={(node) => setSelectedNode((node as GeoTreeNode | null) ?? null)}
            loadChildren={loadChildren}
            rootLabel={selectedCountry.name}
            className="flex h-full flex-col overflow-hidden bg-card shadow-sm"
            headerClassName="border-b bg-muted/30 p-4"
            contentClassName="flex-1 overflow-auto p-2"
            treeClassName={rootNodes.isLoading ? "opacity-60" : undefined}
          />
        }
        detail={
          <GeoDetailPane
            country={selectedCountry}
            selectedNode={selectedNode}
            units={units.data?.data ?? []}
            isUnitsLoading={units.isLoading}
            columns={columns}
            onBackToCountries={() => {
              setSelectedCountry(null);
              setSelectedNode(null);
            }}
            onAdd={openCreate}
            onEdit={(u) => setDialogState({ open: true, mode: "edit", unit: u })}
            onDelete={setDeleteTarget}
          />
        }
      />

      <GeoDialogs
        countryName={selectedCountry.name}
        dialogState={dialogState}
        onDialogOpenChange={(open) => setDialogState((s) => (open ? s : CLOSED_DIALOG))}
        fields={fields}
        initialData={initialData}
        mapProviders={mapProviders.data ?? []}
        onSubmit={handleSubmit}
        isSubmitting={create.isPending || update.isPending}
        deleteTarget={deleteTarget}
        onDeleteOpenChange={(open) => !open && setDeleteTarget(null)}
        onConfirmDelete={() => deleteTarget && remove.mutate(deleteTarget.id)}
        isDeleting={remove.isPending}
      />
    </>
  );
}
