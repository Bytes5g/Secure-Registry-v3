import type { Express, NextFunction, Request, Response } from "express";

export function log(message: string, source = "express"): void {
  const formattedTime = new Date().toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
    second: "2-digit",
    hour12: true,
  });
  console.log(`${formattedTime} [${source}] ${message}`);
}

export function summarizeForLog(payload: unknown): unknown {
  if (!payload || typeof payload !== "object") {
    if (typeof payload === "string" && payload.length > 500) {
      return { type: "string", length: payload.length };
    }
    return payload;
  }

  if (Array.isArray(payload)) return { arrayCount: payload.length };

  const p = payload as any;

  if (Array.isArray(p.data)) {
    const { page, limit, total, totalPages, success } = p;
    return {
      ...(typeof success === "boolean" ? { success } : {}),
      dataCount: p.data.length,
      ...(page !== undefined ? { page } : {}),
      ...(limit !== undefined ? { limit } : {}),
      ...(total !== undefined ? { total } : {}),
      ...(totalPages !== undefined ? { totalPages } : {}),
    };
  }

  if (p.error && typeof p.error === "object") {
    const { success } = p;
    const { code, message } = p.error;
    return {
      ...(typeof success === "boolean" ? { success } : {}),
      error: {
        ...(typeof code === "string" ? { code } : {}),
        ...(typeof message === "string" ? { message } : {}),
      },
    };
  }

  if (p.authenticated !== undefined) {
    return {
      authenticated: Boolean(p.authenticated),
      userId: p?.user?.id ?? null,
      role: p?.user?.role ?? null,
    };
  }

  if (p.success !== undefined) return { success: Boolean(p.success) };

  return { keys: Object.keys(p).slice(0, 12) };
}

export function applyRequestLogger(app: Express): void {
  app.use((req: Request, res: Response, next: NextFunction) => {
    const start = Date.now();
    const reqPath = req.path;
    let captured: Record<string, any> | undefined;

    const originalJson = res.json.bind(res);
    res.json = ((bodyJson: any) => {
      captured = bodyJson;
      return originalJson(bodyJson);
    }) as typeof res.json;

    res.on("finish", () => {
      const duration = Date.now() - start;
      if (reqPath.startsWith("/api")) {
        let line = `${req.method} ${reqPath} ${res.statusCode} in ${duration}ms`;
        if (captured) line += ` :: ${JSON.stringify(summarizeForLog(captured))}`;
        log(line);
      }
    });

    next();
  });
}
