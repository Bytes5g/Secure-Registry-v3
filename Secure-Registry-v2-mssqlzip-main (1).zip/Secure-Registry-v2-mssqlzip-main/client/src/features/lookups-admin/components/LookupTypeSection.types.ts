import type { LookupTypeFormState } from "../models/lookups-admin-models";

export type LookupTypeFieldSetter = <K extends keyof LookupTypeFormState>(
  field: K,
  nextValue: LookupTypeFormState[K],
) => void;

export interface LookupTypeSectionProps {
  value: LookupTypeFormState;
  setField: LookupTypeFieldSetter;
}
