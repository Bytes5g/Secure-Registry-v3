import { useState } from "react";
import type { UseFormReturn } from "react-hook-form";

import {
  Checkbox,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
  Input,
  LookupPicker,
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
  Textarea,
} from "@secure-registry/components-ui";
import type { UiPageFormField } from "@/types/ui";
import type { LookupTypeWithValues } from "@shared/schema";

import { SYSTEM_LOOKUP_IDS } from "@/lib/constants";
import { GeoUnitMapPicker } from "./dynamic-field/GeoUnitMapPicker";
import { useDynamicFormFieldOptions } from "./dynamic-field/useDynamicFormFieldOptions";

interface DynamicFormFieldProps {
  field: UiPageFormField;
  form: UseFormReturn<any>;
  lookupTypes?: LookupTypeWithValues[];
  isReadOnly?: boolean;
}

type OptionItem = { label: string; value: string; parentValue: string | null };

export function DynamicFormField({
  field,
  form,
  lookupTypes = [],
  isReadOnly = false,
}: DynamicFormFieldProps) {
  const isDisabled = isReadOnly || field.isEditable === false;
  const enableGeoMapPicker = Boolean(
    field.lookupTypeId === SYSTEM_LOOKUP_IDS.GEO_UNITS && (field.config as any)?.enableGeoMapPicker
  );
  const [geoMapOpen, setGeoMapOpen] = useState(false);
  const [geoSearch, setGeoSearch] = useState("");

  const { options, usePicker, clearOnChange, remoteSelectDisabled, remoteQueryInfo, remoteOptionsQuery } =
    useDynamicFormFieldOptions({ field, form, lookupTypes });

  return (
    <FormField
      control={form.control}
      name={field.fieldCode}
      render={({ field: formField }) => {
        const handleValueChange = (value: any) => {
          formField.onChange(value);
          for (const dep of clearOnChange) {
            if (!dep || dep === field.fieldCode) continue;
            form.setValue(dep, "", { shouldDirty: true, shouldTouch: true, shouldValidate: true });
          }
          const onSelectSet = remoteQueryInfo?.onSelectSet as any;
          if (onSelectSet && remoteOptionsQuery.data?.records) {
            const valueKey = remoteQueryInfo?.valueKey ?? "id";
            const rec = (remoteOptionsQuery.data.records as any[]).find(
              (r) => String(r?.[valueKey]) === String(value)
            );
            if (rec) {
              for (const [targetField, recordKey] of Object.entries(onSelectSet)) {
                const v = (rec as any)?.[String(recordKey)];
                if (v == null) continue;
                form.setValue(String(targetField), String(v), {
                  shouldDirty: true,
                  shouldTouch: true,
                  shouldValidate: true,
                });
              }
            }
          }
        };

        return (
          <FormItem className="flex flex-col">
            <FormLabel>
              {field.nameAr} {field.isRequired && <span className="text-destructive">*</span>}
            </FormLabel>
            <FormControl>
              {field.fieldType === "boolean" ? (
                <Checkbox
                  checked={Boolean(formField.value)}
                  onCheckedChange={(v) => handleValueChange(Boolean(v))}
                  disabled={isDisabled}
                />
              ) : field.fieldType === "select" || field.lookupTypeId || field.options ? (
                <div className="space-y-2">
                  {usePicker ? (
                    <LookupPicker
                      value={formField.value?.toString() ?? ""}
                      onValueChange={handleValueChange}
                      options={options as OptionItem[]}
                      disabled={isDisabled || remoteSelectDisabled}
                    />
                  ) : (
                    <Select
                      onValueChange={handleValueChange}
                      value={formField.value?.toString() ?? ""}
                      disabled={isDisabled || remoteSelectDisabled}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="اختر..." />
                      </SelectTrigger>
                      <SelectContent>
                        {(options as OptionItem[]).map((option) => (
                          <SelectItem key={option.value} value={option.value}>
                            {option.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  )}

                  {enableGeoMapPicker && !isDisabled ? (
                    <GeoUnitMapPicker
                      open={geoMapOpen}
                      onOpenChange={setGeoMapOpen}
                      search={geoSearch}
                      onSearchChange={setGeoSearch}
                      selectedValue={formField.value?.toString() ?? ""}
                      onSelectValue={(value) => formField.onChange(value)}
                    />
                  ) : null}
                </div>
              ) : field.fieldType === "textarea" ? (
                <Textarea
                  {...formField}
                  value={formField.value || ""}
                  placeholder={field.placeholder}
                  disabled={isDisabled}
                  className="min-h-24"
                />
              ) : (
                <Input
                  {...formField}
                  type={field.fieldType === "number" ? "number" : "text"}
                  value={formField.value || ""}
                  placeholder={field.placeholder}
                  disabled={isDisabled}
                />
              )}
            </FormControl>
            <FormMessage />
          </FormItem>
        );
      }}
    />
  );
}
