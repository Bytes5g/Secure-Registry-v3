import type { SqlExecutor } from "../config/connection";
import { insertRow, runQuery, runQueryOne } from "./helpers";

export interface UiPageColumnOverride {
  fieldCode: string;
  nameAr: string;
  columnType: string;
  isVisible: boolean;
  isSortable: boolean;
  orderIndex: number;
  lookupTypeId?: number;
}

export interface UiPageFormFieldOverride {
  fieldCode: string;
  nameAr: string;
  fieldType: string;
  isRequired: boolean;
  isVisible: boolean;
  orderIndex: number;
  gridCols?: number;
  lookupTypeId?: number;
  placeholder?: string;
  defaultValue?: string;
  config?: Record<string, unknown>;
}

export interface UiPageOverridePayload {
  columns?: UiPageColumnOverride[];
  formFields?: UiPageFormFieldOverride[];
}

export interface SeedPageOverrideResult {
  pageKey: string;
  tabId: number;
  columnsInserted: number;
  formFieldsInserted: number;
  mode: "created" | "replaced" | "skipped";
}

export type SeedOverrideScope = "all" | "columns" | "formFields";

export interface UiPageTabRecord {
  id: number;
  pageKey: string;
  tabKey: string;
  labelAr: string;
  labelEn: string | null;
  iconClass: string | null;
  sortOrder: number;
  isDefault: boolean;
  tabOptions: Record<string, unknown> | null;
}

export interface UiPageRegistryRecord {
  pageKey: string;
  pageNameAr: string | null;
  entityType: string | null;
  defaultTabKey: string | null;
  tabsCount: number;
  columnsCount: number;
  formFieldsCount: number;
  dataSourcesCount: number;
}

export interface UiPageRegistryInfo {
  pageKey: string;
  pageNameAr: string | null;
  entityType: string | null;
}

export interface UiDataSourceRecord {
  id: number;
  dataSourceKey: string;
  displayNameAr: string;
  displayNameEn: string | null;
  sourceType: string;
  sourceSchema: string | null;
  sourceObject: string | null;
  inlineQuery: string | null;
  parameters: unknown;
  notes: string | null;
}

export interface UiTabDataSourceRecord {
  id: number;
  tabId: number;
  dataSourceId: number;
  purpose: string;
  sortOrder: number;
  mapping: unknown;
  dataSource: UiDataSourceRecord;
}

type WriteContext = {
  userId: number;
  workContextBy: number;
};

function safeJsonParse(value: unknown): Record<string, unknown> | null {
  if (!value) return null;
  if (typeof value === "object") return value as Record<string, unknown>;
  if (typeof value !== "string") return null;
  const text = value.trim();
  if (!text) return null;
  try {
    const obj = JSON.parse(text);
    return obj && typeof obj === "object" ? (obj as Record<string, unknown>) : null;
  } catch {
    return null;
  }
}

function safeJsonParseAny(value: unknown): unknown {
  if (!value) return null;
  if (typeof value === "object") return value;
  if (typeof value !== "string") return null;
  const text = value.trim();
  if (!text) return null;
  try {
    return JSON.parse(text);
  } catch {
    return null;
  }
}

async function getPreferredTabId(pageKey: string, executor?: SqlExecutor): Promise<number | undefined> {
  const row = await runQueryOne<{ id: number }>(
    `
      SELECT TOP 1 id
      FROM dbo.ui_page_tabs
      WHERE page_key = @pageKey AND is_deleted = 0
      ORDER BY is_default DESC, sort_order ASC, id ASC
    `,
    { pageKey },
    executor,
  );
  return row ? Number((row as any).id) : undefined;
}

async function ensureDefaultTab(pageKey: string, ctx: WriteContext, executor?: SqlExecutor): Promise<number> {
  const existing = await getPreferredTabId(pageKey, executor);
  if (existing) return existing;

  const row = await insertRow<Record<string, unknown>>(
    { schemaName: "dbo", tableName: "ui_page_tabs" },
    {
      page_key: pageKey,
      tab_key: "main",
      label_ar: "الرئيسية",
      sort_order: 0,
      is_default: 1,
      is_active: 1,
      is_deleted: 0,
      work_context_by: ctx.workContextBy,
      created_by: ctx.userId,
    },
    executor,
  );
  return Number(row.id);
}

export class UiRegistryModule {
  async getDataSourceByKey(dataSourceKey: string, executor?: SqlExecutor): Promise<UiDataSourceRecord | null> {
    const row = await runQueryOne<Record<string, unknown>>(
      `
        SELECT TOP 1
          id,
          data_source_key,
          display_name_ar,
          display_name_en,
          source_type,
          source_schema,
          source_object,
          inline_query,
          parameters_json,
          notes
        FROM dbo.ui_data_sources
        WHERE data_source_key = @dataSourceKey AND is_deleted = 0 AND is_active = 1
        ORDER BY id DESC
      `,
      { dataSourceKey },
      executor,
    );

    if (!row) return null;
    return {
      id: Number(row.id),
      dataSourceKey: String(row.data_source_key ?? ""),
      displayNameAr: String(row.display_name_ar ?? ""),
      displayNameEn: row.display_name_en == null ? null : String(row.display_name_en),
      sourceType: String(row.source_type ?? ""),
      sourceSchema: row.source_schema == null ? null : String(row.source_schema),
      sourceObject: row.source_object == null ? null : String(row.source_object),
      inlineQuery: row.inline_query == null ? null : String(row.inline_query),
      parameters: safeJsonParseAny(row.parameters_json),
      notes: row.notes == null ? null : String(row.notes),
    };
  }

  async getPageTabs(pageKey: string, executor?: SqlExecutor): Promise<UiPageTabRecord[]> {
    const rows = await runQuery<Record<string, unknown>>(
      `
        SELECT
          id,
          page_key,
          tab_key,
          label_ar,
          label_en,
          icon_class,
          sort_order,
          is_default,
          tab_options_json
        FROM dbo.ui_page_tabs
        WHERE page_key = @pageKey AND is_deleted = 0 AND is_active = 1
        ORDER BY is_default DESC, sort_order ASC, id ASC
      `,
      { pageKey },
      executor,
    );

    return rows.map((r) => ({
      id: Number(r.id),
      pageKey: String(r.page_key ?? ""),
      tabKey: String(r.tab_key ?? ""),
      labelAr: String(r.label_ar ?? ""),
      labelEn: r.label_en == null ? null : String(r.label_en),
      iconClass: r.icon_class == null ? null : String(r.icon_class),
      sortOrder: Number(r.sort_order ?? 0),
      isDefault: Boolean(r.is_default),
      tabOptions: safeJsonParse(r.tab_options_json),
    }));
  }

  async getTabDataSources(tabId: number, executor?: SqlExecutor): Promise<UiTabDataSourceRecord[]> {
    const rows = await runQuery<Record<string, unknown>>(
      `
        SELECT
          tds.id AS tab_data_source_id,
          tds.tab_id,
          tds.data_source_id,
          tds.purpose,
          tds.sort_order,
          tds.mapping_json,
          ds.id AS data_source_row_id,
          ds.data_source_key,
          ds.display_name_ar,
          ds.display_name_en,
          ds.source_type,
          ds.source_schema,
          ds.source_object,
          ds.inline_query,
          ds.parameters_json,
          ds.notes
        FROM dbo.ui_tab_data_sources tds
        JOIN dbo.ui_data_sources ds ON ds.id = tds.data_source_id
        WHERE tds.tab_id = @tabId
          AND tds.is_deleted = 0 AND tds.is_active = 1
          AND ds.is_deleted = 0 AND ds.is_active = 1
        ORDER BY tds.sort_order ASC, tds.id ASC
      `,
      { tabId },
      executor,
    );

    return rows.map((r) => ({
      id: Number(r.tab_data_source_id),
      tabId: Number(r.tab_id),
      dataSourceId: Number(r.data_source_id),
      purpose: String(r.purpose ?? "list"),
      sortOrder: Number(r.sort_order ?? 0),
      mapping: safeJsonParseAny(r.mapping_json),
      dataSource: {
        id: Number(r.data_source_row_id),
        dataSourceKey: String(r.data_source_key ?? ""),
        displayNameAr: String(r.display_name_ar ?? ""),
        displayNameEn: r.display_name_en == null ? null : String(r.display_name_en),
        sourceType: String(r.source_type ?? ""),
        sourceSchema: r.source_schema == null ? null : String(r.source_schema),
        sourceObject: r.source_object == null ? null : String(r.source_object),
        inlineQuery: r.inline_query == null ? null : String(r.inline_query),
        parameters: safeJsonParseAny(r.parameters_json),
        notes: r.notes == null ? null : String(r.notes),
      },
    }));
  }

  async getPageTabsWithDataSources(
    pageKey: string,
    executor?: SqlExecutor,
  ): Promise<Array<{ tab: UiPageTabRecord; dataSources: UiTabDataSourceRecord[] }>> {
    const tabs = await this.getPageTabs(pageKey, executor);
    const results: Array<{ tab: UiPageTabRecord; dataSources: UiTabDataSourceRecord[] }> = [];
    for (const tab of tabs) {
      const dataSources = await this.getTabDataSources(tab.id, executor);
      results.push({ tab, dataSources });
    }
    return results;
  }

  async getRegisteredPages(executor?: SqlExecutor): Promise<UiPageRegistryRecord[]> {
    const rows = await runQuery<Record<string, unknown>>(
      `
        WITH base_tabs AS (
          SELECT
            t.id,
            t.page_key,
            t.tab_key,
            t.is_default,
            t.sort_order,
            t.tab_options_json
          FROM dbo.ui_page_tabs t
          WHERE t.is_deleted = 0 AND t.is_active = 1
        ),
        preferred_tabs AS (
          SELECT
            bt.page_key,
            bt.tab_key,
            bt.tab_options_json,
            ROW_NUMBER() OVER (PARTITION BY bt.page_key ORDER BY bt.is_default DESC, bt.sort_order ASC, bt.id ASC) AS rn
          FROM base_tabs bt
        )
        SELECT
          bt.page_key,
          pt.tab_key AS default_tab_key,
          pt.tab_options_json,
          COUNT(DISTINCT bt.id) AS tabs_count,
          (
            SELECT COUNT(1)
            FROM dbo.ui_page_columns c
            JOIN base_tabs t2 ON t2.id = c.tab_id
            WHERE t2.page_key = bt.page_key AND c.is_deleted = 0 AND c.is_active = 1
          ) AS columns_count,
          (
            SELECT COUNT(1)
            FROM dbo.ui_page_form_fields f
            JOIN base_tabs t3 ON t3.id = f.tab_id
            WHERE t3.page_key = bt.page_key AND f.is_deleted = 0 AND f.is_active = 1
          ) AS form_fields_count,
          (
            SELECT COUNT(1)
            FROM dbo.ui_tab_data_sources tds
            JOIN base_tabs t4 ON t4.id = tds.tab_id
            WHERE t4.page_key = bt.page_key AND tds.is_deleted = 0 AND tds.is_active = 1
          ) AS data_sources_count
        FROM base_tabs bt
        LEFT JOIN preferred_tabs pt ON pt.page_key = bt.page_key AND pt.rn = 1
        GROUP BY bt.page_key, pt.tab_key, pt.tab_options_json
        ORDER BY bt.page_key
      `,
      {},
      executor,
    );

    return rows.map((r) => {
      const opts = safeJsonParse(r.tab_options_json);
      const pageNameAr = opts?.pageNameAr == null ? null : String(opts.pageNameAr);
      const entityType = opts?.entityType == null ? null : String(opts.entityType);
      return {
        pageKey: String(r.page_key ?? ""),
        pageNameAr,
        entityType,
        defaultTabKey: r.default_tab_key == null ? null : String(r.default_tab_key),
        tabsCount: Number(r.tabs_count ?? 0),
        columnsCount: Number(r.columns_count ?? 0),
        formFieldsCount: Number(r.form_fields_count ?? 0),
        dataSourcesCount: Number(r.data_sources_count ?? 0),
      };
    });
  }

  async getPageRegistryInfo(pageKey: string, executor?: SqlExecutor): Promise<UiPageRegistryInfo | null> {
    const tabRows = await runQuery<Record<string, unknown>>(
      `
        SELECT TOP 1
          page_key,
          tab_key,
          tab_options_json
        FROM dbo.ui_page_tabs
        WHERE page_key = @pageKey AND is_deleted = 0 AND is_active = 1
        ORDER BY is_default DESC, sort_order ASC, id ASC
      `,
      { pageKey },
      executor,
    );

    const row = tabRows?.[0];
    if (!row) return null;
    const opts = safeJsonParse(row.tab_options_json);
    return {
      pageKey: String(row.page_key ?? pageKey),
      pageNameAr: opts?.pageNameAr == null ? null : String(opts.pageNameAr),
      entityType: opts?.entityType == null ? null : String(opts.entityType),
    };
  }

  async getPageOverride(pageKey: string, executor?: SqlExecutor): Promise<UiPageOverridePayload | null> {
    const tabId = await getPreferredTabId(pageKey, executor);
    if (!tabId) return null;

    const columnRows = await runQuery<Record<string, unknown>>(
      `
        SELECT
          column_key,
          label_ar,
          ui_column_type,
          is_visible,
          is_sortable,
          sort_order,
          column_options_json
        FROM dbo.ui_page_columns
        WHERE tab_id = @tabId AND is_deleted = 0 AND is_active = 1
        ORDER BY sort_order ASC, id ASC
      `,
      { tabId },
      executor,
    );

    const fieldRows = await runQuery<Record<string, unknown>>(
      `
        SELECT
          field_key,
          label_ar,
          control_type,
          is_required,
          default_value,
          sort_order,
          field_options_json
        FROM dbo.ui_page_form_fields
        WHERE tab_id = @tabId AND is_deleted = 0 AND is_active = 1
        ORDER BY sort_order ASC, id ASC
      `,
      { tabId },
      executor,
    );

    const columns: UiPageColumnOverride[] = columnRows.map((r) => {
      const opts = safeJsonParse(r.column_options_json);
      const lookupTypeId = opts?.lookupTypeId == null ? undefined : Number(opts.lookupTypeId);
      return {
        fieldCode: String(r.column_key || ""),
        nameAr: String(r.label_ar || ""),
        columnType: String(r.ui_column_type || "text"),
        isVisible: Boolean(r.is_visible),
        isSortable: Boolean(r.is_sortable),
        orderIndex: Number(r.sort_order ?? 0),
        lookupTypeId: Number.isFinite(lookupTypeId as number) ? lookupTypeId : undefined,
      };
    });

    const formFields: UiPageFormFieldOverride[] = fieldRows.map((r) => {
      const opts = safeJsonParse(r.field_options_json);
      const gridCols = opts?.gridCols == null ? undefined : Number(opts.gridCols);
      const lookupTypeId = opts?.lookupTypeId == null ? undefined : Number(opts.lookupTypeId);
      const placeholder = opts?.placeholder == null ? undefined : String(opts.placeholder);
      const config: Record<string, unknown> = {};
      if (opts?.section != null) config.section = opts.section;
      if (opts?.remoteOptions != null) config.remoteOptions = opts.remoteOptions;
      if (opts?.clearOnChange != null) config.clearOnChange = opts.clearOnChange;
      return {
        fieldCode: String(r.field_key || ""),
        nameAr: String(r.label_ar || ""),
        fieldType: String(r.control_type || "text"),
        isRequired: Boolean(r.is_required),
        isVisible: true,
        orderIndex: Number(r.sort_order ?? 0),
        gridCols: Number.isFinite(gridCols as number) ? gridCols : undefined,
        lookupTypeId: Number.isFinite(lookupTypeId as number) ? lookupTypeId : undefined,
        placeholder: placeholder && placeholder.trim() ? placeholder : undefined,
        defaultValue: r.default_value == null ? undefined : String(r.default_value),
        config: Object.keys(config).length ? config : undefined,
      };
    });

    const hasColumns = columns.length > 0;
    const hasFormFields = formFields.length > 0;
    if (!hasColumns && !hasFormFields) return null;

    const payload: UiPageOverridePayload = {};
    if (hasColumns) payload.columns = columns;
    if (hasFormFields) payload.formFields = formFields;
    return payload;
  }

  async setPageOverridePart(
    pageKey: string,
    payload: UiPageOverridePayload | null,
    ctx: WriteContext,
    options: { replaceColumns: boolean; replaceFormFields: boolean },
    executor?: SqlExecutor,
  ): Promise<void> {
    const tabId = await ensureDefaultTab(pageKey, ctx, executor);

    const replaceColumns = Boolean(options.replaceColumns);
    const replaceFormFields = Boolean(options.replaceFormFields);
    const columns = Array.isArray(payload?.columns) ? payload!.columns! : [];
    const formFields = Array.isArray(payload?.formFields) ? payload!.formFields! : [];

    if (!payload) {
      await runQuery(
        `
          ${replaceColumns ? "UPDATE dbo.ui_page_columns SET is_deleted = 1, updated_at = getdate(), updated_by = @userId WHERE tab_id = @tabId AND is_deleted = 0;" : ""}
          ${replaceFormFields ? "UPDATE dbo.ui_page_form_fields SET is_deleted = 1, updated_at = getdate(), updated_by = @userId WHERE tab_id = @tabId AND is_deleted = 0;" : ""}
        `,
        { tabId, userId: ctx.userId },
        executor,
      );
      return;
    }

    if (replaceColumns) {
      await runQuery(
        `
          UPDATE dbo.ui_page_columns
          SET is_deleted = 1, updated_at = getdate(), updated_by = @userId
          WHERE tab_id = @tabId AND is_deleted = 0;
        `,
        { tabId, userId: ctx.userId },
        executor,
      );

      for (const col of columns) {
        const columnKey = String(col.fieldCode || "").trim();
        if (!columnKey) continue;

        await insertRow(
          { schemaName: "dbo", tableName: "ui_page_columns" },
          {
            tab_id: tabId,
            column_key: columnKey,
            field_name: columnKey,
            label_ar: String(col.nameAr || columnKey),
            ui_column_type: String(col.columnType || "text"),
            is_visible: col.isVisible ? 1 : 0,
            is_sortable: col.isSortable ? 1 : 0,
            is_filterable: 1,
            sort_order: Number(col.orderIndex ?? 0),
            column_options_json: col.lookupTypeId != null ? JSON.stringify({ lookupTypeId: col.lookupTypeId }) : null,
            is_active: 1,
            is_deleted: 0,
            work_context_by: ctx.workContextBy,
            created_by: ctx.userId,
          },
          executor,
        );
      }
    }

    if (replaceFormFields) {
      await runQuery(
        `
          UPDATE dbo.ui_page_form_fields
          SET is_deleted = 1, updated_at = getdate(), updated_by = @userId
          WHERE tab_id = @tabId AND is_deleted = 0;
        `,
        { tabId, userId: ctx.userId },
        executor,
      );

      for (const f of formFields) {
        const fieldKey = String(f.fieldCode || "").trim();
        if (!fieldKey) continue;

        const optionsObj: Record<string, unknown> = {};
        if (f.gridCols != null) optionsObj.gridCols = f.gridCols;
        if (f.lookupTypeId != null) optionsObj.lookupTypeId = f.lookupTypeId;
        if (f.placeholder != null && String(f.placeholder).trim()) optionsObj.placeholder = String(f.placeholder);
        if (f.config && typeof f.config === "object") {
          const cfg = f.config as Record<string, unknown>;
          if (cfg.section != null) optionsObj.section = cfg.section;
          if (cfg.remoteOptions != null) optionsObj.remoteOptions = cfg.remoteOptions;
          if (cfg.clearOnChange != null) optionsObj.clearOnChange = cfg.clearOnChange;
        }

        await insertRow(
          { schemaName: "dbo", tableName: "ui_page_form_fields" },
          {
            tab_id: tabId,
            field_key: fieldKey,
            field_name: fieldKey,
            label_ar: String(f.nameAr || fieldKey),
            control_type: String(f.fieldType || "text"),
            is_required: f.isRequired ? 1 : 0,
            default_value: f.defaultValue == null ? null : String(f.defaultValue),
            sort_order: Number(f.orderIndex ?? 0),
            field_options_json: Object.keys(optionsObj).length ? JSON.stringify(optionsObj) : null,
            is_active: 1,
            is_deleted: 0,
            work_context_by: ctx.workContextBy,
            created_by: ctx.userId,
          },
          executor,
        );
      }
    }
  }

  async setPageOverride(pageKey: string, payload: UiPageOverridePayload | null, ctx: WriteContext, executor?: SqlExecutor): Promise<void> {
    await this.setPageOverridePart(pageKey, payload, ctx, { replaceColumns: true, replaceFormFields: true }, executor);
  }

  async seedPageOverrideFromConfig(
    pageKey: string,
    config: Record<string, unknown>,
    ctx: WriteContext,
    options?: { force?: boolean; scope?: SeedOverrideScope },
    executor?: SqlExecutor,
  ): Promise<SeedPageOverrideResult> {
    const tabId = await ensureDefaultTab(pageKey, ctx, executor);

    const existingCounts = await runQueryOne<{ columns_count: number; fields_count: number }>(
      `
        SELECT
          (SELECT COUNT(1) FROM dbo.ui_page_columns WHERE tab_id = @tabId AND is_deleted = 0) AS columns_count,
          (SELECT COUNT(1) FROM dbo.ui_page_form_fields WHERE tab_id = @tabId AND is_deleted = 0) AS fields_count
      `,
      { tabId },
      executor,
    );

    const columnsCount = Number((existingCounts as any)?.columns_count ?? 0);
    const fieldsCount = Number((existingCounts as any)?.fields_count ?? 0);
    const scope: SeedOverrideScope = options?.scope ?? "all";
    const shouldSkip =
      !options?.force &&
      ((scope === "all" && (columnsCount > 0 || fieldsCount > 0)) ||
        (scope === "columns" && columnsCount > 0) ||
        (scope === "formFields" && fieldsCount > 0));
    if (shouldSkip) {
      return { pageKey, tabId, columnsInserted: 0, formFieldsInserted: 0, mode: "skipped" };
    }

    const columnsRaw = (config as any)?.columns;
    const formFieldsRaw = (config as any)?.formFields;
    const columns = Array.isArray(columnsRaw) ? columnsRaw : [];
    const formFields = Array.isArray(formFieldsRaw) ? formFieldsRaw : [];

    const payload: UiPageOverridePayload = {
      columns: columns.map((c: any) => ({
        fieldCode: String(c?.fieldCode ?? ""),
        nameAr: String(c?.nameAr ?? ""),
        columnType: String(c?.columnType ?? "text"),
        isVisible: c?.isVisible !== false,
        isSortable: c?.isSortable !== false,
        orderIndex: Number(c?.orderIndex ?? 0),
        lookupTypeId: c?.lookupTypeId == null ? undefined : Number(c.lookupTypeId),
      })),
      formFields: formFields.map((f: any) => ({
        fieldCode: String(f?.fieldCode ?? ""),
        nameAr: String(f?.nameAr ?? ""),
        fieldType: String(f?.fieldType ?? "text"),
        isRequired: Boolean(f?.isRequired),
        isVisible: f?.isVisible !== false,
        orderIndex: Number(f?.orderIndex ?? 0),
        gridCols: f?.gridCols == null ? undefined : Number(f.gridCols),
        lookupTypeId: f?.lookupTypeId == null ? undefined : Number(f.lookupTypeId),
        placeholder: f?.placeholder == null ? undefined : String(f.placeholder),
        defaultValue: f?.defaultValue == null ? undefined : String(f.defaultValue),
        config: f?.config && typeof f.config === "object" ? (f.config as Record<string, unknown>) : undefined,
      })),
    };

    const replaceColumns = scope === "all" || scope === "columns";
    const replaceFormFields = scope === "all" || scope === "formFields";
    const partialPayload: UiPageOverridePayload = {};
    if (replaceColumns) partialPayload.columns = payload.columns;
    if (replaceFormFields) partialPayload.formFields = payload.formFields;

    await this.setPageOverridePart(pageKey, partialPayload, ctx, { replaceColumns, replaceFormFields }, executor);

    return {
      pageKey,
      tabId,
      columnsInserted: replaceColumns ? columns.length : 0,
      formFieldsInserted: replaceFormFields ? formFields.length : 0,
      mode: options?.force ? "replaced" : "created",
    };
  }
}

export const uiRegistryModule = new UiRegistryModule();
