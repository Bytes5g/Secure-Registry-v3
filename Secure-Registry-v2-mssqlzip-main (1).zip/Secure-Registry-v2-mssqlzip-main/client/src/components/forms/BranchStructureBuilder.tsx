import React, { useState, useEffect } from "react";
import { useQuery, useQueryClient, useMutation } from "@tanstack/react-query";
import { Button, Checkbox, Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, ScrollArea } from "@secure-registry/components-ui";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Loader2 } from "lucide-react";

interface StructureBuilderProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  branch: any;
}

export default function BranchStructureBuilder({ open, onOpenChange, branch }: StructureBuilderProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedIds, setSelectedIds] = useState<number[]>([]);

  useEffect(() => {
    if (!open || !branch?.id) {
      setSelectedIds([]);
    }
  }, [open, branch?.id]);

  // Fetch Source Tree (Organization Structure)
  const { data: treeNodes, isLoading } = useQuery({
    queryKey: ["source-tree", branch?.id],
    queryFn: async () => {
      if (!branch?.id) return [];
      return await apiRequest("GET", `/api/branches/${branch.id}/source-tree`);
    },
    enabled: !!branch?.id && open
  });

  // Fetch Existing Branch Nodes to Pre-select
  const { data: existingNodes } = useQuery({
    queryKey: ["branch-nodes", branch?.id],
    queryFn: async () => {
        if (!branch?.id) return [];
        return await apiRequest("GET", `/api/branches/${branch.id}/nodes`);
    },
    enabled: !!branch?.id && open
  });

  useEffect(() => {
    if (!open) return;
    if (!Array.isArray(existingNodes)) return;

    const mappedIds = existingNodes
      .map((n: any) =>
        n.org_structure_node_id ??
        n.orgStructureNodeId ??
        n.orgStructureNodeID ??
        n.org_tree_node_id ??
        n.orgTreeNodeId,
      )
      .map((v: unknown) => Number(v))
      .filter((v: number) => Number.isFinite(v));

    setSelectedIds(Array.from(new Set(mappedIds)));
  }, [existingNodes, open]);

  const generateMutation = useMutation({
    mutationFn: async (nodeIds: number[]) => {
      if (!branch?.id) throw new Error("Branch ID missing");
      await apiRequest("POST", `/api/branches/${branch.id}/assign-nodes`, { nodeIds });
    },
    onSuccess: () => {
      toast({ title: "تم الحفظ بنجاح", description: "تم تحديث هيكلية الفرع" });
      queryClient.invalidateQueries({ queryKey: ["branch-nodes", branch?.id] });
      onOpenChange(false);
    },
    onError: () => {
      toast({ title: "خطأ", description: "فشل حفظ الهيكلية", variant: "destructive" });
    }
  });

  const handleToggle = (id: number, parentId: number | null) => {
    setSelectedIds(prev => {
      const isSelected = prev.includes(id);
      let newSelection = [...prev];

      if (isSelected) {
        // Deselect: also deselect children? Yes, always deselect children
        const descendants = getDescendants(id, treeNodes);
        newSelection = newSelection.filter(x => x !== id && !descendants.includes(x));
      } else {
        // Select: also select descendants? Yes, select all descendants by default
        const descendants = getDescendants(id, treeNodes);
        newSelection = [...newSelection, id, ...descendants];
        
        // Ensure unique
        newSelection = Array.from(new Set(newSelection));

        // Select ancestors to maintain hierarchy
        if (parentId) {
            const ancestors = getAncestors(parentId, treeNodes);
            ancestors.forEach(a => {
                if (!newSelection.includes(a)) newSelection.push(a);
            });
        }
      }
      return newSelection;
    });
  };

  const handleSelectAll = () => {
    if (!treeNodes) return;
    const allIds = treeNodes.map((n: any) => n.id);
    setSelectedIds(allIds);
  };

  const handleDeselectAll = () => {
    setSelectedIds([]);
  };

  const getDescendants = (id: number, nodes: any[]): number[] => {
    const children = nodes.filter(n => {
        const pId = n.parentId !== undefined ? n.parentId : n.parent_id;
        return pId === id;
    });
    let result = children.map(c => c.id);
    children.forEach(c => {
        result = [...result, ...getDescendants(c.id, nodes)];
    });
    return result;
  };

  const getAncestors = (parentId: number, nodes: any[]): number[] => {
    const parent = nodes.find(n => n.id === parentId);
    if (!parent) return [];
    let result = [parent.id];
    const grandParentId = parent.parentId !== undefined ? parent.parentId : parent.parent_id;
    if (grandParentId) {
        result = [...result, ...getAncestors(grandParentId, nodes)];
    }
    return result;
  };

  const renderTree = (nodes: any[], parentId: number | null = null, level = 0) => {
    // Correctly handle parent_id/parentId differences from API
    const currentNodes = nodes.filter(n => {
        const pId = n.parentId !== undefined ? n.parentId : n.parent_id;
        return pId === parentId;
    });
    
    return currentNodes.map(node => (
      <div key={node.id} className="mb-1" style={{ marginRight: `${level * 20}px` }}>
        <div className="flex items-center space-x-2 flex-row-reverse space-x-reverse">
          <Checkbox 
            id={`node-${node.id}`} 
            checked={selectedIds.includes(node.id)}
            onCheckedChange={() => handleToggle(node.id, node.parentId !== undefined ? node.parentId : node.parent_id)}
          />
          <label 
            htmlFor={`node-${node.id}`} 
            className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer mr-2"
          >
            {node.name} <span className="text-xs text-muted-foreground">({node.nodeType || node.node_type})</span>
          </label>
        </div>
        {renderTree(nodes, node.id, level + 1)}
      </div>
    ));
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl" dir="rtl">
        <DialogHeader>
          <DialogTitle>بناء الهيكل التنظيمي: {branch?.name || branch?.nameAr}</DialogTitle>
          <DialogDescription>
            حدد الوحدات الإدارية التي ترغب في إدراجها ضمن هيكل هذا الفرع.
          </DialogDescription>
        </DialogHeader>

        <div className="flex justify-between items-center mb-2 px-1">
          <div className="text-sm text-muted-foreground">
             {selectedIds.length} وحدة مختارة
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={handleSelectAll} disabled={isLoading || !treeNodes?.length}>
              تحديد الكل
            </Button>
            <Button variant="outline" size="sm" onClick={handleDeselectAll} disabled={isLoading || !treeNodes?.length || selectedIds.length === 0}>
              إلغاء التحديد
            </Button>
          </div>
        </div>

        <ScrollArea className="h-[400px] w-full rounded-md border p-4">
          {isLoading ? (
            <div className="flex justify-center p-8"><Loader2 className="h-6 w-6 animate-spin" /></div>
          ) : (
            treeNodes && treeNodes.length > 0 ? (
              renderTree(treeNodes || [])
            ) : (
              <div className="p-4 text-center text-muted-foreground">
                لا يوجد هيكل تنظيمي متاح لهذه الجهة. قم بتهيئة الهيكل أولاً من تبويب "تهيئة الهيكل".
              </div>
            )
          )}
        </ScrollArea>

        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={() => onOpenChange(false)}>إلغاء</Button>
          <Button
            onClick={() => generateMutation.mutate(selectedIds)}
            disabled={generateMutation.isPending || !treeNodes?.length}
          >
            {generateMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            حفظ
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
