import { createRequest, type SqlExecutor } from "../config/connection";

export type SqlRow = Record<string, unknown>;
export type TableInput = string | TableReference;

export interface TableReference {
  databaseName?: string | null;
  schemaName?: string | null;
  tableName: string;
}

export function quoteIdentifier(identifier: string): string {
  return `[${identifier.replace(/]/g, "]]")}]`;
}

export function asTableReference(table: TableInput): TableReference {
  if (typeof table === "string") {
    return { tableName: table };
  }

  return {
    databaseName: table.databaseName ?? null,
    schemaName: table.schemaName ?? null,
    tableName: table.tableName,
  };
}

export function qualifyTableName(table: TableInput): string {
  const reference = asTableReference(table);
  const parts = [
    reference.databaseName,
    reference.schemaName,
    reference.tableName,
  ].filter((value): value is string => Boolean(value));

  return parts.map((part) => quoteIdentifier(part)).join(".");
}

export function mapRow<T>(row: SqlRow | undefined | null): T | undefined {
  if (!row) {
    return undefined;
  }

  return Object.fromEntries(
    Object.entries(row).map(([key, value]) => [toCamelCase(key), value]),
  ) as T;
}

export function mapRows<T>(rows: SqlRow[] | undefined): T[] {
  return (rows || []).map((row) => mapRow<T>(row) as T);
}

export function toCamelCase(value: string): string {
  return value.replace(/_([a-z])/g, (_, char: string) => char.toUpperCase());
}

export function toSnakeCase(value: string): string {
  return value.replace(/[A-Z]/g, (char) => `_${char.toLowerCase()}`);
}

export function pickDefined<T extends Record<string, unknown>>(input: T): Partial<T> {
  return Object.fromEntries(
    Object.entries(input).filter(([, value]) => value !== undefined),
  ) as Partial<T>;
}

export function normalizeForDb<T>(input: T): unknown {
  if (input instanceof Date) {
    return input;
  }

  if (Array.isArray(input)) {
    return JSON.stringify(input);
  }

  if (input && typeof input === "object") {
    return JSON.stringify(input);
  }

  return input;
}

export async function runQuery<T = SqlRow>(
  query: string,
  params: Record<string, unknown> = {},
  executor?: SqlExecutor,
): Promise<T[]> {
  const request = await createRequest(executor);

  for (const [name, value] of Object.entries(params)) {
    request.input(name, value as never);
  }

  const result = await request.query<T>(query);
  return result.recordset;
}

export async function runQueryOne<T = SqlRow>(
  query: string,
  params: Record<string, unknown> = {},
  executor?: SqlExecutor,
): Promise<T | undefined> {
  const rows = await runQuery<T>(query, params, executor);
  return rows[0];
}

type SelectOptions = {
  columns?: string;
  whereClause?: string;
  orderByClause?: string;
  params?: Record<string, unknown>;
  executor?: SqlExecutor;
  top?: number;
};

export async function selectRows<T = SqlRow>(
  table: TableInput,
  options: SelectOptions = {},
): Promise<T[]> {
  const columns = options.columns ?? "*";
  const topClause = options.top != null ? `TOP ${options.top} ` : "";
  const whereClause = options.whereClause ? ` ${options.whereClause}` : "";
  const orderByClause = options.orderByClause ? ` ${options.orderByClause}` : "";

  return runQuery<T>(
    `SELECT ${topClause}${columns} FROM ${qualifyTableName(table)}${whereClause}${orderByClause}`,
    options.params ?? {},
    options.executor,
  );
}

export async function selectSingleRow<T = SqlRow>(
  table: TableInput,
  options: Omit<SelectOptions, "top"> = {},
): Promise<T | undefined> {
  const rows = await selectRows<T>(table, { ...options, top: 1 });
  return rows[0];
}

export async function insertRow<T>(
  table: TableInput,
  payload: Record<string, unknown>,
  executor?: SqlExecutor,
): Promise<T> {
  const entries = Object.entries(pickDefined(payload));
  const tableReference = asTableReference(table);
  if (entries.length === 0) {
    throw new Error(`Cannot insert empty payload into ${tableReference.tableName}`);
  }

  const columns = entries.map(([column]) => quoteIdentifier(column)).join(", ");
  const values = entries.map(([column]) => `@${column}`).join(", ");
  const params = Object.fromEntries(entries.map(([column, value]) => [column, normalizeForDb(value)]));
  const qualifiedTableName = qualifyTableName(tableReference);

  const hasId = Object.prototype.hasOwnProperty.call(payload, "id") && payload.id != null;
  if (hasId) {
    await runQuery(
      `INSERT INTO ${qualifiedTableName} (${columns}) VALUES (${values})`,
      params,
      executor,
    );

    const row = await selectSingleRow<T>(tableReference, {
      whereClause: "WHERE id = @id",
      params: { id: payload.id },
      executor,
    });

    if (!row) {
      throw new Error(`Insert into ${tableReference.tableName} did not return a row`);
    }

    return row;
  }

  const request = await createRequest(executor);
  for (const [name, value] of Object.entries(params)) {
    request.input(name, value as never);
  }

  const result = await request.query(
    `
      SET NOCOUNT ON;
      INSERT INTO ${qualifiedTableName} (${columns}) VALUES (${values});
      SELECT CONVERT(bigint, SCOPE_IDENTITY()) AS id;
    `
  );

  const recordsets = Array.isArray(result.recordsets)
    ? result.recordsets
    : Object.values(result.recordsets);
  const lastRecordset = recordsets.length > 0 ? recordsets[recordsets.length - 1] : null;
  const idRow = lastRecordset && (lastRecordset as any[]).length > 0 ? (lastRecordset as any[])[0] : null;

  const insertedId = idRow?.id == null ? null : Number(idRow.id);
  if (!Number.isFinite(insertedId)) {
    throw new Error(`Insert into ${tableReference.tableName} did not return an id`);
  }

  const row = await selectSingleRow<T>(tableReference, {
    whereClause: "WHERE id = @id",
    params: { id: insertedId },
    executor,
  });

  if (!row) {
    throw new Error(`Insert into ${tableReference.tableName} did not return a row`);
  }

  return row;
}

export async function updateRow<T>(
  table: TableInput,
  id: number,
  payload: Record<string, unknown>,
  executor?: SqlExecutor,
): Promise<T | undefined> {
  const entries = Object.entries(pickDefined(payload));
  if (entries.length === 0) {
    return undefined;
  }

  const setters = entries.map(([column]) => `${quoteIdentifier(column)} = @${column}`).join(", ");
  const params = Object.fromEntries(entries.map(([column, value]) => [column, normalizeForDb(value)]));
  const qualifiedTableName = qualifyTableName(table);
  await runQuery(
    `UPDATE ${qualifiedTableName} SET ${setters} WHERE id = @id`,
    { ...params, id },
    executor,
  );

  return selectSingleRow<T>(table, {
    whereClause: "WHERE id = @id",
    params: { id },
    executor,
  });
}

export async function deleteRow(table: TableInput, id: number, executor?: SqlExecutor): Promise<boolean> {
  const qualifiedTableName = qualifyTableName(table);
  const row = await runQueryOne<{ affected: number }>(
    `
      SET NOCOUNT ON;
      DELETE FROM ${qualifiedTableName} WHERE id = @id;
      SELECT @@ROWCOUNT AS affected;
    `,
    { id },
    executor,
  );

  return Boolean(row && Number(row.affected) > 0);
}
