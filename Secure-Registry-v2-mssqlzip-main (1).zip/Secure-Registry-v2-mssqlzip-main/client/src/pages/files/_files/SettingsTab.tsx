import {
  Button,
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  Input,
  Label,
  Textarea,
} from "@secure-registry/components-ui";
import { DEFAULT_MAX_FILE_SIZE_MB, DEFAULT_RELATIVE_DIRECTORY } from "./config";
import type { FilesPageController } from "./useFilesPage";

export function SettingsTab({ ctrl }: { ctrl: FilesPageController }) {
  const { settingsQuery, settingsForm, setSettingsForm, saveSettingsMutation } = ctrl;

  return (
    <Card>
      <CardHeader>
        <CardTitle>تهيئة إعدادات رفع الملفات</CardTitle>
      </CardHeader>
      <CardContent>
        {settingsQuery.isLoading ? (
          <div className="text-sm text-muted-foreground">جاري التحميل…</div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>المسار النسبي داخل uploads</Label>
              <Input
                value={settingsForm.relativeDirectory}
                onChange={(e) =>
                  setSettingsForm((p) => ({ ...p, relativeDirectory: e.target.value }))
                }
                placeholder={DEFAULT_RELATIVE_DIRECTORY}
              />
            </div>

            <div className="space-y-2">
              <Label>الحد الأقصى لحجم الملف (MB)</Label>
              <Input
                value={settingsForm.maxFileSizeMB}
                onChange={(e) =>
                  setSettingsForm((p) => ({ ...p, maxFileSizeMB: e.target.value }))
                }
                placeholder={String(DEFAULT_MAX_FILE_SIZE_MB)}
              />
            </div>

            <div className="space-y-2">
              <Label>المجلد الافتراضي (ID)</Label>
              <Input
                value={settingsForm.defaultFolderId}
                onChange={(e) =>
                  setSettingsForm((p) => ({ ...p, defaultFolderId: e.target.value }))
                }
                placeholder="اختياري"
              />
            </div>

            <div className="space-y-2 md:col-span-2">
              <Label>أنواع الملفات المسموحة (سطر لكل نوع)</Label>
              <Textarea
                value={settingsForm.allowedMimeTypesText}
                onChange={(e) =>
                  setSettingsForm((p) => ({ ...p, allowedMimeTypesText: e.target.value }))
                }
                rows={10}
              />
            </div>

            <div className="flex justify-end md:col-span-2 pt-2">
              <Button
                disabled={saveSettingsMutation.isPending}
                onClick={() => saveSettingsMutation.mutate()}
              >
                {saveSettingsMutation.isPending ? "جاري الحفظ..." : "حفظ الإعدادات"}
              </Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
