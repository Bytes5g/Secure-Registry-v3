import type { Express, NextFunction, Request, Response } from "express";
import { ZodError } from "zod";
import { ApiError } from "../utils/response";

export function applyErrorHandler(app: Express): void {
  app.use((err: unknown, _req: Request, res: Response, _next: NextFunction) => {
    if (res.headersSent) {
      console.error(err);
      return;
    }

    if (err instanceof ApiError) {
      res.status(err.statusCode).json({
        success: false,
        error: { code: err.code, message: err.message, details: err.details },
      });
      return;
    }

    if (err instanceof ZodError) {
      res.status(400).json({
        success: false,
        error: {
          code: "VALIDATION_ERROR",
          message: "Validation failed",
          details: err.errors,
        },
      });
      return;
    }

    const error = err as { status?: number; statusCode?: number; message?: string };
    const status = error.status || error.statusCode || 500;
    const message = error.message || "Internal Server Error";

    res.status(status).json({
      success: false,
      error: { code: "INTERNAL_ERROR", message },
    });
    console.error(err);
  });
}
