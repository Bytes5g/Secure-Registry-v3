import { useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import {
  createLookupTypeAlias,
  deleteLookupTypeAlias,
  fetchLookupTypeAliases,
  updateLookupTypeAlias,
} from "@/lib/api/lookups-admin";
import type {
  InsertLookupTypeAlias,
  LookupType,
  LookupTypeAlias,
} from "@shared/schema";
import {
  createAliasFormFromRecord,
  createEmptyAliasForm,
  mapAliasPayload,
  type AliasFormState,
} from "../models/lookups-admin-models";
import {
  createMutationFeedbackHandlers,
  ensureRequiredAliasFields,
  openCreateDialog,
  openEditDialog,
  submitNestedEntity,
  type SharedDeps,
} from "./_internals/shared";

interface AliasesArgs extends SharedDeps {
  selectedTypeId: number | null;
  selectedType: LookupType | null;
}

export function useLookupAliasesController({
  toast,
  invalidateAll,
  selectedTypeId,
  selectedType,
}: AliasesArgs) {
  const [aliasDialogOpen, setAliasDialogOpen] = useState(false);
  const [editingAlias, setEditingAlias] = useState<LookupTypeAlias | null>(null);
  const [aliasForm, setAliasForm] = useState<AliasFormState>(createEmptyAliasForm());
  const [aliasToDelete, setAliasToDelete] = useState<LookupTypeAlias | null>(null);

  const { data: lookupAliases = [], isLoading: lookupAliasesLoading } = useQuery({
    queryKey: ["lookup-admin", "aliases", selectedTypeId],
    queryFn: () => fetchLookupTypeAliases(selectedTypeId!),
    enabled: selectedTypeId != null,
  });

  const createAliasMutation = useMutation({
    mutationFn: (payload: InsertLookupTypeAlias) =>
      createLookupTypeAlias(payload.lookupTypeId, payload),
    ...createMutationFeedbackHandlers({
      invalidate: invalidateAll,
      toast,
      successTitle: "تمت إضافة الاسم البديل",
      errorTitle: "تعذر حفظ الاسم البديل",
      onSuccess: () => setAliasDialogOpen(false),
    }),
  });

  const updateAliasMutation = useMutation({
    mutationFn: ({ id, payload }: { id: number; payload: Partial<InsertLookupTypeAlias> }) =>
      updateLookupTypeAlias(id, payload),
    ...createMutationFeedbackHandlers({
      invalidate: invalidateAll,
      toast,
      successTitle: "تم تحديث الاسم البديل",
      errorTitle: "تعذر تحديث الاسم البديل",
      onSuccess: () => setAliasDialogOpen(false),
    }),
  });

  const deleteAliasMutation = useMutation({
    mutationFn: (id: number) => deleteLookupTypeAlias(id),
    ...createMutationFeedbackHandlers({
      invalidate: invalidateAll,
      toast,
      successTitle: "تم حذف الاسم البديل",
      errorTitle: "تعذر حذف الاسم البديل",
      onSuccess: () => setAliasToDelete(null),
    }),
  });

  const openCreateAliasDialog = () => {
    openCreateDialog({
      setEditing: setEditingAlias,
      setForm: setAliasForm,
      createEmptyForm: createEmptyAliasForm,
      setOpen: setAliasDialogOpen,
    });
  };

  const openEditAliasDialog = (record: LookupTypeAlias) => {
    openEditDialog({
      record,
      setEditing: setEditingAlias,
      setForm: setAliasForm,
      mapRecordToForm: createAliasFormFromRecord,
      setOpen: setAliasDialogOpen,
    });
  };

  const submitAlias = () => {
    submitNestedEntity({
      selectedType,
      form: aliasForm,
      editingRecord: editingAlias,
      mapPayload: mapAliasPayload,
      validate: ensureRequiredAliasFields,
      create: (payload) => createAliasMutation.mutate(payload),
      update: (record, payload) => updateAliasMutation.mutate({ id: record.id, payload }),
      toast,
    });
  };

  return {
    lookupAliases,
    lookupAliasesLoading,
    aliasDialogOpen,
    setAliasDialogOpen,
    editingAlias,
    aliasForm,
    setAliasForm,
    aliasToDelete,
    setAliasToDelete,
    openCreateAliasDialog,
    openEditAliasDialog,
    submitAlias,
    createAliasMutation,
    updateAliasMutation,
    deleteAliasMutation,
  };
}
