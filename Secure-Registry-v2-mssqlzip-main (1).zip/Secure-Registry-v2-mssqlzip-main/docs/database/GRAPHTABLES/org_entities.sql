USE [secure_registry_v4]
GO
/****** Object:  Trigger [dbo].[trg_org_entities_ai_create_hq_branch]    Script Date: 2026-05-13 12:04:45 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER TRIGGER [dbo].[trg_org_entities_ai_create_hq_branch]
ON [dbo].[org_entities]
AFTER INSERT
AS
BEGIN
  SET NOCOUNT ON;
  IF TRIGGER_NESTLEVEL() > 1 RETURN;

  INSERT INTO dbo.org_branches
  (
    org_id,
    geo_unit_id,
    branch_scope_lookup_id,
    parent_branch_id,
    name,
    code,
    is_active,
    metadata,
    standard_id,
    work_context_by,
    created_at,
    created_by,
    is_deleted
  )
  SELECT
    i.id,
    1,
    4,
    NULL,
    N'المركز الرئيسي',
    N'HQ',
    1,
    NULL,
    NULL,
    i.work_context_by,
    COALESCE(i.created_at, GETDATE()),
    i.created_by,
    0
  FROM inserted i
  WHERE NOT EXISTS
  (
    SELECT 1
    FROM dbo.org_branches b
    WHERE b.org_id = i.id
      AND b.geo_unit_id = 1
      AND b.branch_scope_lookup_id = 4
      AND ISNULL(b.is_deleted, 0) = 0
  );

  INSERT INTO dbo.org_entity_structure
  (
    org_id,
    name,
    code,
    structure_id,
    level,
    is_active,
    order_index,
    work_context_by,
    created_at,
    created_by,
    is_deleted
  )
  SELECT
    i.id,
    i.name,
    i.code,
    1,
    1,
    1,
    NULL,
    i.work_context_by,
    COALESCE(i.created_at, GETDATE()),
    i.created_by,
    0
  FROM inserted i
  WHERE NOT EXISTS (
    SELECT 1
    FROM dbo.org_entity_structure s
    WHERE s.org_id = i.id
  );
END;
