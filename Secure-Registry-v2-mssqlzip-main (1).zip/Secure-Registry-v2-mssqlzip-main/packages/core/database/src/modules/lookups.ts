import { createRequest, type SqlExecutor } from "../config/connection";
import {
  deleteRow,
  insertRow,
  quoteIdentifier,
  selectRows,
  selectSingleRow,
  updateRow,
  type TableReference,
} from "./helpers";
import {
  createLookupConfig,
  clearLookupRegistryCache,
  deleteLookupConfig,
  getLookupConfigByCode,
  getLookupConfigById,
  getLookupConfigs,
  getLookupTableReference,
  updateLookupConfig,
  type LookupConfig,
  type LookupConfigMutation,
} from "./lookup-registry";
import {
  getProvidedLookupValueById,
  getProvidedLookupValues,
} from "./lookup-value-providers";
import type { LookupTypeRecord, LookupValueRecord } from "./lookup-records";
import {
  createLookupTypeAlias,
  createLookupVirtualValue,
  deleteLookupTypeAlias,
  deleteLookupVirtualValue,
  getLookupTypeAliasById,
  getLookupTypeAliases,
  getLookupVirtualValueById,
  getLookupVirtualValues,
  updateLookupTypeAlias,
  updateLookupVirtualValue,
  type LookupTypeAliasMutation,
  type LookupTypeAliasRecord,
  type LookupVirtualValueMutation,
  type LookupVirtualValueRecord,
} from "./lookup-admin-records";

export type { LookupTypeRecord, LookupValueRecord } from "./lookup-records";
export type {
  LookupTypeAliasMutation,
  LookupTypeAliasRecord,
  LookupVirtualValueMutation,
  LookupVirtualValueRecord,
} from "./lookup-admin-records";

interface ResolvedLookupValue {
  config: LookupConfig;
  value: LookupValueRecord;
}

type WriteContext = {
  workContextBy?: number | null;
  createdBy?: number | null;
  updatedBy?: number | null;
};

export interface OrgStructureCodeDecoration {
  id: number;
  parentId: number | null;
  code: string;
  name: string;
  orderIndex: number;
  isActive: boolean;
  clare: string | null;
  logo: string | null;
  color: string | null;
}

function asOptionalText(value: unknown): string | null {
  if (value == null) {
    return null;
  }
  const text = String(value).trim();
  return text.length > 0 ? text : null;
}

function asOptionalNumber(value: unknown): number | null {
  if (value == null) {
    return null;
  }
  const n = typeof value === "number" ? value : Number(value);
  return Number.isFinite(n) ? n : null;
}

function isInvalidObjectNameError(error: unknown): boolean {
  const message = String((error as { message?: unknown } | null)?.message ?? error ?? "");
  return message.toLowerCase().includes("invalid object name");
}

function isDatabaseUnavailableError(error: unknown): boolean {
  const message = String((error as { message?: unknown } | null)?.message ?? error ?? "").toLowerCase();
  return message.includes("cannot open database")
    || message.includes("is not able to access the database")
    || message.includes("server principal") && message.includes("access the database");
}

function shouldIgnoreLookupSourceError(error: unknown): boolean {
  return isInvalidObjectNameError(error) || isDatabaseUnavailableError(error);
}

const tableColumnsCache = new Map<string, Promise<Set<string>>>();

function normalizeSchemaName(value: string | null | undefined): string {
  return (value && value.trim().length > 0 ? value : "dbo").trim();
}

function getColumnsCacheKey(table: TableReference): string {
  const db = table.databaseName ?? "";
  const schema = normalizeSchemaName(table.schemaName ?? "dbo");
  const name = table.tableName;
  return `${db}.${schema}.${name}`.toLowerCase();
}

async function getTableColumnSet(table: TableReference, executor?: SqlExecutor): Promise<Set<string>> {
  const key = getColumnsCacheKey(table);
  const cached = tableColumnsCache.get(key);
  if (cached) return cached;

  const pending = (async () => {
    const schemaName = normalizeSchemaName(table.schemaName ?? "dbo");
    const dbPrefix = table.databaseName ? `${quoteIdentifier(table.databaseName)}.` : "";

    const request = await createRequest(executor);
    request.input("tableName", table.tableName);
    request.input("schemaName", schemaName);
    const result = await request.query<{ column_name: string }>(
      `SELECT
         c.name AS column_name
       FROM ${dbPrefix}sys.columns c
       INNER JOIN ${dbPrefix}sys.tables t ON t.object_id = c.object_id
       INNER JOIN ${dbPrefix}sys.schemas s ON s.schema_id = t.schema_id
       WHERE t.name = @tableName
         AND s.name = @schemaName
       ORDER BY c.column_id`,
    );

    return new Set(result.recordset.map((row) => String(row.column_name).toLowerCase()));
  })();

  tableColumnsCache.set(key, pending);
  return pending;
}

function applyEntryAuditForInsert(
  payload: Record<string, unknown>,
  columns: Set<string>,
  context: WriteContext | undefined,
) {
  if (!context) return;
  if (columns.has("work_context_by") && payload.work_context_by === undefined) payload.work_context_by = context.workContextBy ?? null;
  if (columns.has("created_by") && payload.created_by === undefined) payload.created_by = context.createdBy ?? null;
  if (columns.has("is_deleted") && payload.is_deleted === undefined) payload.is_deleted = false;
}

function applyEntryAuditForUpdate(
  payload: Record<string, unknown>,
  columns: Set<string>,
  context: WriteContext | undefined,
) {
  if (!context) return;
  if (columns.has("work_context_by") && payload.work_context_by === undefined) payload.work_context_by = context.workContextBy ?? null;
  if (columns.has("updated_by") && payload.updated_by === undefined) payload.updated_by = context.updatedBy ?? null;
  if (columns.has("updated_at") && payload.updated_at === undefined) payload.updated_at = new Date();
}

function mapType(config: LookupConfig): LookupTypeRecord {
  return {
    id: config.id,
    code: config.code,
    aliasCode: config.aliasCode,
    nameAr: config.nameAr,
    description: config.description,
    isActive: config.isActive,
    databaseName: config.databaseName,
    schemaName: config.schemaName,
    tableName: config.tableName,
    nameColumn: config.nameColumn,
    orderColumn: config.orderColumn,
    parentColumn: config.parentColumn,
    createdAtColumn: config.createdAtColumn,
    writable: config.writable,
    valueProviderKey: config.valueProviderKey,
    providerStrategy: config.providerStrategy,
    aliases: config.aliases,
    createdAt: config.createdAt,
    updatedAt: config.updatedAt,
  };
}

function getNameColumn(config: LookupConfig): string {
  return config.nameColumn ?? "name";
}

function getCreatedAtColumn(config: LookupConfig): string {
  return config.createdAtColumn ?? "created_at";
}

function isLookupWritable(config: LookupConfig): boolean {
  return config.writable;
}

function buildLookupPayload(
  config: LookupConfig,
  payload: Partial<LookupValueRecord>,
): Record<string, unknown> {
  const result: Record<string, unknown> = {
    code: payload.code,
    is_active: payload.isActive,
  };

  if (payload.nameAr !== undefined) {
    result[getNameColumn(config)] = payload.nameAr;
  }
  if (config.parentColumn && payload.parentId !== undefined) {
    result[config.parentColumn] = payload.parentId;
  }
  if (config.orderColumn && payload.orderIndex !== undefined) {
    result[config.orderColumn] = payload.orderIndex;
  }

  return result;
}

function mapLookupRow(
  row: Record<string, unknown>,
  config: LookupConfig,
): LookupValueRecord {
  return {
    id: Number(row.id),
    typeId: config.id,
    code: String(row.code || ""),
    nameAr: String(row[getNameColumn(config)] || ""),
    orderIndex: config.orderColumn ? Number(row[config.orderColumn] || 0) : 0,
    isActive: row.is_active == null ? true : Boolean(row.is_active),
    parentId: config.parentColumn && row[config.parentColumn] != null
      ? Number(row[config.parentColumn])
      : null,
    metadata: null,
    createdAt: row[getCreatedAtColumn(config)] == null
      ? null
      : String(row[getCreatedAtColumn(config)]),
  };
}

function getLookupOrderByClause(config: LookupConfig): string {
  const columns = [config.orderColumn, getNameColumn(config)]
    .filter((column): column is string => Boolean(column))
    .map((column) => `[${column}]`);

  return columns.length > 0 ? `ORDER BY ${columns.join(", ")}` : "";
}

async function getTableLookupValues(
  config: LookupConfig,
  executor?: SqlExecutor,
): Promise<LookupValueRecord[]> {
  const table = getLookupTableReference(config);
  if (!table) {
    return [];
  }

  const load = async (target: typeof table) => selectRows<Record<string, unknown>>(target, {
    orderByClause: getLookupOrderByClause(config),
    executor,
  });

  let rows: Record<string, unknown>[];
  try {
    rows = await load(table);
  } catch (error) {
    if (isDatabaseUnavailableError(error) && table.databaseName) {
      rows = await load({ ...table, databaseName: null });
    } else {
      throw error;
    }
  }

  return rows.map((row) => mapLookupRow(row, config));
}

async function getTableLookupValueById(
  config: LookupConfig,
  id: number,
  executor?: SqlExecutor,
): Promise<LookupValueRecord | undefined> {
  const table = getLookupTableReference(config);
  if (!table) {
    return undefined;
  }

  const load = async (target: typeof table) => selectSingleRow<Record<string, unknown>>(target, {
    whereClause: "WHERE id = @id",
    params: { id },
    executor,
  });

  let row: Record<string, unknown> | undefined;
  try {
    row = await load(table);
  } catch (error) {
    if (isDatabaseUnavailableError(error) && table.databaseName) {
      row = await load({ ...table, databaseName: null });
    } else {
      throw error;
    }
  }

  return row ? mapLookupRow(row, config) : undefined;
}

async function getLookupValuesFromConfig(
  config: LookupConfig,
  executor?: SqlExecutor,
): Promise<LookupValueRecord[]> {
  if (config.valueProviderKey && config.providerStrategy === "override") {
    return getProvidedLookupValues(config, executor);
  }

  const tableValues = await getTableLookupValues(config, executor);
  if (tableValues.length > 0) {
    return tableValues;
  }

  return getProvidedLookupValues(config, executor);
}

async function getLookupValueFromConfig(
  config: LookupConfig,
  id: number,
  executor?: SqlExecutor,
): Promise<LookupValueRecord | undefined> {
  if (config.valueProviderKey && config.providerStrategy === "override") {
    return getProvidedLookupValueById(config, id, executor);
  }

  const tableValue = await getTableLookupValueById(config, id, executor);
  if (tableValue) {
    return tableValue;
  }

  return getProvidedLookupValueById(config, id, executor);
}

function getWritableLookupTable(config: LookupConfig): TableReference {
  const table = getLookupTableReference(config);
  if (!table) {
    throw new Error(`Lookup type ${config.id} is not writable`);
  }
  if (!isLookupWritable(config)) {
    throw new Error(`Lookup type ${config.id} is read-only`);
  }

  return table;
}

export class LookupModule {
  async createType(payload: LookupConfigMutation): Promise<LookupTypeRecord> {
    return mapType(await createLookupConfig(payload));
  }

  async updateType(id: number, payload: Partial<LookupConfigMutation>): Promise<LookupTypeRecord | undefined> {
    const config = await updateLookupConfig(id, payload);
    return config ? mapType(config) : undefined;
  }

  async deleteType(
    id: number,
    context?: {
      workContextBy?: number | null;
      updatedBy?: number | null;
    },
  ): Promise<boolean> {
    return deleteLookupConfig(id, context);
  }

  async getAllTypes(): Promise<LookupTypeRecord[]> {
    return (await getLookupConfigs()).map(mapType);
  }

  async getType(id: number): Promise<LookupTypeRecord | undefined> {
    const type = await getLookupConfigById(id);
    return type ? mapType(type) : undefined;
  }

  async getTypeByCode(code: string): Promise<LookupTypeRecord | undefined> {
    const type = await getLookupConfigByCode(code);
    return type ? mapType(type) : undefined;
  }

  async getTypeWithValues(
    id: number,
  ): Promise<(LookupTypeRecord & { values: LookupValueRecord[] }) | undefined> {
    const type = await this.getType(id);
    if (!type) {
      return undefined;
    }

    try {
      const values = await this.getValuesByTypeId(id);
      return { ...type, values };
    } catch (error) {
      if (shouldIgnoreLookupSourceError(error)) {
        return { ...type, values: [] };
      }
      throw error;
    }
  }

  async getAllTypesWithValues(): Promise<Array<LookupTypeRecord & { values: LookupValueRecord[] }>> {
    const types = await this.getAllTypes();
    return Promise.all(types.map(async (type) => {
      try {
        const values = await this.getValuesByTypeId(type.id);
        return { ...type, values };
      } catch (error) {
        if (shouldIgnoreLookupSourceError(error)) {
          return { ...type, values: [] };
        }
        throw error;
      }
    }));
  }

  async getOrgStructureCodesDecorations(executor?: SqlExecutor): Promise<OrgStructureCodeDecoration[]> {
    const table: TableReference = { schemaName: "dbo", tableName: "org_structure_codes" };
    const rows = await selectRows<Record<string, unknown>>(table, {
      orderByClause: "ORDER BY order_index, id",
      executor,
    });

    return rows.map((row) => ({
      id: Number(row.id),
      parentId: asOptionalNumber(row.parent_id),
      code: String(row.code || ""),
      name: String(row.name || ""),
      orderIndex: Number(row.order_index || 0),
      isActive: row.is_active == null ? true : Boolean(row.is_active),
      clare: asOptionalText(row.clare),
      logo: asOptionalText(row.logo),
      color: asOptionalText(row.color),
    }));
  }

  private async resolveValueTarget(
    id: number,
    typeId?: number,
    executor?: SqlExecutor,
  ): Promise<ResolvedLookupValue | undefined> {
    if (typeId != null) {
      const config = await getLookupConfigById(typeId);
      if (!config) {
        return undefined;
      }

      const value = await getLookupValueFromConfig(config, id, executor);
      return value ? { config, value } : undefined;
    }

    const matches: ResolvedLookupValue[] = [];
    for (const config of await getLookupConfigs()) {
      try {
        const value = await getLookupValueFromConfig(config, id, executor);
        if (value) {
          matches.push({ config, value });
        }
      } catch (error) {
        if (!shouldIgnoreLookupSourceError(error)) {
          throw error;
        }
      }
    }

    if (matches.length <= 1) {
      return matches[0];
    }

    const candidates = matches
      .map((match) => `${match.config.code}(${match.config.id})`)
      .join(", ");

    throw new Error(`Lookup value id ${id} is ambiguous across types: ${candidates}. Pass typeId explicitly.`);
  }

  async getValue(
    id: number,
    typeId?: number,
    executor?: SqlExecutor,
  ): Promise<LookupValueRecord | undefined> {
    const resolved = await this.resolveValueTarget(id, typeId, executor);
    return resolved?.value;
  }

  async getValuesByTypeId(typeId: number, executor?: SqlExecutor): Promise<LookupValueRecord[]> {
    const load = async (): Promise<LookupValueRecord[]> => {
      const config = await getLookupConfigById(typeId);
      if (!config) {
        return [];
      }

      return getLookupValuesFromConfig(config, executor);
    };

    try {
      return await load();
    } catch (error) {
      if (isDatabaseUnavailableError(error)) {
        return [];
      }

      if (!isInvalidObjectNameError(error)) {
        throw error;
      }

      clearLookupRegistryCache();
      try {
        return await load();
      } catch (retryError) {
        if (isInvalidObjectNameError(retryError)) {
          return [];
        }
        throw retryError;
      }
    }
  }

  async createValue(
    payload: Omit<LookupValueRecord, "id" | "createdAt">,
    executor?: SqlExecutor,
  ): Promise<LookupValueRecord> {
    const config = await getLookupConfigById(payload.typeId);
    if (!config) {
      throw new Error(`Lookup type ${payload.typeId} is not configured`);
    }

    const table = getWritableLookupTable(config);
    const columns = await getTableColumnSet(table, executor);
    const context = {
      workContextBy: (payload as any).workContextBy ?? null,
      createdBy: (payload as any).createdBy ?? null,
    } satisfies WriteContext;

    const insertPayload = buildLookupPayload(config, payload);
    applyEntryAuditForInsert(insertPayload, columns, context);

    const row = await insertRow<Record<string, unknown>>(
      table,
      insertPayload,
      executor,
    );

    return mapLookupRow(row, config);
  }

  async updateValue(
    id: number,
    payload: Partial<LookupValueRecord>,
    executor?: SqlExecutor,
  ): Promise<LookupValueRecord | undefined> {
    const resolved = await this.resolveValueTarget(id, payload.typeId, executor);
    if (!resolved) {
      return undefined;
    }

    const table = getWritableLookupTable(resolved.config);
    const columns = await getTableColumnSet(table, executor);
    const context = {
      workContextBy: (payload as any).workContextBy ?? null,
      updatedBy: (payload as any).updatedBy ?? null,
    } satisfies WriteContext;

    const updatePayload = buildLookupPayload(resolved.config, payload);
    applyEntryAuditForUpdate(updatePayload, columns, context);

    const row = await updateRow<Record<string, unknown>>(
      table,
      id,
      updatePayload,
      executor,
    );

    return row ? mapLookupRow(row, resolved.config) : undefined;
  }

  async deleteValue(
    id: number,
    typeId?: number,
    context?: WriteContext,
    executor?: SqlExecutor,
  ): Promise<boolean> {
    const resolved = await this.resolveValueTarget(id, typeId, executor);
    if (!resolved) {
      return false;
    }

    const table = getWritableLookupTable(resolved.config);
    const columns = await getTableColumnSet(table, executor);
    if (columns.has("is_deleted")) {
      const updatePayload: Record<string, unknown> = {
        is_deleted: true,
        is_active: columns.has("is_active") ? false : undefined,
      };
      applyEntryAuditForUpdate(updatePayload, columns, context);
      const row = await updateRow<Record<string, unknown>>(table, id, updatePayload, executor);
      return Boolean(row);
    }

    return deleteRow(table, id, executor);
  }

  async getTypeAliases(typeId: number): Promise<LookupTypeAliasRecord[]> {
    return getLookupTypeAliases(typeId);
  }

  async getTypeAlias(id: number): Promise<LookupTypeAliasRecord | undefined> {
    return getLookupTypeAliasById(id);
  }

  async createTypeAlias(payload: LookupTypeAliasMutation): Promise<LookupTypeAliasRecord> {
    return createLookupTypeAlias(payload);
  }

  async updateTypeAlias(
    id: number,
    payload: Partial<LookupTypeAliasMutation>,
  ): Promise<LookupTypeAliasRecord | undefined> {
    return updateLookupTypeAlias(id, payload);
  }

  async deleteTypeAlias(
    id: number,
    context?: {
      workContextBy?: number | null;
      updatedBy?: number | null;
    },
  ): Promise<boolean> {
    return deleteLookupTypeAlias(id, context);
  }

  async getVirtualValues(typeId: number): Promise<LookupVirtualValueRecord[]> {
    return getLookupVirtualValues(typeId);
  }

  async getVirtualValue(id: number): Promise<LookupVirtualValueRecord | undefined> {
    return getLookupVirtualValueById(id);
  }

  async createVirtualValue(
    payload: LookupVirtualValueMutation,
  ): Promise<LookupVirtualValueRecord> {
    return createLookupVirtualValue(payload);
  }

  async updateVirtualValue(
    id: number,
    payload: Partial<LookupVirtualValueMutation>,
  ): Promise<LookupVirtualValueRecord | undefined> {
    return updateLookupVirtualValue(id, payload);
  }

  async deleteVirtualValue(
    id: number,
    context?: {
      workContextBy?: number | null;
      updatedBy?: number | null;
    },
  ): Promise<boolean> {
    return deleteLookupVirtualValue(id, context);
  }
}

export const lookupModule = new LookupModule();
