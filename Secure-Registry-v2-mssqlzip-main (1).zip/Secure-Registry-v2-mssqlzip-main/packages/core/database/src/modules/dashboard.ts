import type { SqlExecutor } from "../config/connection";
import { runQuery } from "./helpers";

export type SystemDashboardStatisticRecord = {
  id: number;
  parentId: number | null;
  databaseName: string;
  schemaName: string;
  objectName: string;
  displayName: string;
  isActive: boolean;
  orderIndex: number | null;
  objectDescription: string | null;
  columnCount: number | null;
  rowCount: number | null;
  notes: string | null;
};

export async function getSystemDashboardStatistics(executor?: SqlExecutor): Promise<SystemDashboardStatisticRecord[]> {
  const rows = await runQuery<Record<string, unknown>>(
    `
      SELECT
        [id],
        [parent_id],
        [database_name],
        [schema_name],
        [object_name],
        [display_name],
        [is_active],
        [order_index],
        [object_description],
        [column_count],
        [row_count],
        [notes]
      FROM [dbo].[vw_system_dashboard_statistics]
      ORDER BY
        CASE WHEN [order_index] IS NULL THEN 1 ELSE 0 END,
        [order_index],
        [id]
    `,
    {},
    executor,
  );

  return rows.map((r) => ({
    id: Number(r.id),
    parentId: r.parent_id == null ? null : Number(r.parent_id),
    databaseName: String(r.database_name ?? ""),
    schemaName: String(r.schema_name ?? ""),
    objectName: String(r.object_name ?? ""),
    displayName: String(r.display_name ?? ""),
    isActive: Boolean(r.is_active),
    orderIndex: r.order_index == null ? null : Number(r.order_index),
    objectDescription: r.object_description == null ? null : String(r.object_description),
    columnCount: r.column_count == null ? null : Number(r.column_count),
    rowCount: r.row_count == null ? null : Number(r.row_count),
    notes: r.notes == null ? null : String(r.notes),
  }));
}

