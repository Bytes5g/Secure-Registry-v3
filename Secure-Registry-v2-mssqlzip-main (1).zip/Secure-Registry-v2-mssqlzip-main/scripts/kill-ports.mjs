import { execSync } from "child_process";

function uniq(values) {
  return Array.from(new Set(values));
}

function parsePorts(args) {
  const ports = args
    .map((v) => Number(String(v).trim()))
    .filter((n) => Number.isFinite(n) && n > 0);
  return ports.length ? ports : [3001, 5001];
}

function killPidsWindows(pids) {
  for (const pid of uniq(pids)) {
    if (!pid || !Number.isFinite(pid)) continue;
    try {
      execSync(`taskkill /PID ${pid} /F /T`, { stdio: "ignore" });
    } catch {
      continue;
    }
  }
}

function getListeningPidsWindows(port) {
  try {
    const out = execSync(`netstat -ano -p tcp | findstr :${port}`, { stdio: ["ignore", "pipe", "ignore"] }).toString();
    const pids = out
      .split(/\r?\n/)
      .map((l) => l.trim())
      .filter(Boolean)
      .filter((l) => /\sLISTENING\s/i.test(l))
      .map((l) => {
        const parts = l.split(/\s+/);
        const pid = parts[parts.length - 1];
        return Number(pid);
      })
      .filter((n) => Number.isFinite(n));
    return uniq(pids);
  } catch {
    return [];
  }
}

function killPortWindows(port) {
  const pids = getListeningPidsWindows(port);
  if (!pids.length) return;
  killPidsWindows(pids);
}

function killPortPosix(port) {
  try {
    const out = execSync(`lsof -ti tcp:${port}`, { stdio: ["ignore", "pipe", "ignore"] }).toString();
    const pids = out
      .split(/\r?\n/)
      .map((v) => Number(String(v).trim()))
      .filter((n) => Number.isFinite(n));
    for (const pid of uniq(pids)) {
      try {
        process.kill(pid, "SIGKILL");
      } catch {
        continue;
      }
    }
  } catch {
    return;
  }
}

const ports = parsePorts(process.argv.slice(2));
for (const port of ports) {
  if (process.platform === "win32") {
    killPortWindows(port);
  } else {
    killPortPosix(port);
  }
}

