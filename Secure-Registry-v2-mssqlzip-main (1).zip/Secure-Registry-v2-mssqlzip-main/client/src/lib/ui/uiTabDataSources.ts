export type UiPageDetailsLike = {
  tabs?: Array<{ tabKey: string; isDefault?: boolean }>;
  tabDataSources?: Array<{
    tabKey: string;
    dataSources: Array<{
      purpose?: string | null;
      sortOrder?: number | null;
      dataSource?: { dataSourceKey?: string | null } | null;
      mapping?: unknown;
    }>;
  }>;
};

export type UiTabDataSourceMapping = {
  params?: Record<string, string>;
  staticParams?: Record<string, unknown>;
  cursorParam?: string;
  limitParam?: string;
  limit?: number;
  paramTypes?: Record<string, "number" | "boolean" | "string" | "trimmedString">;
};

export type UiTabDataSourceResolved = {
  tabKey: string;
  purpose: string;
  sortOrder: number;
  dataSourceKey: string;
  mapping: UiTabDataSourceMapping | null;
};

export function getDefaultTabKey(details: UiPageDetailsLike | undefined | null): string | null {
  const tabs = Array.isArray(details?.tabs) ? details?.tabs : [];
  const explicitDefault = tabs.find((t) => Boolean(t?.isDefault) && t?.tabKey);
  if (explicitDefault?.tabKey) return String(explicitDefault.tabKey);
  const first = tabs.find((t) => t?.tabKey);
  return first?.tabKey ? String(first.tabKey) : null;
}

export function getTabDataSourcesForTab(
  details: UiPageDetailsLike | undefined | null,
  tabKey: string,
): UiTabDataSourceResolved[] {
  const tabDataSources = Array.isArray(details?.tabDataSources) ? details?.tabDataSources : [];
  const bucket = tabDataSources.find((t) => String(t?.tabKey ?? "") === String(tabKey));
  const list = Array.isArray(bucket?.dataSources) ? bucket?.dataSources : [];
  return list
    .map((ds) => {
      const key = ds?.dataSource?.dataSourceKey ? String(ds.dataSource.dataSourceKey) : "";
      return {
        tabKey: String(tabKey),
        purpose: String(ds?.purpose ?? "list"),
        sortOrder: Number(ds?.sortOrder ?? 0),
        dataSourceKey: key,
        mapping: ds?.mapping && typeof ds.mapping === "object" ? (ds.mapping as UiTabDataSourceMapping) : null,
      };
    })
    .filter((x) => Boolean(x.dataSourceKey))
    .sort((a, b) => a.sortOrder - b.sortOrder);
}

export function getTabDataSource(details: UiPageDetailsLike | undefined | null, tabKey: string, purpose = "list") {
  const normalizedPurpose = String(purpose || "list").toLowerCase();
  const all = getTabDataSourcesForTab(details, tabKey);
  const matched = all.find((ds) => String(ds.purpose ?? "list").toLowerCase() === normalizedPurpose);
  return matched ?? null;
}

export function getTabDataSourceKey(input: {
  details: UiPageDetailsLike | undefined | null;
  tabKey?: string | null;
  purpose?: string;
}): string | null {
  const tabKey = input.tabKey ? String(input.tabKey) : getDefaultTabKey(input.details);
  if (!tabKey) return null;

  const normalizedPurpose = (input.purpose ?? "list").toLowerCase();

  const all = getTabDataSourcesForTab(input.details, tabKey);
  const matched = all.find((ds) => String(ds.purpose ?? "list").toLowerCase() === normalizedPurpose);
  const picked = matched ?? all[0];
  return picked?.dataSourceKey ? String(picked.dataSourceKey) : null;
}

export function buildUiDataSourceParams(input: {
  criteria: Record<string, any>;
  mapping?: UiTabDataSourceMapping | null;
  cursor?: number | null;
  limitDefault?: number;
}): Record<string, any> {
  const mapping = input.mapping ?? null;
  const limitParam = mapping?.limitParam ? String(mapping.limitParam) : "limit";
  const cursorParam = mapping?.cursorParam ? String(mapping.cursorParam) : "cursor";
  const limitValue = Number(mapping?.limit ?? input.limitDefault ?? 50);
  const params: Record<string, any> = { [limitParam]: Number.isFinite(limitValue) ? limitValue : 50 };

  const paramTypes =
    mapping?.paramTypes && typeof mapping.paramTypes === "object" ? (mapping.paramTypes as UiTabDataSourceMapping["paramTypes"]) : null;
  const coerce = (paramKey: string, raw: any) => {
    const t = paramTypes?.[paramKey];
    if (!t) return raw;
    if (t === "number") {
      const n = Number(raw);
      return Number.isFinite(n) ? n : undefined;
    }
    if (t === "boolean") {
      const isTrue = raw === true || raw === 1 || raw === "1" || raw === "true";
      return isTrue ? 1 : undefined;
    }
    if (t === "trimmedString") {
      const s = String(raw ?? "").trim();
      return s ? s : undefined;
    }
    if (t === "string") return String(raw);
    return raw;
  };

  const staticParams = mapping?.staticParams && typeof mapping.staticParams === "object" ? mapping.staticParams : null;
  if (staticParams) {
    for (const [k, v] of Object.entries(staticParams)) {
      const coerced = coerce(k, v);
      if (coerced === undefined) continue;
      params[k] = coerced;
    }
  }

  const spec = mapping?.params && typeof mapping.params === "object" ? mapping.params : null;
  if (spec) {
    for (const [paramKey, criteriaKey] of Object.entries(spec)) {
      const v = (input.criteria as any)?.[criteriaKey];
      if (v == null) continue;
      if (typeof v === "string" && !v.trim()) continue;
      const coerced = coerce(paramKey, v);
      if (coerced === undefined) continue;
      params[paramKey] = coerced;
    }
  } else {
    for (const [k, v] of Object.entries(input.criteria ?? {})) {
      if (v == null) continue;
      if (typeof v === "string" && !v.trim()) continue;
      const coerced = coerce(k, v);
      if (coerced === undefined) continue;
      params[k] = coerced;
    }
  }

  if (input.cursor != null) {
    const coerced = coerce(cursorParam, input.cursor);
    params[cursorParam] = coerced === undefined ? input.cursor : coerced;
  }
  return params;
}
