import { z } from "zod";
import type { LookupValue } from "./lookups";

const nullableInt = z.number().int().nullable();
const nullableNumber = z.number().finite().nullable();
const nullableString = z.string().nullable();
const nullableBigIntNumber = z.number().int().safe().nullable();
const optionalNullableInt = nullableInt.optional().default(null);
const optionalNullableNumber = nullableNumber.optional().default(null);
const optionalNullableString = nullableString.optional().default(null);
const optionalNullableBigIntNumber = nullableBigIntNumber.optional().default(null);
const optionalNullableBool = z.boolean().nullable().optional().default(null);

export const geoAdminUnitSchema = z.object({
  id: z.number().int(),
  parentId: nullableInt,
  countryId: z.number().int(),
  level: nullableInt,
  codes: nullableString,
  name: z.string(),
  nameEn: nullableString,
  adminTypeAr: nullableString,
  adminTypeEn: nullableString,
  isActive: z.boolean(),
  geometryType: nullableString,
  latitude: nullableNumber,
  longitude: nullableNumber,
  bboxMinLon: nullableNumber,
  bboxMinLat: nullableNumber,
  bboxMaxLon: nullableNumber,
  bboxMaxLat: nullableNumber,
  geometryAreaSqm: nullableNumber,
  geometryPerimeterM: nullableNumber,
  geometryJson: nullableString,
  geom: nullableString,
  numVertices: nullableBigIntNumber,
  isValid: z.boolean().nullable(),
  createdAt: nullableString,
});
export const selectGeoAdminUnitSchema = geoAdminUnitSchema;
export type GeoAdminUnit = z.infer<typeof geoAdminUnitSchema>;

export const insertGeoAdminUnitSchema = z.object({
  parentId: optionalNullableInt,
  countryId: z.number().int(),
  level: optionalNullableInt,
  codes: optionalNullableString,
  name: z.string().min(1),
  nameEn: optionalNullableString,
  adminTypeAr: optionalNullableString,
  adminTypeEn: optionalNullableString,
  isActive: z.boolean().optional().default(true),
  geometryType: optionalNullableString,
  latitude: optionalNullableNumber,
  longitude: optionalNullableNumber,
  bboxMinLon: optionalNullableNumber,
  bboxMinLat: optionalNullableNumber,
  bboxMaxLon: optionalNullableNumber,
  bboxMaxLat: optionalNullableNumber,
  geometryAreaSqm: optionalNullableNumber,
  geometryPerimeterM: optionalNullableNumber,
  geometryJson: optionalNullableString,
  geom: optionalNullableString,
  numVertices: optionalNullableBigIntNumber,
  isValid: optionalNullableBool,
});
export type InsertGeoAdminUnit = z.input<typeof insertGeoAdminUnitSchema>;

export type GeoAdminUnitWithChildren = GeoAdminUnit & {
  children?: GeoAdminUnitWithChildren[];
  lookupValue?: LookupValue;
};
