import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { ArrowRight } from "lucide-react";
import { useLocation } from "wouter";
import { Button, EntityMediaManagerDialog } from "@secure-registry/components-ui";
import {
  deletePersonPhoto,
  fetchPersonFiles,
  setPersonPhotoFromExisting,
  uploadPersonPhoto,
} from "@/lib/api/persons-admin";
import { updateFileMetadata } from "@/lib/api/files-admin";

interface PersonProfileHeaderActionsProps {
  personId: number;
  backHref?: string;
}

export function PersonProfileHeaderActions({
  personId,
  backHref = "/config/persons",
}: PersonProfileHeaderActionsProps) {
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const [open, setOpen] = useState(false);

  const historyQuery = useQuery({
    queryKey: ["person-files", personId, "photo"],
    queryFn: () => fetchPersonFiles(personId, "photo"),
    enabled: Number.isFinite(personId) && personId > 0,
  });

  const invalidate = () => {
    queryClient.invalidateQueries({ queryKey: ["person-photo", personId] });
    queryClient.invalidateQueries({ queryKey: ["person-files", personId, "photo"] });
  };

  const uploadPhoto = useMutation({
    mutationFn: (file: File) => uploadPersonPhoto(personId, file),
    onSuccess: () => invalidate(),
  });

  const selectExisting = useMutation({
    mutationFn: (fileId: number) => setPersonPhotoFromExisting(personId, fileId),
    onSuccess: () => invalidate(),
  });

  const deletePhoto = useMutation({
    mutationFn: () => deletePersonPhoto(personId),
    onSuccess: () => invalidate(),
  });

  const updateMeta = useMutation({
    mutationFn: (payload: { fileId: number; title?: string | null; description?: string | null }) =>
      updateFileMetadata(payload.fileId, { title: payload.title, description: payload.description }),
    onSuccess: () => invalidate(),
  });

  return (
    <>
      <Button variant="secondary" onClick={() => setOpen(true)}>
        إدارة الصورة
      </Button>
      <Button variant="ghost" onClick={() => setLocation(backHref)}>
        <ArrowRight className="h-4 w-4" />
        <span className="ms-2">رجوع</span>
      </Button>

      <EntityMediaManagerDialog
        open={open}
        onOpenChange={setOpen}
        title="إدارة صورة الملف الشخصي"
        slots={[
          {
            key: "photo",
            label: "الصورة",
            accept: "image/png,image/jpeg,image/webp",
            maxSizeMb: 5,
            items: (historyQuery.data ?? []).map((row) => ({
              id: row.id,
              fileId: row.file.id,
              url: row.file.filePath,
              fileName: row.file.title ?? row.file.fileName,
              mimeType: row.file.mimeType,
              description: row.file.description,
              createdAt: row.createdAt,
              isPrimary: row.isPrimary,
            })),
            onUpload: async (file) => {
              await uploadPhoto.mutateAsync(file);
            },
            onSelectAsPrimary: async (fileId) => {
              await selectExisting.mutateAsync(fileId);
            },
            onDeletePrimary: async () => {
              await deletePhoto.mutateAsync();
            },
            onUpdateMetadata: async (fileId, patch) => {
              await updateMeta.mutateAsync({ fileId, title: patch.title, description: patch.description });
            },
          },
        ]}
        defaultSlotKey="photo"
      />
    </>
  );
}
