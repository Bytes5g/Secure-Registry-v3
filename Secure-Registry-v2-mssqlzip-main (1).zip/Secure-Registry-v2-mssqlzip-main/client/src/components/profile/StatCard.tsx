import type { ReactNode } from "react";

export type StatCardTone = "default" | "accent" | "warning" | "muted";

export interface StatCardProps {
  icon?: ReactNode;
  label: string;
  value: number | string;
  hint?: string;
  tone?: StatCardTone;
}

const TONE_CLASSES: Record<StatCardTone, string> = {
  default: "border-border bg-card",
  accent: "border-primary/30 bg-primary/5",
  warning: "border-amber-300/40 bg-amber-50 dark:bg-amber-950/20",
  muted: "border-border bg-muted/30",
};

export function StatCard({ icon, label, value, hint, tone = "default" }: StatCardProps) {
  return (
    <div className={`rounded-lg border p-4 ${TONE_CLASSES[tone]}`}>
      <div className="flex items-start justify-between gap-2">
        <div className="flex-1 min-w-0">
          <p className="text-sm text-muted-foreground truncate">{label}</p>
          <p className="mt-1 text-2xl font-bold tabular-nums">{value}</p>
          {hint ? <p className="mt-1 text-xs text-muted-foreground">{hint}</p> : null}
        </div>
        {icon ? <div className="text-muted-foreground shrink-0">{icon}</div> : null}
      </div>
    </div>
  );
}

export interface StatGridProps {
  items: StatCardProps[];
  columnsClassName?: string;
}

export function StatGrid({
  items,
  columnsClassName = "grid-cols-2 md:grid-cols-3 lg:grid-cols-5",
}: StatGridProps) {
  return (
    <div className={`grid gap-3 ${columnsClassName}`}>
      {items.map((item) => (
        <StatCard key={item.label} {...item} />
      ))}
    </div>
  );
}
