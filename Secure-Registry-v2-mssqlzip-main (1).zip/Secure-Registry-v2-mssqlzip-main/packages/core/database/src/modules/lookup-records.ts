export interface LookupTypeRecord {
  id: number;
  code: string;
  aliasCode: string | null;
  nameAr: string;
  description: string | null;
  isActive: boolean;
  databaseName: string | null;
  schemaName: string | null;
  tableName: string | null;
  nameColumn: string | null;
  orderColumn: string | null;
  parentColumn: string | null;
  createdAtColumn: string | null;
  writable: boolean;
  valueProviderKey: string | null;
  providerStrategy: "override" | "fallback";
  aliases: string[];
  createdAt: string | null;
  updatedAt: string | null;
}

export interface LookupValueRecord {
  id: number;
  typeId: number;
  code: string;
  nameAr: string;
  orderIndex: number;
  isActive: boolean;
  parentId: number | null;
  metadata: Record<string, unknown> | null;
  createdAt: string | null;
}
