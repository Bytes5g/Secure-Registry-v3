import {
  Button,
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  Input,
  Label,
  useMediaPreviewDialog,
} from "@secure-registry/components-ui";
import { Download, Eye, FileText, Folder, Pencil, Trash2, Upload } from "lucide-react";
import { formatBytes } from "./utils";
import type { FilesPageController } from "./useFilesPage";

export function ExplorerTab({ ctrl }: { ctrl: FilesPageController }) {
  const preview = useMediaPreviewDialog();

  const {
    browseQuery,
    currentFolder,
    setCurrentFolder,
    newFolderName,
    setNewFolderName,
    createFolderMutation,
    renameFolderMutation,
    deleteFolderMutation,
    deleteFileMutation,
    uploadMutation,
    setForm,
  } = ctrl;

  return (
    <Card>
      <CardHeader>
        <CardTitle>متصفح الملفات والمجلدات</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex flex-col gap-4">
          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              className="text-sm text-primary hover:underline"
              onClick={() => setCurrentFolder(null)}
            >
              الملفات
            </button>
            {(browseQuery.data?.data.breadcrumbs ?? []).map((crumb, index, arr) => {
              const isLast = index === arr.length - 1;
              return (
                <div key={crumb.id} className="flex items-center gap-2">
                  <span className="text-muted-foreground">/</span>
                  <button
                    type="button"
                    className={
                      isLast
                        ? "text-sm font-medium"
                        : "text-sm text-primary hover:underline"
                    }
                    onClick={() => setCurrentFolder(crumb.id)}
                    disabled={isLast}
                  >
                    {crumb.name}
                  </button>
                </div>
              );
            })}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-3">
            <div className="lg:col-span-2 flex flex-wrap items-end gap-3">
              <div className="space-y-2">
                <Label>اسم مجلد جديد</Label>
                <Input
                  value={newFolderName}
                  onChange={(e) => setNewFolderName(e.target.value)}
                />
              </div>
              <Button
                disabled={createFolderMutation.isPending}
                onClick={() => createFolderMutation.mutate()}
              >
                {createFolderMutation.isPending ? "جاري الإنشاء..." : "إنشاء مجلد"}
              </Button>
            </div>

            <div className="space-y-2">
              <Label>رفع داخل هذا المجلد</Label>
              <div className="flex items-center gap-2">
                <Input
                  type="file"
                  onChange={(e) =>
                    setForm((prev) => ({ ...prev, file: e.target.files?.[0] ?? null }))
                  }
                />
                <Button
                  disabled={uploadMutation.isPending}
                  onClick={() => uploadMutation.mutate({ folderId: currentFolder })}
                >
                  <Upload className="me-2 h-4 w-4" />
                  {uploadMutation.isPending ? "..." : "رفع"}
                </Button>
              </div>
            </div>
          </div>

          {browseQuery.isLoading ? (
            <div className="text-sm text-muted-foreground">جاري التحميل…</div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              <div className="space-y-2">
                <div className="text-sm font-medium">المجلدات</div>
                <div className="border rounded-md divide-y">
                  {(browseQuery.data?.data.folders ?? []).length === 0 ? (
                    <div className="p-3 text-sm text-muted-foreground">لا توجد مجلدات</div>
                  ) : (
                    (browseQuery.data?.data.folders ?? []).map((folder) => (
                      <div
                        key={folder.id}
                        className="p-3 flex items-center justify-between gap-3"
                      >
                        <button
                          type="button"
                          className="flex items-center gap-2 text-sm text-primary hover:underline"
                          onClick={() => setCurrentFolder(folder.id)}
                        >
                          <Folder className="h-4 w-4" />
                          {folder.name}
                        </button>
                        <div className="flex items-center gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => {
                              const nextName = window
                                .prompt("اسم المجلد", folder.name)
                                ?.trim();
                              if (!nextName || nextName === folder.name) return;
                              renameFolderMutation.mutate({ id: folder.id, name: nextName });
                            }}
                            disabled={renameFolderMutation.isPending}
                          >
                            <Pencil className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="destructive"
                            size="sm"
                            onClick={() => {
                              if (!window.confirm("حذف هذا المجلد؟")) return;
                              deleteFolderMutation.mutate(folder.id);
                            }}
                            disabled={deleteFolderMutation.isPending}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>

              <div className="space-y-2">
                <div className="text-sm font-medium">الملفات</div>
                <div className="border rounded-md divide-y">
                  {(browseQuery.data?.data.files ?? []).length === 0 ? (
                    <div className="p-3 text-sm text-muted-foreground">لا توجد ملفات</div>
                  ) : (
                    (browseQuery.data?.data.files ?? []).map((file) => (
                      <div
                        key={file.id}
                        className="p-3 flex items-center justify-between gap-3"
                      >
                        <div className="min-w-0 flex items-center gap-2">
                          <FileText className="h-4 w-4 text-muted-foreground shrink-0" />
                          <div className="min-w-0">
                            <div className="text-sm truncate">
                              {file.title ?? file.filenameDownload}
                            </div>
                            <div className="text-xs text-muted-foreground truncate">
                              {file.type ?? "-"} · {formatBytes(file.filesize)}
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => {
                              const url = `/api/files/${file.id}/download`;
                              const mime = file.type ?? null;
                              const kind = mime?.startsWith("video/")
                                ? "video"
                                : mime?.startsWith("image/")
                                  ? "image"
                                  : "auto";
                              preview.open({
                                url,
                                title: file.title ?? file.filenameDownload ?? `#${file.id}`,
                                mimeType: mime,
                                kind,
                              });
                            }}
                          >
                            <Eye className="h-4 w-4" />
                          </Button>
                          <a
                            className="inline-flex"
                            href={`/api/files/${file.id}/download`}
                            target="_blank"
                            rel="noreferrer"
                          >
                            <Button variant="outline" size="sm">
                              <Download className="h-4 w-4" />
                            </Button>
                          </a>
                          <Button
                            variant="destructive"
                            size="sm"
                            onClick={() => {
                              if (!window.confirm("حذف هذا الملف؟")) return;
                              deleteFileMutation.mutate(file.id);
                            }}
                            disabled={deleteFileMutation.isPending}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      </CardContent>
      {preview.dialog}
    </Card>
  );
}
