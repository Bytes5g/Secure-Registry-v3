import { useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import {
  createLookupVirtualValue,
  deleteLookupVirtualValue,
  fetchLookupVirtualValues,
  updateLookupVirtualValue,
} from "@/lib/api/lookups-admin";
import type {
  InsertLookupVirtualValue,
  LookupType,
  LookupVirtualValue,
} from "@shared/schema";
import {
  createEmptyVirtualSeedForm,
  createVirtualSeedFormFromRecord,
  mapVirtualSeedPayload,
  type VirtualSeedFormState,
} from "../models/lookups-admin-models";
import {
  createMutationFeedbackHandlers,
  ensureRequiredVirtualSeedFields,
  openCreateDialog,
  openEditDialog,
  submitNestedEntity,
  type SharedDeps,
} from "./_internals/shared";

interface VirtualSeedsArgs extends SharedDeps {
  selectedTypeId: number | null;
  selectedType: LookupType | null;
}

export function useLookupVirtualSeedsController({
  toast,
  invalidateAll,
  selectedTypeId,
  selectedType,
}: VirtualSeedsArgs) {
  const [virtualSeedDialogOpen, setVirtualSeedDialogOpen] = useState(false);
  const [editingVirtualSeed, setEditingVirtualSeed] = useState<LookupVirtualValue | null>(null);
  const [virtualSeedForm, setVirtualSeedForm] = useState<VirtualSeedFormState>(
    createEmptyVirtualSeedForm(),
  );
  const [virtualSeedToDelete, setVirtualSeedToDelete] =
    useState<LookupVirtualValue | null>(null);

  const { data: virtualSeeds = [], isLoading: virtualSeedsLoading } = useQuery({
    queryKey: ["lookup-admin", "virtual-seeds", selectedTypeId],
    queryFn: () => fetchLookupVirtualValues(selectedTypeId!),
    enabled: selectedTypeId != null,
  });

  const createVirtualSeedMutation = useMutation({
    mutationFn: (payload: InsertLookupVirtualValue) =>
      createLookupVirtualValue(payload.lookupTypeId, payload),
    ...createMutationFeedbackHandlers({
      invalidate: invalidateAll,
      toast,
      successTitle: "تمت إضافة البذرة الافتراضية",
      errorTitle: "تعذر حفظ البذرة",
      onSuccess: () => setVirtualSeedDialogOpen(false),
    }),
  });

  const updateVirtualSeedMutation = useMutation({
    mutationFn: ({
      id,
      payload,
    }: {
      id: number;
      payload: Partial<InsertLookupVirtualValue>;
    }) => updateLookupVirtualValue(id, payload),
    ...createMutationFeedbackHandlers({
      invalidate: invalidateAll,
      toast,
      successTitle: "تم تحديث البذرة الافتراضية",
      errorTitle: "تعذر تحديث البذرة",
      onSuccess: () => setVirtualSeedDialogOpen(false),
    }),
  });

  const deleteVirtualSeedMutation = useMutation({
    mutationFn: (id: number) => deleteLookupVirtualValue(id),
    ...createMutationFeedbackHandlers({
      invalidate: invalidateAll,
      toast,
      successTitle: "تم حذف البذرة الافتراضية",
      errorTitle: "تعذر حذف البذرة",
      onSuccess: () => setVirtualSeedToDelete(null),
    }),
  });

  const openCreateVirtualSeedDialog = () => {
    openCreateDialog({
      setEditing: setEditingVirtualSeed,
      setForm: setVirtualSeedForm,
      createEmptyForm: createEmptyVirtualSeedForm,
      setOpen: setVirtualSeedDialogOpen,
    });
  };

  const openEditVirtualSeedDialog = (record: LookupVirtualValue) => {
    openEditDialog({
      record,
      setEditing: setEditingVirtualSeed,
      setForm: setVirtualSeedForm,
      mapRecordToForm: createVirtualSeedFormFromRecord,
      setOpen: setVirtualSeedDialogOpen,
    });
  };

  const submitVirtualSeed = () => {
    submitNestedEntity({
      selectedType,
      form: virtualSeedForm,
      editingRecord: editingVirtualSeed,
      mapPayload: mapVirtualSeedPayload,
      validate: ensureRequiredVirtualSeedFields,
      create: (payload) => createVirtualSeedMutation.mutate(payload),
      update: (record, payload) =>
        updateVirtualSeedMutation.mutate({ id: record.id, payload }),
      toast,
    });
  };

  return {
    virtualSeeds,
    virtualSeedsLoading,
    virtualSeedDialogOpen,
    setVirtualSeedDialogOpen,
    editingVirtualSeed,
    virtualSeedForm,
    setVirtualSeedForm,
    virtualSeedToDelete,
    setVirtualSeedToDelete,
    openCreateVirtualSeedDialog,
    openEditVirtualSeedDialog,
    submitVirtualSeed,
    createVirtualSeedMutation,
    updateVirtualSeedMutation,
    deleteVirtualSeedMutation,
  };
}
