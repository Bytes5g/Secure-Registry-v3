import { createRequest } from "../config/connection";

export type StandardFieldDefinition = {
  id: number;
  fieldName: string;
  formattedName: string | null;
  nameAr: string | null;
  description: string | null;
  uiColumnType: string | null;
};

type DictionarySnapshot = {
  items: StandardFieldDefinition[];
  byKey: Map<string, StandardFieldDefinition>;
};

const CACHE_TTL_MS = 60_000;
let cache: { loadedAt: number; snapshot: Promise<DictionarySnapshot> } | null = null;

function normalizeKey(value: unknown): string | null {
  if (value == null) return null;
  const text = String(value).trim();
  return text ? text.toLowerCase() : null;
}

function mapRow(row: Record<string, unknown>): StandardFieldDefinition {
  return {
    id: Number(row.id),
    fieldName: String(row.field_name ?? ""),
    formattedName: row.formatted_name == null ? null : String(row.formatted_name),
    nameAr: row.name == null ? null : String(row.name),
    description: row.description == null ? null : String(row.description),
    uiColumnType: row.ui_column_type == null ? null : String(row.ui_column_type),
  };
}

function createSnapshot(items: StandardFieldDefinition[]): DictionarySnapshot {
  const byKey = new Map<string, StandardFieldDefinition>();

  for (const item of items) {
    const key1 = normalizeKey(item.fieldName);
    if (key1) byKey.set(key1, item);
    const key2 = normalizeKey(item.formattedName);
    if (key2) byKey.set(key2, item);
  }

  return { items, byKey };
}

async function loadSnapshot(): Promise<DictionarySnapshot> {
  const request = await createRequest();
  const result = await request.query<Record<string, unknown>>(
    `
      SELECT
        id,
        field_name,
        formatted_name,
        name,
        description,
        ui_column_type
      FROM dbo.standard_field_dictionary
      WHERE is_deleted = 0 AND is_active = 1
    `,
  );
  return createSnapshot(result.recordset.map(mapRow));
}

async function getSnapshot(): Promise<DictionarySnapshot> {
  if (!cache || Date.now() - cache.loadedAt > CACHE_TTL_MS) {
    cache = { loadedAt: Date.now(), snapshot: loadSnapshot() };
  }
  return cache.snapshot;
}

export class StandardFieldsModule {
  clearCache(): void {
    cache = null;
  }

  async getFieldDefinitionMap(): Promise<Map<string, StandardFieldDefinition>> {
    const snapshot = await getSnapshot();
    return snapshot.byKey;
  }
}

export const standardFieldsModule = new StandardFieldsModule();

