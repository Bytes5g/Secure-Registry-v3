import type { SqlExecutor } from "../config/connection";
import {
  insertRow,
  selectRows,
  selectSingleRow,
  updateRow,
  type TableReference,
} from "./helpers";

export interface OrgStructureRoleTitleRecord {
  id: number;
  orgId: number;
  branchScopeLookupId: number;
  orgStructureId: number;
  orgStructureCodeId: number;
  orgRoleTitleId: number;
  orderIndex: number;
  isActive: boolean;
  createdAt: string | null;
  workContextBy?: number | null;
  createdBy?: number | null;
  updatedAt?: string | Date | null;
  updatedBy?: number | null;
  isDeleted?: boolean | null;
}

export type OrgStructureRoleTitleMutation = Omit<OrgStructureRoleTitleRecord, "id" | "createdAt">;

const TABLE: TableReference = { schemaName: "dbo", tableName: "org_structure_role_titles" };

function asNumber(value: unknown): number | null {
  return value == null ? null : Number(value);
}

function mapRow(row: Record<string, unknown>): OrgStructureRoleTitleRecord {
  return {
    id: Number(row.id),
    orgId: Number(row.org_id),
    branchScopeLookupId: Number(row.branch_scope_lookup_id),
    orgStructureId: Number(row.org_structure_id),
    orgStructureCodeId: Number(row.org_structure_code_id),
    orgRoleTitleId: Number(row.org_role_title_id),
    orderIndex: row.order_index == null ? 0 : Number(row.order_index),
    isActive: row.is_active == null ? true : Boolean(row.is_active),
    createdAt: row.created_at == null ? null : String(row.created_at),
    workContextBy: asNumber(row.work_context_by),
    createdBy: asNumber(row.created_by),
    updatedAt: row.updated_at == null ? null : (row.updated_at as any),
    updatedBy: asNumber(row.updated_by),
    isDeleted: row.is_deleted == null ? null : Boolean(row.is_deleted),
  };
}

export class OrgStructureRoleTitlesModule {
  async getById(id: number, executor?: SqlExecutor): Promise<OrgStructureRoleTitleRecord | undefined> {
    const row = await selectSingleRow<Record<string, unknown>>(TABLE, {
      whereClause: "WHERE id = @id AND (is_deleted = 0 OR is_deleted IS NULL)",
      params: { id },
      executor,
    });
    return row ? mapRow(row) : undefined;
  }

  async getByOrgId(orgId: number, executor?: SqlExecutor): Promise<OrgStructureRoleTitleRecord[]> {
    const rows = await selectRows<Record<string, unknown>>(TABLE, {
      whereClause: "WHERE org_id = @orgId AND (is_deleted = 0 OR is_deleted IS NULL)",
      orderByClause: "ORDER BY ISNULL(order_index, 0), id",
      params: { orgId },
      executor,
    });
    return rows.map(mapRow);
  }

  async create(payload: OrgStructureRoleTitleMutation, executor?: SqlExecutor): Promise<OrgStructureRoleTitleRecord> {
    const row = await insertRow<Record<string, unknown>>(
      TABLE,
      {
        org_id: payload.orgId,
        branch_scope_lookup_id: payload.branchScopeLookupId,
        org_structure_id: payload.orgStructureId,
        org_structure_code_id: payload.orgStructureCodeId,
        org_role_title_id: payload.orgRoleTitleId,
        order_index: payload.orderIndex ?? 0,
        is_active: payload.isActive ?? true,
        work_context_by: payload.workContextBy ?? null,
        created_by: payload.createdBy ?? null,
        is_deleted: payload.isDeleted ?? false,
      },
      executor,
    );
    return mapRow(row);
  }

  async update(
    id: number,
    payload: Partial<OrgStructureRoleTitleMutation>,
    executor?: SqlExecutor,
  ): Promise<OrgStructureRoleTitleRecord | undefined> {
    const mappings: Array<[keyof OrgStructureRoleTitleMutation, string]> = [
      ["orgId", "org_id"],
      ["branchScopeLookupId", "branch_scope_lookup_id"],
      ["orgStructureId", "org_structure_id"],
      ["orgStructureCodeId", "org_structure_code_id"],
      ["orgRoleTitleId", "org_role_title_id"],
      ["orderIndex", "order_index"],
      ["isActive", "is_active"],
      ["workContextBy", "work_context_by"],
      ["updatedAt", "updated_at"],
      ["updatedBy", "updated_by"],
      ["isDeleted", "is_deleted"],
    ];

    const updatePayload: Record<string, unknown> = {};
    for (const [key, column] of mappings) {
      if ((payload as any)[key] !== undefined) {
        updatePayload[column] = (payload as any)[key] as unknown;
      }
    }

    const row = await updateRow<Record<string, unknown>>(TABLE, id, updatePayload, executor);
    return row ? mapRow(row) : undefined;
  }

  async softDelete(
    id: number,
    payload?: { workContextBy?: number | null; updatedBy?: number | null },
    executor?: SqlExecutor,
  ): Promise<boolean> {
    const updatePayload: Record<string, unknown> = {
      is_deleted: true,
      is_active: false,
      updated_at: new Date(),
    };
    if (payload?.workContextBy != null) updatePayload.work_context_by = payload.workContextBy;
    if (payload?.updatedBy != null) updatePayload.updated_by = payload.updatedBy;

    const row = await updateRow<Record<string, unknown>>(TABLE, id, updatePayload, executor);
    return Boolean(row);
  }
}

export const orgStructureRoleTitlesModule = new OrgStructureRoleTitlesModule();
