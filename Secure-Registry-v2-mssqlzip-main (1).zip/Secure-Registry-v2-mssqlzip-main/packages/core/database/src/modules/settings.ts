import type { SqlExecutor } from "../config/connection";
import { insertRow, runQueryOne, updateRow } from "./helpers";

export type FileUploadSettings = {
  relativeDirectory: string;
  maxFileSizeMB: number;
  allowedMimeTypes: string[];
  defaultFolderId: number | null;
};

type SettingsRow = {
  id: number;
  storage_default_folder: unknown;
  storage_asset_presets: unknown;
};

const FILE_SETTINGS_KEY = "secure_registry_files";
const UI_PAGE_OVERRIDES_KEY = "ui_page_config_overrides";

const DEFAULT_FILE_SETTINGS: FileUploadSettings = {
  relativeDirectory: "files",
  maxFileSizeMB: 25,
  allowedMimeTypes: [
    "image/jpeg",
    "image/png",
    "image/webp",
    "application/pdf",
    "application/zip",
    "application/x-zip-compressed",
    "application/msword",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    "application/vnd.ms-excel",
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    "text/plain",
  ],
  defaultFolderId: null,
};

function asNumber(value: unknown): number | null {
  if (value == null) return null;
  const n = Number(value);
  return Number.isFinite(n) ? n : null;
}

function parseJsonObject(value: unknown): Record<string, unknown> {
  if (value == null) return {};
  if (typeof value === "object") return value as Record<string, unknown>;
  if (typeof value !== "string") return {};
  try {
    const parsed = JSON.parse(value);
    return parsed && typeof parsed === "object" ? (parsed as Record<string, unknown>) : {};
  } catch {
    return {};
  }
}

function normalizeRelativeDirectory(value: unknown): string | null {
  if (typeof value !== "string") return null;
  const normalized = value.trim().replace(/\\/g, "/").replace(/^\/+/, "").replace(/\/+$/, "");
  if (!normalized) return null;
  if (normalized.includes("..")) return null;
  return normalized;
}

function normalizeMimeTypes(value: unknown): string[] | null {
  if (!Array.isArray(value)) return null;
  const list = value.map((v) => String(v).trim()).filter(Boolean);
  return list.length > 0 ? Array.from(new Set(list)) : null;
}

function normalizeMaxFileSizeMB(value: unknown): number | null {
  const n = Number(value);
  if (!Number.isFinite(n)) return null;
  const rounded = Math.round(n);
  if (rounded <= 0) return null;
  return Math.min(rounded, 2048);
}

function normalizeDefaultFolderId(value: unknown): number | null {
  if (value == null) return null;
  const n = Number(value);
  if (!Number.isFinite(n) || n <= 0) return null;
  return Math.trunc(n);
}

function mergeSettings(base: FileUploadSettings, patch: Partial<FileUploadSettings>): FileUploadSettings {
  const next: FileUploadSettings = { ...base };

  if (patch.relativeDirectory !== undefined) {
    const dir = normalizeRelativeDirectory(patch.relativeDirectory);
    if (dir) next.relativeDirectory = dir;
  }

  if (patch.maxFileSizeMB !== undefined) {
    const max = normalizeMaxFileSizeMB(patch.maxFileSizeMB);
    if (max) next.maxFileSizeMB = max;
  }

  if (patch.allowedMimeTypes !== undefined) {
    const mimes = normalizeMimeTypes(patch.allowedMimeTypes);
    if (mimes) next.allowedMimeTypes = mimes;
  }

  if (patch.defaultFolderId !== undefined) {
    next.defaultFolderId = normalizeDefaultFolderId(patch.defaultFolderId);
  }

  return next;
}

export class SettingsModule {
  private async getRawSettingsRow(executor?: SqlExecutor): Promise<SettingsRow | undefined> {
    return runQueryOne<SettingsRow>("SELECT TOP 1 id, storage_default_folder, storage_asset_presets FROM dbo.settings ORDER BY id", {}, executor);
  }

  async ensureSettingsRow(executor?: SqlExecutor): Promise<number> {
    const existing = await this.getRawSettingsRow(executor);
    if (existing?.id) return Number(existing.id);

    const inserted = await insertRow<Record<string, unknown>>(
      "settings",
      {
        project_name: "Secure Registry",
        project_color: "#983724",
        default_language: "ar",
        default_appearance: "dark",
        public_registration: false,
        public_registration_verify_email: false,
        mcp_enabled: false,
        mcp_allow_deletes: false,
        mcp_system_prompt_enabled: false,
      },
      executor,
    );

    return Number((inserted as any).id);
  }

  async getFileUploadSettings(executor?: SqlExecutor): Promise<FileUploadSettings> {
    await this.ensureSettingsRow(executor);
    const row = await this.getRawSettingsRow(executor);
    if (!row) {
      return DEFAULT_FILE_SETTINGS;
    }

    const presets = parseJsonObject(row.storage_asset_presets);
    const stored = parseJsonObject(presets[FILE_SETTINGS_KEY]);
    const fromDb: Partial<FileUploadSettings> = {
      relativeDirectory: stored.relativeDirectory as any,
      maxFileSizeMB: stored.maxFileSizeMB as any,
      allowedMimeTypes: stored.allowedMimeTypes as any,
      defaultFolderId: stored.defaultFolderId as any,
    };

    const base = mergeSettings(DEFAULT_FILE_SETTINGS, fromDb);
    const storageDefaultFolder = asNumber(row.storage_default_folder);
    if (base.defaultFolderId == null && storageDefaultFolder != null) {
      base.defaultFolderId = storageDefaultFolder;
    }

    return base;
  }

  async updateFileUploadSettings(patch: Partial<FileUploadSettings>, executor?: SqlExecutor): Promise<FileUploadSettings> {
    const id = await this.ensureSettingsRow(executor);
    const current = await this.getFileUploadSettings(executor);
    const next = mergeSettings(current, patch);

    const row = await this.getRawSettingsRow(executor);
    const presets = parseJsonObject(row?.storage_asset_presets);
    presets[FILE_SETTINGS_KEY] = next;

    await updateRow("settings", id, {
      storage_asset_presets: JSON.stringify(presets),
      storage_default_folder: next.defaultFolderId,
    }, executor);

    return next;
  }

  async getUiPageConfigOverride(pageCode: string, executor?: SqlExecutor): Promise<Record<string, unknown> | null> {
    const key = String(pageCode || "").trim();
    if (!key) return null;

    await this.ensureSettingsRow(executor);
    const row = await this.getRawSettingsRow(executor);
    const presets = parseJsonObject(row?.storage_asset_presets);
    const overrides = parseJsonObject(presets[UI_PAGE_OVERRIDES_KEY]);
    const value = overrides[key];
    if (!value || typeof value !== "object") return null;
    return value as Record<string, unknown>;
  }

  async setUiPageConfigOverride(
    pageCode: string,
    patch: Record<string, unknown> | null,
    executor?: SqlExecutor,
  ): Promise<void> {
    const key = String(pageCode || "").trim();
    if (!key) {
      throw new Error("pageCode is required");
    }

    const id = await this.ensureSettingsRow(executor);
    const row = await this.getRawSettingsRow(executor);
    const presets = parseJsonObject(row?.storage_asset_presets);
    const overrides = parseJsonObject(presets[UI_PAGE_OVERRIDES_KEY]);

    if (patch == null) {
      delete overrides[key];
    } else {
      overrides[key] = patch;
    }

    presets[UI_PAGE_OVERRIDES_KEY] = overrides;
    await updateRow(
      "settings",
      id,
      {
        storage_asset_presets: JSON.stringify(presets),
      },
      executor,
    );
  }
}

export const settingsModule = new SettingsModule();
