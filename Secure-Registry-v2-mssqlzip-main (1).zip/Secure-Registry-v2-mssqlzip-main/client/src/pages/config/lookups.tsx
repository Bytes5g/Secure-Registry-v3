import { LookupsAdminPage } from "@/features/lookups-admin/components/LookupsAdminPage";

export default function LookupsManagement() {
  return <LookupsAdminPage />;
}
