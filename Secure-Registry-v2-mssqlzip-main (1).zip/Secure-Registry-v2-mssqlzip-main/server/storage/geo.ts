import { geoModule } from "@core/database";
import type { GeoAdminUnit, InsertGeoAdminUnit, LookupValue } from "@shared/schema";
import type { IGeoAdminUnitsStorage } from "./types";

type GeoCreatePayload = Parameters<typeof geoModule.create>[0];
type GeoUpdatePayload = Parameters<typeof geoModule.update>[1];

// هذه الدالة تحول payload إدخال الوحدة الإدارية إلى payload متوافق مع geoModule مع تمرير workContextBy وحقول التدقيق
function toGeoCreatePayload(unit: InsertGeoAdminUnit): GeoCreatePayload {
  return {
    parentId: unit.parentId ?? null,
    countryId: unit.countryId,
    level: unit.level ?? null,
    codes: unit.codes ?? null,
    name: unit.name,
    nameEn: unit.nameEn ?? null,
    adminTypeAr: unit.adminTypeAr ?? null,
    adminTypeEn: unit.adminTypeEn ?? null,
    isActive: unit.isActive ?? true,
    geometryType: unit.geometryType ?? null,
    latitude: unit.latitude ?? null,
    longitude: unit.longitude ?? null,
    bboxMinLon: unit.bboxMinLon ?? null,
    bboxMinLat: unit.bboxMinLat ?? null,
    bboxMaxLon: unit.bboxMaxLon ?? null,
    bboxMaxLat: unit.bboxMaxLat ?? null,
    geometryAreaSqm: unit.geometryAreaSqm ?? null,
    geometryPerimeterM: unit.geometryPerimeterM ?? null,
    geometryJson: unit.geometryJson ?? null,
    geom: unit.geom ?? null,
    numVertices: unit.numVertices ?? null,
    isValid: unit.isValid ?? null,
    workContextBy: (unit as any).workContextBy,
    createdBy: (unit as any).createdBy,
    isDeleted: (unit as any).isDeleted,
  };
}

// هذه الدالة تحول payload تحديث الوحدة الإدارية إلى payload متوافق مع geoModule مع تمرير workContextBy وحقول التدقيق
function toGeoUpdatePayload(unit: Partial<InsertGeoAdminUnit>): GeoUpdatePayload {
  return {
    parentId: unit.parentId,
    countryId: unit.countryId,
    level: unit.level,
    codes: unit.codes,
    name: unit.name,
    nameEn: unit.nameEn,
    adminTypeAr: unit.adminTypeAr,
    adminTypeEn: unit.adminTypeEn,
    isActive: unit.isActive,
    geometryType: unit.geometryType,
    latitude: unit.latitude,
    longitude: unit.longitude,
    bboxMinLon: unit.bboxMinLon,
    bboxMinLat: unit.bboxMinLat,
    bboxMaxLon: unit.bboxMaxLon,
    bboxMaxLat: unit.bboxMaxLat,
    geometryAreaSqm: unit.geometryAreaSqm,
    geometryPerimeterM: unit.geometryPerimeterM,
    geometryJson: unit.geometryJson,
    geom: unit.geom,
    numVertices: unit.numVertices,
    isValid: unit.isValid,
    workContextBy: (unit as any).workContextBy,
    updatedAt: (unit as any).updatedAt,
    updatedBy: (unit as any).updatedBy,
    isDeleted: (unit as any).isDeleted,
  };
}

export class GeoAdminUnitsStorage implements IGeoAdminUnitsStorage {
  async getGeoAdminUnit(id: number): Promise<GeoAdminUnit | undefined> {
    return geoModule.getById(id);
  }
  
  async getAllGeoAdminUnits(): Promise<GeoAdminUnit[]> {
    return geoModule.getAll();
  }

  async queryGeoAdminUnits(params: {
    page: number;
    limit: number;
    search?: string;
    level?: number;
    parentId?: number | null;
    countryId?: number;
  }): Promise<{ data: GeoAdminUnit[]; total: number }> {
    return geoModule.query(params);
  }
  
  async getGeoAdminUnitsByLevel(level: number): Promise<GeoAdminUnit[]> {
    return geoModule.getByLevel(level);
  }
  
  async getGeoAdminUnitsByParentId(parentId: number | null): Promise<GeoAdminUnit[]> {
    return geoModule.getByParentId(parentId);
  }

  async getGeoCountries() {
    return geoModule.getCountries();
  }

  async updateGeoCountryOrderIndex(id: number, orderIndex: number) {
    return geoModule.updateCountryOrderIndex(id, orderIndex);
  }
  
  async createGeoAdminUnit(unit: InsertGeoAdminUnit): Promise<GeoAdminUnit> {
    return geoModule.create(toGeoCreatePayload(unit));
  }
  
  async createManyGeoAdminUnits(units: InsertGeoAdminUnit[]): Promise<GeoAdminUnit[]> {
    return geoModule.createMany(units.map(toGeoCreatePayload));
  }
  
  async updateGeoAdminUnit(id: number, unit: Partial<InsertGeoAdminUnit>): Promise<GeoAdminUnit | undefined> {
    return geoModule.update(id, toGeoUpdatePayload(unit));
  }
  
  async deleteGeoAdminUnit(id: number): Promise<boolean> {
    return await geoModule.delete(id);
  }

  async getGeoLevels(): Promise<LookupValue[]> {
    return geoModule.getLevels();
  }
}
