import { lookupModule } from "@core/database";
import type {
  LookupType,
  InsertLookupType,
  LookupValue,
  InsertLookupValue,
  LookupTypeWithValues,
  LookupTypeAlias,
  InsertLookupTypeAlias,
  LookupVirtualValue,
  InsertLookupVirtualValue,
} from "@shared/schema";
import type {
  ILookupTypesStorage,
  ILookupValuesStorage,
  ILookupTypeAliasesStorage,
  ILookupVirtualValuesStorage,
} from "./types";

export class LookupTypesStorage implements ILookupTypesStorage {
  async getLookupType(id: number): Promise<LookupType | undefined> {
    return lookupModule.getType(id);
  }
  
  async getLookupTypeByCode(code: string): Promise<LookupType | undefined> {
    return lookupModule.getTypeByCode(code);
  }
  
  async getLookupTypeWithValues(id: number): Promise<LookupTypeWithValues | undefined> {
    return lookupModule.getTypeWithValues(id);
  }
  
  async getAllLookupTypes(): Promise<LookupType[]> {
    return lookupModule.getAllTypes();
  }
  
  async getAllLookupTypesWithValues(): Promise<LookupTypeWithValues[]> {
    return lookupModule.getAllTypesWithValues();
  }
  
  async createLookupType(lookupType: InsertLookupType): Promise<LookupType> {
    return lookupModule.createType(lookupType);
  }
  
  async updateLookupType(id: number, lookupType: Partial<InsertLookupType>): Promise<LookupType | undefined> {
    return lookupModule.updateType(id, lookupType);
  }
  
  // هذه الدالة تحذف نوع lookup عبر طبقة قاعدة البيانات مع تمرير سياق التدقيق (workContextBy/updatedBy) إن توفر
  async deleteLookupType(
    id: number,
    context?: { workContextBy?: number | null; updatedBy?: number | null },
  ): Promise<boolean> {
    return lookupModule.deleteType(id, context);
  }
}

export class LookupValuesStorage implements ILookupValuesStorage {
  async getLookupValue(id: number, typeId?: number): Promise<LookupValue | undefined> {
    return lookupModule.getValue(id, typeId);
  }
  
  async getLookupValuesByTypeId(typeId: number): Promise<LookupValue[]> {
    return lookupModule.getValuesByTypeId(typeId);
  }
  
  async createLookupValue(lookupValue: InsertLookupValue): Promise<LookupValue> {
    return lookupModule.createValue(lookupValue);
  }
  
  async updateLookupValue(id: number, lookupValue: Partial<InsertLookupValue>, typeId?: number): Promise<LookupValue | undefined> {
    return lookupModule.updateValue(
      id,
      {
        ...lookupValue,
        typeId: typeId ?? lookupValue.typeId,
      },
    );
  }
  
  // هذه الدالة تحذف قيمة lookup مع تمرير سياق التدقيق (workContextBy/updatedBy) إن توفر
  async deleteLookupValue(
    id: number,
    typeId?: number,
    context?: { workContextBy?: number | null; updatedBy?: number | null },
  ): Promise<boolean> {
    return await lookupModule.deleteValue(id, typeId, context);
  }
}

export class LookupTypeAliasesStorage implements ILookupTypeAliasesStorage {
  async getLookupTypeAlias(id: number): Promise<LookupTypeAlias | undefined> {
    return lookupModule.getTypeAlias(id);
  }

  async getLookupTypeAliasesByTypeId(typeId: number): Promise<LookupTypeAlias[]> {
    return lookupModule.getTypeAliases(typeId);
  }

  async createLookupTypeAlias(alias: InsertLookupTypeAlias): Promise<LookupTypeAlias> {
    return lookupModule.createTypeAlias(alias);
  }

  async updateLookupTypeAlias(
    id: number,
    alias: Partial<InsertLookupTypeAlias>,
  ): Promise<LookupTypeAlias | undefined> {
    return lookupModule.updateTypeAlias(id, alias);
  }

  // هذه الدالة تحذف alias لنوع lookup مع تمرير سياق التدقيق (workContextBy/updatedBy) إن توفر
  async deleteLookupTypeAlias(
    id: number,
    context?: { workContextBy?: number | null; updatedBy?: number | null },
  ): Promise<boolean> {
    return lookupModule.deleteTypeAlias(id, context);
  }
}

export class LookupVirtualValuesStorage implements ILookupVirtualValuesStorage {
  async getLookupVirtualValue(id: number): Promise<LookupVirtualValue | undefined> {
    return lookupModule.getVirtualValue(id);
  }

  async getLookupVirtualValuesByTypeId(typeId: number): Promise<LookupVirtualValue[]> {
    return lookupModule.getVirtualValues(typeId);
  }

  async createLookupVirtualValue(
    seed: InsertLookupVirtualValue,
  ): Promise<LookupVirtualValue> {
    return lookupModule.createVirtualValue(seed);
  }

  async updateLookupVirtualValue(
    id: number,
    seed: Partial<InsertLookupVirtualValue>,
  ): Promise<LookupVirtualValue | undefined> {
    return lookupModule.updateVirtualValue(id, seed);
  }

  // هذه الدالة تحذف قيمة افتراضية (virtual seed) مع تمرير سياق التدقيق (workContextBy/updatedBy) إن توفر
  async deleteLookupVirtualValue(
    id: number,
    context?: { workContextBy?: number | null; updatedBy?: number | null },
  ): Promise<boolean> {
    return lookupModule.deleteVirtualValue(id, context);
  }
}
