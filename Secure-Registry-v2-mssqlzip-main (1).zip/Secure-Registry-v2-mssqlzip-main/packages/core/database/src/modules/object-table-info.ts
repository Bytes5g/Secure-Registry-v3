import { getObjectColumns } from "./table-introspection";

export type ObjectTableColumnInfo = {
  propKey: string;
  dbKey: string;
  dataType: string;
  isNullable: boolean;
  maxLength: number | null;
  precision: number | null;
  scale: number | null;
  isIdentity: boolean;
  hasDefault: boolean;
};

export type ObjectTableInfo = {
  tableName: string;
  schemaName: string;
  columns: ObjectTableColumnInfo[];
  columnMap: Map<string, ObjectTableColumnInfo>;
};

function toCamelCase(value: string): string {
  return value.replace(/_([a-z])/g, (_, char: string) => char.toUpperCase());
}

const tableInfoCache = new Map<string, Promise<ObjectTableInfo>>();

// هذه الدالة تُرجع توصيف الأعمدة لجسم (Table/View) بالاعتماد على sys.* عبر getObjectColumns مع دعم propToDb لتحويل أسماء الحقول
export async function getObjectTableInfo(input: {
  schemaName?: string;
  objectName: string;
  propToDb?: Record<string, string>;
}): Promise<ObjectTableInfo> {
  const schemaName = (input.schemaName ?? "dbo").trim() || "dbo";
  const cacheKey = `${schemaName}.${input.objectName}|${JSON.stringify(input.propToDb ?? {})}`;
  const cached = tableInfoCache.get(cacheKey);
  if (cached) return cached;

  const pending = (async () => {
    const introspected = await getObjectColumns({ schemaName, objectName: input.objectName });
    const propEntries = Object.entries(input.propToDb ?? {});
    const explicitPropByDb = new Map(propEntries.map(([propKey, dbKey]) => [dbKey, propKey]));

    const columns: ObjectTableColumnInfo[] = introspected.map((row) => {
      const dbKey = row.columnName;
      return {
        propKey: explicitPropByDb.get(dbKey) ?? toCamelCase(dbKey),
        dbKey,
        dataType: String(row.dataType || ""),
        isNullable: Boolean(row.isNullable),
        maxLength: row.maxLength == null ? null : Number(row.maxLength),
        precision: row.precision == null ? null : Number(row.precision),
        scale: row.scale == null ? null : Number(row.scale),
        isIdentity: Boolean(row.isIdentity),
        hasDefault: Boolean(row.hasDefault),
      };
    });

    const columnMap = new Map(columns.map((column) => [column.propKey, column]));
    return { tableName: input.objectName, schemaName, columns, columnMap };
  })();

  tableInfoCache.set(cacheKey, pending);
  return pending;
}

