import type { LookupTypeWithValues, LookupValue } from "@shared/schema";

export async function fetchLookupTypesWithValues(): Promise<LookupTypeWithValues[]> {
  const response = await fetch("/api/lookups/types-with-values");
  if (!response.ok) throw new Error("Failed to fetch lookup types");
  return response.json();
}

export async function fetchLookupTypeWithValues(id: number): Promise<LookupTypeWithValues> {
  const response = await fetch(`/api/lookups/types/${id}/with-values`);
  if (!response.ok) throw new Error("Failed to fetch lookup type");
  return response.json();
}

export async function fetchLookupValuesByTypeCode(typeCode: string): Promise<LookupValue[]> {
  const response = await fetch(`/api/lookups/types/by-code/${typeCode}/values`);
  if (!response.ok) return [];
  return response.json();
}
