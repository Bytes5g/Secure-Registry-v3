import { Router } from "express";
import organizationsRouter from "./org/organizations.routes";
import structureRoleTitlesRouter from "./org/structure-role-titles.routes";
import treeRouter from "./org/tree.routes";

const router = Router();

// هذا الملف مُجمِّع لمسارات org لتقسيم المسؤوليات وتجنّب الملفات الكبيرة
router.use(structureRoleTitlesRouter);
router.use(organizationsRouter);
router.use(treeRouter);

export default router;
