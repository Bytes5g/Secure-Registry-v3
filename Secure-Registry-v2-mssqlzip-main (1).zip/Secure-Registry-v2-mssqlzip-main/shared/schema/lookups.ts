import { z } from "zod";
const nullableString = z.string().nullable();
const aliasListSchema = z.array(z.string().min(1)).optional().default([]);

export const lookupTypeSchema = z.object({
  id: z.number().int(),
  code: z.string().min(1),
  aliasCode: nullableString.optional().default(null),
  nameAr: z.string().min(1),
  description: nullableString.optional().default(null),
  isActive: z.boolean().default(true),
  databaseName: nullableString.optional().default(null),
  schemaName: nullableString.optional().default(null),
  tableName: nullableString.optional().default(null),
  nameColumn: nullableString.optional().default(null),
  orderColumn: nullableString.optional().default(null),
  parentColumn: nullableString.optional().default(null),
  createdAtColumn: nullableString.optional().default(null),
  writable: z.boolean().default(true),
  valueProviderKey: nullableString.optional().default(null),
  providerStrategy: z.enum(["override", "fallback"]).default("override"),
  aliases: aliasListSchema,
  createdAt: nullableString.optional().default(null),
  updatedAt: nullableString.optional().default(null),
});

export const insertLookupTypeSchema = lookupTypeSchema.omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type InsertLookupType = z.infer<typeof insertLookupTypeSchema>;
export type LookupType = z.infer<typeof lookupTypeSchema>;

export const lookupValueSchema = z.object({
  id: z.number().int(),
  typeId: z.number().int(),
  code: z.string().min(1),
  nameAr: z.string().min(1),
  orderIndex: z.number().int().default(0),
  isActive: z.boolean().default(true),
  parentId: z.number().int().nullable().optional().default(null),
  metadata: z.record(z.string(), z.unknown()).nullable().optional().default(null),
  createdAt: nullableString.optional().default(null),
});

export const insertLookupValueSchema = lookupValueSchema.omit({
  id: true,
  createdAt: true,
});
export type InsertLookupValue = z.infer<typeof insertLookupValueSchema>;
export type LookupValue = z.infer<typeof lookupValueSchema>;

export const lookupTypeAliasSchema = z.object({
  id: z.number().int(),
  lookupTypeId: z.number().int(),
  aliasCode: z.string().min(1),
  isActive: z.boolean().default(true),
  createdAt: nullableString.optional().default(null),
  updatedAt: nullableString.optional().default(null),
});

export const insertLookupTypeAliasSchema = lookupTypeAliasSchema.omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertLookupTypeAlias = z.infer<typeof insertLookupTypeAliasSchema>;
export type LookupTypeAlias = z.infer<typeof lookupTypeAliasSchema>;

export const lookupVirtualValuesSchema = z.object({
  id: z.number().int(),
  lookupTypeId: z.number().int(),
  valueId: z.number().int(),
  code: z.string().min(1),
  nameAr: z.string().min(1),
  orderIndex: z.number().int().default(0),
  aliases: aliasListSchema,
  isActive: z.boolean().default(true),
  createdAt: nullableString.optional().default(null),
  updatedAt: nullableString.optional().default(null),
});

export const insertLookupVirtualValuesSchema = lookupVirtualValuesSchema.omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertLookupVirtualValue = z.infer<typeof insertLookupVirtualValuesSchema>;
export type LookupVirtualValue = z.infer<typeof lookupVirtualValuesSchema>;

export type LookupTypeWithValues = LookupType & {
  values: LookupValue[];
};
