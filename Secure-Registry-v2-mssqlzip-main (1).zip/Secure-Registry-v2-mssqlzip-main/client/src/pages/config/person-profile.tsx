import { useMemo, useState } from "react";
import { useParams } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Loader2, User } from "lucide-react";
import {
  EntityContentCard,
  EntityProfileHeader,
  EntityRelationsTabs,
} from "@secure-registry/components-ui";
import { fetchPerson, fetchPersonPhoto } from "@/lib/api/persons-admin";
import { PersonOverviewTab } from "./_person-profile/PersonOverviewTab";
import { PersonContactsTab } from "./_person-profile/PersonContactsTab";
import { PersonAssignmentsTab } from "./_person-profile/PersonAssignmentsTab";
import { PersonIdentitiesTab } from "./_person-profile/PersonIdentitiesTab";
import { PersonFilesTab } from "./_person-profile/PersonFilesTab";
import { PersonProfileHeaderActions } from "./_person-profile/PersonProfileHeaderActions";

export default function PersonProfilePage() {
  const { id } = useParams<{ id: string }>();
  const personId = Number(id);
  const enabled = Number.isFinite(personId) && personId > 0;
  const [activeTab, setActiveTab] = useState("general");

  const { data: person, isLoading } = useQuery({
    queryKey: ["person", personId],
    queryFn: () => fetchPerson(personId),
    enabled,
  });

  const { data: photo } = useQuery({
    queryKey: ["person-photo", personId],
    queryFn: () => fetchPersonPhoto(personId),
    enabled,
  });

  const headerMeta = useMemo(() => {
    if (!person) return [];
    return [
      { label: "الجنس:", value: person.genderName ?? "—" },
      { label: "الجنسية:", value: person.nationalityName ?? "—" },
      { label: "الحالة الاجتماعية:", value: person.maritalName ?? "—" },
      { label: "تاريخ الميلاد:", value: person.dateOfBirth ?? "—" },
    ];
  }, [person]);

  if (isLoading) {
    return (
      <div className="p-10 flex justify-center" dir="rtl">
        <Loader2 className="animate-spin h-8 w-8" />
      </div>
    );
  }

  if (!person) {
    return (
      <div className="p-8 text-center text-destructive" dir="rtl">
        لم يتم العثور على بيانات الشخص
      </div>
    );
  }

  const tabs = [
    { value: "general", label: "البيانات العامة", content: <PersonOverviewTab person={person} /> },
    { value: "contacts", label: "بيانات التواصل", content: <PersonContactsTab personId={personId} /> },
    { value: "identities", label: "الهويات", content: <PersonIdentitiesTab /> },
    { value: "files", label: "الصور والملفات", content: <PersonFilesTab personId={personId} /> },
    { value: "assignments", label: "البيانات الوظيفية", content: <PersonAssignmentsTab personId={personId} /> },
  ];

  return (
    <div className="p-6 space-y-4" dir="rtl">
      <EntityProfileHeader
        title={person.fullName}
        subtitle="بروفايل الشخص (البيانات الأساسية + العلاقات)"
        status={{
          label: person.isActive ? "فعّال" : "موقوف",
          variant: person.isActive ? "secondary" : "outline",
        }}
        meta={headerMeta}
        showCoverPlaceholder={true}
        coverImageUrl={null}
        avatarImageUrl={photo?.filePath || null}
        avatarFallback={<User className="h-5 w-5" />}
        coverHeightClassName="h-40 sm:h-48 md:h-56"
        avatarClassName="h-24 w-24 sm:h-28 sm:w-28"
        avatarOverlapClassName="-mt-10 sm:-mt-12"
        actions={<PersonProfileHeaderActions personId={personId} />}
      />

      <EntityContentCard contentClassName="p-6">
        <EntityRelationsTabs
          tabs={tabs}
          value={activeTab}
          onValueChange={setActiveTab}
          direction="rtl"
          className="w-full"
          tabsListClassName="mb-4 w-full overflow-x-auto"
        />
      </EntityContentCard>
    </div>
  );
}
