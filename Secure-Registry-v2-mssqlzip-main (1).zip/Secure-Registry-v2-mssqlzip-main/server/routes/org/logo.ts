import { Router } from "express";
import { entityFilesModule } from "@core/database";
import { asyncHandler } from "../../utils/asyncHandler";
import { cleanupTempFile, createOrgMediaFileFromRequest, createOrgMediaUploader, deletePrimaryOrgMedia, getPrimaryOrgMedia, parseOrgId, setPrimaryOrgMediaFromRequest } from "./media-utils";

const router = Router({ mergeParams: true });

router.get("/", asyncHandler(async (req, res) => {
  const orgId = parseOrgId(req);
  const includeHistory = String((req.query as any)?.includeHistory ?? "") === "1";

  if (includeHistory) {
    const rows = await entityFilesModule.getLinkedFiles("org_entities", orgId, "logo");
    const history = rows.map((r) => ({
      id: r.link.id,
      fileId: r.file.id,
      orgId,
      filePath: r.file.location ?? "",
      fileName: r.file.filenameDownload ?? null,
      title: r.file.title ?? null,
      mimeType: r.file.type ?? null,
      size: r.file.filesize ?? null,
      isPrimary: r.link.isPrimary,
      description: r.file.description ?? null,
      createdAt: r.link.createdAt,
    }));
    const current = history.find((x) => x.isPrimary) ?? null;
    return res.json({ current, history });
  }

  const current = await getPrimaryOrgMedia(orgId, "logo");
  if (!current) return res.json(null);

  res.json({
    id: current.link.id,
    fileId: current.file.id,
    orgId,
    filePath: current.file.location ?? "",
    fileName: current.file.filenameDownload ?? null,
    title: current.file.title ?? null,
    mimeType: current.file.type ?? null,
    size: current.file.filesize ?? null,
    isPrimary: current.link.isPrimary,
    description: current.file.description ?? null,
    createdAt: current.link.createdAt,
  });
}));

router.post(
  "/",
  asyncHandler(async (req, res, next) => {
    if (!req.is("application/json")) return next();
    const orgId = parseOrgId(req);
    const fileId = Number((req.body as any)?.fileId);
    if (!Number.isInteger(fileId) || fileId <= 0) return res.status(400).json({ error: "Invalid fileId" });

    const link = await setPrimaryOrgMediaFromRequest(req, orgId, "logo", fileId);
    const current = await getPrimaryOrgMedia(orgId, "logo");
    if (!current) throw new Error("Failed to set logo");

    res.status(200).json({
      id: link.id,
      fileId: current.file.id,
      orgId,
      filePath: current.file.location ?? "",
      fileName: current.file.filenameDownload ?? null,
      title: current.file.title ?? null,
      mimeType: current.file.type ?? null,
      size: current.file.filesize ?? null,
      isPrimary: true,
      description: current.file.description ?? null,
      createdAt: link.createdAt,
    });
  }),
);

router.post(
  "/",
  createOrgMediaUploader(5 * 1024 * 1024, "logo"),
  asyncHandler(async (req, res) => {
    const orgId = parseOrgId(req);
    if (!req.file) throw new Error("No file uploaded");

    try {
      const created = await createOrgMediaFileFromRequest(req, {
        orgId,
        kind: "logo",
        absoluteTempFilePath: req.file.path,
        originalName: req.file.originalname,
        declaredMime: req.file.mimetype,
        size: req.file.size,
        description: req.body.description,
      });

      const link = await setPrimaryOrgMediaFromRequest(req, orgId, "logo", created.fileId);
      const current = await getPrimaryOrgMedia(orgId, "logo");
      if (!current) throw new Error("Failed to set logo");

      res.status(201).json({
        id: link.id,
        fileId: current.file.id,
        orgId,
        filePath: current.file.location ?? created.publicUrl,
        fileName: current.file.filenameDownload ?? null,
        title: current.file.title ?? null,
        mimeType: current.file.type ?? null,
        size: current.file.filesize ?? null,
        isPrimary: true,
        description: current.file.description ?? null,
        createdAt: link.createdAt,
      });
    } catch (error) {
      await cleanupTempFile(req.file?.path);
      throw error;
    }
  }),
);

router.delete("/", asyncHandler(async (req, res) => {
  const orgId = parseOrgId(req);
  await deletePrimaryOrgMedia(orgId, "logo");
  res.sendStatus(204);
}));

export default router;
