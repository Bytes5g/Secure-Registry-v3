import { Router } from "express";
import { branchesModule, geoModule, orgModule, withTransaction } from "@core/database";
import { insertOrgBranchesSchema } from "@shared/schema";
import { asyncHandler } from "../utils/asyncHandler";
import { requireWriteContext } from "./_internals";

const router = Router();

// Get Branches
router.get("/", asyncHandler(async (req, res) => {
  const result = await branchesModule.getAll();
  res.json(result);
}));

// Get Options for Branch Form (Orgs)
router.get("/options/orgs", asyncHandler(async (req, res) => {
  const orgs = await orgModule.getAllOrganizations();
  res.json(orgs.map((org) => ({ id: org.id, name: org.name })));
}));

// Get Options for Branch Form (Geos)
router.get("/options/geos", asyncHandler(async (req, res) => {
  const geos = await geoModule.getAll();
  res.json(geos.map((geo) => ({ id: geo.id, name: geo.name })));
}));

// Get Branches covering a structure node
router.get("/by-node/:nodeId", asyncHandler(async (req, res) => {
  const nodeId = parseInt((req.params as any).nodeId);
  if (isNaN(nodeId)) throw new Error("Invalid node id");

  const branches = await branchesModule.getBranchesByStructureNodeId(nodeId);
  res.json(branches);
}));

// Get Branch by ID
router.get("/:id", asyncHandler(async (req, res) => {
  const branchId = parseInt(req.params.id);
  if (isNaN(branchId)) throw new Error("Invalid ID");

  const branch = await branchesModule.getById(branchId);
  if (!branch) return res.status(404).json({ error: "Branch not found" });
  
  res.json(branch);
}));

// Update Branch
router.patch("/:id", asyncHandler(async (req, res) => {
  const branchId = parseInt(req.params.id);
  if (isNaN(branchId)) throw new Error("Invalid ID");

  const updateSchema = insertOrgBranchesSchema.partial();
  const data = updateSchema.parse(req.body);
  const ctx = await requireWriteContext(req as any);

  const updated = await withTransaction(async (tx) => {
    const row = await branchesModule.update(
      branchId,
      {
        ...data,
        workContextBy: (data as any).workContextBy ?? ctx.workContextBy,
        updatedBy: ctx.userId,
        updatedAt: new Date(),
      } as any,
      tx,
    );
    return row;
  });

  if (!updated) return res.status(404).json({ error: "Branch not found" });
  res.json(updated);
}));

// Create Branch
router.post("/", asyncHandler(async (req, res) => {
  const data = insertOrgBranchesSchema.parse(req.body);
  const ctx = await requireWriteContext(req as any);
  const result = await withTransaction(async (tx) => {
    const created = await branchesModule.create(
      {
        ...(data as any),
        workContextBy: (data as any).workContextBy ?? ctx.workContextBy,
        createdBy: ctx.userId,
      } as never,
      tx,
    );
    return created;
  });
  res.json(result);
}));

// Get Branch Nodes (assigned nodes)
router.get("/:id/nodes", asyncHandler(async (req, res) => {
  const branchId = parseInt((req.params as any).id);
  if (isNaN(branchId)) throw new Error("Invalid ID");

  const nodes = await branchesModule.getNodesByBranchId(branchId);
  res.json(nodes);
}));

// Get Source Tree for Branch (Flat list from Org Tree)
router.get("/:id/source-tree", asyncHandler(async (req, res) => {
  const branchId = parseInt((req.params as any).id);
  if (isNaN(branchId)) throw new Error("Invalid ID");

  const branch = await branchesModule.getById(branchId);
  const orgId = branch?.orgId;

  if (!orgId) return res.status(404).json({ error: "Branch org not found" });

  const nodes = await branchesModule.getSourceTreeByBranchId(branchId);
  res.json(nodes.filter((node) => Number(node.org_id) === orgId));
}));

// Assign Nodes to Branch
router.post("/:id/assign-nodes", asyncHandler(async (req, res) => {
  const branchId = parseInt((req.params as any).id);
  if (isNaN(branchId)) throw new Error("Invalid ID");

  const branch = await branchesModule.getById(branchId);
  const orgId = branch?.orgId;

  if (!orgId) {
    return res.status(404).json({ error: "Branch not found or has no organization" });
  }

  const { nodeIds } = req.body;
  if (!Array.isArray(nodeIds)) {
    throw new Error("nodeIds must be an array");
  }

  await withTransaction(async (tx) => {
    const ctx = await requireWriteContext(req as any);
    await branchesModule.replaceBranchNodes(
      branchId,
      orgId,
      nodeIds,
      {
        userId: ctx.userId,
        workContextBy: ctx.workContextBy,
      },
      tx,
    );
  });

  res.json({ success: true });
}));

export default router;
