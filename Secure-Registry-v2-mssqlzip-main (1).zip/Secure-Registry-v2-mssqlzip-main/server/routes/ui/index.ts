import { Router } from "express";
import pagesRouter from "./pages.routes";
import dataSourcesRouter from "./data-sources.routes";

const router = Router();

router.use("/pages", pagesRouter);
router.use("/data-sources", dataSourcesRouter);

export default router;
