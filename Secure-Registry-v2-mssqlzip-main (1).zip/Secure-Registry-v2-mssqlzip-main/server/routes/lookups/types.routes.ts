import { Router, type Request } from "express";
import { storage } from "../../storage";
import { insertLookupTypeSchema } from "@shared/schema";
import { getErrorMessage, isInvalidObjectNameError } from "./helpers";
import { requireWriteContext } from "../_internals";

const router = Router();

router.get("/types", async (_req, res) => {
  try {
    const types = await storage.getAllLookupTypes();
    res.json(types);
  } catch (error) {
    console.error("Error fetching lookup types:", error);
    res.status(500).json({ error: "Failed to fetch lookup types" });
  }
});

router.get("/types-with-values", async (_req, res) => {
  try {
    const types = await storage.getAllLookupTypesWithValues();
    res.json(types);
  } catch (error) {
    if (isInvalidObjectNameError(error)) {
      try {
        const types = await storage.getAllLookupTypes();
        const enriched = await Promise.all(
          types.map(async (type) => {
            try {
              const values = await storage.getLookupValuesByTypeId(type.id);
              return { ...type, values };
            } catch (valueError) {
              if (isInvalidObjectNameError(valueError)) return { ...type, values: [] };
              throw valueError;
            }
          }),
        );
        return res.json(enriched);
      } catch (fallbackError) {
        console.error("Error fetching lookup types with values (fallback failed):", fallbackError);
        return res.status(500).json({ error: "Failed to fetch lookup types with values" });
      }
    }
    console.error("Error fetching lookup types with values:", error);
    return res.status(500).json({ error: "Failed to fetch lookup types with values" });
  }
});

router.get("/types/:id", async (req, res) => {
  try {
    const id = parseInt((req.params as any).id);
    const type = await storage.getLookupType(id);
    if (!type) return res.status(404).json({ error: "Lookup type not found" });
    res.json(type);
  } catch (error) {
    console.error("Error fetching lookup type:", error);
    res.status(500).json({ error: "Failed to fetch lookup type" });
  }
});

router.get("/types/code/:code", async (req, res) => {
  try {
    const type = await storage.getLookupTypeByCode((req.params as any).code);
    if (!type) return res.status(404).json({ error: "Lookup type not found" });
    res.json(type);
  } catch (error) {
    console.error("Error fetching lookup type:", error);
    res.status(500).json({ error: "Failed to fetch lookup type" });
  }
});

router.get("/types/by-code/:code/values", async (req, res) => {
  try {
    const type = await storage.getLookupTypeByCode((req.params as any).code);
    if (!type) return res.status(404).json({ error: "Lookup type not found" });
    const values = await storage.getLookupValuesByTypeId(type.id);
    res.json(values);
  } catch (error) {
    console.error("Error fetching lookup values by code:", error);
    res.status(500).json({ error: "Failed to fetch lookup values" });
  }
});

router.get("/types/:id/with-values", async (req, res) => {
  try {
    const id = parseInt((req.params as any).id);
    const type = await storage.getLookupTypeWithValues(id);
    if (!type) return res.status(404).json({ error: "Lookup type not found" });
    res.json(type);
  } catch (error) {
    console.error("Error fetching lookup type:", error);
    res.status(500).json({ error: "Failed to fetch lookup type" });
  }
});

router.post("/types", async (req, res) => {
  try {
    const parsed = insertLookupTypeSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: "Invalid lookup type data", details: parsed.error });
    }
    const ctx = await requireWriteContext(req);
    const type = await storage.createLookupType({
      ...(parsed.data as any),
      workContextBy: ctx.workContextBy,
      createdBy: ctx.userId,
    } as any);
    res.status(201).json(type);
  } catch (error) {
    console.error("Error creating lookup type:", error);
    res.status(500).json({ error: getErrorMessage(error, "Failed to create lookup type") });
  }
});

router.patch("/types/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const parsed = insertLookupTypeSchema.partial().safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: "Invalid lookup type data", details: parsed.error });
    }
    const ctx = await requireWriteContext(req);
    const type = await storage.updateLookupType(id, {
      ...(parsed.data as any),
      workContextBy: (parsed.data as any).workContextBy ?? ctx.workContextBy,
      updatedBy: ctx.userId,
    } as any);
    if (!type) return res.status(404).json({ error: "Lookup type not found" });
    res.json(type);
  } catch (error) {
    console.error("Error updating lookup type:", error);
    res.status(500).json({ error: getErrorMessage(error, "Failed to update lookup type") });
  }
});

router.delete("/types/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const ctx = await requireWriteContext(req);
    const success = await storage.deleteLookupType(id, {
      workContextBy: ctx.workContextBy,
      updatedBy: ctx.userId,
    });
    if (!success) return res.status(404).json({ error: "Lookup type not found" });
    res.status(204).send();
  } catch (error) {
    console.error("Error deleting lookup type:", error);
    res.status(500).json({ error: getErrorMessage(error, "Failed to delete lookup type") });
  }
});

export default router;
