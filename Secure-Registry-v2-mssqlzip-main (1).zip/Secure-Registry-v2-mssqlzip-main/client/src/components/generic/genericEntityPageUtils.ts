import type { Column } from "@secure-registry/components-ui";
import type { LookupTypeWithValues, LookupValue } from "@shared/schema";
import type { UiPageColumn, UiPageConfig } from "@/types/ui";

export function buildRuntimeConfig(args: {
  entityType: string;
  config: UiPageConfig;
  entities: any[];
  orgStructureAllNodes: any[];
}): UiPageConfig {
  const { entityType, config, entities, orgStructureAllNodes } = args;

  if (entityType === "organizationalStructure") {
    const orgOptions = entities
      .map((org: any) => ({
        value: String(org.id),
        label: org.name,
        parentValue: org.parentId == null ? null : String(org.parentId),
      }))
      .filter((option: { value: string; label: string; parentValue: string | null }) => option.value && option.label);

    const formFields = config.formFields.map((field) => {
      if (field.fieldCode === "parentId") {
        return {
          ...field,
          fieldType: "select",
          isRequired: false,
          config: {
            ...(field.config ?? {}),
            treeOptions: orgOptions,
          },
        };
      }
      return field;
    });

    return { ...config, formFields };
  }

  if (entityType === "orgStructureTree") {
    const nodeOptions = (Array.isArray(orgStructureAllNodes) ? orgStructureAllNodes : [])
      .map((n: any) => ({
        value: String(n.id),
        label: String(n.name ?? ""),
        parentValue: n.parentId == null ? null : String(n.parentId),
      }))
      .filter((option: { value: string; label: string; parentValue: string | null }) => option.value && option.label);

    const treeOptions = [{ value: "null", label: "بدون أب", parentValue: null }, ...nodeOptions];

    const formFields = config.formFields.map((field) => {
      if (field.fieldCode === "parentId") {
        return {
          ...field,
          fieldType: "select",
          isRequired: false,
          config: {
            ...(field.config ?? {}),
            treeOptions,
          },
        };
      }
      return field;
    });

    return { ...config, formFields };
  }

  return config;
}

export function buildGenericEntityTableColumns(args: {
  config: UiPageConfig | undefined;
  dbMeta: any[] | undefined;
  allLookups: LookupTypeWithValues[];
  extraColumns: Column<any>[];
}): Column<any>[] {
  const { config, dbMeta, allLookups, extraColumns } = args;

  if (!config?.columns || config.columns.length === 0) {
    if (!dbMeta || dbMeta.length === 0) return [];
    return dbMeta.map((c: any) => ({
      key: c.column_name,
      header: c.column_description || c.column_name,
      sortable: true,
    }));
  }

  const mappedColumns: Column<any>[] = config.columns
    .filter((col) => col.isVisible)
    .sort((a, b) => (a.orderIndex || 0) - (b.orderIndex || 0))
    .map((col: UiPageColumn) => ({
      key: col.fieldCode,
      header: col.nameAr,
      width: col.width || undefined,
      sortable: col.isSortable,
      render: (value: any) => {
        if (typeof value === "boolean") {
          return value ? "نعم" : "لا";
        }
        if (col.lookupTypeId) {
          const lookupType = allLookups.find((lt: LookupTypeWithValues) => lt.id === col.lookupTypeId);
          const lookupValue = lookupType?.values.find((v: LookupValue) => v.id == value || v.code == value);
          return lookupValue ? lookupValue.nameAr : value;
        }
        if (col.columnType === "date" && value) {
          return new Date(value).toLocaleDateString("ar-SA");
        }
        return value;
      },
    }));

  return [...mappedColumns, ...extraColumns];
}

