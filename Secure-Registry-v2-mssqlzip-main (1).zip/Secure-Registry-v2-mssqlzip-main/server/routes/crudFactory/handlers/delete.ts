import type { Router } from "express";
import { executeSoftDelete, resolveIdCondition } from "@core/database";
import type { TableDescriptor } from "../types";
import { getTableInfo } from "../sql/table-info";
import { runWrite } from "../run-write";
import { getAfterWriteHook } from "../../crudHooks";
import { getSessionUserId } from "../../_internals";

export function registerDeleteHandler(router: Router, descriptor: TableDescriptor) {
  const hook = getAfterWriteHook(descriptor);

  router.delete("/:id", async (req, res) => {
    try {
      const deleted = await runWrite(hook, "delete", async (executor) => {
        const tableInfo = await getTableInfo(descriptor);
        const { columnMap } = tableInfo;
        const { clause, params } = resolveIdCondition(req.params.id, columnMap);
        const sessionUserId = getSessionUserId(req);
        return executeSoftDelete({ tableInfo, clause, params, sessionUserId, executor });
      });

      if (!deleted) return res.status(404).json({ error: "Not found" });
      res.json({ success: true });
    } catch (e: any) {
      if (e.message.startsWith("Invalid ID") || e.message.startsWith("Table does not have")) {
        return res.status(400).json({ error: e.message });
      }
      console.error(`Error in DELETE /api/${descriptor.exportName}/${req.params.id}:`, e);
      res.status(500).json({ error: e.message });
    }
  });
}
