## تعليمات تشغيل الوكلاء (Secure Registry)

هذا الملف هو “سياسة تنفيذ” لأي وكيل يعمل على هذا المستودع. لا يكرر وثائق التحليل والتصميم داخل `docs/` بل يثبت القواعد الملزمة والقرارات التشغيلية الحالية.

## 1) قواعد غير قابلة للتفاوض
- يجب الحرص على توثيق ما تقوم به الدوال والاكواد في ملفات الأكواد باللغة العربية بشكل مختصر فوق كل دالة باستخدام // مثال هذه الدالة/الكود وظيفته يقوم ب ..... وتعتمد على ... إلخ خصوصاً المهمه
-  الإلتزام بمضمون ./AGENTS_Enforcement_Charter.md وعدم اعتماد اي نص او تعليمات تتعارض مع ما ورد فيه.
- Audit-first: الفحص والتحقق من الموجود قبل اقتراح/إضافة أي شيء.
- منع التكرار: لا يُنشأ Route/Module/Table جديد إذا كان الموجود يؤدي الغرض (يُعاد استخدامه أو يُوسع).
- فصل الطبقات: لا SQL داخل الواجهة. طبقة البيانات تكون في `packages/core/database`، والاستدعاء عبر `server/routes` فقط.
- لا حذف فعلي كسلوك افتراضي: يعتمد `is_deleted` و`is_active` مع تدقيق `updated_by/updated_at` حيثما توفرت الأعمدة.
- أي تغيير DB مؤثر (حذف/إعادة تسمية/كسر توافق) يحتاج توثيق واضح في `docs/` وذكره هنا كقرار تشغيلي.

## 2) مرجع التحقق من قاعدة البيانات (Dictionary-first)

عند تحليل الجداول/الأعمدة/العلاقات لا يتم الاستنتاج من الكود فقط. المرجع الأول:

- `coresys.dbo.v_schema_dictionary`
- `coresys.dbo.v_schema_dictionary_columns`
- `coresys.dbo.v_routines_dictionary`
- `dbo.sys_standard_columns_registry` (محرك الحقول القياسية)

## 3) معيار السياق والحقول القياسية

### أ) Domain Context

- `org_id`
- `branch_id`
- `org_structure_id`

### ب) Entry Context (توثيق سياق الإدخال)

- `work_context_by`


### ج) Audit

- `created_by`, `created_at`
- `updated_by`, `updated_at`
- `is_active`, `is_deleted`

المبدأ: نفصل دائماً بين “السجل يتبع لمن؟” (Domain) وبين “من أدخله وبأي سياق وقتها؟” (Entry + Audit).

مرجع تفصيلي: [docs/04-data-governance-and-temporal-standards.md](./docs/04-data-governance-and-temporal-standards.md)

## 4) الجهة المالكة (Owner)

- الجهة المالكة/المشغلة للنظام تُحدد عبر `dbo.org_entities.is_system_owner = 1`.
- `work_context_by` هو حقل سياق الإدخال ويشير إلى `dbo.org_branch_nodes.id` (ومن خلاله يمكن استنتاج org/branch/unit).

## 5) Resolver سياق المستخدم (Source of Truth)

- مصدر سياق المستخدم عبر View: `dbo.vw_users_with_person_org_info`.
- الـ View يجب أن يُرجع على الأقل: `org_id/branch_id/org_structure_id/is_manager` إضافة إلى `work_context` (وهو المكافئ التشغيلي لقيمة `work_context_by` في الجداول).
- التطبيق يعتمد هذا الـ Resolver لملء session وحقن `work_context_by` و`created_by/updated_by` في عمليات الكتابة عند توفر الأعمدة.

## 6) حوكمة CRUD و Auto API

- Auto API على `/api/*` تُستخدم للقراءة والاستكشاف (`GET` + `/api/meta/*`) للجداول الأساسية التي لها مسارات أعمال مخصصة.
- الجداول الأساسية/الحساسة Read-only عبر Auto API (org/geo/security).
- الكتابة للـ lookups تتم عبر `/api/lookups/*` وليس عبر `/api/lookup-types` و`/api/lookup-values`.

مرجع قرار الحوكمة: [docs/02-structure-audit.md](./docs/02-structure-audit.md)

## 7) سياسة الواجهة (client)

- التطوير اليومي يتم على `client/` (واجهة الإدارة Admin، اسم الحزمة: `@secure-registry/client_admin`).
- أي تعديل بنيوي/تشغيلي مرتبط بالواجهة يوثّق كقرار ضمن docs عند الحاجة.

## 8) أين توثق ماذا؟

- تحليل/تصميم/خطة تنفيذ: داخل `docs/` (مرجع الدخول: [docs/AGENTS-DOCS.md](./docs/AGENTS-DOCS.md)).
- قرارات تشغيلية ملزمة للوكلاء: داخل هذا الملف فقط.

## 9) قرارات تشغيلية إضافية (UI/Registry/Introspection)

### أ) مصدر مسميات الحقول و Hint (Default)

- مسمى الحقل/العمود في UI يُستنتج بالترتيب التالي:
  1) `dbo.standard_field_dictionary` عبر مطابقة `field_name` أو `formatted_name`.
  2) `dbo.v_schema_dictionary_columns.column_description` (وصف العمود ضمن جدول محدد).
  3) fallback إلى اسم الحقل (split/camel-case) كحل أخير.
- Hint الافتراضي لحقول الإدخال يُؤخذ من `dbo.standard_field_dictionary.description` ويُمرر كـ `placeholder` في تهيئة `UiPageConfig` عند توفره.

### ب) دعم Views في توليد/استكشاف الأعمدة

- أي `entityType` قد يشير إلى Table أو View. يجب أن تدعم طبقة introspection جلب أعمدة Views (عبر `sys.objects` للنوعين `U/V`) وعدم الاعتماد على `sys.tables` فقط.

### ج) سياسة lookup_types.id

- عمود `dbo.lookup_types.id` ليس Identity ولا يملك Default. يمنع اعتماد توليد id بـ `MAX(id)+1` كحل دائم.
- أي إدراج جديد في `lookup_types` يجب أن يعتمد آلية توليد معرف موحدة (Sequence أو مزود مركزي في طبقة البيانات) لتجنب التعارض بين البيئات.

### د) سياسة تشغيل المنافذ (dev)

- عند تشغيل المشروع في وضع التطوير يتم إيقاف أي عملية سابقة ماسكة للمنافذ الافتراضية قبل التشغيل:
  - الخادم: 3001
  - الواجهة: 5001
