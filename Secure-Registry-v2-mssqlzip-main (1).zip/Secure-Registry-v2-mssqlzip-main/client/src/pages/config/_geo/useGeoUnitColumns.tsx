import { Eye, FolderTree } from "lucide-react";
import { Badge, Button } from "@secure-registry/components-ui";
import type { GeoAdminUnit, LookupValue } from "@shared/schema";
import type { Column } from "@secure-registry/components-ui";
import { getLevelName, mapToTreeNode, type GeoTreeNode } from "./types";

interface Args {
  localLevels: LookupValue[];
  onView: (unit: GeoAdminUnit) => void;
  onSelectNode: (node: GeoTreeNode) => void;
}

export function useGeoUnitColumns({ localLevels, onView, onSelectNode }: Args): Column<GeoAdminUnit>[] {
  return [
    { key: "name", header: "الاسم", sortable: true },
    { key: "codes", header: "الكود", sortable: true },
    { key: "level", header: "نوع الوحدة", render: (v) => getLevelName(v, localLevels) },
    {
      key: "isActive",
      header: "فعال",
      render: (v) => <Badge variant={v ? "default" : "secondary"}>{v ? "نعم" : "لا"}</Badge>,
    },
    {
      key: "view",
      header: "عرض",
      render: (_, row) => (
        <Button variant="ghost" className="text-primary hover:underline" onClick={() => onView(row)}>
          <Eye className="h-4 w-4 ms-1" /> عرض
        </Button>
      ),
    },
    {
      key: "children",
      header: "التفرعات",
      render: (_, row) => (
        <Button
          variant="ghost"
          className="text-primary hover:underline"
          onClick={() => onSelectNode(mapToTreeNode(row))}
        >
          <FolderTree className="h-4 w-4 ms-1" /> استعراض
        </Button>
      ),
    },
  ];
}
