import { withTransaction, type SqlExecutor } from "../config/connection";
import { deleteRow, insertRow, runQuery, runQueryOne, updateRow } from "./helpers";

export interface OrganizationRecord {
  id: number;
  name: string;
  code: string;
  sectorId: number | null;
  locationId: number | null;
  categoryId: number | null;
  parentId: number | null;
  isActive: boolean;
  orderIndex: number;
  createdAt: string | null;
  workContextBy?: number | null;
  createdBy?: number | null;
  updatedAt?: string | null;
  updatedBy?: number | null;
  isDeleted?: boolean | null;
}

export interface TreeNodeRecord {
  id: number;
  parentId: number | null;
  orgId: number;
  name: string;
  code: string;
  structureId: number | null;
  isActive: boolean;
  orderIndex: number;
  level: number;
  createdAt: string | null;
  workContextBy?: number | null;
  createdBy?: number | null;
  updatedAt?: string | null;
  updatedBy?: number | null;
  isDeleted?: boolean | null;
}

export type CreateTreeNodeInput = Omit<TreeNodeRecord, "id" | "createdAt" | "orderIndex" | "level"> & {
  orderIndex?: number | null;
  level?: number | null;
};

// هذه الدالة تستنتج قيم level و order_index تلقائياً لعقدة الهيكل عند عدم تزويدها من الواجهة (وفق الأب والإخوة).
async function inferTreeNodeDefaults(
  input: { orgId: number; parentId: number | null; orderIndex?: number | null; level?: number | null },
  executor: SqlExecutor,
): Promise<{ orderIndex: number; level: number }> {
  const { orgId, parentId } = input;

  let level = input.level;
  if (level == null) {
    if (parentId == null) {
      level = 1;
    } else {
      const parentRow = await runQueryOne<{ level: unknown }>(
        `SELECT TOP 1 level
         FROM dbo.org_entity_structure
         WHERE id = @parentId
           AND org_id = @orgId
           AND (is_deleted = 0 OR is_deleted IS NULL)`,
        { parentId, orgId },
        executor,
      );
      const parentLevel = parentRow?.level == null ? null : Number(parentRow.level);
      if (parentLevel == null || !Number.isFinite(parentLevel)) {
        throw new Error("تعذر استنتاج مستوى العقدة لأن الأب غير موجود أو غير صالح");
      }
      level = parentLevel + 1;
    }
  }

  let orderIndex = input.orderIndex;
  if (orderIndex == null) {
    const nextRow = parentId == null
      ? await runQueryOne<{ nextOrderIndex: unknown }>(
          `SELECT ISNULL(MAX(order_index), -1) + 1 AS nextOrderIndex
           FROM dbo.org_entity_structure
           WHERE org_id = @orgId
             AND parent_id IS NULL
             AND (is_deleted = 0 OR is_deleted IS NULL)`,
          { orgId },
          executor,
        )
      : await runQueryOne<{ nextOrderIndex: unknown }>(
          `SELECT ISNULL(MAX(order_index), -1) + 1 AS nextOrderIndex
           FROM dbo.org_entity_structure
           WHERE org_id = @orgId
             AND parent_id = @parentId
             AND (is_deleted = 0 OR is_deleted IS NULL)`,
          { orgId, parentId },
          executor,
        );

    const parsed = nextRow?.nextOrderIndex == null ? 0 : Number(nextRow.nextOrderIndex);
    orderIndex = Number.isFinite(parsed) ? parsed : 0;
  }

  return { orderIndex, level };
}

function mapOrganization(row: Record<string, unknown>): OrganizationRecord {
  return {
    id: Number(row.id),
    name: String(row.name || ""),
    code: String(row.code || ""),
    sectorId: row.sector_id == null ? null : Number(row.sector_id),
    locationId: row.location_id == null ? null : Number(row.location_id),
    categoryId: row.category_id == null ? null : Number(row.category_id),
    parentId: row.parent_id == null ? null : Number(row.parent_id),
    isActive: Boolean(row.is_active),
    orderIndex: Number(row.order_index || 0),
    createdAt: row.created_at == null ? null : String(row.created_at),
    workContextBy: row.work_context_by == null ? null : Number(row.work_context_by),
    createdBy: row.created_by == null ? null : Number(row.created_by),
    updatedAt: row.updated_at == null ? null : String(row.updated_at),
    updatedBy: row.updated_by == null ? null : Number(row.updated_by),
    isDeleted: row.is_deleted == null ? null : Boolean(row.is_deleted),
  };
}

function mapTreeNode(row: Record<string, unknown>): TreeNodeRecord {
  return {
    id: Number(row.id),
    parentId: row.parent_id == null ? null : Number(row.parent_id),
    orgId: Number(row.org_id),
    name: String(row.name || ""),
    code: String(row.code || ""),
    structureId: row.structure_id == null ? null : Number(row.structure_id),
    isActive: Boolean(row.is_active),
    orderIndex: Number(row.order_index || 0),
    level: Number(row.level || 0),
    createdAt: row.created_at == null ? null : String(row.created_at),
    workContextBy: row.work_context_by == null ? null : Number(row.work_context_by),
    createdBy: row.created_by == null ? null : Number(row.created_by),
    updatedAt: row.updated_at == null ? null : String(row.updated_at),
    updatedBy: row.updated_by == null ? null : Number(row.updated_by),
    isDeleted: row.is_deleted == null ? null : Boolean(row.is_deleted),
  };
}

export class OrgModule {
  async getOrganization(id: number): Promise<OrganizationRecord | undefined> {
    const row = await runQueryOne<Record<string, unknown>>(
      "SELECT TOP 1 * FROM [org_entities] WHERE id = @id AND (is_deleted = 0 OR is_deleted IS NULL)",
      { id },
    );
    return row ? mapOrganization(row) : undefined;
  }

  async getAllOrganizations(options?: { includeInactive?: boolean }): Promise<OrganizationRecord[]> {
    const includeInactive = Boolean(options?.includeInactive);
    const rows = await runQuery<Record<string, unknown>>(
      `SELECT * FROM [org_entities]
       WHERE ${includeInactive ? "1=1" : "is_active = 1"}
         AND (is_deleted = 0 OR is_deleted IS NULL)
       ORDER BY order_index, name`,
    );
    return rows.map(mapOrganization);
  }

  async getOrganizationsByParentId(
    parentId: number | null,
    options?: { includeInactive?: boolean },
  ): Promise<OrganizationRecord[]> {
    const includeInactive = Boolean(options?.includeInactive);
    const rows = parentId === null
      ? await runQuery<Record<string, unknown>>(
          `SELECT * FROM [org_entities]
           WHERE parent_id IS NULL
             AND ${includeInactive ? "1=1" : "is_active = 1"}
             AND (is_deleted = 0 OR is_deleted IS NULL)
           ORDER BY order_index, name`,
        )
      : await runQuery<Record<string, unknown>>(
          `SELECT * FROM [org_entities]
           WHERE parent_id = @parentId
             AND ${includeInactive ? "1=1" : "is_active = 1"}
             AND (is_deleted = 0 OR is_deleted IS NULL)
           ORDER BY order_index, name`,
          { parentId },
        );
    return rows.map(mapOrganization);
  }

  async createOrganization(payload: Omit<OrganizationRecord, "id" | "createdAt">, executor?: SqlExecutor): Promise<OrganizationRecord> {
    if (!executor) {
      return withTransaction((tx) => this.createOrganization(payload, tx));
    }

    const row = await insertRow<Record<string, unknown>>(
      "org_entities",
      {
        name: payload.name,
        code: payload.code,
        sector_id: payload.sectorId,
        location_id: payload.locationId,
        category_id: payload.categoryId,
        parent_id: payload.parentId,
        is_active: payload.isActive,
        order_index: payload.orderIndex,
        work_context_by: payload.workContextBy,
        created_by: payload.createdBy,
      },
      executor,
    );
    const organization = mapOrganization(row);
    return organization;
  }

  async updateOrganization(id: number, payload: Partial<OrganizationRecord>, executor?: SqlExecutor): Promise<OrganizationRecord | undefined> {
    if (!executor) {
      return withTransaction((tx) => this.updateOrganization(id, payload, tx));
    }

    const row = await updateRow<Record<string, unknown>>(
      "org_entities",
      id,
      {
        name: payload.name,
        code: payload.code,
        sector_id: payload.sectorId,
        location_id: payload.locationId,
        category_id: payload.categoryId,
        parent_id: payload.parentId,
        is_active: payload.isActive,
        order_index: payload.orderIndex,
        work_context_by: payload.workContextBy,
        updated_at: payload.updatedAt,
        updated_by: payload.updatedBy,
        is_deleted: payload.isDeleted,
      },
      executor,
    );
    if (!row) {
      return undefined;
    }

    const organization = mapOrganization(row);
    return organization;
  }

  async deleteOrganization(id: number, executor?: SqlExecutor): Promise<boolean> {
    if (!executor) {
      return withTransaction((tx) => this.deleteOrganization(id, tx));
    }

    const row = await updateRow<Record<string, unknown>>(
      "org_entities",
      id,
      { is_deleted: true, is_active: false, updated_at: new Date() },
      executor,
    );
    return Boolean(row);
  }

  async getTreeNode(id: number): Promise<TreeNodeRecord | undefined> {
    const row = await runQueryOne<Record<string, unknown>>(
      `SELECT TOP 1 *
       FROM dbo.org_entity_structure
       WHERE id = @id
         AND (is_deleted = 0 OR is_deleted IS NULL)`,
      { id },
    );
    return row ? mapTreeNode(row) : undefined;
  }

  async getTreeNodesByOrgId(orgId: number, options?: { includeInactive?: boolean }): Promise<TreeNodeRecord[]> {
    const includeInactive = Boolean(options?.includeInactive);
    const rows = await runQuery<Record<string, unknown>>(
      `SELECT *
       FROM dbo.org_entity_structure
       WHERE org_id = @orgId
         AND ${includeInactive ? "1=1" : "is_active = 1"}
         AND (is_deleted = 0 OR is_deleted IS NULL)
       ORDER BY level, order_index, name`,
      { orgId },
    );
    return rows.map(mapTreeNode);
  }

  async getTreeNodesByParentId(
    orgId: number,
    parentId: number | null,
    options?: { includeInactive?: boolean },
  ): Promise<TreeNodeRecord[]> {
    const includeInactive = Boolean(options?.includeInactive);
    const rows = parentId === null
      ? await runQuery<Record<string, unknown>>(
          `SELECT *
           FROM dbo.org_entity_structure
           WHERE org_id = @orgId
             AND parent_id IS NULL
             AND ${includeInactive ? "1=1" : "is_active = 1"}
             AND (is_deleted = 0 OR is_deleted IS NULL)
           ORDER BY order_index, name`,
          { orgId },
        )
      : await runQuery<Record<string, unknown>>(
          `SELECT *
           FROM dbo.org_entity_structure
           WHERE org_id = @orgId
             AND parent_id = @parentId
             AND ${includeInactive ? "1=1" : "is_active = 1"}
             AND (is_deleted = 0 OR is_deleted IS NULL)
           ORDER BY order_index, name`,
          { orgId, parentId },
        );
    return rows.map(mapTreeNode);
  }

  async createTreeNode(payload: CreateTreeNodeInput, executor?: SqlExecutor): Promise<TreeNodeRecord> {
    if (!executor) {
      return withTransaction((tx) => this.createTreeNode(payload, tx));
    }

    const inferred = await inferTreeNodeDefaults(
      {
        orgId: payload.orgId,
        parentId: payload.parentId,
        orderIndex: payload.orderIndex,
        level: payload.level,
      },
      executor,
    );

    const row = await insertRow<Record<string, unknown>>(
      "org_entity_structure",
      {
        parent_id: payload.parentId,
        org_id: payload.orgId,
        name: payload.name,
        code: payload.code,
        structure_id: payload.structureId,
        is_active: payload.isActive,
        order_index: inferred.orderIndex,
        level: inferred.level,
        work_context_by: payload.workContextBy,
        created_by: payload.createdBy,
      },
      executor,
    );
    const node = mapTreeNode(row);
    return node;
  }

  async createManyTreeNodes(payload: CreateTreeNodeInput[], executor?: SqlExecutor): Promise<TreeNodeRecord[]> {
    const created: TreeNodeRecord[] = [];
    for (const item of payload) {
      created.push(await this.createTreeNode(item, executor));
    }
    return created;
  }

  async updateTreeNode(id: number, payload: Partial<TreeNodeRecord>, executor?: SqlExecutor): Promise<TreeNodeRecord | undefined> {
    if (!executor) {
      return withTransaction((tx) => this.updateTreeNode(id, payload, tx));
    }

    const row = await updateRow<Record<string, unknown>>(
      "org_entity_structure",
      id,
      {
        parent_id: payload.parentId,
        org_id: payload.orgId,
        name: payload.name,
        code: payload.code,
        structure_id: payload.structureId,
        is_active: payload.isActive,
        order_index: payload.orderIndex,
        level: payload.level,
        work_context_by: payload.workContextBy,
        updated_at: payload.updatedAt,
        updated_by: payload.updatedBy,
        is_deleted: payload.isDeleted,
      },
      executor,
    );
    if (!row) {
      return undefined;
    }

    const node = mapTreeNode(row);
    return node;
  }

  async deleteTreeNode(id: number, executor?: SqlExecutor): Promise<boolean> {
    if (!executor) {
      return withTransaction((tx) => this.deleteTreeNode(id, tx));
    }

    const row = await updateRow<Record<string, unknown>>(
      "org_entity_structure",
      id,
      { is_deleted: true, is_active: false, updated_at: new Date() },
      executor,
    );
    return Boolean(row);
  }
}

export const orgModule = new OrgModule();
