import { Router } from "express";
import { foldersModule } from "@core/database";
import { insertFolderSchema } from "@shared/schema";
import { asyncHandler } from "../../utils/asyncHandler";
import {
  ensureFolderExists,
  parseFolderFilter,
  parseId,
  parseOptionalNumber,
} from "./helpers";
import { requireWriteContext } from "../_internals";

const router = Router();

router.get(
  "/folders",
  asyncHandler(async (req, res) => {
    const parent = parseFolderFilter(req.query.parent);
    const limit = parseOptionalNumber(req.query.limit);
    const search = typeof req.query.search === "string" ? req.query.search : undefined;

    const folders = await foldersModule.getFolders({
      parent,
      limit: typeof limit === "number" ? limit : undefined,
      search,
    });
    res.json({ data: folders });
  }),
);

router.get(
  "/folders/:id",
  asyncHandler(async (req, res) => {
    const id = parseId(req.params.id);
    if (!id) return res.status(400).json({ error: "Invalid id" });
    const folder = await foldersModule.getFolder(id);
    if (!folder) return res.status(404).json({ error: "Not found" });
    res.json(folder);
  }),
);

router.post(
  "/folders",
  // هذا المسار ينشئ مجلد جديد ويحقن workContextBy و createdBy من session عبر requireWriteContext
  asyncHandler(async (req, res) => {
    const parsed = insertFolderSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: "Invalid folder payload", details: parsed.error });
    }
    await ensureFolderExists(parsed.data.parent ?? null);
    const ctx = await requireWriteContext(req as any);
    const created = await foldersModule.createFolder({
      name: parsed.data.name,
      parent: parsed.data.parent ?? null,
      workContextBy: ctx.workContextBy,
      createdBy: ctx.userId,
      isActive: true,
      isDeleted: false,
    });
    res.status(201).json(created);
  }),
);

router.put(
  "/folders/:id",
  asyncHandler(async (req, res) => {
    const id = parseId(req.params.id);
    if (!id) return res.status(400).json({ error: "Invalid id" });
    const parsed = insertFolderSchema.partial().safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: "Invalid folder payload", details: parsed.error });
    }
    if (parsed.data.parent === id) {
      return res.status(400).json({ error: "A folder cannot be its own parent" });
    }
    if (parsed.data.parent !== undefined) {
      await ensureFolderExists(parsed.data.parent);
    }
    const ctx = await requireWriteContext(req as any);
    const updated = await foldersModule.updateFolder(id, {
      name: parsed.data.name,
      parent: parsed.data.parent,
      updatedBy: ctx.userId,
      updatedAt: new Date(),
    });
    if (!updated) return res.status(404).json({ error: "Not found" });
    res.json(updated);
  }),
);

router.delete(
  "/folders/:id",
  asyncHandler(async (req, res) => {
    const id = parseId(req.params.id);
    if (!id) return res.status(400).json({ error: "Invalid id" });
    const folder = await foldersModule.getFolder(id);
    if (!folder) return res.status(404).json({ error: "Not found" });
    try {
      await foldersModule.deleteFolder(id);
    } catch {
      return res
        .status(409)
        .json({ error: "Cannot delete a folder that still contains files or child folders" });
    }
    res.sendStatus(204);
  }),
);

export default router;
