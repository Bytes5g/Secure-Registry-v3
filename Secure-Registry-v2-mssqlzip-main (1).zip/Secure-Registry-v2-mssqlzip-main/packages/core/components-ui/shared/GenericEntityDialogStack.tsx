import type { ReactNode } from "react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "../ui/dialog";
import { EntityDeleteDialog } from "./EntityDeleteDialog";

interface GenericEntityDialogStackProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  isEditing: boolean;
  titleCreate?: string;
  titleEdit?: string;
  descriptionCreate?: string;
  descriptionEdit?: string;
  deleteOpen: boolean;
  onDeleteOpenChange: (open: boolean) => void;
  onConfirmDelete: () => void;
  isDeleting: boolean;
  children: ReactNode;
}

export function GenericEntityDialogStack({
  open,
  onOpenChange,
  isEditing,
  titleCreate = "إضافة سجل جديد",
  titleEdit = "تعديل سجل",
  descriptionCreate = "قم بتعبئة البيانات التالية",
  descriptionEdit = "قم بتعديل البيانات أدناه",
  deleteOpen,
  onDeleteOpenChange,
  onConfirmDelete,
  isDeleting,
  children,
}: GenericEntityDialogStackProps) {
  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{isEditing ? titleEdit : titleCreate}</DialogTitle>
            <DialogDescription>
              {isEditing ? descriptionEdit : descriptionCreate}
            </DialogDescription>
          </DialogHeader>
          {children}
        </DialogContent>
      </Dialog>

      <EntityDeleteDialog
        open={deleteOpen}
        onOpenChange={onDeleteOpenChange}
        title="هل أنت متأكد؟"
        description="سيتم حذف هذا السجل نهائياً. لا يمكن التراجع عن هذا الإجراء."
        onConfirm={onConfirmDelete}
        isSubmitting={isDeleting}
      />
    </>
  );
}

