import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Building2, ChevronLeft, Loader2 } from "lucide-react";
import { Badge, Button } from "@secure-registry/components-ui";
import { fetchOrganizationChildren } from "@/lib/api/org-admin";

interface OrgSubEntitiesTabProps {
  orgId: number;
}

export function OrgSubEntitiesTab({ orgId }: OrgSubEntitiesTabProps) {
  const [, setLocation] = useLocation();

  const { data: children = [], isLoading } = useQuery({
    queryKey: ["org-entity-children", orgId],
    queryFn: () => fetchOrganizationChildren(orgId, { includeInactive: true }),
    enabled: Number.isFinite(orgId) && orgId > 0,
  });

  if (isLoading) {
    return (
      <div className="flex justify-center p-10">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (!children.length) {
    return (
      <div className="rounded-md border p-10 text-center text-muted-foreground">
        لا توجد جهات تابعة لهذه الجهة.
      </div>
    );
  }

  return (
    <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-3">
      {children.map((child: any) => (
        <button
          key={child.id}
          type="button"
          onClick={() => setLocation(`/config/org-entities/${child.id}`)}
          className="text-start rounded-lg border bg-card p-4 hover:border-primary hover:bg-accent/30 transition-colors group"
        >
          <div className="flex items-start justify-between gap-2">
            <div className="flex items-center gap-2 min-w-0">
              <div className="rounded-md bg-primary/10 text-primary p-2 shrink-0">
                <Building2 className="h-4 w-4" />
              </div>
              <div className="min-w-0">
                <div className="font-medium truncate">{child.name}</div>
                <div className="text-xs text-muted-foreground truncate">
                  {child.code || "—"}
                </div>
              </div>
            </div>
            <ChevronLeft className="h-4 w-4 text-muted-foreground group-hover:text-primary shrink-0" />
          </div>
          <div className="mt-3 flex items-center gap-2">
            <Badge variant={child.isActive ? "secondary" : "outline"} className="text-xs">
              {child.isActive ? "فعّالة" : "موقوفة"}
            </Badge>
            <span className="text-xs text-muted-foreground tabular-nums">#{child.id}</span>
          </div>
        </button>
      ))}
    </div>
  );
}
