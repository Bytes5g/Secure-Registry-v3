import { useMemo } from "react";
import { useLocation } from "wouter";
import { Button, DataTable, EntityContentCard, EntityProfileHeader, type Column } from "@secure-registry/components-ui";
import { Settings2 } from "lucide-react";
import { PAGE_CODE_PRESETS } from "./uiPageOverridesPresets";
import { useQuery } from "@tanstack/react-query";
import { genericApi } from "@/lib/api/generic";

type PageRow = {
  pageCode: string;
  label: string;
  entityType?: string | null;
  tabsCount?: number;
  columnsCount?: number;
  formFieldsCount?: number;
  dataSourcesCount?: number;
};

export default function UiPageOverridesIndexPage() {
  const [, setLocation] = useLocation();

  const registryQuery = useQuery({
    queryKey: ["ui-pages-registry"],
    queryFn: async () => genericApi.getUiPagesRegistry() as Promise<any[]>,
  });

  const rows = useMemo<PageRow[]>(() => {
    const fromApi = Array.isArray(registryQuery.data) ? registryQuery.data : null;
    if (fromApi && fromApi.length) {
      return fromApi.map((r: any) => ({
        pageCode: String(r.pageKey ?? r.page_code ?? r.pageCode ?? ""),
        label: String(r.pageNameAr ?? r.nameAr ?? r.labelAr ?? r.pageKey ?? ""),
        entityType: r.entityType == null ? null : String(r.entityType),
        tabsCount: r.tabsCount == null ? undefined : Number(r.tabsCount),
        columnsCount: r.columnsCount == null ? undefined : Number(r.columnsCount),
        formFieldsCount: r.formFieldsCount == null ? undefined : Number(r.formFieldsCount),
        dataSourcesCount: r.dataSourcesCount == null ? undefined : Number(r.dataSourcesCount),
      })).filter((x) => x.pageCode);
    }

    return PAGE_CODE_PRESETS
      .filter((p) => p.value !== "__custom__")
      .map((p) => ({
        pageCode: p.value,
        label: p.label,
        entityType: p.defaultEntityType ?? null,
      }));
  }, [registryQuery.data]);

  const columns = useMemo<Column<PageRow>[]>(
    () => [
      { key: "label", header: "اسم الصفحة", sortable: true },
      { key: "pageCode", header: "pageCode", sortable: true },
      { key: "entityType", header: "entityType", sortable: true },
      { key: "tabsCount", header: "تبويبات", sortable: true },
      { key: "columnsCount", header: "أعمدة", sortable: true },
      { key: "formFieldsCount", header: "حقول", sortable: true },
      { key: "dataSourcesCount", header: "مصادر بيانات", sortable: true },
      {
        key: "actions",
        header: "",
        render: (_: any, row?: PageRow) => {
          const pageCode = row?.pageCode;
          if (!pageCode) return null;
          return (
            <Button
              type="button"
              variant="outline"
              onClick={() => setLocation(`/config/ui-page-overrides/${encodeURIComponent(pageCode)}`)}
            >
              فتح
            </Button>
          );
        },
      },
    ],
    [setLocation],
  );

  return (
    <div className="p-6 space-y-4" dir="rtl">
      <EntityProfileHeader
        title="تهيئات الصفحات"
        subtitle="اختر صفحة ثم عدّل الأعمدة وحقول النموذج مع معاينة مباشرة"
        status={{ label: "Registry", variant: "secondary" }}
        icon={<Settings2 className="h-5 w-5" />}
        showCoverPlaceholder={false}
        coverImageUrl={null}
        avatarImageUrl={null}
      />

      <EntityContentCard contentClassName="p-6">
        <DataTable data={rows} columns={columns} searchable={true} className="text-start" isLoading={registryQuery.isLoading} />
      </EntityContentCard>
    </div>
  );
}
