import type { Router } from "express";
import { executeGetById, resolveIdCondition } from "@core/database";
import type { TableDescriptor } from "../types";
import { getTableInfo } from "../sql/table-info";

export function registerGetByIdHandler(router: Router, descriptor: TableDescriptor) {
  router.get("/:id", async (req, res) => {
    try {
      const tableInfo = await getTableInfo(descriptor);
      const { clause, params } = resolveIdCondition(req.params.id, tableInfo.columnMap);
      const row = await executeGetById({ tableInfo, clause, params });
      if (!row) return res.status(404).json({ error: "Not found" });
      res.json(row);
    } catch (e: any) {
      if (e.message.startsWith("Invalid ID") || e.message.startsWith("Table does not have")) {
        return res.status(400).json({ error: e.message });
      }
      console.error(`Error in GET /api/${descriptor.exportName}/${req.params.id}:`, e);
      res.status(500).json({ error: e.message });
    }
  });
}
