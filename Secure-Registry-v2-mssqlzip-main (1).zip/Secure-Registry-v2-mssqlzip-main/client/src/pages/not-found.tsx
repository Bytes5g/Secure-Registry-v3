import { Button, Card, CardContent } from "@secure-registry/components-ui";
import { AlertCircle, Home } from "lucide-react";
import { Link } from "wouter";

export default function NotFound() {
  return (
    <div className="flex items-center justify-center min-h-[60vh]">
      <Card className="w-full max-w-md mx-4 text-center">
        <CardContent className="pt-8 pb-8">
          <div className="flex flex-col items-center gap-4">
            <div className="flex h-16 w-16 items-center justify-center rounded-full bg-destructive/10">
              <AlertCircle className="h-8 w-8 text-destructive" />
            </div>
            <div className="space-y-2">
              <h1 className="text-3xl font-bold text-foreground">404</h1>
              <p className="text-lg text-muted-foreground">
                الصفحة غير موجودة
              </p>
            </div>
            <p className="text-sm text-muted-foreground max-w-xs">
              عذراً، الصفحة التي تبحث عنها غير موجودة أو تم نقلها.
            </p>
            <Button asChild className="mt-4 gap-2">
              <Link href="/">
                <Home className="h-4 w-4" />
                العودة للرئيسية
              </Link>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
