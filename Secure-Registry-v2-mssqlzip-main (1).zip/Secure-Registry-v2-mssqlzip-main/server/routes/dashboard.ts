import { Router } from "express";
import { getSystemDashboardStatistics } from "@core/database";

const router = Router();

router.get("/summary", async (_req, res) => {
  const rows = await getSystemDashboardStatistics();
  res.json({
    data: rows,
  });
});

export default router;
