import Page from "@/features/ui-registry/UiPageOverridesIndexPage";

export default Page;
