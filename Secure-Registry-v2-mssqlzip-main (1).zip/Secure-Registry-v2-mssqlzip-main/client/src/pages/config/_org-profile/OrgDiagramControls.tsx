import {
  Badge,
  Button,
  Input,
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
  Switch,
} from "@secure-registry/components-ui";
import type { DiagramScope } from "./useOrgDiagramData";

interface ToggleItem {
  label: string;
  checked: boolean;
  onChange: (v: boolean) => void;
  show?: boolean;
}

function ToggleRow({ items }: { items: ToggleItem[] }) {
  return (
    <div className="flex flex-wrap items-center gap-4">
      {items
        .filter((i) => i.show !== false)
        .map((i) => (
          <div key={i.label} className="flex items-center gap-2">
            <Switch checked={i.checked} onCheckedChange={i.onChange} />
            <span className="text-sm text-muted-foreground">{i.label}</span>
          </div>
        ))}
    </div>
  );
}

export interface OrgDiagramControlsProps {
  scope: DiagramScope;
  setScope: (v: DiagramScope) => void;
  selectedBranchValue: string;
  setSelectedBranchValue: (v: string) => void;
  selectedNodeId: number | null;
  setSelectedNodeId: (v: number | null) => void;
  nodeSearch: string;
  setNodeSearch: (v: string) => void;

  showBranchAssignments: boolean;
  setShowBranchAssignments: (v: boolean) => void;
  showOnlySelectedUnitChildren: boolean;
  setShowOnlySelectedUnitChildren: (v: boolean) => void;
  showUnitBranchesOnDiagram: boolean;
  setShowUnitBranchesOnDiagram: (v: boolean) => void;
  showOrgChartStaff: boolean;
  setShowOrgChartStaff: (v: boolean) => void;
  focusOnly: boolean;
  setFocusOnly: (v: boolean) => void;
  showMiniMap: boolean;
  setShowMiniMap: (v: boolean) => void;
  showBackground: boolean;
  setShowBackground: (v: boolean) => void;
  snapToGrid: boolean;
  setSnapToGrid: (v: boolean) => void;
  nodesDraggable: boolean;
  setNodesDraggable: (v: boolean) => void;
  showEdgeLabels: boolean;
  setShowEdgeLabels: (v: boolean) => void;
  colorEdges: boolean;
  setColorEdges: (v: boolean) => void;

  branchesForOrg: any[];
  filteredNodes: any[];
  effectiveBranchId: number | null;
  effectiveNodeId: number | null;
  selectedUnitId: number | null;
  totalNodeCount: number;
  assignedCount: number;
  branchHasNoExtensions: boolean;

  onFitView: () => void;
  onRelayout: () => void;
}

export function OrgDiagramControls(props: OrgDiagramControlsProps) {
  const {
    scope,
    setScope,
    selectedBranchValue,
    setSelectedBranchValue,
    selectedNodeId,
    setSelectedNodeId,
    nodeSearch,
    setNodeSearch,
    branchesForOrg,
    filteredNodes,
    effectiveBranchId,
    effectiveNodeId,
    selectedUnitId,
    totalNodeCount,
    assignedCount,
    branchHasNoExtensions,
    onFitView,
    onRelayout,
  } = props;

  const scopeLabel =
    scope === "org" ? "عرض كل الهيكل" : scope === "branch" ? "عرض امتدادات فرع" : "عرض وحدة (فروع/كادر)";
  const requiresUnitSelection = scope === "unit";

  return (
    <div className="flex flex-col gap-3">
      {/* Top row: view mode + selectors + actions */}
      <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
        <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:gap-3">
          <div className="min-w-[220px]">
            <Select value={scope} onValueChange={(v) => setScope(v as DiagramScope)}>
              <SelectTrigger dir="rtl">
                <SelectValue placeholder={scopeLabel} />
              </SelectTrigger>
              <SelectContent dir="rtl">
                <SelectItem value="org">عرض كل الهيكل</SelectItem>
                <SelectItem value="branch">عرض امتدادات فرع</SelectItem>
                <SelectItem value="unit">عرض وحدة (فروع/كادر)</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {scope === "branch" ? (
            <div className="min-w-[260px]">
              <Select
                value={selectedBranchValue}
                onValueChange={setSelectedBranchValue}
                disabled={branchesForOrg.length === 0}
              >
                <SelectTrigger dir="rtl">
                  <SelectValue placeholder="اختر فرعاً" />
                </SelectTrigger>
                <SelectContent dir="rtl">
                  <SelectItem value="none">بدون إبراز</SelectItem>
                  {branchesForOrg.map((b) => (
                    <SelectItem key={String(b.id)} value={String(b.id)}>
                      {String(b.name ?? b.nameAr ?? `فرع ${b.id}`)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          ) : null}

          <div className="min-w-[220px]">
            <Input
              value={nodeSearch}
              onChange={(e) => setNodeSearch(e.target.value)}
              placeholder={scope === "branch" ? "بحث عن وحدة للفلترة..." : "بحث عن وحدة..."}
            />
          </div>

          <div className="min-w-[260px]">
            <Select
              value={
                requiresUnitSelection
                  ? effectiveNodeId == null
                    ? "none"
                    : String(effectiveNodeId)
                  : selectedNodeId == null
                    ? "none"
                    : String(selectedNodeId)
              }
              onValueChange={(v) => setSelectedNodeId(v === "none" ? null : Number(v))}
              disabled={filteredNodes.length === 0}
            >
              <SelectTrigger dir="rtl">
                <SelectValue
                  placeholder={requiresUnitSelection ? "اختر وحدة" : "اختر وحدة (اختياري)"}
                />
              </SelectTrigger>
              <SelectContent dir="rtl">
                {!requiresUnitSelection ? <SelectItem value="none">بدون تحديد وحدة</SelectItem> : null}
                {filteredNodes.slice(0, 300).map((n) => (
                  <SelectItem key={String(n.id)} value={String(n.id)}>
                    {String(n.name ?? "")}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <Button variant="outline" onClick={onFitView}>
            توسيط الرسم
          </Button>
          <Button variant="outline" onClick={onRelayout}>
            إعادة تنظيم
          </Button>
          {scope === "branch" ? (
            <Badge variant={branchHasNoExtensions ? "destructive" : "secondary"}>
              {effectiveBranchId == null
                ? "بدون فرع"
                : branchHasNoExtensions
                  ? "لا توجد امتدادات لهذا الفرع"
                  : `امتدادات: ${assignedCount} / ${totalNodeCount}`}
            </Badge>
          ) : null}
        </div>
      </div>

      {/* Toggles */}
      <ToggleRow
        items={[
          {
            label: "إبراز امتدادات الفرع",
            checked: props.showBranchAssignments,
            onChange: props.setShowBranchAssignments,
            show: scope === "branch",
          },
          {
            label: "عرض أبناء الوحدة فقط",
            checked: props.showOnlySelectedUnitChildren,
            onChange: props.setShowOnlySelectedUnitChildren,
            show: selectedUnitId != null,
          },
          {
            label: "عرض فروع الوحدة على الرسم",
            checked: props.showUnitBranchesOnDiagram,
            onChange: props.setShowUnitBranchesOnDiagram,
            show: scope === "unit" && selectedUnitId != null,
          },
          {
            label: "عرض الكادر على الرسم",
            checked: props.showOrgChartStaff,
            onChange: props.setShowOrgChartStaff,
            show: scope === "unit" && selectedUnitId != null,
          },
          { label: "تركيز على المحدد", checked: props.focusOnly, onChange: props.setFocusOnly },
          { label: "خريطة مصغرة", checked: props.showMiniMap, onChange: props.setShowMiniMap },
          { label: "خلفية", checked: props.showBackground, onChange: props.setShowBackground },
          { label: "شبكة", checked: props.snapToGrid, onChange: props.setSnapToGrid },
          { label: "سحب العقد", checked: props.nodesDraggable, onChange: props.setNodesDraggable },
          { label: "تسميات العلاقات", checked: props.showEdgeLabels, onChange: props.setShowEdgeLabels },
          { label: "تلوين الخطوط", checked: props.colorEdges, onChange: props.setColorEdges },
        ]}
      />
    </div>
  );
}
