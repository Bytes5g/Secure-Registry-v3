import { useState, useCallback, useEffect } from "react";
import { ChevronDown, ChevronLeft, Folder, FolderOpen, Loader2 } from "lucide-react";
import { cn } from "../lib/utils";

export interface TreeNode {
  id: number;
  name: string;
  parentId: number | null;
  hasChildren?: boolean;
  childrenCount?: number;
}

interface TreeState {
  expandedNodes: Set<number>;
  loadedChildren: Record<number, TreeNode[]>;
  loadingNodes: Set<number>;
}

interface TreeNodeComponentProps {
  node: TreeNode;
  level: number;
  selectedNodeId: number | null;
  treeState: TreeState;
  onSelect: (node: TreeNode) => void;
  onToggle: (node: TreeNode) => void;
}

function TreeNodeComponent({
  node,
  level,
  selectedNodeId,
  treeState,
  onSelect,
  onToggle,
}: TreeNodeComponentProps) {
  const isExpanded = treeState.expandedNodes.has(node.id);
  const isLoading = treeState.loadingNodes.has(node.id);
  const children = treeState.loadedChildren[node.id] || [];
  const isSelected = selectedNodeId === node.id;
  const hasChildren = node.hasChildren || (node.childrenCount && node.childrenCount > 0) || children.length > 0;

  return (
    <div>
      <div
        className={cn(
          "flex items-center gap-1 py-1.5 px-2 rounded-md cursor-pointer transition-colors",
          "hover:bg-muted/50",
          isSelected && "bg-primary/10 text-primary font-medium"
        )}
        style={{ paddingInlineStart: `${level * 16 + 8}px` }}
        onClick={() => onSelect(node)}
        data-testid={`tree-node-${node.id}`}
      >
        {hasChildren ? (
          <button
            onClick={(e) => {
              e.stopPropagation();
              onToggle(node);
            }}
            className="p-0.5 hover:bg-muted rounded"
            data-testid={`tree-toggle-${node.id}`}
          >
            {isLoading ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : isExpanded ? (
              <ChevronDown className="h-4 w-4" />
            ) : (
              <ChevronLeft className="h-4 w-4" />
            )}
          </button>
        ) : (
          <span className="w-5" />
        )}
        {isExpanded ? (
          <FolderOpen className="h-4 w-4 text-muted-foreground" />
        ) : (
          <Folder className="h-4 w-4 text-muted-foreground" />
        )}
        <span className="flex-1 text-sm truncate">{node.name}</span>
        {node.childrenCount !== undefined && node.childrenCount > 0 && (
          <span className="text-xs text-muted-foreground bg-muted px-1.5 py-0.5 rounded">
            {node.childrenCount}
          </span>
        )}
      </div>
      {isExpanded && children.length > 0 && (
        <div>
          {children.map((child) => (
            <TreeNodeComponent
              key={child.id}
              node={child}
              level={level + 1}
              selectedNodeId={selectedNodeId}
              treeState={treeState}
              onSelect={onSelect}
              onToggle={onToggle}
            />
          ))}
        </div>
      )}
    </div>
  );
}

interface TreeNavigationProps {
  rootNodes: TreeNode[];
  selectedNodeId?: number | null;
  onSelectNode: (node: TreeNode | null) => void;
  loadChildren: (parentId: number, parentNode?: TreeNode) => Promise<TreeNode[]>;
  rootLabel?: string;
  className?: string;
  contentClassName?: string;
}

export function TreeNavigation({
  rootNodes,
  selectedNodeId = null,
  onSelectNode,
  loadChildren,
  rootLabel = "الجذر",
  className,
  contentClassName,
}: TreeNavigationProps) {
  const [treeState, setTreeState] = useState<TreeState>({
    expandedNodes: new Set(),
    loadedChildren: {},
    loadingNodes: new Set(),
  });

  const handleToggle = useCallback(async (node: TreeNode) => {
    const nodeId = node.id;
    const isCurrentlyExpanded = treeState.expandedNodes.has(nodeId);
    
    if (isCurrentlyExpanded) {
      setTreeState(prev => {
        const newExpanded = new Set(prev.expandedNodes);
        newExpanded.delete(nodeId);
        return { ...prev, expandedNodes: newExpanded };
      });
    } else {
      if (!treeState.loadedChildren[nodeId]) {
        setTreeState(prev => {
          const newLoading = new Set(prev.loadingNodes);
          newLoading.add(nodeId);
          return { ...prev, loadingNodes: newLoading };
        });

        try {
          const children = await loadChildren(nodeId, node);
          setTreeState(prev => {
            const newLoading = new Set(prev.loadingNodes);
            newLoading.delete(nodeId);
            const newExpanded = new Set(prev.expandedNodes);
            newExpanded.add(nodeId);
            return {
              ...prev,
              loadingNodes: newLoading,
              expandedNodes: newExpanded,
              loadedChildren: {
                ...prev.loadedChildren,
                [nodeId]: children,
              },
            };
          });
        } catch (error) {
          console.error("Failed to load children:", error);
          setTreeState(prev => {
            const newLoading = new Set(prev.loadingNodes);
            newLoading.delete(nodeId);
            return { ...prev, loadingNodes: newLoading };
          });
        }
      } else {
        setTreeState(prev => {
          const newExpanded = new Set(prev.expandedNodes);
          newExpanded.add(nodeId);
          return { ...prev, expandedNodes: newExpanded };
        });
      }
    }
  }, [treeState.expandedNodes, treeState.loadedChildren, loadChildren]);

  const handleSelect = useCallback((node: TreeNode) => {
    onSelectNode(node);
  }, [onSelectNode]);

  return (
    <div className={cn("border rounded-lg overflow-hidden", className)} dir="rtl">
      <div className="bg-muted/50 px-3 py-2 border-b">
        <button
          onClick={() => onSelectNode(null)}
          className={cn(
            "flex items-center gap-2 text-sm w-full",
            selectedNodeId === null && "text-primary font-medium"
          )}
          data-testid="tree-root"
        >
          <Folder className="h-4 w-4" />
          {rootLabel}
        </button>
      </div>
      <div className={cn("max-h-[500px] overflow-y-auto p-1", contentClassName)}>
        {rootNodes.map((node) => (
          <TreeNodeComponent
            key={node.id}
            node={node}
            level={0}
            selectedNodeId={selectedNodeId}
            treeState={treeState}
            onSelect={handleSelect}
            onToggle={handleToggle}
          />
        ))}
      </div>
    </div>
  );
}
