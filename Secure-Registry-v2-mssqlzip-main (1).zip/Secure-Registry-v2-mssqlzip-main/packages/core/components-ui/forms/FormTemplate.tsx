import { useForm, Controller } from "react-hook-form";
import { useEffect } from "react";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Textarea } from "../ui/textarea";
import { Switch } from "../ui/switch";
import { Label } from "../ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "../ui/dialog";
import { Loader2 } from "lucide-react";

export interface FormField {
  name: string;
  label: string;
  type: "text" | "textarea" | "number" | "switch" | "select";
  placeholder?: string;
  required?: boolean;
  options?: { value: string; label: string }[];
}

interface FormTemplateProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title: string;
  description?: string;
  fields: FormField[];
  defaultValues?: Record<string, any>;
  onSubmit: (data: Record<string, any>) => Promise<void>;
  isLoading?: boolean;
  submitLabel?: string;
}

export function FormTemplate({
  open,
  onOpenChange,
  title,
  description,
  fields,
  defaultValues = {},
  onSubmit,
  isLoading = false,
  submitLabel = "حفظ",
}: FormTemplateProps) {
  const schema = z.object(
    fields.reduce((acc, field) => {
      let validator: z.ZodTypeAny = z.any();
      if (field.type === "text" || field.type === "textarea") {
        validator = field.required ? z.string().min(1, "مطلوب") : z.string().optional();
      } else if (field.type === "number") {
        validator = field.required ? z.number() : z.number().optional();
      } else if (field.type === "switch") {
        validator = z.boolean().optional();
      } else if (field.type === "select") {
        validator = field.required 
          ? z.string().min(1, "مطلوب").or(z.number()) 
          : z.string().optional().or(z.number().optional());
      }
      acc[field.name] = validator;
      return acc;
    }, {} as Record<string, z.ZodTypeAny>)
  );

  const form = useForm({
    resolver: zodResolver(schema),
    defaultValues,
  });

  useEffect(() => {
    if (open) {
      form.reset(defaultValues);
    }
  }, [open, defaultValues]);

  const handleSubmit = async (data: Record<string, any>) => {
    await onSubmit(data);
    form.reset();
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
          {description && <DialogDescription>{description}</DialogDescription>}
        </DialogHeader>
        
        <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
          {fields.map((field) => (
            <div key={field.name} className="space-y-2">
              <Label htmlFor={field.name}>
                {field.label}
                {field.required && <span className="text-destructive ms-1">*</span>}
              </Label>
              
              {field.type === "text" && (
                <Input
                  id={field.name}
                  placeholder={field.placeholder}
                  {...form.register(field.name)}
                  data-testid={`input-${field.name}`}
                />
              )}
              
              {field.type === "textarea" && (
                <Textarea
                  id={field.name}
                  placeholder={field.placeholder}
                  {...form.register(field.name)}
                  data-testid={`textarea-${field.name}`}
                />
              )}
              
              {field.type === "number" && (
                <Input
                  id={field.name}
                  type="number"
                  placeholder={field.placeholder}
                  {...form.register(field.name, { valueAsNumber: true })}
                  data-testid={`input-${field.name}`}
                />
              )}
              
          {field.type === "switch" && (
            <div className="flex items-center gap-2">
              <Switch
                id={field.name}
                checked={form.watch(field.name)}
                onCheckedChange={(checked) => form.setValue(field.name, checked)}
                data-testid={`switch-${field.name}`}
              />
            </div>
          )}

          {field.type === "select" && (
            <Controller
              name={field.name}
              control={form.control}
              render={({ field: ctl }) => (
                <Select
                  value={ctl.value?.toString() || ""}
                  onValueChange={(value) => {
                    const num = parseInt(value);
                    ctl.onChange(isNaN(num) ? value : num);
                  }}
                >
                  <SelectTrigger id={field.name} data-testid={`select-${field.name}`}>
                    <SelectValue placeholder={field.placeholder || "اختر..."} />
                  </SelectTrigger>
                  <SelectContent>
                    {(field.options || []).map((opt) => (
                      <SelectItem key={opt.value} value={opt.value}>
                        {opt.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              )}
            />
          )}
              
              {form.formState.errors[field.name] && (
                <p className="text-sm text-destructive">
                  {form.formState.errors[field.name]?.message as string}
                </p>
              )}
            </div>
          ))}
          
          <DialogFooter className="gap-2 pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)} data-testid="button-cancel">
              إلغاء
            </Button>
            <Button type="submit" disabled={isLoading} data-testid="button-submit">
              {isLoading && <Loader2 className="h-4 w-4 me-2 animate-spin" />}
              {submitLabel}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
