import type { SqlExecutor } from "../config/connection";
import { deleteRow, insertRow, pickDefined, runQuery, runQueryOne, updateRow } from "./helpers";

export interface FileRecord {
  id: number;
  storage: string;
  filenameDisk: string | null;
  filenameDownload: string;
  title: string | null;
  type: string | null;
  folder: number | null;
  uploadedBy: number | null;
  createdOn: string | null;
  modifiedBy: number | null;
  modifiedOn: string | null;
  charset: string | null;
  filesize: number | null;
  width: number | null;
  height: number | null;
  duration: number | null;
  embed: string | null;
  description: string | null;
  location: string | null;
  tags: string | null;
  metadata: string | null;
  focalPointX: number | null;
  focalPointY: number | null;
  tusId: string | null;
  tusData: string | null;
  uploadedOn: string | null;
  workContextBy?: number | null;
  createdBy?: number | null;
  createdAt?: string | null;
  updatedAt?: string | null;
  updatedBy?: number | null;
  isActive?: boolean | null;
  isDeleted?: boolean | null;
}

export type FileCreatePayload = Omit<FileRecord, "id" | "createdOn" | "modifiedOn"> & {
  createdOn?: string | null;
  modifiedOn?: string | null;
};

export type FileUpdatePayload = Partial<FileCreatePayload>;

function asString(value: unknown): string | null {
  return value == null ? null : String(value);
}

function asNumber(value: unknown): number | null {
  if (value == null) return null;
  const n = Number(value);
  return Number.isFinite(n) ? n : null;
}

function mapFile(row: Record<string, unknown>): FileRecord {
  return {
    id: Number(row.id),
    storage: String(row.storage || ""),
    filenameDisk: asString(row.filename_disk),
    filenameDownload: String(row.filename_download || ""),
    title: asString(row.title),
    type: asString(row.type),
    folder: asNumber(row.folder),
    uploadedBy: asNumber(row.uploaded_by),
    createdOn: asString(row.created_on),
    modifiedBy: asNumber(row.modified_by),
    modifiedOn: asString(row.modified_on),
    charset: asString(row.charset),
    filesize: asNumber(row.filesize),
    width: asNumber(row.width),
    height: asNumber(row.height),
    duration: asNumber(row.duration),
    embed: asString(row.embed),
    description: asString(row.description),
    location: asString(row.location),
    tags: asString(row.tags),
    metadata: asString(row.metadata),
    focalPointX: asNumber(row.focal_point_x),
    focalPointY: asNumber(row.focal_point_y),
    tusId: asString(row.tus_id),
    tusData: asString(row.tus_data),
    uploadedOn: asString(row.uploaded_on),
    workContextBy: asNumber(row.work_context_by),
    createdBy: asNumber(row.created_by),
    createdAt: asString(row.created_at),
    updatedAt: asString(row.updated_at),
    updatedBy: asNumber(row.updated_by),
    isActive: row.is_active == null ? null : Boolean(row.is_active),
    isDeleted: row.is_deleted == null ? null : Boolean(row.is_deleted),
  };
}

function buildFileRow(payload: FileCreatePayload | FileUpdatePayload): Record<string, unknown> {
  return pickDefined({
    storage: payload.storage,
    filename_disk: payload.filenameDisk,
    filename_download: payload.filenameDownload,
    title: payload.title,
    type: payload.type,
    folder: payload.folder,
    uploaded_by: payload.uploadedBy,
    created_on: payload.createdOn,
    modified_by: payload.modifiedBy,
    modified_on: payload.modifiedOn,
    charset: payload.charset,
    filesize: payload.filesize,
    width: payload.width,
    height: payload.height,
    duration: payload.duration,
    embed: payload.embed,
    description: payload.description,
    location: payload.location,
    tags: payload.tags,
    metadata: payload.metadata,
    focal_point_x: payload.focalPointX,
    focal_point_y: payload.focalPointY,
    tus_id: payload.tusId,
    tus_data: payload.tusData,
    uploaded_on: payload.uploadedOn,
    work_context_by: payload.workContextBy,
    created_by: payload.createdBy,
    updated_at: payload.updatedAt,
    updated_by: payload.updatedBy,
    is_active: payload.isActive,
    is_deleted: payload.isDeleted,
  });
}

export class FilesModule {
  async getFile(id: number): Promise<FileRecord | undefined> {
    const row = await runQueryOne<Record<string, unknown>>("SELECT TOP 1 * FROM dbo.files WHERE id = @id", { id });
    return row ? mapFile(row) : undefined;
  }

  async getFiles(
    filters: { search?: string; folder?: number | null; uploadedBy?: number; limit?: number } = {},
  ): Promise<FileRecord[]> {
    const clauses: string[] = [];
    const params: Record<string, unknown> = {};

    if (filters.folder === null) {
      clauses.push("folder IS NULL");
    } else if (filters.folder != null) {
      clauses.push("folder = @folder");
      params.folder = filters.folder;
    }

    if (filters.uploadedBy != null) {
      clauses.push("uploaded_by = @uploadedBy");
      params.uploadedBy = filters.uploadedBy;
    }

    if (filters.search) {
      clauses.push("(title LIKE @q OR filename_download LIKE @q)");
      params.q = `%${filters.search}%`;
    }

    const where = clauses.length ? `WHERE ${clauses.join(" AND ")}` : "";
    const top = filters.limit != null ? `TOP ${Math.min(filters.limit, 500)}` : "";
    const rows = await runQuery<Record<string, unknown>>(
      `SELECT ${top} * FROM dbo.files ${where} ORDER BY id DESC`,
      params,
    );
    return rows.map(mapFile);
  }

  async createFile(payload: FileCreatePayload, executor?: SqlExecutor): Promise<FileRecord> {
    const nextIdRow = await runQueryOne<{ id: number }>(
      "SELECT ISNULL(MAX(id), 0) + 1 AS id FROM dbo.files WITH (UPDLOCK, HOLDLOCK)",
      {},
      executor,
    );
    const id = Number(nextIdRow?.id);
    if (!Number.isFinite(id) || id <= 0) {
      throw new Error("Failed to generate files.id");
    }

    const row = await insertRow<Record<string, unknown>>("files", { id, ...buildFileRow(payload) }, executor);
    return mapFile(row);
  }

  async updateFile(id: number, payload: FileUpdatePayload, executor?: SqlExecutor): Promise<FileRecord | undefined> {
    const row = await updateRow<Record<string, unknown>>("files", id, buildFileRow(payload), executor);
    return row ? mapFile(row) : undefined;
  }

  async deleteFile(id: number, executor?: SqlExecutor): Promise<boolean> {
    return deleteRow("files", id, executor);
  }
}

export const filesModule = new FilesModule();
