import type { useToast } from "@/hooks/use-toast";
import type {
  InsertLookupType,
  InsertLookupTypeAlias,
  InsertLookupValue,
  InsertLookupVirtualValue,
  LookupType,
} from "@shared/schema";

export type EditMode = "create" | "edit";
export type ToastFn = ReturnType<typeof useToast>["toast"];

export interface MutationFeedbackOptions<TResult> {
  invalidate: () => Promise<void>;
  toast: ToastFn;
  successTitle: string;
  successDescription?: string;
  errorTitle: string;
  onSuccess?: (result: TResult) => void;
}

export function createMutationFeedbackHandlers<TResult>({
  invalidate,
  toast,
  successTitle,
  successDescription,
  errorTitle,
  onSuccess,
}: MutationFeedbackOptions<TResult>) {
  return {
    onSuccess: async (result: TResult) => {
      await invalidate();
      onSuccess?.(result);
      toast({ title: successTitle, description: successDescription });
    },
    onError: (error: Error) => {
      toast({ title: errorTitle, description: error.message, variant: "destructive" });
    },
  };
}

export function openCreateDialog<TForm, TRecord>({
  setEditing,
  setForm,
  createEmptyForm,
  setOpen,
}: {
  setEditing: (record: TRecord | null) => void;
  setForm: (form: TForm) => void;
  createEmptyForm: () => TForm;
  setOpen: (open: boolean) => void;
}) {
  setEditing(null);
  setForm(createEmptyForm());
  setOpen(true);
}

export function openEditDialog<TForm, TRecord>({
  record,
  setEditing,
  setForm,
  mapRecordToForm,
  setOpen,
}: {
  record: TRecord;
  setEditing: (record: TRecord | null) => void;
  setForm: (form: TForm) => void;
  mapRecordToForm: (record: TRecord) => TForm;
  setOpen: (open: boolean) => void;
}) {
  setEditing(record);
  setForm(mapRecordToForm(record));
  setOpen(true);
}

export function showValidationError(toast: ToastFn, message: string) {
  toast({ title: "بيانات ناقصة", description: message, variant: "destructive" });
}

interface NestedSubmitOptions<TRecord, TPayload> {
  selectedType: LookupType | null;
  form: TPayload;
  editingRecord: TRecord | null;
  mapPayload: (typeId: number, form: TPayload) => any;
  validate: (payload: any) => string | null;
  create: (payload: any) => void;
  update: (record: TRecord, payload: any) => void;
  toast: ToastFn;
}

export function submitNestedEntity<TRecord extends { id: number }, TForm>({
  selectedType,
  form,
  editingRecord,
  mapPayload,
  validate,
  create,
  update,
  toast,
}: NestedSubmitOptions<TRecord, TForm>) {
  if (!selectedType) return;
  const payload = mapPayload(selectedType.id, form);
  const validationMessage = validate(payload);
  if (validationMessage) {
    showValidationError(toast, validationMessage);
    return;
  }
  if (editingRecord) {
    update(editingRecord, payload);
    return;
  }
  create(payload);
}

export function ensureRequiredLookupFields(payload: InsertLookupType): string | null {
  if (!payload.code || !payload.nameAr) return "الكود والاسم العربي حقول مطلوبة.";
  return null;
}

export function ensureRequiredAliasFields(payload: InsertLookupTypeAlias): string | null {
  if (!payload.aliasCode) return "الاسم البديل مطلوب.";
  return null;
}

export function ensureRequiredValueFields(payload: InsertLookupValue): string | null {
  if (!payload.code || !payload.nameAr) return "الكود والاسم العربي مطلوبان.";
  return null;
}

export function ensureRequiredVirtualSeedFields(
  payload: InsertLookupVirtualValue,
): string | null {
  if (!payload.valueId || !payload.code || !payload.nameAr) {
    return "معرف القيمة والكود والاسم العربي مطلوبة.";
  }
  return null;
}

export interface SharedDeps {
  toast: ToastFn;
  invalidateAll: () => Promise<void>;
}
