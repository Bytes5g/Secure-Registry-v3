import type { SqlExecutor } from "../config/connection";
import { deleteRow, insertRow, runQuery, runQueryOne } from "./helpers";
import type { FileRecord } from "./files";

export interface EntityFileLinkRecord {
  id: number;
  entityType: string;
  entityId: number;
  role: string;
  fileId: number;
  isPrimary: boolean;
  createdAt: string | null;
}

export type EntityFileWriteContext = {
  workContextBy: number;
  createdBy: number;
};

function asText(value: unknown): string | null {
  return value == null ? null : String(value);
}

function mapEntityFileLink(row: Record<string, unknown>): EntityFileLinkRecord {
  return {
    id: Number(row.id),
    entityType: String(row.entity_type || ""),
    entityId: Number(row.entity_id),
    role: String(row.role || ""),
    fileId: Number(row.file_id),
    isPrimary: Boolean(row.is_primary),
    createdAt: asText(row.created_at),
  };
}

type LinkedFileRow = Record<string, unknown>;

function mapFileFromJoinedRow(row: LinkedFileRow): FileRecord {
  return {
    id: Number(row.file_id),
    storage: String(row.file_storage || ""),
    filenameDisk: asText(row.file_filename_disk),
    filenameDownload: String(row.file_filename_download || ""),
    title: asText(row.file_title),
    type: asText(row.file_type),
    folder: row.file_folder == null ? null : Number(row.file_folder),
    uploadedBy: row.file_uploaded_by == null ? null : Number(row.file_uploaded_by),
    createdOn: asText(row.file_created_on),
    modifiedBy: row.file_modified_by == null ? null : Number(row.file_modified_by),
    modifiedOn: asText(row.file_modified_on),
    charset: asText(row.file_charset),
    filesize: row.file_filesize == null ? null : Number(row.file_filesize),
    width: row.file_width == null ? null : Number(row.file_width),
    height: row.file_height == null ? null : Number(row.file_height),
    duration: row.file_duration == null ? null : Number(row.file_duration),
    embed: asText(row.file_embed),
    description: asText(row.file_description),
    location: asText(row.file_location),
    tags: asText(row.file_tags),
    metadata: asText(row.file_metadata),
    focalPointX: row.file_focal_point_x == null ? null : Number(row.file_focal_point_x),
    focalPointY: row.file_focal_point_y == null ? null : Number(row.file_focal_point_y),
    tusId: asText(row.file_tus_id),
    tusData: asText(row.file_tus_data),
    uploadedOn: asText(row.file_uploaded_on),
  };
}

export class EntityFilesModule {
  async getPrimaryLinkedFile(entityType: string, entityId: number, role: string): Promise<{ link: EntityFileLinkRecord; file: FileRecord } | undefined> {
    const row = await runQueryOne<Record<string, unknown>>(
      `SELECT TOP 1
        ef.*,
        f.id AS file_id,
        f.storage AS file_storage,
        f.filename_disk AS file_filename_disk,
        f.filename_download AS file_filename_download,
        f.title AS file_title,
        f.type AS file_type,
        f.folder AS file_folder,
        f.uploaded_by AS file_uploaded_by,
        f.created_on AS file_created_on,
        f.modified_by AS file_modified_by,
        f.modified_on AS file_modified_on,
        f.charset AS file_charset,
        f.filesize AS file_filesize,
        f.width AS file_width,
        f.height AS file_height,
        f.duration AS file_duration,
        f.embed AS file_embed,
        f.description AS file_description,
        f.location AS file_location,
        f.tags AS file_tags,
        f.metadata AS file_metadata,
        f.focal_point_x AS file_focal_point_x,
        f.focal_point_y AS file_focal_point_y,
        f.tus_id AS file_tus_id,
        f.tus_data AS file_tus_data,
        f.uploaded_on AS file_uploaded_on
      FROM dbo.entity_files ef
      INNER JOIN dbo.files f ON f.id = ef.file_id
      WHERE ef.entity_type = @entityType AND ef.entity_id = @entityId AND ef.role = @role AND ef.is_primary = 1
      ORDER BY ef.created_at DESC, ef.id DESC`,
      { entityType, entityId, role },
    );
    if (!row) return undefined;

    return {
      link: mapEntityFileLink(row),
      file: mapFileFromJoinedRow(row),
    };
  }

  async getLinkedFiles(entityType: string, entityId: number, role?: string): Promise<Array<{ link: EntityFileLinkRecord; file: FileRecord }>> {
    const clauses = ["ef.entity_type = @entityType", "ef.entity_id = @entityId"];
    const params: Record<string, unknown> = { entityType, entityId };
    if (role) {
      clauses.push("ef.role = @role");
      params.role = role;
    }

    const rows = await runQuery<Record<string, unknown>>(
      `SELECT
        ef.*,
        f.id AS file_id,
        f.storage AS file_storage,
        f.filename_disk AS file_filename_disk,
        f.filename_download AS file_filename_download,
        f.title AS file_title,
        f.type AS file_type,
        f.folder AS file_folder,
        f.uploaded_by AS file_uploaded_by,
        f.created_on AS file_created_on,
        f.modified_by AS file_modified_by,
        f.modified_on AS file_modified_on,
        f.charset AS file_charset,
        f.filesize AS file_filesize,
        f.width AS file_width,
        f.height AS file_height,
        f.duration AS file_duration,
        f.embed AS file_embed,
        f.description AS file_description,
        f.location AS file_location,
        f.tags AS file_tags,
        f.metadata AS file_metadata,
        f.focal_point_x AS file_focal_point_x,
        f.focal_point_y AS file_focal_point_y,
        f.tus_id AS file_tus_id,
        f.tus_data AS file_tus_data,
        f.uploaded_on AS file_uploaded_on
      FROM dbo.entity_files ef
      INNER JOIN dbo.files f ON f.id = ef.file_id
      WHERE ${clauses.join(" AND ")}
      ORDER BY ef.is_primary DESC, ef.created_at DESC, ef.id DESC`,
      params,
    );

    return rows.map((row) => ({
      link: mapEntityFileLink(row),
      file: mapFileFromJoinedRow(row),
    }));
  }

  async clearPrimary(entityType: string, entityId: number, role: string, executor?: SqlExecutor): Promise<void> {
    await runQuery(
      "UPDATE dbo.entity_files SET is_primary = 0 WHERE entity_type = @entityType AND entity_id = @entityId AND role = @role AND is_primary = 1",
      { entityType, entityId, role },
      executor,
    );
  }

  async linkFile(payload: { entityType: string; entityId: number; role: string; fileId: number; isPrimary?: boolean; createdAt?: string | null }, executor?: SqlExecutor): Promise<EntityFileLinkRecord> {
    if (payload.isPrimary) {
      await this.clearPrimary(payload.entityType, payload.entityId, payload.role, executor);
    }

    const row = await insertRow<Record<string, unknown>>(
      { schemaName: "dbo", tableName: "entity_files" },
      {
        entity_type: payload.entityType,
        entity_id: payload.entityId,
        role: payload.role,
        file_id: payload.fileId,
        is_primary: payload.isPrimary ?? false,
        created_at: payload.createdAt ?? undefined,
      },
      executor,
    );

    return mapEntityFileLink(row);
  }

  async linkFileWithContext(
    payload: { entityType: string; entityId: number; role: string; fileId: number; isPrimary?: boolean; createdAt?: string | null },
    ctx: EntityFileWriteContext,
    executor?: SqlExecutor,
  ): Promise<EntityFileLinkRecord> {
    if (payload.isPrimary) {
      await this.clearPrimary(payload.entityType, payload.entityId, payload.role, executor);
    }

    const row = await insertRow<Record<string, unknown>>(
      { schemaName: "dbo", tableName: "entity_files" },
      {
        entity_type: payload.entityType,
        entity_id: payload.entityId,
        role: payload.role,
        file_id: payload.fileId,
        is_primary: payload.isPrimary ?? false,
        created_at: payload.createdAt ?? undefined,
        work_context_by: ctx.workContextBy,
        created_by: ctx.createdBy,
        is_active: true,
        is_deleted: false,
      },
      executor,
    );

    return mapEntityFileLink(row);
  }

  async deleteLink(id: number, executor?: SqlExecutor): Promise<boolean> {
    return deleteRow({ schemaName: "dbo", tableName: "entity_files" }, id, executor);
  }
}

export const entityFilesModule = new EntityFilesModule();
