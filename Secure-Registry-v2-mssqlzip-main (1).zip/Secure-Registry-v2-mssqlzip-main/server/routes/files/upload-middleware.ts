import fs from "fs";
import path from "path";
import multer from "multer";
import { getLocalStorage } from "../../files/storage";

const localStorage = getLocalStorage();
const tempRelativeDirectory = "_tmp/files";
export const tempUploadDirectory = localStorage.resolveAbsolutePath(tempRelativeDirectory);

if (!fs.existsSync(tempUploadDirectory)) {
  fs.mkdirSync(tempUploadDirectory, { recursive: true });
}

export function createUpload(maxFileSizeBytes: number) {
  return multer({
    storage: multer.diskStorage({
      destination: (_req, _file, cb) => cb(null, tempUploadDirectory),
      filename: (_req, file, cb) => {
        const uniqueSuffix = `${Date.now()}-${Math.round(Math.random() * 1e9)}`;
        cb(null, `${uniqueSuffix}${path.extname(file.originalname)}`);
      },
    }),
    limits: { fileSize: maxFileSizeBytes },
  });
}
