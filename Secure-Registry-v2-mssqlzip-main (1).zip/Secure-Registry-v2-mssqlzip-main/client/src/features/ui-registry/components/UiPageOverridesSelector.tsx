import {
  Button,
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  Input,
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@secure-registry/components-ui";
import { ENTITY_TYPE_PRESETS, PAGE_CODE_PRESETS } from "../uiPageOverridesPresets";

export function UiPageOverridesSelector({
  pageCode,
  setPageCode,
  entityType,
  setEntityType,
  canLoad,
  isBusy,
  onLoadAll,
  onLoadOverrideOnly,
  onResetToBase,
  onSave,
  onClear,
  hasBaseConfig,
  isValid,
  validationErrors,
  showActions = true,
}: {
  pageCode: string;
  setPageCode: (v: string) => void;
  entityType: string;
  setEntityType: (v: string) => void;
  canLoad: boolean;
  isBusy: boolean;
  onLoadAll: () => void;
  onLoadOverrideOnly: () => void;
  onResetToBase: () => void;
  onSave: () => void;
  onClear: () => void;
  hasBaseConfig: boolean;
  isValid: boolean;
  validationErrors: string[];
  showActions?: boolean;
}) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>الاختيار والتحميل</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4" dir="rtl">
        {!isValid && (validationErrors?.length ?? 0) > 0 ? (
          <div className="text-sm text-destructive">{validationErrors.join(" | ")}</div>
        ) : null}
        <div className="grid gap-3 md:grid-cols-2">
          <div className="space-y-2">
            <div className="text-sm text-muted-foreground">الصفحة</div>
            <Select
              value={PAGE_CODE_PRESETS.some((p) => p.value === pageCode) ? pageCode : "__custom__"}
              onValueChange={(v) => {
                if (v === "__custom__") {
                  setPageCode("");
                  return;
                }
                setPageCode(v);
                const preset = PAGE_CODE_PRESETS.find((p) => p.value === v);
                if (preset?.defaultEntityType) setEntityType(preset.defaultEntityType);
              }}
            >
              <SelectTrigger>
                <SelectValue placeholder="اختر..." />
              </SelectTrigger>
              <SelectContent>
                {PAGE_CODE_PRESETS.map((p) => (
                  <SelectItem key={p.value} value={p.value}>
                    {p.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {!PAGE_CODE_PRESETS.some((p) => p.value === pageCode) ? (
              <Input value={pageCode} onChange={(e) => setPageCode(e.target.value)} placeholder="pageCode" />
            ) : null}
          </div>

          <div className="space-y-2">
            <div className="text-sm text-muted-foreground">نوع الكيان</div>
            <Select
              value={ENTITY_TYPE_PRESETS.some((p) => p.value === entityType) ? entityType : "__custom__"}
              onValueChange={(v) => {
                if (v === "__custom__") {
                  setEntityType("");
                  return;
                }
                setEntityType(v);
              }}
            >
              <SelectTrigger>
                <SelectValue placeholder="اختر..." />
              </SelectTrigger>
              <SelectContent>
                {ENTITY_TYPE_PRESETS.map((p) => (
                  <SelectItem key={p.value} value={p.value}>
                    {p.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {!ENTITY_TYPE_PRESETS.some((p) => p.value === entityType) ? (
              <Input value={entityType} onChange={(e) => setEntityType(e.target.value)} placeholder="entityType" />
            ) : null}
          </div>
        </div>

        {showActions ? (
          <div className="flex flex-wrap gap-2">
            <Button type="button" onClick={onLoadAll} disabled={!canLoad || isBusy}>
              تحميل
            </Button>
            <Button type="button" variant="outline" onClick={onLoadOverrideOnly} disabled={!canLoad || isBusy}>
              تحميل override فقط
            </Button>
            <Button type="button" variant="outline" onClick={onResetToBase} disabled={!canLoad || !hasBaseConfig || isBusy}>
              إعادة ضبط للأساس
            </Button>
            <Button type="button" onClick={onSave} disabled={!canLoad || !hasBaseConfig || isBusy || !isValid}>
              حفظ override
            </Button>
            <Button type="button" variant="destructive" onClick={onClear} disabled={!canLoad || isBusy}>
              حذف override
            </Button>
          </div>
        ) : null}
      </CardContent>
    </Card>
  );
}
