import { useEffect, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiClient } from "@/lib/api/client";
import {
  DEFAULT_ALLOWED_MIME_TYPES,
  DEFAULT_MAX_FILE_SIZE_MB,
  DEFAULT_RELATIVE_DIRECTORY,
} from "./config";
import { toMimeList } from "./utils";
import type {
  BrowseFolder,
  BrowseResponse,
  FileUploadSettingsResponse,
  SettingsFormState,
  UploadFormState,
} from "./types";

export function useFilesPage() {
  const queryClient = useQueryClient();

  const [form, setForm] = useState<UploadFormState>({
    title: "",
    description: "",
    tags: "",
    folder: "",
    file: null,
  });
  const [currentFolder, setCurrentFolder] = useState<number | null>(null);
  const [newFolderName, setNewFolderName] = useState("");

  const settingsQuery = useQuery({
    queryKey: ["files-upload-settings"],
    queryFn: async () => apiClient.get<FileUploadSettingsResponse>("/api/files/settings"),
  });

  const browseQuery = useQuery({
    queryKey: ["files-browse", currentFolder],
    queryFn: async () => {
      const folderParam = currentFolder == null ? "null" : String(currentFolder);
      return apiClient.get<BrowseResponse>(
        `/api/files/browse?folder=${encodeURIComponent(folderParam)}`,
      );
    },
  });

  const [settingsForm, setSettingsForm] = useState<SettingsFormState>({
    relativeDirectory: DEFAULT_RELATIVE_DIRECTORY,
    maxFileSizeMB: String(DEFAULT_MAX_FILE_SIZE_MB),
    defaultFolderId: "",
    allowedMimeTypesText: DEFAULT_ALLOWED_MIME_TYPES.join("\n"),
  });

  useEffect(() => {
    const settings = settingsQuery.data?.data;
    if (!settings) return;
    setSettingsForm({
      relativeDirectory: settings.relativeDirectory ?? DEFAULT_RELATIVE_DIRECTORY,
      maxFileSizeMB: String(settings.maxFileSizeMB ?? DEFAULT_MAX_FILE_SIZE_MB),
      defaultFolderId: settings.defaultFolderId != null ? String(settings.defaultFolderId) : "",
      allowedMimeTypesText: (settings.allowedMimeTypes ?? []).join("\n"),
    });
  }, [settingsQuery.data]);

  const saveSettingsMutation = useMutation({
    mutationFn: async () => {
      const maxFileSizeMB = Number(settingsForm.maxFileSizeMB);
      const payload = {
        relativeDirectory: settingsForm.relativeDirectory,
        maxFileSizeMB: Number.isFinite(maxFileSizeMB) ? Math.trunc(maxFileSizeMB) : undefined,
        defaultFolderId: settingsForm.defaultFolderId
          ? Number(settingsForm.defaultFolderId)
          : null,
        allowedMimeTypes: toMimeList(settingsForm.allowedMimeTypesText),
      };
      return apiClient.put<FileUploadSettingsResponse>("/api/files/settings", payload);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["files-upload-settings"] });
    },
  });

  const uploadMutation = useMutation({
    mutationFn: async (args?: { folderId?: number | null }) => {
      if (!form.file) throw new Error("يرجى اختيار ملف");

      const defaultFolderId = settingsQuery.data?.data.defaultFolderId ?? null;
      const folderId =
        args?.folderId !== undefined
          ? args.folderId
          : form.folder
            ? Number(form.folder)
            : defaultFolderId;

      const body = new FormData();
      body.append("file", form.file);
      if (form.title) body.append("title", form.title);
      if (form.description) body.append("description", form.description);
      if (form.tags) body.append("tags", form.tags);
      if (folderId != null) body.append("folder", String(folderId));

      const res = await fetch("/api/files/upload", {
        method: "POST",
        body,
        credentials: "include",
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err?.error?.message || err?.error || "فشل رفع الملف");
      }
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["files"] });
      queryClient.invalidateQueries({ queryKey: ["files-browse"] });
      setForm({ title: "", description: "", tags: "", folder: "", file: null });
    },
  });

  const createFolderMutation = useMutation({
    mutationFn: async () => {
      const name = newFolderName.trim();
      if (!name) throw new Error("يرجى إدخال اسم المجلد");
      return apiClient.post<BrowseFolder>("/api/files/folders", {
        name,
        parent: currentFolder,
      });
    },
    onSuccess: () => {
      setNewFolderName("");
      queryClient.invalidateQueries({ queryKey: ["files-browse"] });
    },
  });

  const renameFolderMutation = useMutation({
    mutationFn: async (args: { id: number; name: string }) =>
      apiClient.put<BrowseFolder>(`/api/files/folders/${args.id}`, { name: args.name }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["files-browse"] });
    },
  });

  const deleteFolderMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiClient.delete(`/api/files/folders/${id}`);
      return id;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["files-browse"] });
    },
  });

  const deleteFileMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiClient.delete(`/api/files/${id}`);
      return id;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["files"] });
      queryClient.invalidateQueries({ queryKey: ["files-browse"] });
    },
  });

  return {
    form,
    setForm,
    currentFolder,
    setCurrentFolder,
    newFolderName,
    setNewFolderName,
    settingsForm,
    setSettingsForm,
    settingsQuery,
    browseQuery,
    saveSettingsMutation,
    uploadMutation,
    createFolderMutation,
    renameFolderMutation,
    deleteFolderMutation,
    deleteFileMutation,
  };
}

export type FilesPageController = ReturnType<typeof useFilesPage>;
