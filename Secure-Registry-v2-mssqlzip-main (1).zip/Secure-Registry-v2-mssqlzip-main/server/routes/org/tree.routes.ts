import { Router, type Request, type Response } from "express";
import { z } from "zod";
import { insertOrgStructureTreeSchema } from "@shared/schema";
import { storage } from "../../storage";
import { normalizeInputTypes, normalizeNulls, requireWriteContext } from "../_internals";

const router = Router();

// هذا الراوتر يوفّر عمليات القراءة/الكتابة الخاصة بالهيكل الشجري (org_entity_structure) مع حقن workContextBy وحقول التدقيق
router.get("/organizations/:orgId/tree", async (req: Request, res: Response) => {
  try {
    const orgId = parseInt(req.params.orgId);
    if (isNaN(orgId)) {
      return res.status(400).json({ error: "معرف غير صالح" });
    }

    const includeInactive = req.query.includeInactive === "1" || req.query.includeInactive === "true";
    const tree = await storage.getTreeWithChildren(orgId, { includeInactive });
    res.json(tree);
  } catch (error) {
    console.error("Error fetching org tree:", error);
    res.status(500).json({ error: "فشل في جلب الهيكل التنظيمي" });
  }
});

router.get("/organizations/:orgId/tree/flat", async (req: Request, res: Response) => {
  try {
    const orgId = parseInt(req.params.orgId);
    if (isNaN(orgId)) {
      return res.status(400).json({ error: "معرف غير صالح" });
    }

    const includeInactive = req.query.includeInactive === "1" || req.query.includeInactive === "true";
    const nodes = await storage.getTreeNodesByOrgId(orgId, { includeInactive });
    res.json(nodes);
  } catch (error) {
    console.error("Error fetching org tree nodes:", error);
    res.status(500).json({ error: "فشل في جلب وحدات الهيكل" });
  }
});

router.get("/organizations/:orgId/tree/children/:parentId", async (req: Request, res: Response) => {
  try {
    const orgId = parseInt(req.params.orgId);
    const parentId = req.params.parentId === "null" ? null : parseInt(req.params.parentId);

    if (isNaN(orgId) || (parentId !== null && isNaN(parentId))) {
      return res.status(400).json({ error: "معرف غير صالح" });
    }

    const includeInactive = req.query.includeInactive === "1" || req.query.includeInactive === "true";
    const children = await storage.getTreeNodesByParentId(orgId, parentId, { includeInactive });
    res.json(children);
  } catch (error) {
    console.error("Error fetching tree children:", error);
    res.status(500).json({ error: "فشل في جلب الوحدات الفرعية" });
  }
});

router.get("/tree-nodes/:id", async (req: Request, res: Response) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ error: "معرف غير صالح" });
    }

    const node = await storage.getTreeNode(id);
    if (!node) {
      return res.status(404).json({ error: "الوحدة غير موجودة" });
    }

    res.json(node);
  } catch (error) {
    console.error("Error fetching tree node:", error);
    res.status(500).json({ error: "فشل في جلب الوحدة" });
  }
});

router.post("/tree-nodes", async (req: Request, res: Response) => {
  try {
    const body = normalizeNulls(req.body, ["parentId", "structureId", "orderIndex", "level"]);
    const normalized = normalizeInputTypes(body, {
      intFields: ["parentId", "orgId", "structureId", "orderIndex", "level"],
      boolFields: ["isActive"],
    });
    const validated = insertOrgStructureTreeSchema.parse(normalized);
    const ctx = await requireWriteContext(req);
    const node = await storage.createTreeNode({
      ...validated,
      workContextBy: ctx.workContextBy,
      createdBy: ctx.userId,
    } as any);
    res.status(201).json(node);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ error: "بيانات غير صالحة", details: error.errors });
    }
    console.error("Error creating tree node:", error);
    res.status(500).json({ error: "فشل في إنشاء الوحدة" });
  }
});

router.post("/tree-nodes/bulk", async (req: Request, res: Response) => {
  try {
    const nodes = z.array(insertOrgStructureTreeSchema).parse(req.body);
    const ctx = await requireWriteContext(req);
    const created = await storage.createManyTreeNodes(
      nodes.map((n) => ({
        ...n,
        workContextBy: ctx.workContextBy,
        createdBy: ctx.userId,
      })) as any,
    );
    res.status(201).json(created);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ error: "بيانات غير صالحة", details: error.errors });
    }
    console.error("Error creating tree nodes:", error);
    res.status(500).json({ error: "فشل في إنشاء الوحدات" });
  }
});

router.patch("/tree-nodes/:id", async (req: Request, res: Response) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ error: "معرف غير صالح" });
    }

    const body = normalizeNulls(req.body, ["parentId", "structureId", "orderIndex", "level"]);
    const normalized = normalizeInputTypes(body, {
      intFields: ["parentId", "orgId", "structureId", "orderIndex", "level"],
      boolFields: ["isActive"],
    });
    const ctx = await requireWriteContext(req);
    const node = await storage.updateTreeNode(id, {
      ...normalized,
      workContextBy: (normalized as any).workContextBy ?? ctx.workContextBy,
      updatedBy: ctx.userId,
      updatedAt: new Date(),
    } as any);
    if (!node) {
      return res.status(404).json({ error: "الوحدة غير موجودة" });
    }

    res.json(node);
  } catch (error) {
    console.error("Error updating tree node:", error);
    res.status(500).json({ error: "فشل في تحديث الوحدة" });
  }
});

router.delete("/tree-nodes/:id", async (req: Request, res: Response) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ error: "معرف غير صالح" });
    }

    const ctx = await requireWriteContext(req);
    const updated = await storage.updateTreeNode(id, {
      isDeleted: true,
      isActive: false,
      workContextBy: ctx.workContextBy,
      updatedBy: ctx.userId,
      updatedAt: new Date(),
    } as any);
    if (!updated) {
      return res.status(404).json({ error: "الوحدة غير موجودة" });
    }

    res.status(204).send();
  } catch (error) {
    console.error("Error deleting tree node:", error);
    res.status(500).json({ error: "فشل في حذف الوحدة" });
  }
});

export default router;
