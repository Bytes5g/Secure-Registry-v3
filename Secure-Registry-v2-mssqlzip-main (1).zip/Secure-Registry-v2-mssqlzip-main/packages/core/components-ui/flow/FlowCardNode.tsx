import type { CSSProperties } from "react"
import { Handle, Position, type NodeProps } from "@xyflow/react"
import { cn } from "../lib/utils"

export type FlowCardNodeTone = "default" | "muted" | "accent" | "danger"

export type FlowHandlePosition = "top" | "bottom" | "left" | "right"

export interface FlowHandleSpec {
  id?: string
  type: "source" | "target"
  position: FlowHandlePosition
  color?: string
}

export interface FlowCardNodeData {
  title: string
  subtitle?: string
  badge?: string
  color?: string
  highlighted?: boolean
  dimmed?: boolean
  tone?: FlowCardNodeTone
  handles?: FlowHandleSpec[]
}

function toneClassName(tone: FlowCardNodeTone | undefined) {
  switch (tone) {
    case "muted":
      return "border-muted-foreground/20 bg-muted/40"
    case "accent":
      return "border-primary/30 bg-primary/5"
    case "danger":
      return "border-destructive/30 bg-destructive/5"
    default:
      return "border-border bg-card"
  }
}

function fallbackBarColor(tone: FlowCardNodeTone | undefined) {
  switch (tone) {
    case "accent":
      return "#2563eb"
    case "danger":
      return "#dc2626"
    default:
      return "#64748b"
  }
}

export function FlowCardNode({ data, selected }: NodeProps) {
  const payload = data as unknown as FlowCardNodeData
  const ringColor = payload.color ?? fallbackBarColor(payload.tone)
  const handleColor = payload.color ?? fallbackBarColor(payload.tone)
  const style: CSSProperties | undefined = {
    ...(payload.dimmed ? { opacity: 0.45 } : null),
    borderLeftColor: payload.color ?? fallbackBarColor(payload.tone),
    ...(selected || payload.highlighted
      ? { boxShadow: `0 0 0 2px ${ringColor}` }
      : null),
  } as CSSProperties

  const handles: FlowHandleSpec[] = payload.handles && payload.handles.length > 0
    ? payload.handles
    : [
        { type: "target", position: "top" },
        { type: "source", position: "bottom" },
      ]

  const mapPosition = (position: FlowHandlePosition) => {
    switch (position) {
      case "left":
        return Position.Left
      case "right":
        return Position.Right
      case "bottom":
        return Position.Bottom
      default:
        return Position.Top
    }
  }

  return (
    <div
      style={style}
      className={cn(
        "relative min-w-[220px] max-w-[280px] rounded-md border border-l-4 px-3 py-2 shadow-sm",
        toneClassName(payload.tone),
      )}
    >
      {handles.map((h, index) => (
        <Handle
          key={h.id ?? `${h.type}-${h.position}-${index}`}
          id={h.id}
          type={h.type}
          position={mapPosition(h.position)}
          className="!h-2 !w-2 !border-0"
          style={{ background: h.color ?? handleColor }}
        />
      ))}
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0 flex-1 text-center">
          <div className="truncate text-sm font-medium">{payload.title}</div>
          {payload.subtitle ? <div className="truncate text-xs text-muted-foreground">{payload.subtitle}</div> : null}
        </div>
        {payload.badge ? (
          <div className="shrink-0 rounded-sm bg-muted px-2 py-0.5 text-[11px] text-muted-foreground text-center">
            {payload.badge}
          </div>
        ) : null}
      </div>
    </div>
  )
}
