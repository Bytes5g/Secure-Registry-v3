import { Switch, Route, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@secure-registry/components-ui";
import NotFound from "@/pages/not-found";
import { AuthProvider, useAuth } from "@/lib/mock-auth";
import Layout from "@/components/layout/Layout";
import Login from "@/pages/Login";
import Dashboard from "@/pages/Dashboard";
import FilesManagementPage from "@/pages/files";
import LookupsManagement from "@/pages/config/lookups";
import GeoManagement from "@/pages/config/geo";
import OrgEntitiesManagementPage from "@/pages/config/org-entities";
import OrgEntityProfilePage from "@/pages/config/org-entity-profile";
import PersonsManagementPage from "@/pages/config/persons";
import PersonProfilePage from "@/pages/config/person-profile";
import UiPageOverridesIndexPage from "@/pages/config/ui-page-overrides";
import UiPageOverridesDetailsPage from "@/pages/config/ui-page-overrides-page";
import { useEffect } from "react";

function ProtectedRoute({ component: Component }: { component: React.ComponentType }) {
  const { isAuthenticated, isLoading } = useAuth();
  const [, setLocation] = useLocation();

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      setLocation("/login");
    }
  }, [isAuthenticated, isLoading, setLocation]);

  if (isLoading) return null;
  if (!isAuthenticated) return null;

  return (
    <Layout>
      <Component />
    </Layout>
  );
}

function PlaceholderPage({ title }: { title: string }) {
  return (
    <div className="flex flex-col items-center justify-center h-[50vh] gap-4">
      <div className="text-6xl">🚧</div>
      <h2 className="text-xl font-semibold text-muted-foreground">
        {title}
      </h2>
      <p className="text-sm text-muted-foreground">
        هذه الصفحة قيد التطوير
      </p>
    </div>
  );
}

function RedirectToOrgEntities() {
  const [, setLocation] = useLocation();

  useEffect(() => {
    setLocation("/config/org-entities");
  }, [setLocation]);

  return null;
}

function Router() {
  return (
    <Switch>
      <Route path="/login" component={Login} />
      
      {/* Dashboard */}
      <Route path="/">
        {() => <ProtectedRoute component={Dashboard} />}
      </Route>
      
      <Route path="/files">
        {() => <ProtectedRoute component={FilesManagementPage} />}
      </Route>
      
      {/* Search */}
      <Route path="/search">
        {() => <ProtectedRoute component={() => <PlaceholderPage title="البحث المتقدم" />} />}
      </Route>
      
      {/* Reports */}
      <Route path="/statistics">
        {() => <ProtectedRoute component={() => <PlaceholderPage title="الإحصائيات" />} />}
      </Route>
      
      {/* Configuration */}
      <Route path="/config/lookups">
        {() => <ProtectedRoute component={LookupsManagement} />}
      </Route>
      <Route path="/config/geo">
        {() => <ProtectedRoute component={GeoManagement} />}
      </Route>
      <Route path="/config/org-structure">
        {() => <ProtectedRoute component={RedirectToOrgEntities} />}
      </Route>
      <Route path="/config/org-entities">
        {() => <ProtectedRoute component={OrgEntitiesManagementPage} />}
      </Route>
      <Route path="/config/org-entities/:id">
        {() => <ProtectedRoute component={OrgEntityProfilePage} />}
      </Route>
      <Route path="/config/persons">
        {() => <ProtectedRoute component={PersonsManagementPage} />}
      </Route>
      <Route path="/config/persons/:id">
        {() => <ProtectedRoute component={PersonProfilePage} />}
      </Route>
      <Route path="/config/ui-page-overrides">
        {() => <ProtectedRoute component={UiPageOverridesIndexPage} />}
      </Route>
      <Route path="/config/ui-page-overrides/:pageCode">
        {() => <ProtectedRoute component={UiPageOverridesDetailsPage} />}
      </Route>
      <Route path="/config/branch">
        {() => <ProtectedRoute component={RedirectToOrgEntities} />}
      </Route>
      <Route path="/config/branch/new">
        {() => <ProtectedRoute component={RedirectToOrgEntities} />}
      </Route>
      <Route path="/config/branch/:id">
        {() => <ProtectedRoute component={RedirectToOrgEntities} />}
      </Route>
      
      {/* Settings */}
      <Route path="/settings">
        {() => <ProtectedRoute component={() => <PlaceholderPage title="الإعدادات العامة" />} />}
      </Route>
      <Route path="/settings/profile">
        {() => <ProtectedRoute component={() => <PlaceholderPage title="الملف الشخصي" />} />}
      </Route>

      {/* 404 - Also wrapped in Layout */}
      <Route>
        {() => <ProtectedRoute component={NotFound} />}
      </Route>
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
