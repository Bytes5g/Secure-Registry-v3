import type { ReactNode } from "react"
import { Button } from "../ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../ui/card"

interface RelatedRecordsPanelProps {
  title: string
  description?: string
  actionLabel?: string
  onAction?: () => void
  children: ReactNode
}

export function RelatedRecordsPanel({
  title,
  description,
  actionLabel,
  onAction,
  children,
}: RelatedRecordsPanelProps) {
  return (
    <Card>
      <CardHeader className="flex flex-col gap-3 md:flex-row md:items-start md:justify-between">
        <div className="space-y-1">
          <CardTitle>{title}</CardTitle>
          {description ? <CardDescription>{description}</CardDescription> : null}
        </div>
        {actionLabel && onAction ? (
          <Button type="button" onClick={onAction}>
            {actionLabel}
          </Button>
        ) : null}
      </CardHeader>
      <CardContent>{children}</CardContent>
    </Card>
  )
}

