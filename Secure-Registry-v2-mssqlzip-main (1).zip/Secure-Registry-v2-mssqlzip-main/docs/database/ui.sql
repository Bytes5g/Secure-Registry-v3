-- ==========================================================================================
-- إعادة هندسة جداول واجهة المستخدم (Metadata-Driven UI Architecture)
-- خالية من التكرار - خالية من سياق الفروع - تدعم بناء الشاشات ديناميكياً
-- ==========================================================================================

-- ------------------------------------------------------------------------------------------
-- 0. الجداول المرجعية لواجهة المستخدم (UI Lookups)
-- لتوحيد القيم (مثل أنواع المكونات، أنواع الحقول، أنواع مصادر البيانات)
-- ------------------------------------------------------------------------------------------
IF OBJECT_ID('dbo.ui_lookup_values', 'U') IS NOT NULL DROP TABLE dbo.ui_lookup_values;
IF OBJECT_ID('dbo.ui_lookup_types', 'U') IS NOT NULL DROP TABLE dbo.ui_lookup_types;

-- أ. أنواع القوائم المرجعية
CREATE TABLE dbo.ui_lookup_types (
    id INT IDENTITY(1,1) PRIMARY KEY,
    type_code NVARCHAR(50) UNIQUE NOT NULL, -- مثال: 'UI_CONTROL_TYPE', 'COMPONENT_TYPE', 'DATA_SOURCE_TYPE'
    name NVARCHAR(100) NOT NULL,
    is_active BIT DEFAULT 1
);

-- ب. قيم القوائم المرجعية
CREATE TABLE dbo.ui_lookup_values (
    id INT IDENTITY(1,1) PRIMARY KEY,
    type_id INT NOT NULL FOREIGN KEY REFERENCES dbo.ui_lookup_types(id) ON DELETE CASCADE,
    value_code NVARCHAR(50) NOT NULL, -- مثال: 'TEXT', 'TABLE', 'INLINE_SQL'
    name NVARCHAR(100) NOT NULL,
    sort_order INT DEFAULT 0,
    is_active BIT DEFAULT 1,
    CONSTRAINT UQ_Lookup_Type_Value UNIQUE (type_id, value_code)
);

-- إدخال البيانات الأساسية للقوائم المرجعية (أمثلة)
INSERT INTO dbo.ui_lookup_types (type_code, name) VALUES 
('DATA_SOURCE_TYPE', N'نوع مصدر البيانات'),
('COMPONENT_TYPE', N'نوع المكون'),
('UI_CONTROL_TYPE', N'نوع عنصر التحكم'),
('TARGET_TYPE', N'نوع الهدف');

DECLARE @DsTypeId INT = (SELECT id FROM dbo.ui_lookup_types WHERE type_code = 'DATA_SOURCE_TYPE');
INSERT INTO dbo.ui_lookup_values (type_id, value_code, name) VALUES
(@DsTypeId, 'INLINE_SQL', N'استعلام SQL 直ق'),
(@DsTypeId, 'STORED_PROCEDURE', N'إجراء مخزن'),
(@DsTypeId, 'API_ENDPOINT', N'رابط API');

DECLARE @CompTypeId INT = (SELECT id FROM dbo.ui_lookup_types WHERE type_code = 'COMPONENT_TYPE');
INSERT INTO dbo.ui_lookup_values (type_id, value_code, name_ar, name) VALUES
(@CompTypeId, 'TABLE', N'جدول بيانات'),
(@CompTypeId, 'FORM', N'نموذج إدخال'),
(@CompTypeId, 'CHART', N'رسم بياني'),
(@CompTypeId, 'PROFILE_HEADER', N'ترويسة الملف الشخصي');

DECLARE @ControlTypeId INT = (SELECT id FROM dbo.ui_lookup_types WHERE type_code = 'UI_CONTROL_TYPE');
INSERT INTO dbo.ui_lookup_values (type_id, value_code, name_ar, name) VALUES
(@ControlTypeId, 'TEXT', N'نص قصير'),
(@ControlTypeId, 'TEXTAREA', N'نص طويل'),
(@ControlTypeId, 'NUMBER', N'رقم'),
(@ControlTypeId, 'DATE', N'تاريخ'),
(@ControlTypeId, 'SELECT', N'قائمة منسدلة'),
(@ControlTypeId, 'BOOLEAN', N'نعم/لا (مربع اختيار)');

DECLARE @TargetTypeId INT = (SELECT id FROM dbo.ui_lookup_types WHERE type_code = 'TARGET_TYPE');
INSERT INTO dbo.ui_lookup_values (type_id, value_code, name_ar, name) VALUES
(@TargetTypeId, 'PAGE', N'صفحة'),
(@TargetTypeId, 'TAB', N'تبويب'),
(@TargetTypeId, 'COMPONENT', N'مكون'),
(@TargetTypeId, 'ELEMENT', N'عنصر/حقل');

-- ------------------------------------------------------------------------------------------
-- 1. مصادر البيانات (Data Sources)
-- ------------------------------------------------------------------------------------------
IF OBJECT_ID('dbo.ui_data_sources', 'U') IS NOT NULL DROP TABLE dbo.ui_data_sources;
CREATE TABLE dbo.ui_data_sources (
    id INT IDENTITY(1,1) PRIMARY KEY,
    source_key NVARCHAR(100) UNIQUE NOT NULL, 
    name NVARCHAR(200) NOT NULL,
    source_type_id INT NOT NULL FOREIGN KEY REFERENCES dbo.ui_lookup_values(id), -- تم التعديل إلى مرجع
    parameters_json NVARCHAR(MAX) NULL, 
    is_active BIT DEFAULT 1,
    created_at DATETIME DEFAULT GETDATE(),
    created_by INT 
);

-- ------------------------------------------------------------------------------------------
-- 2. الصفحات (Pages)
-- ------------------------------------------------------------------------------------------
IF OBJECT_ID('dbo.ui_pages', 'U') IS NOT NULL DROP TABLE dbo.ui_pages;
CREATE TABLE dbo.ui_pages (
    id INT IDENTITY(1,1) PRIMARY KEY,
    page_key NVARCHAR(100) UNIQUE NOT NULL,
    title NVARCHAR(200) NOT NULL,
    icon_class NVARCHAR(100) NULL,
    route_path NVARCHAR(255) NOT NULL, 
    sort_order INT DEFAULT 0,
    is_active BIT DEFAULT 1
);

-- ------------------------------------------------------------------------------------------
-- 3. التبويبات أو الأقسام (Tabs / Sections)
-- ------------------------------------------------------------------------------------------
IF OBJECT_ID('dbo.ui_tabs', 'U') IS NOT NULL DROP TABLE dbo.ui_tabs;
CREATE TABLE dbo.ui_tabs (
    id INT IDENTITY(1,1) PRIMARY KEY,
    page_id INT NOT NULL FOREIGN KEY REFERENCES dbo.ui_pages(id) ON DELETE CASCADE,
    tab_key NVARCHAR(100) NOT NULL,
    title NVARCHAR(200) NOT NULL,
    icon_class NVARCHAR(100) NULL,
    sort_order INT DEFAULT 0,
    is_active BIT DEFAULT 1,
    CONSTRAINT UQ_Page_Tab UNIQUE (page_id, tab_key)
);

-- ------------------------------------------------------------------------------------------
-- 4. مكتبة المكونات (Component Library)
-- تم فصل المكونات عن التبويبات لتصبح مكتبة مركزية قابلة لإعادة الاستخدام في أي مكان
-- ------------------------------------------------------------------------------------------
IF OBJECT_ID('dbo.ui_components', 'U') IS NOT NULL DROP TABLE dbo.ui_components;
CREATE TABLE dbo.ui_components (
    id INT IDENTITY(1,1) PRIMARY KEY,
    component_key NVARCHAR(100) UNIQUE NOT NULL, -- مفتاح فريد (مثال: shared_person_basic_info)
    component_type_id INT NOT NULL FOREIGN KEY REFERENCES dbo.ui_lookup_values(id), -- تم التعديل إلى مرجع
    data_source_id INT NULL FOREIGN KEY REFERENCES dbo.ui_data_sources(id),
    title NVARCHAR(200) NULL,
    config_json NVARCHAR(MAX) NULL, -- الإعدادات الافتراضية للمكون
    is_active BIT DEFAULT 1
);

-- ------------------------------------------------------------------------------------------
-- 4.5. توزيع المكونات على التبويبات (Component Placement / Junction Table)
-- هذا الجدول يسمح باستخدام نفس المكون في أكثر من صفحة/تبويب دون تكرار الحقول
-- ------------------------------------------------------------------------------------------
IF OBJECT_ID('dbo.ui_tab_components', 'U') IS NOT NULL DROP TABLE dbo.ui_tab_components;
CREATE TABLE dbo.ui_tab_components (
    id INT IDENTITY(1,1) PRIMARY KEY,
    tab_id INT NOT NULL FOREIGN KEY REFERENCES dbo.ui_tabs(id) ON DELETE CASCADE,
    component_id INT NOT NULL FOREIGN KEY REFERENCES dbo.ui_components(id) ON DELETE CASCADE,
    
    sort_order INT DEFAULT 0,
    
    -- خاصية متقدمة: السماح بتجاوز الإعدادات الافتراضية للمكون في هذا التبويب المحدد
    -- مثال: المكون الأساسي قابل للتعديل، لكن في شاشة "الأرشيف" نجعله (Readonly)
    override_config_json NVARCHAR(MAX) NULL, 
    
    is_active BIT DEFAULT 1,
    CONSTRAINT UQ_Tab_Component UNIQUE (tab_id, component_id)
);

-- ------------------------------------------------------------------------------------------
-- 5. العناصر الموحدة (Elements - Fields & Columns)
-- يدمج الحقول والأعمدة في جدول واحد لمنع التكرار (ترتبط بالمكون المركزي)
-- ------------------------------------------------------------------------------------------
IF OBJECT_ID('dbo.ui_elements', 'U') IS NOT NULL DROP TABLE dbo.ui_elements;
CREATE TABLE dbo.ui_elements (
    id INT IDENTITY(1,1) PRIMARY KEY,
    component_id INT NOT NULL FOREIGN KEY REFERENCES dbo.ui_components(id) ON DELETE CASCADE,
    field_key NVARCHAR(100) NOT NULL, -- اسم الحقل في قاعدة البيانات/API (مثال: fullName)
    label NVARCHAR(200) NOT NULL,
    ui_control_type_id INT NOT NULL FOREIGN KEY REFERENCES dbo.ui_lookup_values(id), -- تم التعديل إلى مرجع
    
    -- خصائص العرض والسلوك
    is_visible BIT DEFAULT 1,
    is_required BIT DEFAULT 0,
    is_readonly BIT DEFAULT 0,
    sort_order INT DEFAULT 0,
    
    -- الإعدادات المتقدمة (JSON يغني عن عشرات الأعمدة المشتتة)
    -- للنموذج: {gridCols: 6, placeholder: "...", lookupTypeId: 9}
    -- للجدول: {width: 150, isSortable: true, isFilterable: true, format: "dd/MM/yyyy"}
    options_json NVARCHAR(MAX) NULL, 
    
    is_active BIT DEFAULT 1,
    CONSTRAINT UQ_Component_Field UNIQUE (component_id, field_key)
);

-- ------------------------------------------------------------------------------------------
-- 6. صلاحيات واجهة المستخدم (UI RBAC Integration)
-- ------------------------------------------------------------------------------------------
-- ملاحظة: نفترض وجود جدول للأدوار (Roles) في نظامك
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'roles')
CREATE TABLE dbo.roles (id INT IDENTITY(1,1) PRIMARY KEY, role_name NVARCHAR(100) NOT NULL);

IF OBJECT_ID('dbo.role_ui_permissions', 'U') IS NOT NULL DROP TABLE dbo.role_ui_permissions;
CREATE TABLE dbo.role_ui_permissions (
    id INT IDENTITY(1,1) PRIMARY KEY,
    role_id INT NOT NULL FOREIGN KEY REFERENCES dbo.roles(id) ON DELETE CASCADE,
    
    -- Polymorphic Relation (علاقة متعددة الأوجه) للتحكم في أي مستوى من الـ UI
    target_type_id INT NOT NULL FOREIGN KEY REFERENCES dbo.ui_lookup_values(id), -- تم التعديل إلى مرجع
    target_id INT NOT NULL, -- المعرف بناءً على النوع أعلاه
    
    can_view BIT DEFAULT 1,
    can_edit BIT DEFAULT 0, -- مفيد إذا كان Target هو 'ELEMENT' (حقل في نموذج)
    
    CONSTRAINT UQ_Role_UI_Target UNIQUE (role_id, target_type_id, target_id)
);
GO

-- ==========================================================================================
-- إضافة أوصاف الجداول والحقول (Table & Column Descriptions)
-- ==========================================================================================

-- 1. وصف جدول أنواع القوائم المرجعية
DECLARE @cols_lookup_types dbo.ColumnDescriptionType;
INSERT INTO @cols_lookup_types (column_name, description) VALUES
('type_code', N'الرمز الفريد لنوع القائمة (مثال: UI_CONTROL_TYPE)'),
('name', N'اسم نوع القائمة بالعربية'),
('is_active', N'حالة التفعيل');

EXEC dbo.sp_set_table_descriptions
    @schema_name = 'dbo',
    @table_name = 'ui_lookup_types',
    @table_description = N'جدول لتعريف أنواع القوائم المرجعية المستخدمة في نظام واجهة المستخدم (مثل أنواع المكونات وحقول التحكم)',
    @columns = @cols_lookup_types;

-- 2. وصف جدول قيم القوائم المرجعية
DECLARE @cols_lookup_values dbo.ColumnDescriptionType;
DELETE FROM @cols_lookup_values; -- تفريغ الجدول المؤقت
INSERT INTO @cols_lookup_values (column_name, description) VALUES
('type_id', N'معرف نوع القائمة المرجعية (رابط لجدول ui_lookup_types)'),
('value_code', N'الرمز الفريد للقيمة (مثال: TEXT)'),
('name', N'اسم القيمة بالعربية (يستخدم للعرض)'),
('sort_order', N'ترتيب عرض القيمة في القائمة'),
('is_active', N'حالة التفعيل');

EXEC dbo.sp_set_table_descriptions
    @schema_name = 'dbo',
    @table_name = 'ui_lookup_values',
    @table_description = N'جدول لتخزين القيم الفعلية للقوائم المرجعية لواجهة المستخدم',
    @columns = @cols_lookup_values;

-- 3. وصف جدول العناصر الموحدة (مثال للتوضيح)
DECLARE @cols_ui_elements dbo.ColumnDescriptionType;
DELETE FROM @cols_ui_elements;
INSERT INTO @cols_ui_elements (column_name, description) VALUES
('component_id', N'معرف المكون الذي ينتمي إليه هذا العنصر'),
('field_key', N'الاسم البرمجي للحقل كما هو في مصدر البيانات (API أو Database)'),
('label', N'عنوان الحقل المعروض للمستخدم بالعربية'),
('ui_control_type_id', N'نوع عنصر التحكم (نص، قائمة، تاريخ) - رابط لجدول ui_lookup_values'),
('is_visible', N'هل الحقل مرئي للمستخدم الافتراضي؟'),
('is_required', N'هل إدخال قيمة في هذا الحقل إلزامي؟'),
('is_readonly', N'هل الحقل للقراءة فقط؟'),
('sort_order', N'ترتيب ظهور الحقل ضمن المكون'),
('options_json', N'إعدادات متقدمة للحقل بصيغة JSON (مثل العرض، خصائص القوائم، التنسيق)'),
('is_active', N'حالة التفعيل');

EXEC dbo.sp_set_table_descriptions
    @schema_name = 'dbo',
    @table_name = 'ui_elements',
    @table_description = N'جدول العناصر الموحدة (Fields/Columns) التي يتكون منها كل مكون في واجهة المستخدم',
    @columns = @cols_ui_elements;

-- (يمكنك تكرار نفس النمط لإضافة أوصاف لبقية الجداول ui_pages, ui_components, الخ)