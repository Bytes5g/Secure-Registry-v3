import { z } from "zod";

const nullableInt = z.number().int().nullable();
const optionalNullableInt = nullableInt.optional().default(null);

export const folderSchema = z.object({
  id: z.number().int(),
  name: z.string().min(1),
  parent: nullableInt,
});
export type FolderRecord = z.infer<typeof folderSchema>;

export const insertFolderSchema = z.object({
  name: z.string().min(1),
  parent: optionalNullableInt,
});
export type InsertFolder = z.input<typeof insertFolderSchema>;
