# تدقيق تنظيم الملفات والتكرارات والملاحظات الهندسية

## 1) التنظيم الحالي للمجلدات

| المسار | الدور الحالي | الملاحظة |
| --- | --- | --- |
| `client/src` | الواجهات، الصفحات، hooks، الأنواع | منظم إجمالاً لكن بعض التهيئات مرتبطة بأرقام ثابتة |
| `server/routes` | تعريف HTTP endpoints | توجد مسارات عامة وأخرى مخصصة لنفس الدومينات |
| `server/storage` | طبقة Adapter (Facade) | لا تحتوي SQL؛ تستدعي وحدات `packages/core/database` لتوحيد منطق البيانات |
| `packages/core/database/src/modules` | منطق الوصول للبيانات | أفضل نقطة لتوحيد منطق البيانات |
| `packages/core/components-ui` | مكتبة المكونات المشتركة | أساس جيد لكن يحتاج توحيد نمط الاستدعاء داخل client |
| `shared/schema` | مخططات ونماذج مشتركة | مهم لتقليل التكرار بين الواجهة والخادم |
| `docs` | توثيق الدومين وقاعدة البيانات | غني لكنه يحتاج فهرسة أوضح ومسارات موضوعية أكثر |

## 2) نقاط القوة في التنظيم

1. الفصل الفيزيائي بين الطبقات واضح.
2. وجود مجلدات domain-oriented داخل الواجهة.
3. وجود `modules` في طبقة قاعدة البيانات يسهل التوسع المنظم.
4. وجود توثيق مستقل للـ database والـ lookups.
5. وجود حزمة `components-ui` كمصدر مركزي قابل لإعادة الاستخدام.

## 3) التكرارات والتعارضات الحالية

### أ. ازدواجية CRUD

يوجد أكثر من مسار للتعامل مع نفس الجداول أو نفس المفهوم:

- Auto API للجداول.
- Routes مخصصة للجهات والفروع.
- Storage في `server/storage` أصبح Adapter فقط فوق `packages/core/database` (بدون SQL).

**الأثر:**

- تضاعف نقاط الصيانة.
- صعوبة تحديد المصدر الرسمي للسلوك.
- احتمال اختلاف قواعد التحقق أو التحويل بين المسارات.

### ب. ازدواجية مصدر الصلاحيات

الوضع الحالي يشير إلى أكثر من اتجاه:

- `roles` و`permissions` داخل التطبيق.
- وثائق legacy حول `metadata_registry` و`menu_permissions`.
- `sys_action_types` كقاموس إجراءات أكثر نضجاً لتصميم مستقبلي.

**الأثر:**

- عدم وضوح من هو Source of Truth النهائي.
- صعوبة بناء واجهة صلاحيات مستقرة.

### ج. التكرار في تعريف lookup references

يوجد اعتماد مباشر على `SYSTEM_LOOKUP_IDS` داخل الواجهة.

**الأثر:**

- ربط التهيئة بأرقام قد تختلف بين البيئات.
- تقليل مرونة الإدارة من قاعدة البيانات.

### د. تكرار مسؤولية التحويل بين snake_case وcamelCase

هذا يظهر في أكثر من موضع داخل routes/modules/components.

**الأثر:**

- تشتيت منطق التحويل.
- زيادة احتمالية عدم الاتساق.

### هـ. تكرار/عدم اتساق استخدام `components-ui` داخل الواجهة

الحالة الحالية تظهر 3 أنماط متوازية:

1. استيراد مباشر من `@secure-registry/components-ui` (النمط الأوضح).
2. استيراد عبر alias `@secure-registry/ui` (مربوط فعلياً لنفس المصدر في `tsconfig.json`/`vite.admin.config.ts`).
3. استيراد عبر wrappers محلية مثل `client/src/components/tables/DataTable.tsx` التي تعيد التصدير فقط.

مرجعية الإعداد الحالية التي تؤكد هذا الازدواج:

- `tsconfig.json` → `compilerOptions.paths['@secure-registry/ui'] = ['./packages/core/components-ui/index.ts']`
- `vite.admin.config.ts` → `resolve.alias['@secure-registry/ui'] = path.resolve(..., 'packages/core/components-ui/index.ts')`

**الأثر:**

- تكرار في نقاط الدخول لنفس المكوّن.
- ضعف القدرة على فرض معيار موحد لبناء الشاشات.
- صعوبة معرفة ما إذا كان المشروع يستفيد من الحزمة المشتركة بشكل صحيح أو يكررها محلياً.

**الخلاصة الخاصة بهذا البند:**

المشروع يستخدم `packages/core/components-ui` فعلياً وبشكل واسع، لكن الاستخدام ليس موحداً بالكامل، ويحتاج سياسة استيراد موحدة لمنع التشتت في التطوير الديناميكي.

## 4) نقاط ضعف تنظيمية تحتاج معالجة مستقبلية

1. عدم اكتمال Registry موحد للشاشات والوحدات والإجراءات (يوجد جزء منفّذ حالياً لتهيئة الصفحات عبر `ui_page_*` وواجهة إدارة overrides، لكنه لا يغطي بعد modules/pages/data sources/actions/permissions بشكل كامل).
2. عدم وجود مجلد توثيق مقسم حسب الدومين/المعمارية/الحوكمة.
3. عدم حسم ما إذا كانت بعض الوحدات يجب أن تكون generic بالكامل أو domain-specific.
4. وجود منطق تحكم بالصلاحيات في مستوى المصادقة بشكل مبسط جداً.
5. عدم وجود معيار إلزامي موحد للاستيراد من `components-ui` داخل كل صفحات الواجهة.

## 4.1) قرارات تشغيلية تم تثبيتها

### أ) مسار تطوير الواجهة (client)

- التطوير اليومي يتم على `client/` (وهي واجهة الإدارة Admin).
- اسم الحزمة: `@secure-registry/client`.
- تم تثبيت تشغيلها عبر إعداد مستقل: `vite.admin.config.ts`.

### ب) حوكمة Auto API (تقليل ازدواجية CRUD)

- Auto API على `/api/*` تُستخدم للقراءة والاستكشاف فقط للجداول الأساسية التي لها مسارات أعمال مخصصة.
- تم جعل الجداول Read-only عبر Auto API:
  - org: `org_entities`, `org_entity_structure`, `org_branches`, `org_branch_nodes`
  - geo: `geo_admin_units`, `unified_geo_locations`
  - security: `users`, `roles`
- تم إيقاف الكتابة عبر `/api/lookup-types` و`/api/lookup-values`، والكتابة تكون عبر `/api/lookups/*`.
- تنبيه: الحذف الفعلي Disabled. مسار DELETE في Auto API ينفّذ Soft Delete فقط ويُرفض على أي جدول لا يحتوي `is_deleted` (mapped كـ `isDeleted`).

### ج) توحيد owner

- تم اعتماد `dbo.org_entities.is_system_owner = 1` لتحديد الجهة المالكة/المشغلة للنظام.
- `work_context_by` يرتبط بـ `org_branch_nodes.id`.

### د) تهيئة الصفحات (UI Overrides) كجزء من Registry

- يوجد API لتوليد تهيئة صفحات CRUD/Forms من القاموس مع دعم override:
  - `/api/ui/pages/:pageCode` + `/api/ui/pages/:pageCode/override`
- تم دعم قراءة/كتابة override من قاعدة البيانات عند توفر جداول:
  - `ui_page_tabs`, `ui_page_columns`, `ui_page_form_fields` (مع fallback عند الحاجة).
- تم تثبيت “هرمية مصدر” لمسميات الحقول وHint لتقليل hard-coded:
  - `standard_field_dictionary` → `v_schema_dictionary_columns` → fallback لاسم الحقل.
- تم تثبيت دعم Views في أدوات استكشاف الأعمدة (Table/View) لتجنب سقوط الشاشات المبنية على Views.

## 5) اقتراح تنظيم مستقبلي للملفات

### داخل `docs/`

- `docs/` للتحليل والمقترحات وخطة التنفيذ.
- `docs/frontend-modules/` لتوثيق بناء الواجهات وتقسيم الوحدات.
- يمكن إضافة `docs/reference/` لاحقاً لمراجع vendor/legal إذا لزم.
- تم اعتماد `docs/work-notes/` لملاحظات التنفيذ المتغيرة (مثل UI Registry/Builder وسجل الإنجاز).

### داخل التطبيق لاحقاً

- `client/src/features/access-control/`
- `client/src/features/module-builder/`
- `server/routes/access-control/`
- `packages/core/database/src/modules/access-control/`

## 6) خلاصة تدقيق التكرار

أهم التكرارات التي يجب معالجتها لاحقاً:

1. **تكرار CRUD بين العام والمخصص**.
2. **تكرار/تعدد نماذج الصلاحيات**.
3. **تكرار الاعتماد على IDs ثابتة بدلاً من الأكواد المرجعية**.
4. **تكرار منطق التحويل والتطبيع بين الطبقات**.
5. **تكرار نقاط الدخول للمكونات المشتركة (`components-ui` مقابل alias/wrappers محلية)**.

المبدأ المقترح: كل ما يخص تعريف الكيانات، الشاشات، الإجراءات، السياسات، والقيود يجب أن تكون له مرجعية واحدة في قاعدة البيانات ثم تُستهلك عبر طبقة بيانات موحدة، مع توحيد صارم لمسار استدعاء مكونات الواجهة المشتركة.
