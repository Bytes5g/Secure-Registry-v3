import { type SqlExecutor } from "../config/connection";
import {
  deleteRow,
  insertRow,
  selectRows,
  selectSingleRow,
  updateRow,
  type SqlRow,
  type TableReference,
} from "./helpers";
import {
  clearLookupRegistryCache,
  getLookupConfigById,
} from "./lookup-registry";

export interface LookupTypeAliasRecord {
  id: number;
  lookupTypeId: number;
  aliasCode: string;
  isActive: boolean;
  createdAt: string | null;
  updatedAt: string | null;
}

export interface LookupVirtualValueRecord {
  id: number;
  lookupTypeId: number;
  valueId: number;
  code: string;
  nameAr: string;
  orderIndex: number;
  aliases: string[];
  isActive: boolean;
  createdAt: string | null;
  updatedAt: string | null;
}

export interface LookupTypeAliasMutation {
  lookupTypeId: number;
  aliasCode: string;
  isActive?: boolean;
  workContextBy?: number | null;
  updatedBy?: number | null;
}

export interface LookupVirtualValueMutation {
  lookupTypeId: number;
  valueId: number;
  code: string;
  nameAr: string;
  orderIndex?: number;
  aliases?: string[];
  isActive?: boolean;
  workContextBy?: number | null;
  createdBy?: number | null;
  updatedBy?: number | null;
  isDeleted?: boolean | null;
}

const LOOKUP_TYPES_TABLE: TableReference = {
  schemaName: "dbo",
  tableName: "lookup_types",
};

const lookup_virtual_value_TABLE: TableReference = {
  schemaName: "dbo",
  tableName: "lookup_virtual_values",
};

function asOptionalText(value: unknown): string | null {
  if (value == null) {
    return null;
  }

  const text = String(value).trim();
  return text.length > 0 ? text : null;
}

function normalizeLookupCode(code: string): string {
  return code.trim().toUpperCase();
}

function normalizeAliasCode(value: unknown, code: string): string | null {
  const alias = asOptionalText(value);
  if (!alias) {
    return null;
  }

  const normalized = normalizeLookupCode(alias);
  return normalized === normalizeLookupCode(code) ? null : normalized;
}

function normalizeAliasList(aliases: string[] | undefined, code?: string): string[] {
  const excluded = code ? normalizeLookupCode(code) : null;
  return Array.from(
    new Set(
      (aliases ?? [])
        .map((alias) => asOptionalText(alias))
        .filter((alias): alias is string => Boolean(alias))
        .map(normalizeLookupCode)
        .filter((alias) => alias !== excluded),
    ),
  );
}

function parseAliases(value: unknown): string[] {
  if (typeof value !== "string" || value.trim().length === 0) {
    return [];
  }

  try {
    const parsed = JSON.parse(value);
    if (!Array.isArray(parsed)) {
      return [];
    }

    return parsed
      .map((entry) => asOptionalText(entry))
      .filter((entry): entry is string => Boolean(entry))
      .map(normalizeLookupCode);
  } catch {
    return [];
  }
}

function stringifyAliases(aliases: string[] | undefined, code?: string): string {
  return JSON.stringify(normalizeAliasList(aliases, code));
}

function mapLookupTypeAlias(row: SqlRow): LookupTypeAliasRecord {
  const code = String(row.code || "");
  const aliasCode = normalizeAliasCode(row.alias_code, code);

  return {
    id: Number(row.id),
    lookupTypeId: Number(row.id),
    aliasCode: aliasCode ?? "",
    isActive: row.is_active == null ? true : Boolean(row.is_active),
    createdAt: row.created_at == null ? null : String(row.created_at),
    updatedAt: row.updated_at == null ? null : String(row.updated_at),
  };
}

function mapLookupVirtualValue(row: SqlRow): LookupVirtualValueRecord {
  return {
    id: Number(row.id),
    lookupTypeId: Number(row.lookup_type_id),
    valueId: Number(row.value_id),
    code: String(row.code || ""),
    nameAr: String(row.name_ar || ""),
    orderIndex: Number(row.order_index || 0),
    aliases: parseAliases(row.aliases_json),
    isActive: row.is_active == null ? true : Boolean(row.is_active),
    createdAt: row.created_at == null ? null : String(row.created_at),
    updatedAt: row.updated_at == null ? null : String(row.updated_at),
  };
}

async function ensureLookupTypeExists(typeId: number): Promise<void> {
  const lookupType = await getLookupConfigById(typeId);
  if (!lookupType) {
    throw new Error(`Lookup type ${typeId} is not configured`);
  }
}

export async function getLookupTypeAliases(typeId: number): Promise<LookupTypeAliasRecord[]> {
  await ensureLookupTypeExists(typeId);

  const row = await selectSingleRow<SqlRow>(LOOKUP_TYPES_TABLE, {
    columns: "id, code, alias_code, is_active, created_at, updated_at",
    whereClause: "WHERE id = @id",
    params: { id: typeId },
  });

  if (!row) {
    return [];
  }

  const mapped = mapLookupTypeAlias(row);
  return mapped.aliasCode.trim().length > 0 ? [mapped] : [];
}

export async function getLookupTypeAliasById(id: number): Promise<LookupTypeAliasRecord | undefined> {
  const aliases = await getLookupTypeAliases(id);
  return aliases[0];
}

export async function createLookupTypeAlias(
  payload: LookupTypeAliasMutation,
  executor?: SqlExecutor,
): Promise<LookupTypeAliasRecord> {
  await ensureLookupTypeExists(payload.lookupTypeId);

  const aliasCode = payload.isActive === false ? null : normalizeLookupCode(payload.aliasCode);
  const updates: Record<string, unknown> = { alias_code: aliasCode, updated_at: new Date() };
  if (payload.workContextBy != null) updates.work_context_by = payload.workContextBy;
  if (payload.updatedBy != null) updates.updated_by = payload.updatedBy;
  const row = await updateRow<SqlRow>(LOOKUP_TYPES_TABLE, payload.lookupTypeId, updates, executor);

  clearLookupRegistryCache();
  if (!row) {
    throw new Error(`Lookup type ${payload.lookupTypeId} is not configured`);
  }
  return mapLookupTypeAlias(row);
}

export async function updateLookupTypeAlias(
  id: number,
  patch: Partial<LookupTypeAliasMutation>,
  executor?: SqlExecutor,
): Promise<LookupTypeAliasRecord | undefined> {
  const targetTypeId = patch.lookupTypeId ?? id;
  if (targetTypeId !== id) {
    throw new Error("lookupTypeId cannot differ from id when updating lookup type alias");
  }
  await ensureLookupTypeExists(targetTypeId);

  const aliasCode = patch.isActive === false
    ? null
    : patch.aliasCode == null
      ? undefined
      : normalizeLookupCode(patch.aliasCode);

  const updates: Record<string, unknown> = { updated_at: new Date() };
  if (aliasCode !== undefined) updates.alias_code = aliasCode;
  if (patch.workContextBy != null) updates.work_context_by = patch.workContextBy;
  if (patch.updatedBy != null) updates.updated_by = patch.updatedBy;
  const row = await updateRow<SqlRow>(LOOKUP_TYPES_TABLE, targetTypeId, updates, executor);

  clearLookupRegistryCache();
  return row ? mapLookupTypeAlias(row) : undefined;
}

export async function deleteLookupTypeAlias(
  id: number,
  context?: {
    workContextBy?: number | null;
    updatedBy?: number | null;
  },
  executor?: SqlExecutor,
): Promise<boolean> {
  await ensureLookupTypeExists(id);
  const updates: Record<string, unknown> = { alias_code: null, updated_at: new Date() };
  if (context?.workContextBy != null) updates.work_context_by = context.workContextBy;
  if (context?.updatedBy != null) updates.updated_by = context.updatedBy;
  const row = await updateRow<SqlRow>(LOOKUP_TYPES_TABLE, id, updates, executor);
  clearLookupRegistryCache();
  return Boolean(row);
}

export async function getLookupVirtualValues(typeId: number): Promise<LookupVirtualValueRecord[]> {
  await ensureLookupTypeExists(typeId);

  const rows = await selectRows<SqlRow>(lookup_virtual_value_TABLE, {
    whereClause: "WHERE lookup_type_id = @typeId AND (is_deleted = 0 OR is_deleted IS NULL)",
    orderByClause: "ORDER BY order_index, value_id",
    params: { typeId },
  });

  return rows.map(mapLookupVirtualValue);
}

export async function getLookupVirtualValueById(
  id: number,
): Promise<LookupVirtualValueRecord | undefined> {
  const row = await selectSingleRow<SqlRow>(lookup_virtual_value_TABLE, {
    whereClause: "WHERE id = @id AND (is_deleted = 0 OR is_deleted IS NULL)",
    params: { id },
  });

  return row ? mapLookupVirtualValue(row) : undefined;
}

export async function createLookupVirtualValue(
  payload: LookupVirtualValueMutation,
  executor?: SqlExecutor,
): Promise<LookupVirtualValueRecord> {
  await ensureLookupTypeExists(payload.lookupTypeId);

  const row = await insertRow<SqlRow>(
    lookup_virtual_value_TABLE,
    {
      lookup_type_id: payload.lookupTypeId,
      value_id: payload.valueId,
      code: normalizeLookupCode(payload.code),
      name_ar: payload.nameAr.trim(),
      order_index: payload.orderIndex ?? 0,
      aliases_json: stringifyAliases(payload.aliases, payload.code),
      is_active: payload.isActive ?? true,
      work_context_by: payload.workContextBy ?? null,
      created_by: payload.createdBy ?? null,
      is_deleted: payload.isDeleted ?? false,
    },
    executor,
  );

  return mapLookupVirtualValue(row);
}

export async function updateLookupVirtualValue(
  id: number,
  patch: Partial<LookupVirtualValueMutation>,
  executor?: SqlExecutor,
): Promise<LookupVirtualValueRecord | undefined> {
  const current = await getLookupVirtualValueById(id);
  if (!current) {
    return undefined;
  }

  if (patch.lookupTypeId != null) {
    await ensureLookupTypeExists(patch.lookupTypeId);
  }

  const nextCode = patch.code ?? current.code;
  const nextAliases = patch.aliases ?? current.aliases;

  const updates: Record<string, unknown> = {
    aliases_json: stringifyAliases(nextAliases, nextCode),
    updated_at: new Date(),
  };
  if (patch.lookupTypeId !== undefined) updates.lookup_type_id = patch.lookupTypeId;
  if (patch.valueId !== undefined) updates.value_id = patch.valueId;
  if (patch.code !== undefined) updates.code = patch.code == null ? null : normalizeLookupCode(patch.code);
  if (patch.nameAr !== undefined) updates.name_ar = patch.nameAr == null ? null : patch.nameAr.trim();
  if (patch.orderIndex !== undefined) updates.order_index = patch.orderIndex;
  if (patch.isActive !== undefined) updates.is_active = patch.isActive;
  if (patch.workContextBy != null) updates.work_context_by = patch.workContextBy;
  if (patch.updatedBy != null) updates.updated_by = patch.updatedBy;
  if (patch.isDeleted !== undefined) updates.is_deleted = patch.isDeleted;
  const row = await updateRow<SqlRow>(lookup_virtual_value_TABLE, id, updates, executor);

  return row ? mapLookupVirtualValue(row) : undefined;
}

export async function deleteLookupVirtualValue(
  id: number,
  context?: {
    workContextBy?: number | null;
    updatedBy?: number | null;
  },
  executor?: SqlExecutor,
): Promise<boolean> {
  const updates: Record<string, unknown> = { is_deleted: true, is_active: false, updated_at: new Date() };
  if (context?.workContextBy != null) updates.work_context_by = context.workContextBy;
  if (context?.updatedBy != null) updates.updated_by = context.updatedBy;

  const row = await updateRow<SqlRow>(lookup_virtual_value_TABLE, id, updates, executor);
  return Boolean(row);
}
