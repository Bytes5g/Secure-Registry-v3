import { beforeEach, describe, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => ({
  runQuery: vi.fn(),
  getDataSourceByKey: vi.fn(),
}));

vi.mock("./helpers", () => ({
  runQuery: mocks.runQuery,
}));

vi.mock("./ui-registry", () => ({
  uiRegistryModule: {
    getDataSourceByKey: mocks.getDataSourceByKey,
  },
}));

import { uiDataSourcesModule } from "./ui-data-sources";

describe("uiDataSourcesModule.executeDataSourceByKey", () => {
  beforeEach(() => {
    mocks.runQuery.mockReset();
    mocks.getDataSourceByKey.mockReset();
  });

  it("rejects unsafe SQL", async () => {
    mocks.getDataSourceByKey.mockResolvedValueOnce({
      sourceType: "INLINE",
      inlineQuery: "select 1; select 2",
      parameters: { allowedParams: [] },
    });

    await expect(uiDataSourcesModule.executeDataSourceByKey("x", {}, { userId: 1, isSuperAdmin: true })).rejects.toThrow("INLINE query is not allowed");
    expect(mocks.runQuery).not.toHaveBeenCalled();
  });

  it("rejects when not authorized", async () => {
    mocks.getDataSourceByKey.mockResolvedValueOnce({
      sourceType: "INLINE",
      inlineQuery: "select 1 as id",
      parameters: { allowedParams: [] },
    });

    await expect(uiDataSourcesModule.executeDataSourceByKey("x", {}, { userId: 1, role: "analyst" })).rejects.toThrow(
      "Not authorized",
    );
    expect(mocks.runQuery).not.toHaveBeenCalled();
  });

  it("binds allowed params only and clamps limit", async () => {
    mocks.getDataSourceByKey.mockResolvedValueOnce({
      sourceType: "INLINE",
      inlineQuery: "select 1 as id",
      parameters: { allowedParams: ["limit", "q"], cursorColumn: "id" },
    });

    mocks.runQuery.mockResolvedValueOnce([{ id: 1 }, { id: 2 }]);

    const res = await uiDataSourcesModule.executeDataSourceByKey(
      "x",
      { limit: 999, q: "abc", ignored: "x" },
      { userId: 1, isSuperAdmin: true },
    );
    expect(res.nextCursor).toBe(2);
    expect(mocks.runQuery).toHaveBeenCalledTimes(1);
    const [, params] = mocks.runQuery.mock.calls[0];
    expect(params).toEqual({ limit: 200, q: "abc" });
  });

  it("sets missing allowed params to null", async () => {
    mocks.getDataSourceByKey.mockResolvedValueOnce({
      sourceType: "INLINE",
      inlineQuery: "select 1 as id",
      parameters: { allowedParams: ["q"] },
    });
    mocks.runQuery.mockResolvedValueOnce([]);

    await uiDataSourcesModule.executeDataSourceByKey("x", {}, { userId: 1, isSuperAdmin: true });
    const [, params] = mocks.runQuery.mock.calls[0];
    expect(params).toEqual({ q: null });
  });

  it("allows execution via allowedRoles", async () => {
    mocks.getDataSourceByKey.mockResolvedValueOnce({
      sourceType: "INLINE",
      inlineQuery: "select 1 as id",
      parameters: { allowedParams: [], allowedRoles: ["admin"] },
    });
    mocks.runQuery.mockResolvedValueOnce([{ id: 1 }]);

    const res = await uiDataSourcesModule.executeDataSourceByKey("x", {}, { userId: 1, role: "admin" });
    expect(res.data.length).toBe(1);
  });

  it("allows execution via allowedPermissions", async () => {
    mocks.getDataSourceByKey.mockResolvedValueOnce({
      sourceType: "INLINE",
      inlineQuery: "select 1 as id",
      parameters: { allowedParams: [], allowedPermissions: ["ui:data-sources:execute"] },
    });
    mocks.runQuery.mockResolvedValueOnce([{ id: 1 }]);

    const res = await uiDataSourcesModule.executeDataSourceByKey(
      "x",
      {},
      { userId: 1, role: "analyst", permissions: ["ui:data-sources:execute"] },
    );
    expect(res.data.length).toBe(1);
  });
});
