import { mapProvidersModule } from "@core/database";
import type { MapProvider } from "@shared/schema";
import type { IMapProvidersStorage } from "./types";

function hasImageExtension(url: string): boolean {
  return /\.(png|jpg|jpeg|webp|gif)(\?.*)?$/i.test(url);
}

function appendExtension(url: string, extension: string): string {
  const cleanExt = extension.startsWith(".") ? extension : `.${extension}`;
  if (!cleanExt || cleanExt === ".") return url;
  if (hasImageExtension(url)) return url;

  const qIndex = url.indexOf("?");
  if (qIndex === -1) return `${url}${cleanExt}`;

  const base = url.slice(0, qIndex);
  const query = url.slice(qIndex);
  return `${base}${cleanExt}${query}`;
}

function buildTileUrl(input: { fullUrl: string | null; host: string; port: number; basePath: string; tileTemplate: string; defaultExtension: string }): string {
  const raw = input.fullUrl && input.fullUrl.trim().length > 0
    ? input.fullUrl
    : `${input.host.replace(/\/$/, "")}:${input.port}${input.basePath}${input.tileTemplate}`;

  return appendExtension(raw, input.defaultExtension);
}

export class MapProvidersStorage implements IMapProvidersStorage {
  async getEnabledMapProviders(): Promise<MapProvider[]> {
    const providers = await mapProvidersModule.getEnabled();
    return providers.map((p) => ({
      id: p.id,
      providerName: p.providerName,
      providerType: p.providerType,
      tileUrl: buildTileUrl(p),
      isOverlay: p.isOverlay,
      orderIndex: p.orderIndex,
    }));
  }
}

