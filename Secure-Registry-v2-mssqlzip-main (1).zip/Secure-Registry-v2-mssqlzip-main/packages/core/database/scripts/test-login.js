#!/usr/bin/env node
/**
 * End-to-end login pipeline test (DB layer + scrypt verifier).
 * Mirrors server/routes/auth.ts logic exactly.
 */
import { scrypt as _scrypt, timingSafeEqual } from "node:crypto";
import { promisify } from "node:util";
import { connect } from "./_config.js";

const scrypt = promisify(_scrypt);

async function comparePassword(password, hash) {
  const [salt, key] = hash.split(":");
  if (!salt || !key) return false;
  const keyBuffer = Buffer.from(key, "hex");
  const derivedKey = await scrypt(password, salt, 64);
  return timingSafeEqual(keyBuffer, derivedKey);
}

const pool = await connect();
const login = process.argv[2] || "admin";
const candidates = process.argv.slice(3);
if (candidates.length === 0) {
  candidates.push("Admin@2026", "Admin@2025", "admin", "Admin123!", "Admin@123", "P@ssw0rd");
}

const r = await pool.request().input("login", login).query(
  `SELECT TOP 1 id, email, password, status, role
     FROM [users]
     WHERE LOWER([email]) = LOWER(@login)
        OR LOWER(CASE WHEN CHARINDEX('@',[email])>0
                      THEN LEFT([email], CHARINDEX('@',[email])-1)
                      ELSE [email] END) = LOWER(@login)`
);

if (!r.recordset.length) {
  console.error(`✗ no user found for login=${login}`);
  await pool.close();
  process.exit(1);
}
const user = r.recordset[0];
console.log(`→ user found: id=${user.id} email=${user.email} status=${user.status} role=${user.role}`);

let matched = null;
for (const pw of candidates) {
  const ok = await comparePassword(pw, user.password);
  console.log(`  try "${pw}" → ${ok ? "✓ MATCH" : "✗"}`);
  if (ok) { matched = pw; break; }
}

await pool.close();

if (matched) {
  console.log(`\n✅ Login pipeline OK. Working credentials: ${login} / ${matched}`);
} else {
  console.log(`\n⚠️  Pipeline reachable but no candidate password matched for "${login}".`);
  console.log(`   Test with a real password:  node scripts/test-login.js ${login} <password>`);
  process.exit(2);
}
