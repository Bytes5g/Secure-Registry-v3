import Page from "@/features/ui-registry/UiPageOverridesDetailsPage";

export default Page;

