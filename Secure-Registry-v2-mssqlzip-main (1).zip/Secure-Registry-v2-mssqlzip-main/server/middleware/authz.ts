import type { NextFunction, Request, Response } from "express";

type SessionUser = {
  id?: string;
  role?: string;
  isSuperAdmin?: boolean;
};

function isSafeMethod(method: string): boolean {
  const m = (method || "").toUpperCase();
  return m === "GET" || m === "HEAD" || m === "OPTIONS";
}

function isAuthExemptPath(pathname: string): boolean {
  return pathname.startsWith("/api/auth/");
}

export function requireApiAuth(req: Request, res: Response, next: NextFunction) {
  if (isSafeMethod(req.method) && req.method.toUpperCase() === "OPTIONS") return next();

  const url = req.originalUrl || req.url || "";
  if (!url.startsWith("/api/")) return next();
  if (isAuthExemptPath(url)) return next();
  if (req.method.toUpperCase() === "OPTIONS") return next();

  // @ts-ignore
  const user = (req.session?.user ?? null) as SessionUser | null;
  if (!user?.id) {
    return res.status(401).json({ error: "غير مصرح: الرجاء تسجيل الدخول" });
  }

  if (!isSafeMethod(req.method)) {
    const role = String(user.role || "").toLowerCase();
    const isAdmin = Boolean(user.isSuperAdmin) || role === "admin";
    if (!isAdmin) {
      return res.status(403).json({ error: "غير مصرح: هذه العملية تتطلب صلاحيات مسؤول" });
    }
  }

  return next();
}
