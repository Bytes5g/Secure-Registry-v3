import { Router } from "express";
import { getTableInfo } from "../crudFactory/sql/table-info";
import { resolveTableDescriptor } from "../auto-api";
import { getSchemaDictionaryColumns, settingsModule, standardFieldsModule, uiRegistryModule } from "@core/database";
import { storage } from "../../storage";
import { getWriteContext } from "../_internals";

const router = Router();

function toKebabCase(value: string): string {
  return value.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase();
}

function normalizeDataType(value: string): string {
  return String(value || "").trim().toLowerCase();
}

function inferColumnType(dataType: string): "text" | "number" | "date" | "boolean" {
  const t = normalizeDataType(dataType);
  if (t === "bit") return "boolean";
  if (t === "date" || t === "datetime" || t === "datetime2" || t === "smalldatetime" || t === "datetimeoffset" || t === "time") {
    return "date";
  }
  if (
    t === "int" ||
    t === "bigint" ||
    t === "smallint" ||
    t === "tinyint" ||
    t === "decimal" ||
    t === "numeric" ||
    t === "float" ||
    t === "real" ||
    t === "money" ||
    t === "smallmoney"
  ) {
    return "number";
  }
  return "text";
}

function inferColumnTypeFromDictionary(value: unknown, fallbackType: string): "text" | "number" | "date" | "boolean" {
  const raw = String(value ?? "").trim().toLowerCase();
  if (raw === "boolean") return "boolean";
  if (raw === "date") return "date";
  if (raw === "number") return "number";
  if (raw === "text") return "text";
  return inferColumnType(fallbackType);
}

function inferFieldType(dataType: string, maxLength: number | null): "text" | "number" | "textarea" | "boolean" {
  const colType = inferColumnType(dataType);
  if (colType === "boolean") return "boolean";
  if (colType === "number") return "number";

  const len = maxLength == null ? null : Number(maxLength);
  if (len != null && (len > 255 || len < 0)) return "textarea";
  return "text";
}

function inferFieldTypeFromDictionary(value: unknown, fallbackType: string, maxLength: number | null): "text" | "number" | "textarea" | "boolean" {
  const raw = String(value ?? "").trim().toLowerCase();
  if (raw === "boolean") return "boolean";
  if (raw === "number") return "number";
  if (raw === "text") {
    const len = maxLength == null ? null : Number(maxLength);
    if (len != null && (len > 255 || len < 0)) return "textarea";
    return "text";
  }
  if (raw === "date") return "text";
  return inferFieldType(fallbackType, maxLength);
}

function splitWords(value: string): string {
  return value
    .replace(/_/g, " ")
    .replace(/([a-z0-9])([A-Z])/g, "$1 $2")
    .trim();
}

function asNonEmptyText(value: unknown): string | null {
  if (value == null) return null;
  const text = String(value).trim();
  return text.length ? text : null;
}

const AUDIT_AND_CONTEXT_KEYS = new Set([
  "createdAt",
  "createdBy",
  "updatedAt",
  "updatedBy",
  "isDeleted",
  "workContextBy",
]);

function asObject(value: unknown): Record<string, unknown> | null {
  if (!value || typeof value !== "object") return null;
  return value as Record<string, unknown>;
}

function mergeUiConfig(base: Record<string, unknown>, patch: Record<string, unknown>): Record<string, unknown> {
  const next: Record<string, unknown> = { ...base, ...patch };

  const mergeArrayByFieldCode = (baseArr: any, patchArr: any) => {
    const baseList = Array.isArray(baseArr) ? baseArr : [];
    const patchList = Array.isArray(patchArr) ? patchArr : [];
    const baseMap = new Map<string, any>();
    for (const item of baseList) {
      const key = String(item?.fieldCode ?? item?.columnKey ?? "");
      if (!key) continue;
      baseMap.set(key, item);
    }
    const used = new Set<string>();
    const merged: any[] = [];
    for (const item of patchList) {
      const key = String(item?.fieldCode ?? item?.columnKey ?? "");
      if (!key) continue;
      const baseItem = baseMap.get(key);
      if (baseItem) {
        merged.push({ ...baseItem, ...item, config: { ...(baseItem as any)?.config, ...(item as any)?.config } });
      } else {
        merged.push(item);
      }
      used.add(key);
    }
    for (const item of baseList) {
      const key = String(item?.fieldCode ?? item?.columnKey ?? "");
      if (!key || used.has(key)) continue;
      merged.push(item);
    }
    return merged;
  };

  if (patch.columns !== undefined) next.columns = mergeArrayByFieldCode((base as any).columns, patch.columns);
  if (patch.formFields !== undefined) next.formFields = mergeArrayByFieldCode((base as any).formFields, patch.formFields);
  if (patch.filters !== undefined) next.filters = patch.filters;

  return next;
}

async function generateUiPageConfig(params: {
  pageCode: string;
  entityType: string;
  ignoreOverride: boolean;
}): Promise<Record<string, unknown>> {
  const pageCode = params.pageCode;
  const entityType = params.entityType;

  const descriptor =
    resolveTableDescriptor(entityType) ??
    resolveTableDescriptor(toKebabCase(entityType));

  if (!descriptor) {
    const error: any = new Error(`Unknown entityType '${entityType}'`);
    error.statusCode = 404;
    throw error;
  }

  if (descriptor.tableName.endsWith("_virtual")) {
    const error: any = new Error(`Entity '${entityType}' is virtual`);
    error.statusCode = 404;
    throw error;
  }

  const info = await getTableInfo(descriptor);
  const columns = info.columns;
  const dictColumns = await getSchemaDictionaryColumns({
    schemaName: info.schemaName,
    objectName: info.tableName,
  });
  const dictByDb = new Map(dictColumns.map((c) => [c.columnName, c]));
  const objectDescription = dictColumns[0]?.objectDescription ?? null;
  const standardFieldMap = await standardFieldsModule.getFieldDefinitionMap();

  const getStandardField = (fieldCode: string, dbKey: string) => {
    const byProp = standardFieldMap.get(String(fieldCode || "").trim().toLowerCase());
    if (byProp) return byProp;
    return standardFieldMap.get(String(dbKey || "").trim().toLowerCase()) ?? null;
  };

  const lookupTypes = await storage.getAllLookupTypes();
  const lookupByTable = new Map<string, { id: number; schemaName: string | null; tableName: string | null }>();
  for (const type of lookupTypes) {
    if (!type.isActive) continue;
    const tableName = type.tableName ?? null;
    if (!tableName) continue;
    lookupByTable.set(`${(type.schemaName ?? "dbo").toLowerCase()}.${tableName.toLowerCase()}`, {
      id: Number(type.id),
      schemaName: type.schemaName ?? "dbo",
      tableName,
    });
  }

  const preferredListKeys = ["id", "code", "name", "nameAr", "title", "fullName", "isActive"];
  const nonAuditColumns = columns.filter((c) => !AUDIT_AND_CONTEXT_KEYS.has(c.propKey));
  const pickedListColumns = (() => {
    const picked: typeof columns = [];
    const pickedSet = new Set<string>();

    for (const key of preferredListKeys) {
      const col = columns.find((c) => c.propKey === key);
      if (col) {
        picked.push(col);
        pickedSet.add(col.propKey);
      }
    }

    for (const col of nonAuditColumns) {
      if (picked.length >= 6) break;
      if (pickedSet.has(col.propKey)) continue;
      if (col.isIdentity) continue;
      picked.push(col);
      pickedSet.add(col.propKey);
    }

    return picked;
  })();

  const uiColumns = pickedListColumns.map((col, index) => ({
    fieldCode: col.propKey,
    nameAr: (() => {
      const standard = getStandardField(col.propKey, col.dbKey);
      return (
        asNonEmptyText(standard?.nameAr) ??
        asNonEmptyText(dictByDb.get(col.dbKey)?.columnDescription) ??
        splitWords(col.propKey)
      );
    })(),
    columnType: (() => {
      const standard = getStandardField(col.propKey, col.dbKey);
      const dict = dictByDb.get(col.dbKey);
      const fkSchema = (dict?.referencedSchema ?? "dbo").toLowerCase();
      const fkTable = dict?.referencedObject ? String(dict.referencedObject).toLowerCase() : null;
      const lookup = fkTable ? lookupByTable.get(`${fkSchema}.${fkTable}`) : undefined;
      if (lookup) return "select" as const;
      return inferColumnTypeFromDictionary(standard?.uiColumnType ?? dict?.uiColumnType, col.dataType);
    })(),
    isVisible: true,
    isSortable: true,
    orderIndex: index + 1,
    lookupTypeId: (() => {
      const dict = dictByDb.get(col.dbKey);
      const fkSchema = (dict?.referencedSchema ?? "dbo").toLowerCase();
      const fkTable = dict?.referencedObject ? String(dict.referencedObject).toLowerCase() : null;
      const lookup = fkTable ? lookupByTable.get(`${fkSchema}.${fkTable}`) : undefined;
      return lookup ? lookup.id : undefined;
    })(),
  }));

  const searchBaseColumns = (() => {
    if (pageCode !== "persons_search") return null;
    return [
      { fieldCode: "id", nameAr: "الرقم الآلي", columnType: "number", isVisible: true, isSortable: true, orderIndex: 1 },
      { fieldCode: "fullName", nameAr: "الاسم", columnType: "text", isVisible: true, isSortable: true, orderIndex: 2 },
      { fieldCode: "genderName", nameAr: "الجنس", columnType: "text", isVisible: true, isSortable: true, orderIndex: 3 },
      { fieldCode: "nationalityName", nameAr: "الجنسية", columnType: "text", isVisible: true, isSortable: true, orderIndex: 4 },
      { fieldCode: "maritalName", nameAr: "الحالة الاجتماعية", columnType: "text", isVisible: true, isSortable: true, orderIndex: 5 },
      { fieldCode: "dateOfBirth", nameAr: "تاريخ الميلاد", columnType: "date", isVisible: true, isSortable: true, orderIndex: 6 },
      { fieldCode: "orgName", nameAr: "مكان العمل", columnType: "text", isVisible: true, isSortable: false, orderIndex: 7 },
      { fieldCode: "branchName", nameAr: "الفرع", columnType: "text", isVisible: true, isSortable: false, orderIndex: 8 },
      { fieldCode: "orgStructureName", nameAr: "الوحدة", columnType: "text", isVisible: true, isSortable: false, orderIndex: 9 },
      { fieldCode: "isManager", nameAr: "مدير", columnType: "boolean", isVisible: true, isSortable: true, orderIndex: 10 },
      { fieldCode: "isActive", nameAr: "نشط", columnType: "boolean", isVisible: true, isSortable: true, orderIndex: 11 },
    ];
  })();

  const formFields = columns
    .filter((col) => {
      if (col.isIdentity) return false;
      if (col.propKey === "id") return false;
      if (AUDIT_AND_CONTEXT_KEYS.has(col.propKey)) return false;
      return true;
    })
    .map((col, index) => {
      const standard = getStandardField(col.propKey, col.dbKey);
      const dict = dictByDb.get(col.dbKey);
      const fieldType = inferFieldTypeFromDictionary(
        standard?.uiColumnType ?? dict?.uiColumnType,
        col.dataType,
        col.maxLength,
      );
      const fkSchema = (dict?.referencedSchema ?? "dbo").toLowerCase();
      const fkTable = dict?.referencedObject ? String(dict.referencedObject).toLowerCase() : null;
      const lookup = fkTable ? lookupByTable.get(`${fkSchema}.${fkTable}`) : undefined;
      return {
        fieldCode: col.propKey,
        nameAr:
          asNonEmptyText(standard?.nameAr) ??
          asNonEmptyText(dictByDb.get(col.dbKey)?.columnDescription) ??
          splitWords(col.propKey),
        fieldType: lookup ? ("select" as const) : (fieldType === "boolean" ? "boolean" : fieldType),
        isRequired: !col.isNullable && !col.hasDefault,
        isVisible: true,
        orderIndex: index + 1,
        gridCols: fieldType === "textarea" ? 12 : 6,
        lookupTypeId: lookup ? lookup.id : undefined,
        placeholder: asNonEmptyText(standard?.description) ?? undefined,
      };
    });

  const searchBaseFormFields = (() => {
    if (pageCode !== "persons_search") return null;
    return [
      { fieldCode: "id", nameAr: "الرقم الآلي", fieldType: "number", isRequired: false, isVisible: true, orderIndex: 1, gridCols: 4 },
      { fieldCode: "fullName", nameAr: "الاسم", fieldType: "text", isRequired: false, isVisible: true, orderIndex: 2, gridCols: 8 },
      {
        fieldCode: "orgId",
        nameAr: "الجهة (مكان العمل)",
        fieldType: "select",
        isRequired: false,
        isVisible: true,
        orderIndex: 3,
        gridCols: 4,
        config: {
          section: "basic",
          clearOnChange: ["branchId", "orgStructureId"],
          remoteOptions: {
            variants: [
              {
                path: "/api/org/organizations",
                response: "array",
                valueKey: "id",
                labelKey: "name",
                query: { includeInactive: 0 },
              },
            ],
          },
        },
      },
      {
        fieldCode: "branchId",
        nameAr: "الفرع",
        fieldType: "select",
        isRequired: false,
        isVisible: true,
        orderIndex: 4,
        gridCols: 4,
        config: {
          section: "basic",
          clearOnChange: ["orgStructureId"],
          remoteOptions: {
            variants: [
              {
                when: { field: "orgId", op: "notEmpty" },
                path: "/api/branches",
                response: "array",
                valueKey: "id",
                labelKey: "name",
                query: {},
                clientFilter: { field: "orgId", recordKey: "orgId" },
                onSelectSet: { orgId: "orgId" },
              },
            ],
          },
        },
      },
      {
        fieldCode: "orgStructureId",
        nameAr: "الوحدة",
        fieldType: "select",
        isRequired: false,
        isVisible: true,
        orderIndex: 5,
        gridCols: 4,
        config: {
          section: "basic",
          remoteOptions: {
            variants: [
              {
                when: { field: "branchId", op: "notEmpty" },
                path: "/api/branches/{branchId}/nodes",
                response: "array",
                valueKey: "org_structure_node_id",
                labelKey: "name",
                query: {},
              },
              {
                when: { field: "orgId", op: "notEmpty" },
                path: "/api/org/organizations/{orgId}/tree/flat",
                response: "array",
                valueKey: "id",
                labelKey: "name",
                query: { includeInactive: 0 },
              },
            ],
          },
        },
      },
      {
        fieldCode: "includeUnassigned",
        nameAr: "إظهار غير المرتبطين",
        fieldType: "boolean",
        isRequired: false,
        isVisible: true,
        orderIndex: 6,
        gridCols: 4,
        defaultValue: "false",
        config: { section: "advanced" },
      },
      {
        fieldCode: "createdBy",
        nameAr: "المستخدم المُدخل",
        fieldType: "select",
        isRequired: false,
        isVisible: true,
        orderIndex: 7,
        gridCols: 4,
        config: {
          section: "advanced",
          remoteOptions: {
            variants: [
              {
                path: "/api/users",
                response: "paged",
                valueKey: "id",
                labelKey: "email",
                query: { page: 1, limit: 200, isDeleted: 0, isActive: 1 },
              },
            ],
          },
        },
      },
      {
        fieldCode: "workContextBy",
        nameAr: "سياق العمل",
        fieldType: "number",
        isRequired: false,
        isVisible: false,
        orderIndex: 8,
        gridCols: 4,
        config: {
          section: "advanced",
        },
      },
    ];
  })();

  const config: Record<string, unknown> = {
    code: pageCode,
    nameAr: objectDescription ?? splitWords(pageCode),
    entityType: descriptor.exportName,
    layoutType: "list",
    description: `${info.schemaName}.${info.tableName}`,
    columns: searchBaseColumns ?? uiColumns,
    formFields: searchBaseFormFields ?? formFields,
    filters: [],
  };

  if (params.ignoreOverride) {
    return config;
  }

  const dbOverride = await uiRegistryModule.getPageOverride(pageCode);
  if (dbOverride) {
    return mergeUiConfig(config as any, dbOverride as any);
  }

  const override = await settingsModule.getUiPageConfigOverride(pageCode);
  const overrideObj = asObject(override);
  if (!overrideObj) {
    return config;
  }

  return mergeUiConfig(config as any, overrideObj);
}

router.get("/:pageCode/details", async (req, res) => {
  try {
    const pageCode = String(req.params.pageCode || "").trim();
    const entityTypeRaw = req.query.entityType == null ? "" : String(req.query.entityType).trim();
    const entityType = entityTypeRaw || pageCode;
    if (!pageCode) {
      return res.status(400).json({ error: "pageCode is required" });
    }

    const ignoreOverrideRaw = req.query.ignoreOverride == null ? "" : String(req.query.ignoreOverride).trim().toLowerCase();
    const ignoreOverride = ignoreOverrideRaw === "1" || ignoreOverrideRaw === "true" || ignoreOverrideRaw === "yes";

    const config = await generateUiPageConfig({ pageCode, entityType, ignoreOverride });
    const tabsWithSources = await uiRegistryModule.getPageTabsWithDataSources(pageCode);
    const tabs = tabsWithSources.map((t) => t.tab);
    const tabDataSources = tabsWithSources.map((t) => ({
      tabId: t.tab.id,
      tabKey: t.tab.tabKey,
      dataSources: t.dataSources.map((ds) => {
        const sourceType = String(ds.dataSource.sourceType || "");
        const sourceObject = ds.dataSource.sourceObject ? String(ds.dataSource.sourceObject) : null;
        const endpointPath =
          sourceType.toLowerCase() === "api" && sourceObject
            ? sourceObject.startsWith("/") ? sourceObject : `/api/${sourceObject}`
            : null;
        return {
          ...ds,
          resolved: {
            endpointPath,
          },
        };
      }),
    }));

    res.json({ pageCode, entityType, config, tabs, tabDataSources });
  } catch (error: any) {
    const statusCode = error?.statusCode ?? 500;
    res.status(statusCode).json({ error: error.message ?? "Failed to load page details" });
  }
});

router.get("/:pageCode/registry-info", async (req, res) => {
  try {
    const pageCode = String(req.params.pageCode || "").trim();
    if (!pageCode) return res.status(400).json({ error: "pageCode is required" });
    const info = await uiRegistryModule.getPageRegistryInfo(pageCode);
    res.json(info);
  } catch (error: any) {
    res.status(500).json({ error: error?.message ?? "Failed to load ui page registry info" });
  }
});

router.get("/registry", async (_req, res) => {
  try {
    const pages = await uiRegistryModule.getRegisteredPages();
    res.json(pages);
  } catch (error: any) {
    res.status(500).json({ error: error?.message ?? "Failed to load ui pages registry" });
  }
});

router.get("/:pageCode", async (req, res) => {
  try {
    const pageCode = String(req.params.pageCode || "").trim();
    const entityTypeRaw = req.query.entityType == null ? "" : String(req.query.entityType).trim();
    const entityType = entityTypeRaw || pageCode;
    if (!pageCode) {
      return res.status(400).json({ error: "pageCode is required" });
    }
    const ignoreOverrideRaw = req.query.ignoreOverride == null ? "" : String(req.query.ignoreOverride).trim().toLowerCase();
    const ignoreOverride = ignoreOverrideRaw === "1" || ignoreOverrideRaw === "true" || ignoreOverrideRaw === "yes";
    const config = await generateUiPageConfig({ pageCode, entityType, ignoreOverride });
    return res.json(config);
  } catch (error: any) {
    console.error("Error generating ui page config:", error);
    const statusCode = error?.statusCode ?? 500;
    res.status(statusCode).json({ error: error.message ?? "Failed to load page config" });
  }
});

router.get("/:pageCode/override", async (req, res) => {
  try {
    const pageCode = String(req.params.pageCode || "").trim();
    if (!pageCode) {
      return res.status(400).json({ error: "pageCode is required" });
    }

    const dbOverride = await uiRegistryModule.getPageOverride(pageCode);
    if (dbOverride) {
      return res.json({ pageCode, override: dbOverride });
    }

    const override = await settingsModule.getUiPageConfigOverride(pageCode);
    res.json({ pageCode, override });
  } catch (error: any) {
    console.error("Error fetching ui page config override:", error);
    res.status(500).json({ error: error.message ?? "Failed to load page override" });
  }
});

router.put("/:pageCode/override", async (req, res) => {
  try {
    const pageCode = String(req.params.pageCode || "").trim();
    if (!pageCode) {
      return res.status(400).json({ error: "pageCode is required" });
    }

    const patch = req.body;
    if (patch != null && typeof patch !== "object") {
      return res.status(400).json({ error: "Override must be an object or null" });
    }

    const ctx = await getWriteContext(req);
    if (!ctx.userId || !ctx.workContextBy) {
      return res.status(401).json({ error: "غير مصرح" });
    }

    await uiRegistryModule.setPageOverride(
      pageCode,
      patch == null ? null : (patch as any),
      {
        userId: ctx.userId,
        workContextBy: ctx.workContextBy,
      },
    );

    const override = await uiRegistryModule.getPageOverride(pageCode);
    res.json({ pageCode, override });
  } catch (error: any) {
    console.error("Error updating ui page config override:", error);
    res.status(500).json({ error: error.message ?? "Failed to update page override" });
  }
});

router.post("/:pageCode/override/seed", async (req, res) => {
  try {
    const pageCode = String(req.params.pageCode || "").trim();
    if (!pageCode) return res.status(400).json({ error: "pageCode is required" });

    const ctx = await getWriteContext(req);
    if (!ctx.userId || !ctx.workContextBy) {
      return res.status(401).json({ error: "غير مصرح" });
    }

    const forceRaw = req.query.force == null ? "" : String(req.query.force).trim().toLowerCase();
    const force = forceRaw === "1" || forceRaw === "true" || forceRaw === "yes";

    const scopeRaw = req.query.scope == null ? "" : String(req.query.scope).trim();
    const scope = scopeRaw === "columns" || scopeRaw === "formFields" ? scopeRaw : "all";

    const entityTypeFromBody = req.body?.entityType == null ? "" : String(req.body.entityType).trim();
    const registryInfo = await uiRegistryModule.getPageRegistryInfo(pageCode);
    const entityType = entityTypeFromBody || registryInfo?.entityType || pageCode;

    const baseConfig = await generateUiPageConfig({ pageCode, entityType, ignoreOverride: true });
    const result = await uiRegistryModule.seedPageOverrideFromConfig(
      pageCode,
      baseConfig,
      {
        userId: ctx.userId,
        workContextBy: ctx.workContextBy,
      },
      { force, scope: scope as any },
    );

    const override = await uiRegistryModule.getPageOverride(pageCode);
    res.json({ ...result, override });
  } catch (error: any) {
    res.status(500).json({ error: error?.message ?? "Failed to seed page override" });
  }
});

export default router;
