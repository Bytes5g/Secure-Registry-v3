import { FieldGroup } from "@/components/shared";
import { Input, Textarea } from "@secure-registry/components-ui";
import type { LookupTypeFormState } from "../models/lookups-admin-models";

interface LookupTypeInputFieldProps {
  id: string;
  label: string;
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
}

export function LookupTypeInputField({
  id,
  label,
  value,
  onChange,
  placeholder,
}: LookupTypeInputFieldProps) {
  return (
    <FieldGroup label={label} htmlFor={id}>
      <Input
        id={id}
        value={value}
        placeholder={placeholder}
        onChange={(event) => onChange(event.target.value)}
      />
    </FieldGroup>
  );
}

interface LookupTypeTextareaFieldProps {
  id: string;
  label: string;
  value: string;
  onChange: (value: string) => void;
  rows?: number;
}

export function LookupTypeTextareaField({
  id,
  label,
  value,
  onChange,
  rows = 3,
}: LookupTypeTextareaFieldProps) {
  return (
    <FieldGroup label={label} htmlFor={id}>
      <Textarea id={id} value={value} rows={rows} onChange={(event) => onChange(event.target.value)} />
    </FieldGroup>
  );
}

interface LookupTypeStrategyFieldProps {
  value: LookupTypeFormState["providerStrategy"];
  onChange: (value: LookupTypeFormState["providerStrategy"]) => void;
}

export function LookupTypeStrategyField({ value, onChange }: LookupTypeStrategyFieldProps) {
  return (
    <FieldGroup label="استراتيجية المزود" htmlFor="provider-strategy">
      <select
        id="provider-strategy"
        name="provider-strategy"
        className="flex h-10 w-full rounded-md border bg-background px-3 py-2 text-sm"
        value={value}
        onChange={(event) => onChange(event.target.value as LookupTypeFormState["providerStrategy"])}
      >
        <option value="override">override</option>
        <option value="fallback">fallback</option>
      </select>
    </FieldGroup>
  );
}
