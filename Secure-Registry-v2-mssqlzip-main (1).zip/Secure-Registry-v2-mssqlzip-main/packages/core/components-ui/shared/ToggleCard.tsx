import { Switch } from "../ui/switch";
import { cn } from "../lib/utils";

interface ToggleCardProps {
  title: string;
  description?: string;
  checked: boolean;
  onCheckedChange: (checked: boolean) => void;
  className?: string;
}

export function ToggleCard({
  title,
  description,
  checked,
  onCheckedChange,
  className,
}: ToggleCardProps) {
  return (
    <div className={cn("flex items-center justify-between rounded-md border p-3", className)}>
      <div>
        <p className="font-medium">{title}</p>
        {description ? <p className="text-sm text-muted-foreground">{description}</p> : null}
      </div>
      <Switch checked={checked} onCheckedChange={onCheckedChange} />
    </div>
  );
}
