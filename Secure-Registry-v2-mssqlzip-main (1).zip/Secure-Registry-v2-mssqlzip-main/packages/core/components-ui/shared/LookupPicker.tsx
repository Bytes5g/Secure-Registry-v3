import { useMemo, useState, type HTMLAttributes } from "react"
import { ChevronsUpDown, Search } from "lucide-react"
import { Button } from "../ui/button"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "../ui/dialog"
import { Input } from "../ui/input"
import { Popover, PopoverContent, PopoverTrigger } from "../ui/popover"
import { ScrollArea } from "../ui/scroll-area"
import { cn } from "../lib/utils"
import type { TreeNode } from "../trees/TreeNavigation"
import { TreeNavigation } from "../trees/TreeNavigation"

export type LookupPickerTreeOption = {
  value: string
  label: string
  parentValue?: string | null
}

interface LookupPickerProps extends HTMLAttributes<HTMLButtonElement> {
  value?: string
  onValueChange: (value: string) => void
  options: LookupPickerTreeOption[]
  placeholder?: string
  disabled?: boolean
  className?: string
  dir?: "rtl" | "ltr"
  enableDialog?: boolean
  dialogTitle?: string
}

function buildTree(options: LookupPickerTreeOption[]) {
  const byParent = new Map<number | null, TreeNode[]>()
  const toId = (value: string) => {
    const parsed = Number(value)
    return Number.isFinite(parsed) ? parsed : null
  }

  options.forEach((option) => {
    const id = toId(option.value)
    if (id == null) return
    const parentId = option.parentValue == null ? null : toId(option.parentValue)
    const node: TreeNode = {
      id,
      name: option.label,
      parentId,
      hasChildren: false,
    }
    const list = byParent.get(parentId) ?? []
    list.push(node)
    byParent.set(parentId, list)
  })

  for (const [parentId, nodes] of Array.from(byParent.entries())) {
    nodes.forEach((node: TreeNode) => {
      const children = byParent.get(node.id)
      if (children && children.length > 0) {
        node.hasChildren = true
      }
    })
    nodes.sort((a: TreeNode, b: TreeNode) => a.name.localeCompare(b.name, "ar"))
    byParent.set(parentId, nodes)
  }

  const rootNodes = byParent.get(null) ?? []
  const loadChildren = async (parentId: number): Promise<TreeNode[]> => {
    return byParent.get(parentId) ?? []
  }

  const idToValue = new Map<number, string>()
  options.forEach((option) => {
    const id = toId(option.value)
    if (id != null) idToValue.set(id, option.value)
  })

  return { rootNodes, loadChildren, idToValue }
}

export function LookupPicker({
  value,
  onValueChange,
  options,
  placeholder = "اختر...",
  disabled,
  className,
  dir = "rtl",
  enableDialog = true,
  dialogTitle = "بحث واختيار",
  ...controlProps
}: LookupPickerProps) {
  const [open, setOpen] = useState(false)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [query, setQuery] = useState("")
  const selectedLabel = useMemo(
    () => options.find((option) => option.value === (value ?? ""))?.label,
    [options, value],
  )

  const hasTree = useMemo(
    () => options.some((option) => option.parentValue != null),
    [options],
  )

  const tree = useMemo(() => (hasTree ? buildTree(options) : null), [hasTree, options])

  const flatSearchOptions = useMemo(() => {
    const withSearch = options.map((option) => ({
      ...option,
      search: `${option.label} ${option.value}`.toLowerCase(),
    }))
    return withSearch
  }, [options])

  const filteredOptions = useMemo(() => {
    const q = query.trim().toLowerCase()
    if (!q) return flatSearchOptions
    return flatSearchOptions.filter((option) => option.search.includes(q))
  }, [flatSearchOptions, query])

  const handleSelect = (next: string) => {
    onValueChange(next)
    setQuery("")
    setOpen(false)
    setDialogOpen(false)
  }

  const Trigger = (
    <div className={cn("flex items-center gap-2", className)} dir={dir}>
      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <Button
            {...controlProps}
            type="button"
            variant="outline"
            role="combobox"
            disabled={disabled}
            className={cn(
              "w-full justify-between",
              !selectedLabel && "text-muted-foreground",
            )}
          >
            <span className="truncate">{selectedLabel ?? placeholder}</span>
            <ChevronsUpDown className="ms-2 h-4 w-4 shrink-0 opacity-50" />
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-[--radix-popover-trigger-width] p-0" align="start" sideOffset={4}>
          <div dir={dir}>
            <div className="flex items-center gap-2 p-2">
              <div className="flex-1">
                <Input
                  placeholder="ابحث..."
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                />
              </div>
              {enableDialog ? (
                <Button type="button" variant="ghost" size="icon" onClick={() => setDialogOpen(true)}>
                  <Search className="h-4 w-4" />
                </Button>
              ) : null}
            </div>
            <ScrollArea className={cn(hasTree ? "h-[320px]" : "h-[240px]")}>
              {hasTree && tree && query.trim().length === 0 ? (
                <div className="p-2">
                  <TreeNavigation
                    rootNodes={tree.rootNodes}
                    selectedNodeId={value ? Number(value) : null}
                    onSelectNode={(node) => {
                      if (!node) return
                      const nextValue = tree.idToValue.get(node.id)
                      if (!nextValue) return
                      handleSelect(nextValue)
                    }}
                    loadChildren={(parentId) => tree.loadChildren(parentId)}
                    rootLabel="الكل"
                    className="border-0"
                    contentClassName="max-h-none overflow-visible p-1"
                  />
                </div>
              ) : (
                <div className="p-2 space-y-1">
                  {filteredOptions.length === 0 ? (
                    <div className="py-6 text-center text-sm text-muted-foreground">لا توجد نتائج</div>
                  ) : (
                    filteredOptions.map((option) => (
                      <button
                        key={option.value}
                        type="button"
                        onClick={() => handleSelect(option.value)}
                        className={cn(
                          "w-full rounded-sm px-2 py-1.5 text-sm text-start hover:bg-accent hover:text-accent-foreground",
                          option.value === (value ?? "") && "bg-accent text-accent-foreground",
                        )}
                      >
                        {option.label}
                      </button>
                    ))
                  )}
                </div>
              )}
            </ScrollArea>
          </div>
        </PopoverContent>
      </Popover>

      {enableDialog ? (
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>{dialogTitle}</DialogTitle>
            </DialogHeader>
            <div dir={dir} className="space-y-3">
              <Input
                placeholder="ابحث بالاسم أو الكود..."
                value={query}
                onChange={(e) => setQuery(e.target.value)}
              />
              <ScrollArea className="h-[480px]">
                <div className="p-2 space-y-1">
                  {filteredOptions.length === 0 ? (
                    <div className="py-6 text-center text-sm text-muted-foreground">لا توجد نتائج</div>
                  ) : (
                    filteredOptions.map((option) => (
                      <button
                        key={option.value}
                        type="button"
                        onClick={() => handleSelect(option.value)}
                        className={cn(
                          "w-full rounded-sm px-2 py-1.5 text-sm text-start hover:bg-accent hover:text-accent-foreground",
                          option.value === (value ?? "") && "bg-accent text-accent-foreground",
                        )}
                      >
                        {option.label}
                      </button>
                    ))
                  )}
                </div>
              </ScrollArea>
            </div>
          </DialogContent>
        </Dialog>
      ) : null}
    </div>
  )

  return Trigger
}
