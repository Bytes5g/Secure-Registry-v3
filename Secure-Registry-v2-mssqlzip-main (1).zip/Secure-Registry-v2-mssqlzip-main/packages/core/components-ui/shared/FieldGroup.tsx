import type { ReactNode } from "react";
import { Label } from "../ui/label";
import { cn } from "../lib/utils";

interface FieldGroupProps {
  label: string;
  htmlFor?: string;
  helperText?: string;
  className?: string;
  children: ReactNode;
}

export function FieldGroup({ label, htmlFor, helperText, className, children }: FieldGroupProps) {
  return (
    <div className={cn("space-y-2", className)}>
      <Label htmlFor={htmlFor}>{label}</Label>
      {children}
      {helperText ? <p className="text-sm text-muted-foreground">{helperText}</p> : null}
    </div>
  );
}
