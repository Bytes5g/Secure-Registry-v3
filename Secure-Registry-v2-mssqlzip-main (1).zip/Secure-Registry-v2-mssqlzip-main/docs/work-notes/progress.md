# سجل الإنجاز (Progress)

هذا الملف يركّز على “ما تم إنجازه فعلياً” بشكل موجز وقابل للتحقق. التفاصيل الفنية المتغيرة تُسجّل في:
- [ui-registry-builder-notes.md](./ui-registry-builder-notes.md)

## 2026-05-11 — UI Page Overrides (persons_search) + Visual Editor

### تم إنجازه
- تحسين شاشة إدارة Overrides لتصبح أقرب لتجربة “Builder” مع محرر + معاينة حيّة + لوحة خصائص.
- منع التكرارات والتعارضات في `columns/formFields` عبر دمج ذكي حسب `fieldCode` + تحذيرات/تنظيف.
- دعم ترتيب Drag & Drop للأعمدة والحقول داخل المحرر.
- فتح لوحة الخصائص تلقائياً عند اختيار عنصر من المحرر أو بالنقر من داخل المعاينة (click-to-select).
- إضافة تبويبات خصائص للحقل/العمود تشمل:
  - الأساسيات (اسم/نوع/ظهور/ترتيب/عرض أو gridCols)
  - المصدر (تحرير `remoteOptions` بصرياً بدلاً من JSON نصي)
  - الأنماط (Presets بسيطة للعرض وgridCols/section)
- تثبيت فلترة “الجهة المُدخلة” في `persons_search` لإظهار الجهات التي `is_system_owner = 1` عبر `remoteOptions.query.isSystemOwner = 1`.

### تحقق/جودة
- نجاح فحص TypeScript على workspace.
- نجاح بناء واجهة الإدارة (vite build).

### ملاحظات/مخاطر (تمت معالجتها)
- تم تحويل DELETE في Auto-API إلى Soft Delete إلزامي عند توفر `is_deleted`، مع منع الحذف الفعلي افتراضياً.
- تم نقل SQL/Introspection وCRUD Factory SQL إلى `packages/core/database` وإزالة SQL من طبقات السيرفر قدر الإمكان.

## 2026-05-11 — حوكمة Auto-API + نقل Introspection

### تم إنجازه
- تحويل مسار الحذف في CRUD Factory (Auto-API) إلى Soft Delete عند توفر `is_deleted`:
  - يحدّث `is_deleted=1` و`is_active=0` (إن وجد) ويكتب `updated_at/updated_by` عند توفر الأعمدة.
  - يمنع الحذف الفعلي افتراضياً للجداول التي لا تملك `is_deleted` (يرجع خطأ واضح).
- نقل استعلامات Introspection من `server/routes/crudFactory/sql/*` إلى طبقة البيانات في `packages/core/database`:
  - `sys.columns/sys.objects` (Table/View)
  - `dbo.v_schema_dictionary_columns`
  - `information_schema.columns` (endpoint legacy `/api/meta/:table`)
- نقل تنفيذ بعض الاستعلامات من `server/routes/*` إلى طبقة البيانات:
  - تنفيذ `ui_data_sources` (INLINE) عبر `uiDataSourcesModule` بدل `createRequest` في route
  - قراءة Dashboard summary عبر `getSystemDashboardStatistics` بدل SQL مباشر في route

### تحقق/جودة
- نجاح فحص TypeScript على workspace.
- نجاح بناء واجهة الإدارة (vite build).
- نجاح اختبارات حزمة قاعدة البيانات (vitest).

## 2026-05-11 — نقل CRUD Factory SQL إلى طبقة البيانات

### تم إنجازه
- نقل تنفيذ SQL الديناميكي الخاص بـ CRUD Factory (Auto-API) من `server/routes/crudFactory/handlers/*` إلى `packages/core/database`:
  - list/get-by-id/insert/update/delete
  - بناء WHERE من querystring، وحل شرط id/uuid، وبناء خطة insert متعددة الاستراتيجيات
- إزالة ملفات SQL غير المستخدمة من `server/routes/crudFactory/sql/*` بعد النقل لتقليل التكرار.

### تحقق/جودة
- نجاح فحص TypeScript على workspace.
- نجاح اختبارات حزمة قاعدة البيانات (vitest).

## 2026-05-11 — نقل SQL خارج routes (Session Store)

### تم إنجازه
- نقل SQL الخاص بتخزين الجلسات من `server/session-store.ts` إلى `packages/core/database`:
  - get/upsert/destroy/touch
  - إبقاء طبقة السيرفر كـ adapter فقط لـ express-session بدون SQL.

### تحقق/جودة
- نجاح فحص TypeScript على workspace.
- نجاح اختبارات حزمة قاعدة البيانات (vitest).

## 2026-05-11 — حوكمة تنفيذ UI Data Sources

### تم إنجازه
- تقييد تنفيذ `/api/ui/data-sources/:dataSourceKey/execute` ليكون لمستخدم مصادق فقط.
- السماح بالتنفيذ وفق القواعد التالية:
  - admin/super-admin (session user) أو `permissions` تحتوي `*`
  - أو عبر ضبط `parameters_json.allowedRoles` / `parameters_json.allowedPermissions` على الـ DataSource نفسه.

### تحقق/جودة
- نجاح اختبارات وحدات لـ `uiDataSourcesModule` (vitest).

## 2026-05-11 — Runtime: استهلاك ui_tab_data_sources (Read-only)

### تم إنجازه
- إضافة helper لاختيار تبويب افتراضي واستخراج `dataSourceKey` حسب `tabKey/purpose` من `tabDataSources`.
- تحديث صفحة `/config/persons` لتعرض تبويباتها من DB (`ui_page_tabs`) وتختار مصدر البيانات من `ui_tab_data_sources` عند التنفيذ (مع fallback عند عدم وجود تهيئة).

### تحقق/جودة
- نجاح فحص TypeScript على workspace.
- نجاح بناء واجهة الإدارة (vite build).

## 2026-05-11 — معيار mapping_json + Runtime Hooks

### تم إنجازه
- إضافة معيار موحد لـ `ui_tab_data_sources.mapping_json` لدعم:
  - mapping للـ params + static params
  - تحويلات للأنواع (number/boolean/string/trimmedString)
  - cursor/limit param names
- إضافة Hooks عامة داخل `client/src/features/ui-runtime/hooks` لتقليل تكرار منطق:
  - تحميل تفاصيل الصفحة
  - إدارة تبويبات الصفحة
  - تنفيذ DataSources (list مع cursor + query بسيط لـ stats/summary)
- تحديث صفحة الأشخاص لاستهلاك هذه الـ hooks وتجنب منطق خاص بالصفحة قدر الإمكان.

### تحقق/جودة
- نجاح فحص TypeScript على workspace.
- نجاح اختبارات حزمة قاعدة البيانات (vitest).
- نجاح بناء واجهة الإدارة (vite build).

## 2026-05-11 — UiRuntimePage + Template Registry (search_table)

### تم إنجازه
- إضافة `UiRuntimePage` (Page Renderer) لاختيار Page Template بناءً على `pageTemplateKey` داخل `ui_page_tabs.tab_options_json` مع fallback آمن عندما لا توجد تهيئة DB.
- إضافة Template Registry كبداية بمفتاح `search_table` (Search + Table + cursor paging + stats اختياري) اعتماداً على Runtime Hooks و`mapping_json`.
- تحديث `/config/lookups` ليحاول استخدام UiRuntimePage عند توفر registry في DB وإلا يعود للواجهة الحالية.

### تحقق/جودة
- نجاح فحص TypeScript على workspace.
- نجاح بناء واجهة الإدارة (vite build).
