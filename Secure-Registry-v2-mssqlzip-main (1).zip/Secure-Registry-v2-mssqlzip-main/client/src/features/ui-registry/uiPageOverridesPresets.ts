import { PAGE_CODES } from "@/lib/constants";

export const PAGE_CODE_PRESETS: Array<{ value: string; label: string; defaultEntityType?: string }> = [
  { value: PAGE_CODES.ORG_STRUCTURE, label: "الجهات (org_entities)", defaultEntityType: "organizationalStructure" },
  { value: PAGE_CODES.ORG_STRUCTURE_TREE, label: "الهيكل التنظيمي (tree)", defaultEntityType: "orgStructureTree" },
  { value: PAGE_CODES.ORG_STRUCTURE_ROLE_TITLES, label: "مسميات الهيكل", defaultEntityType: "orgStructureRoleTitles" },
  { value: PAGE_CODES.BRANCH_MANAGEMENT, label: "الفروع", defaultEntityType: "orgBranches" },
  { value: PAGE_CODES.LOOKUPS, label: "أنواع القوائم المرجعية (lookups)" },
  { value: PAGE_CODES.LOOKUP_VALUES, label: "قيم القوائم المرجعية (lookup values)" },
  { value: PAGE_CODES.GEO_MANAGEMENT, label: "الجغرافيا (geo)" },
  { value: PAGE_CODES.PERSONS_SEARCH, label: "بحث الأشخاص (form)", defaultEntityType: "personsSearch" },
  { value: "__custom__", label: "إدخال يدوي" },
];

export const ENTITY_TYPE_PRESETS: Array<{ value: string; label: string }> = [
  { value: "organizationalStructure", label: "organizationalStructure (الجهات)" },
  { value: "orgStructureTree", label: "orgStructureTree (الهيكل)" },
  { value: "orgBranches", label: "orgBranches (الفروع)" },
  { value: "orgStructureRoleTitles", label: "orgStructureRoleTitles (مسميات الهيكل)" },
  { value: "personsSearch", label: "personsSearch (vm_persons)" },
  { value: "__custom__", label: "إدخال يدوي" },
];

