import { useEffect, useMemo, useState } from "react";
import { getDefaultTabKey } from "@/lib/ui/uiTabDataSources";

export function useUiPageTabs(details: any) {
  const tabs = useMemo(() => {
    const list = Array.isArray(details?.tabs) ? details.tabs : [];
    return list.filter((t: any) => t?.tabKey && t?.labelAr);
  }, [details]);

  const [activeTabKey, setActiveTabKey] = useState<string>("main");

  useEffect(() => {
    const def = getDefaultTabKey(details);
    const hasActive = tabs.some((t: any) => String(t?.tabKey ?? "") === String(activeTabKey));
    if (!hasActive && def) setActiveTabKey(def);
  }, [details, tabs, activeTabKey]);

  return {
    tabs,
    hasTabs: tabs.length > 0,
    activeTabKey,
    setActiveTabKey,
  };
}

