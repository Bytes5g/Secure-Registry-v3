import { Input } from "@secure-registry/components-ui";
import { FieldGroup } from "@/components/shared";

interface LookupDialogInputFieldProps {
  id: string;
  label: string;
  value: string;
  onChange: (value: string) => void;
  type?: "text" | "number";
  placeholder?: string;
  className?: string;
}

export function LookupDialogInputField({
  id,
  label,
  value,
  onChange,
  type = "text",
  placeholder,
  className,
}: LookupDialogInputFieldProps) {
  return (
    <FieldGroup label={label} htmlFor={id} className={className}>
      <Input
        id={id}
        type={type}
        value={value}
        placeholder={placeholder}
        onChange={(event) => onChange(event.target.value)}
      />
    </FieldGroup>
  );
}
