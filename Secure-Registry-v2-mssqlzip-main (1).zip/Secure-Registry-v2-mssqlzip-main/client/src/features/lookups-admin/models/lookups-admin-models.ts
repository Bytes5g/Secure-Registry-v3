import type {
  InsertLookupType,
  InsertLookupTypeAlias,
  InsertLookupValue,
  InsertLookupVirtualValue,
  LookupType,
  LookupTypeAlias,
  LookupValue,
  LookupVirtualValue,
} from "@shared/schema";

export type LookupTypeFormState = {
  code: string;
  aliasCode: string;
  nameAr: string;
  description: string;
  isActive: boolean;
  databaseName: string;
  schemaName: string;
  tableName: string;
  nameColumn: string;
  orderColumn: string;
  parentColumn: string;
  createdAtColumn: string;
  writable: boolean;
  valueProviderKey: string;
  providerStrategy: "override" | "fallback";
};

export type AliasFormState = {
  aliasCode: string;
  isActive: boolean;
};

export type ValueFormState = {
  code: string;
  nameAr: string;
  orderIndex: number;
  parentId: string;
  isActive: boolean;
};

export type VirtualSeedFormState = {
  valueId: string;
  code: string;
  nameAr: string;
  orderIndex: number;
  aliases: string[];
  isActive: boolean;
};

function asText(value: string | null | undefined): string {
  return value ?? "";
}

function asNullableText(value: string): string | null {
  const trimmed = value.trim();
  return trimmed.length > 0 ? trimmed : null;
}

function asTrimmedText(value: string): string {
  return value.trim();
}

function asFormNumber(value: number | null | undefined): string {
  return value == null ? "" : String(value);
}

function asNumberOrZero(value: number | string): number {
  return Number(value) || 0;
}

function asNullableNumber(value: string): number | null {
  const trimmed = value.trim();
  return trimmed ? Number(trimmed) : null;
}

function mapRecordOrEmpty<TRecord, TForm>(
  record: TRecord | null,
  mapRecord: (record: TRecord) => TForm,
  createEmpty: () => TForm,
): TForm {
  return record ? mapRecord(record) : createEmpty();
}

export function createEmptyLookupTypeForm(): LookupTypeFormState {
  return {
    code: "",
    aliasCode: "",
    nameAr: "",
    description: "",
    isActive: true,
    databaseName: "",
    schemaName: "",
    tableName: "",
    nameColumn: "",
    orderColumn: "",
    parentColumn: "",
    createdAtColumn: "",
    writable: true,
    valueProviderKey: "",
    providerStrategy: "override",
  };
}

export function createLookupTypeFormFromRecord(record: LookupType | null): LookupTypeFormState {
  return mapRecordOrEmpty(
    record,
    (current) => ({
      code: current.code,
      aliasCode: asText(current.aliasCode),
      nameAr: current.nameAr,
      description: asText(current.description),
      isActive: current.isActive,
      databaseName: asText(current.databaseName),
      schemaName: asText(current.schemaName),
      tableName: asText(current.tableName),
      nameColumn: asText(current.nameColumn),
      orderColumn: asText(current.orderColumn),
      parentColumn: asText(current.parentColumn),
      createdAtColumn: asText(current.createdAtColumn),
      writable: current.writable,
      valueProviderKey: asText(current.valueProviderKey),
      providerStrategy: current.providerStrategy,
    }),
    createEmptyLookupTypeForm,
  );
}

export function mapLookupTypePayload(form: LookupTypeFormState): InsertLookupType {
  return {
    code: asTrimmedText(form.code),
    aliasCode: asNullableText(form.aliasCode),
    nameAr: asTrimmedText(form.nameAr),
    description: asNullableText(form.description),
    isActive: form.isActive,
    databaseName: asNullableText(form.databaseName),
    schemaName: asNullableText(form.schemaName),
    tableName: asNullableText(form.tableName),
    nameColumn: asNullableText(form.nameColumn),
    orderColumn: asNullableText(form.orderColumn),
    parentColumn: asNullableText(form.parentColumn),
    createdAtColumn: asNullableText(form.createdAtColumn),
    writable: form.writable,
    valueProviderKey: asNullableText(form.valueProviderKey),
    providerStrategy: form.providerStrategy,
    aliases: [],
  };
}

export function createEmptyAliasForm(): AliasFormState {
  return {
    aliasCode: "",
    isActive: true,
  };
}

export function createAliasFormFromRecord(record: LookupTypeAlias | null): AliasFormState {
  return mapRecordOrEmpty(
    record,
    (current) => ({
      aliasCode: current.aliasCode,
      isActive: current.isActive,
    }),
    createEmptyAliasForm,
  );
}

export function mapAliasPayload(typeId: number, form: AliasFormState): InsertLookupTypeAlias {
  return {
    lookupTypeId: typeId,
    aliasCode: asTrimmedText(form.aliasCode),
    isActive: form.isActive,
  };
}

export function createEmptyValueForm(): ValueFormState {
  return {
    code: "",
    nameAr: "",
    orderIndex: 0,
    parentId: "",
    isActive: true,
  };
}

export function createValueFormFromRecord(record: LookupValue | null): ValueFormState {
  return mapRecordOrEmpty(
    record,
    (current) => ({
      code: current.code,
      nameAr: current.nameAr,
      orderIndex: current.orderIndex,
      parentId: asFormNumber(current.parentId),
      isActive: current.isActive,
    }),
    createEmptyValueForm,
  );
}

export function mapValuePayload(typeId: number, form: ValueFormState): InsertLookupValue {
  return {
    typeId,
    code: asTrimmedText(form.code),
    nameAr: asTrimmedText(form.nameAr),
    orderIndex: asNumberOrZero(form.orderIndex),
    parentId: asNullableNumber(form.parentId),
    isActive: form.isActive,
    metadata: null,
  };
}

export function createEmptyVirtualSeedForm(): VirtualSeedFormState {
  return {
    valueId: "",
    code: "",
    nameAr: "",
    orderIndex: 0,
    aliases: [],
    isActive: true,
  };
}

export function createVirtualSeedFormFromRecord(record: LookupVirtualValue | null): VirtualSeedFormState {
  return mapRecordOrEmpty(
    record,
    (current) => ({
      valueId: asFormNumber(current.valueId),
      code: current.code,
      nameAr: current.nameAr,
      orderIndex: current.orderIndex,
      aliases: [...current.aliases],
      isActive: current.isActive,
    }),
    createEmptyVirtualSeedForm,
  );
}

export function mapVirtualSeedPayload(
  typeId: number,
  form: VirtualSeedFormState,
): InsertLookupVirtualValue {
  return {
    lookupTypeId: typeId,
    valueId: asNumberOrZero(form.valueId),
    code: asTrimmedText(form.code),
    nameAr: asTrimmedText(form.nameAr),
    orderIndex: asNumberOrZero(form.orderIndex),
    aliases: form.aliases,
    isActive: form.isActive,
  };
}
