import type { UiPageConfig } from "@/types/ui";

export const FILES_CONFIG: UiPageConfig = {
  code: "files_management",
  nameAr: "إدارة الملفات والمرفقات",
  entityType: "files",
  layoutType: "list",
  columns: [
    { fieldCode: "id", nameAr: "#", columnType: "number", isVisible: true, isSortable: true },
    { fieldCode: "title", nameAr: "العنوان", columnType: "text", isVisible: true, isSortable: true, isFilterable: true },
    { fieldCode: "filenameDownload", nameAr: "اسم التنزيل", columnType: "text", isVisible: true, isSortable: true, isFilterable: true },
    { fieldCode: "type", nameAr: "النوع", columnType: "text", isVisible: true, isSortable: true, isFilterable: true },
    { fieldCode: "filesize", nameAr: "الحجم", columnType: "number", isVisible: true, isSortable: true },
    { fieldCode: "createdOn", nameAr: "تاريخ الإنشاء", columnType: "date", isVisible: true, isSortable: true },
    { fieldCode: "uploadedOn", nameAr: "تاريخ الرفع", columnType: "date", isVisible: true, isSortable: true },
  ],
  formFields: [
    { fieldCode: "storage", nameAr: "المخزن", fieldType: "text", isRequired: true, gridCols: 1, orderIndex: 1, defaultValue: "local" },
    { fieldCode: "filenameDownload", nameAr: "اسم التنزيل", fieldType: "text", isRequired: true, gridCols: 1, orderIndex: 2 },
    { fieldCode: "title", nameAr: "العنوان", fieldType: "text", isRequired: false, gridCols: 1, orderIndex: 3 },
    { fieldCode: "type", nameAr: "النوع", fieldType: "text", isRequired: false, gridCols: 1, orderIndex: 4 },
    { fieldCode: "folder", nameAr: "المجلد", fieldType: "number", isRequired: false, gridCols: 1, orderIndex: 5 },
    { fieldCode: "uploadedBy", nameAr: "رافع الملف", fieldType: "number", isRequired: false, gridCols: 1, orderIndex: 6 },
    { fieldCode: "description", nameAr: "الوصف", fieldType: "textarea", isRequired: false, gridCols: 2, orderIndex: 7 },
    { fieldCode: "tags", nameAr: "الوسوم", fieldType: "textarea", isRequired: false, gridCols: 2, orderIndex: 8 },
    { fieldCode: "metadata", nameAr: "Metadata", fieldType: "textarea", isRequired: false, gridCols: 2, orderIndex: 9 },
  ],
  filters: [],
};

export const DEFAULT_RELATIVE_DIRECTORY = "files";
export const DEFAULT_MAX_FILE_SIZE_MB = 25;

export const DEFAULT_ALLOWED_MIME_TYPES = [
  "image/jpeg",
  "image/png",
  "image/webp",
  "application/pdf",
  "application/zip",
  "application/x-zip-compressed",
  "application/msword",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  "application/vnd.ms-excel",
  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  "text/plain",
] as const;
