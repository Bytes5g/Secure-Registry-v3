#!/usr/bin/env node
import { buildDbConfig, connect } from "./_config.js";

const cfg = buildDbConfig();
console.log(`→ ${cfg.server}:${cfg.port} / ${cfg.database} as ${cfg.user}`);
console.log(`  encrypt=${cfg.options.encrypt} trustCert=${cfg.options.trustServerCertificate} timeout=${cfg.connectionTimeout}ms`);

const t0 = Date.now();
try {
  const pool = await connect();
  const r = await pool.request().query("SELECT DB_NAME() AS db, SUSER_NAME() AS who, @@VERSION AS v");
  console.log(`✓ Connected in ${Date.now() - t0}ms`);
  console.log("  DB :", r.recordset[0].db);
  console.log("  WHO:", r.recordset[0].who);
  console.log("  VER:", String(r.recordset[0].v).split("\n")[0].trim());
  await pool.close();
} catch (e) {
  console.error(`✗ Failed after ${Date.now() - t0}ms`);
  console.error("  message:", e.message);
  if (e.code) console.error("  code   :", e.code);
  if (e.code === "ETIMEOUT" || e.code === "ESOCKET") {
    console.error("  hint   : likely Azure SQL firewall blocking this host's outbound IP.");
    try {
      const ip = await fetch("https://api.ipify.org").then((r) => r.text());
      console.error("  IP     :", ip, "  ← add this to Azure SQL → Networking → Firewall rules");
    } catch { /* ignore */ }
  }
  if (e.originalError?.message) console.error("  detail :", e.originalError.message);
  process.exit(1);
}
