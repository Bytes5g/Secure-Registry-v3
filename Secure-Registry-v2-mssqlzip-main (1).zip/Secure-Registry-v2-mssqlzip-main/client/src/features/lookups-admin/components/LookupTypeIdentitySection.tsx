import { FormSection, ToggleCard } from "@/components/shared";
import { LookupTypeInputField, LookupTypeTextareaField } from "./LookupTypeFormFields";
import type { LookupTypeSectionProps } from "./LookupTypeSection.types";

export function LookupTypeIdentitySection({ value, setField }: LookupTypeSectionProps) {
  return (
    <FormSection
      title="الهوية الوظيفية"
      description="تعريف نوع القائمة المرجعية وما إذا كان مفعلاً ضمن النظام."
    >
      <div className="grid gap-4 md:grid-cols-2">
        <LookupTypeInputField
          id="lookup-code"
          label="الكود"
          value={value.code}
          onChange={(code) => setField("code", code)}
        />
        <LookupTypeInputField
          id="lookup-alias-code"
          label="الكود الالكتروني"
          value={value.aliasCode}
          onChange={(aliasCode) => setField("aliasCode", aliasCode)}
        />
        <LookupTypeInputField
          id="lookup-name-ar"
          label="الاسم بالعربية"
          value={value.nameAr}
          onChange={(nameAr) => setField("nameAr", nameAr)}
        />
      </div>

      <LookupTypeTextareaField
        id="lookup-description"
        label="الوصف"
        value={value.description}
        onChange={(description) => setField("description", description)}
      />

      <div className="grid gap-4 md:grid-cols-2">
        <ToggleCard
          title="مفعل"
          description="إظهار هذا النوع ضمن القوائم العاملة."
          checked={value.isActive}
          onCheckedChange={(checked) => setField("isActive", checked)}
        />
        <ToggleCard
          title="قابل للكتابة"
          description="يسمح بإدارة القيم الفعلية من الواجهة."
          checked={value.writable}
          onCheckedChange={(checked) => setField("writable", checked)}
        />
      </div>
    </FormSection>
  );
}
