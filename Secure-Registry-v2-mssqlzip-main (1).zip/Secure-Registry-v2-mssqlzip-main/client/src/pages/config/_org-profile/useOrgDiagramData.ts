import { useEffect, useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { fetchOrgTreeFlat } from "@/lib/api/org-admin";
import { apiRequest } from "@/lib/queryClient";

export type DiagramScope = "org" | "branch" | "unit";

export interface DiagramFilters {
  scope: DiagramScope;
  selectedBranchValue: string;
  selectedNodeId: number | null;
  nodeSearch: string;
  showBranchAssignments: boolean;
  showOnlySelectedUnitChildren: boolean;
  showUnitBranchesOnDiagram: boolean;
  showOrgChartStaff: boolean;
}

/**
 * Pure data layer for the org structure diagram.
 * Fetches tree, structure codes, branches, and computes derived sets.
 * Holds no UI/render concerns.
 */
export function useOrgDiagramData(orgId: number, filters: DiagramFilters) {
  const {
    scope,
    selectedBranchValue,
    selectedNodeId,
    nodeSearch,
    showBranchAssignments,
    showOnlySelectedUnitChildren,
    showUnitBranchesOnDiagram,
  } = filters;

  const isBranchScope = scope === "branch";
  const isUnitScope = scope === "unit";

  const { data: treeNodes = [], isLoading: treeLoading } = useQuery<any[]>({
    queryKey: ["org-entity-tree-flat", orgId],
    queryFn: () => fetchOrgTreeFlat(orgId),
    enabled: Number.isFinite(orgId) && orgId > 0,
  });

  const { data: structureCodes = [] } = useQuery<any[]>({
    queryKey: ["org-structure-codes"],
    queryFn: () => apiRequest("GET", "/api/org-structure-codes"),
  });

  const { data: allBranches = [], isLoading: branchesLoading } = useQuery<any[]>({
    queryKey: ["branches-all"],
    queryFn: () => apiRequest("GET", "/api/branches"),
  });

  const { data: orgEmployees = [], isLoading: employeesLoading } = useQuery<any[]>({
    queryKey: ["org-employees", orgId],
    queryFn: () => apiRequest("GET", `/api/org/organizations/${orgId}/employees`),
    enabled: Number.isFinite(orgId) && orgId > 0,
  });

  const structureById = useMemo(() => {
    const map = new Map<number, any>();
    for (const item of Array.isArray(structureCodes) ? structureCodes : []) {
      const id = Number(item?.id);
      if (Number.isFinite(id)) map.set(id, item);
    }
    return map;
  }, [structureCodes]);

  const branchesForOrg = useMemo(() => {
    const filtered = (Array.isArray(allBranches) ? allBranches : []).filter(
      (b) => Number(b?.orgId ?? b?.org_id) === orgId,
    );
    filtered.sort((a, b) => Number(a?.id ?? 0) - Number(b?.id ?? 0));
    return filtered;
  }, [allBranches, orgId]);

  const effectiveBranchId = useMemo(() => {
    if (!isBranchScope || selectedBranchValue === "none") return null;
    const id = Number(selectedBranchValue);
    return Number.isFinite(id) ? id : null;
  }, [isBranchScope, selectedBranchValue]);

  const { data: branchNodes = [] } = useQuery<any[]>({
    queryKey: ["branch-nodes", effectiveBranchId],
    queryFn: () =>
      effectiveBranchId
        ? apiRequest("GET", `/api/branches/${effectiveBranchId}/nodes`)
        : Promise.resolve([]),
    enabled: isBranchScope && !!effectiveBranchId && showBranchAssignments,
  });

  const assignedNodeIds = useMemo(() => {
    if (!isBranchScope || !showBranchAssignments) return new Set<number>();
    const ids = (Array.isArray(branchNodes) ? branchNodes : [])
      .map(
        (n) =>
          n.org_structure_node_id ??
          n.orgStructureNodeId ??
          n.orgStructureNodeID ??
          n.org_tree_node_id ??
          n.orgTreeNodeId,
      )
      .map((v) => Number(v))
      .filter((v) => Number.isFinite(v));
    return new Set(ids);
  }, [branchNodes, isBranchScope, showBranchAssignments]);

  const nodeTypeByNodeId = useMemo(() => {
    const map = new Map<number, string>();
    if (!isBranchScope || !showBranchAssignments || !effectiveBranchId) return map;
    for (const n of Array.isArray(branchNodes) ? branchNodes : []) {
      const rawId =
        n.org_structure_node_id ??
        n.orgStructureNodeId ??
        n.orgStructureNodeID ??
        n.org_tree_node_id ??
        n.orgTreeNodeId;
      const nodeId = Number(rawId);
      if (!Number.isFinite(nodeId)) continue;
      const name =
        n.node_type ??
        n.nodeType ??
        n.structure_name ??
        n.structureName ??
        n.node_type_name ??
        null;
      if (name != null && String(name).trim()) {
        map.set(nodeId, String(name));
      }
    }
    return map;
  }, [branchNodes, effectiveBranchId, isBranchScope, showBranchAssignments]);

  const parentById = useMemo(() => {
    const map = new Map<number, number | null>();
    for (const raw of Array.isArray(treeNodes) ? treeNodes : []) {
      const id = Number(raw?.id);
      const parentId = raw?.parentId ?? raw?.parent_id ?? null;
      if (Number.isFinite(id)) map.set(id, parentId == null ? null : Number(parentId));
    }
    return map;
  }, [treeNodes]);

  const filteredNodes = useMemo(() => {
    const q = nodeSearch.trim().toLowerCase();
    const list = (Array.isArray(treeNodes) ? treeNodes : []).slice();
    list.sort((a, b) => {
      const la = Number(a?.level ?? 0);
      const lb = Number(b?.level ?? 0);
      if (la !== lb) return la - lb;
      const oa = Number(a?.orderIndex ?? a?.order_index ?? 0);
      const ob = Number(b?.orderIndex ?? b?.order_index ?? 0);
      if (oa !== ob) return oa - ob;
      return String(a?.name ?? "").localeCompare(String(b?.name ?? ""));
    });
    if (!q) return list;
    return list.filter((n) => {
      const name = String(n?.name ?? "").toLowerCase();
      const code = String(n?.code ?? "").toLowerCase();
      return name.includes(q) || code.includes(q);
    });
  }, [nodeSearch, treeNodes]);

  const effectiveNodeId = useMemo(() => {
    if (selectedNodeId != null && Number.isFinite(selectedNodeId)) return selectedNodeId;
    const first = filteredNodes[0]?.id;
    const id = first == null ? null : Number(first);
    return Number.isFinite(id) ? id : null;
  }, [filteredNodes, selectedNodeId]);

  const focusNodeId = isUnitScope ? effectiveNodeId : selectedNodeId;
  const selectedUnitId = isUnitScope ? effectiveNodeId : null;
  const effectiveShowOnlySelectedUnitChildren = isUnitScope && showOnlySelectedUnitChildren;

  const selectedUnitChildrenIds = useMemo(() => {
    if (!selectedUnitId) return [] as number[];
    const children = (Array.isArray(treeNodes) ? treeNodes : [])
      .filter((n) => Number(n?.parentId ?? n?.parent_id ?? null) === selectedUnitId)
      .map((n) => Number(n?.id))
      .filter((id) => Number.isFinite(id));
    return Array.from(new Set(children));
  }, [selectedUnitId, treeNodes]);

  const { data: branchesByNode = [] } = useQuery<any[]>({
    queryKey: ["branches-by-node", effectiveNodeId],
    queryFn: () =>
      effectiveNodeId
        ? apiRequest("GET", `/api/branches/by-node/${effectiveNodeId}`)
        : Promise.resolve([]),
    enabled: isUnitScope && !!effectiveNodeId && showUnitBranchesOnDiagram,
  });

  const highlightedNodeIds = useMemo(() => {
    const out = new Set<number>();
    if (isBranchScope) {
      if (!showBranchAssignments) return out;
      for (const id of Array.from(assignedNodeIds)) {
        let current: number | null | undefined = id;
        while (current != null && Number.isFinite(current) && !out.has(current)) {
          out.add(current);
          current = parentById.get(current) ?? null;
        }
      }
      return out;
    }
    if (!focusNodeId) return out;
    if (effectiveShowOnlySelectedUnitChildren) {
      out.add(focusNodeId);
      for (const childId of selectedUnitChildrenIds) out.add(childId);
      return out;
    }
    let current: number | null | undefined = focusNodeId;
    while (current != null && Number.isFinite(current) && !out.has(current)) {
      out.add(current);
      current = parentById.get(current) ?? null;
    }
    return out;
  }, [
    assignedNodeIds,
    effectiveShowOnlySelectedUnitChildren,
    focusNodeId,
    isBranchScope,
    parentById,
    selectedUnitChildrenIds,
    showBranchAssignments,
  ]);

  const employeesByUnitId = useMemo(() => {
    const map = new Map<number, any[]>();
    for (const row of Array.isArray(orgEmployees) ? orgEmployees : []) {
      const unitId = Number(row.orgStructureId ?? row.org_structure_id);
      if (!Number.isFinite(unitId)) continue;
      const list = map.get(unitId) ?? [];
      list.push(row);
      map.set(unitId, list);
    }
    return map;
  }, [orgEmployees]);

  const managerByUnitId = useMemo(() => {
    const map = new Map<number, { fullName: string; roleTitleName: string | null }>();
    employeesByUnitId.forEach((list, unitId) => {
      const branchFiltered =
        isBranchScope && effectiveBranchId != null
          ? list.filter((r: any) => Number(r.branchId ?? r.branch_id) === effectiveBranchId)
          : list;
      const manager = branchFiltered.find((r: any) => Boolean(r.isManager ?? r.is_manager));
      const fullName = manager ? String(manager.fullName ?? manager.full_name ?? "") : "";
      if (!fullName.trim()) return;
      const roleTitleNameRaw =
        (branchFiltered[0]?.roleTitleName ?? branchFiltered[0]?.role_title_name ?? null) ??
        (manager ? (manager.roleTitleName ?? manager.role_title_name ?? null) : null);
      const roleTitleName =
        roleTitleNameRaw && String(roleTitleNameRaw).trim() ? String(roleTitleNameRaw) : null;
      map.set(unitId, { fullName, roleTitleName });
    });
    return map;
  }, [effectiveBranchId, employeesByUnitId, isBranchScope]);

  return {
    treeNodes: Array.isArray(treeNodes) ? treeNodes : [],
    branchesForOrg,
    branchesByNode: Array.isArray(branchesByNode) ? branchesByNode : [],
    structureById,
    nodeTypeByNodeId,
    parentById,
    filteredNodes,
    assignedNodeIds,
    highlightedNodeIds,
    selectedUnitChildrenIds,
    effectiveBranchId,
    effectiveNodeId: focusNodeId,
    selectedUnitId,
    employeesByUnitId,
    managerByUnitId,
    isLoading: treeLoading || branchesLoading || employeesLoading,
    treeLoading,
  };
}

/** Auto-select first available branch when scope is `branch`. */
export function useAutoSelectFirstBranch(
  scope: DiagramScope,
  selectedBranchValue: string,
  branchesForOrg: any[],
  setSelectedBranchValue: (v: string) => void,
) {
  useEffect(() => {
    if (scope !== "branch" || selectedBranchValue !== "none") return;
    const first = branchesForOrg[0]?.id;
    if (first != null) setSelectedBranchValue(String(first));
  }, [branchesForOrg, scope, selectedBranchValue, setSelectedBranchValue]);
}
