import { useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { genericApi } from "@/lib/api/generic";
import { buildUiDataSourceParams, getTabDataSource, type UiPageDetailsLike } from "@/lib/ui/uiTabDataSources";

export function useUiTabDataSourceQuery(args: {
  details: UiPageDetailsLike | undefined | null;
  tabKey: string;
  purpose: string;
  criteria: Record<string, any>;
  enabled?: boolean;
  fallbackDataSourceKey?: string | null;
  fallbackBuildParams?: (criteria: Record<string, any>) => Record<string, any>;
  limitDefault?: number;
}) {
  const resolved = useMemo(
    () => getTabDataSource(args.details, args.tabKey, args.purpose),
    [args.details, args.tabKey, args.purpose],
  );
  const dataSourceKey = resolved?.dataSourceKey ?? (args.fallbackDataSourceKey ? String(args.fallbackDataSourceKey) : null);

  const query = useQuery<{ data: any[]; nextCursor: number | null }>({
    queryKey: ["ui-tab-ds", "query", dataSourceKey ?? "", args.purpose, args.criteria],
    enabled: Boolean(args.enabled ?? true) && Boolean(dataSourceKey),
    queryFn: async () => {
      const params =
        resolved?.mapping != null
          ? buildUiDataSourceParams({ criteria: args.criteria, mapping: resolved.mapping, limitDefault: args.limitDefault ?? 1 })
          : args.fallbackBuildParams
            ? args.fallbackBuildParams(args.criteria)
            : buildUiDataSourceParams({ criteria: args.criteria, mapping: null, limitDefault: args.limitDefault ?? 1 });
      return genericApi.executeUiDataSource(String(dataSourceKey), params);
    },
  });

  return { dataSourceKey, mapping: resolved?.mapping ?? null, query };
}

