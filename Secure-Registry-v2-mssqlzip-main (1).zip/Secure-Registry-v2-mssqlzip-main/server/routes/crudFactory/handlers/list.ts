import type { Router } from "express";
import { buildWhereFromQuery, executeList } from "@core/database";
import type { TableDescriptor } from "../types";
import { getTableInfo } from "../sql/table-info";

export function registerListHandler(router: Router, descriptor: TableDescriptor) {
  router.get("/", async (req, res) => {
    try {
      const tableInfo = await getTableInfo(descriptor);
      const { columns, columnMap } = tableInfo;
      const defaultSortColumn = columnMap.get("id") || columns[0];
      const queryParams = req.query as Record<string, any>;

      const page = Number(queryParams.page ?? 1);
      const limit = Number(queryParams.limit ?? 50);
      const sort = queryParams.sort as string | undefined;
      const order =
        (queryParams.order as string | undefined)?.toLowerCase() === "desc" ? "DESC" : "ASC";
      const safeLimit = Number.isFinite(limit) && limit > 0 ? Math.min(limit, 200) : 50;
      const safePage = Number.isFinite(page) && page > 0 ? page : 1;
      const offset = (safePage - 1) * safeLimit;
      const sortColumn = (sort && columnMap.get(sort)) || defaultSortColumn;

      const { whereClause, params } = buildWhereFromQuery(queryParams, columnMap);
      const data = await executeList({
        tableInfo,
        whereClause,
        params,
        sortDbKey: sortColumn.dbKey,
        order,
        offset,
        limit: safeLimit,
      });

      res.json({ data, page: safePage, limit: safeLimit });
    } catch (e: any) {
      console.error(`Error in GET /api/${descriptor.exportName}:`, e);
      res.status(500).json({ error: e.message });
    }
  });
}
