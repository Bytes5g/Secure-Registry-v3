import { Button } from "@secure-registry/components-ui";
import type { LookupTypeFormState } from "../models/lookups-admin-models";
import { LookupTypeIdentitySection } from "./LookupTypeIdentitySection";
import { LookupTypeProviderSection } from "./LookupTypeProviderSection";
import { LookupTypeTableBindingSection } from "./LookupTypeTableBindingSection";

interface LookupTypeFormProps {
  value: LookupTypeFormState;
  onChange: (value: LookupTypeFormState) => void;
  onSubmit: () => void;
  isSubmitting: boolean;
}

export function LookupTypeForm({
  value,
  onChange,
  onSubmit,
  isSubmitting,
}: LookupTypeFormProps) {
  const setField = <K extends keyof LookupTypeFormState>(field: K, nextValue: LookupTypeFormState[K]) => {
    onChange({ ...value, [field]: nextValue });
  };

  return (
    <div className="space-y-6">
      <LookupTypeIdentitySection value={value} setField={setField} />
      <LookupTypeTableBindingSection value={value} setField={setField} />
      <LookupTypeProviderSection value={value} setField={setField} />

      <div className="flex justify-end">
        <Button type="button" onClick={onSubmit} disabled={isSubmitting}>
          {isSubmitting ? "جاري الحفظ..." : "حفظ النوع"}
        </Button>
      </div>
    </div>
  );
}
