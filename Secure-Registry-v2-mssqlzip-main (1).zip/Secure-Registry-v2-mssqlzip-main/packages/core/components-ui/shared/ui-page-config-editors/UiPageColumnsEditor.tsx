import { useMemo, useState } from "react";
import { Button } from "../../ui/button";
import { Checkbox } from "../../ui/checkbox";
import { Input } from "../../ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../../ui/select";
import { ChevronDown, ChevronUp, GripVertical, Plus, Trash2 } from "lucide-react";

import { COLUMN_TYPE_OPTIONS } from "./constants";
import type { LookupTypeOption, UiPageColumnLike } from "./types";
import { normalizeOrder, moveItem, stopPropagation } from "./utils";

export function UiPageColumnsEditor(props: {
  value: UiPageColumnLike[];
  onChange: (next: UiPageColumnLike[]) => void;
  lookupTypeOptions: LookupTypeOption[];
  selectedIndex?: number | null;
  onSelectIndex?: (index: number | null) => void;
}) {
  const [dragIndex, setDragIndex] = useState<number | null>(null);
  const [overIndex, setOverIndex] = useState<number | null>(null);

  const columnCodeCounts = useMemo(() => {
    const counts = new Map<string, number>();
    for (const col of props.value ?? []) {
      const k = String(col?.fieldCode ?? "").trim();
      if (!k) continue;
      counts.set(k, (counts.get(k) ?? 0) + 1);
    }
    return counts;
  }, [props.value]);

  const columnDuplicateCodes = useMemo(
    () => Array.from(columnCodeCounts.entries()).filter(([, cnt]) => cnt > 1).map(([k]) => k),
    [columnCodeCounts]
  );

  const add = () => {
    props.onChange(
      normalizeOrder([
        ...(props.value ?? []),
        {
          fieldCode: "",
          nameAr: "",
          columnType: "text",
          isVisible: true,
          isSortable: true,
          isFilterable: false,
          orderIndex: (props.value?.length ?? 0) + 1,
        },
      ])
    );
  };

  const update = (index: number, patch: Partial<UiPageColumnLike>) => {
    const next = props.value.map((item, idx) => (idx === index ? { ...item, ...patch } : item));
    props.onChange(normalizeOrder(next));
  };

  const remove = (index: number) => {
    const next = props.value.filter((_, idx) => idx !== index);
    props.onChange(normalizeOrder(next));
  };

  const moveUp = (index: number) => {
    if (index <= 0) return;
    props.onChange(normalizeOrder(moveItem(props.value, index, index - 1)));
  };

  const moveDown = (index: number) => {
    if (index >= props.value.length - 1) return;
    props.onChange(normalizeOrder(moveItem(props.value, index, index + 1)));
  };

  const reorder = (from: number, to: number) => {
    if (from === to) return;
    if (from < 0 || to < 0) return;
    if (from >= props.value.length || to >= props.value.length) return;
    props.onChange(normalizeOrder(moveItem(props.value, from, to)));
  };

  const lookupTypeItems = useMemo(
    () =>
      (props.lookupTypeOptions ?? [])
        .map((t) => ({ value: String(t.id), label: `${t.id} - ${t.nameAr}` }))
        .sort((a, b) => a.label.localeCompare(b.label, "ar")),
    [props.lookupTypeOptions]
  );

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <div className="text-sm text-muted-foreground">الأعمدة (Columns)</div>
        <Button type="button" variant="outline" size="sm" onClick={add}>
          <Plus className="h-4 w-4 me-2" />
          إضافة عمود
        </Button>
      </div>

      {columnDuplicateCodes.length > 0 ? (
        <div className="text-sm text-destructive">يوجد تكرار في fieldCode: {columnDuplicateCodes.join("، ")}</div>
      ) : null}

      <div className="space-y-2">
        {(props.value ?? []).map((col, index) => {
          const lookupValue = col.lookupTypeId == null ? "none" : String(col.lookupTypeId);
          const showLookup = col.columnType === "select";
          const fieldCodeTrimmed = String(col.fieldCode ?? "").trim();
          const isDuplicate = fieldCodeTrimmed ? (columnCodeCounts.get(fieldCodeTrimmed) ?? 0) > 1 : false;
          const isOver = overIndex === index && dragIndex != null && dragIndex !== index;
          const isSelected = props.selectedIndex === index;

          return (
            <div
              key={`${index}-${col.fieldCode}`}
              className={`rounded-md border p-3 space-y-3 ${isOver ? "border-primary" : ""} ${isSelected ? "ring-2 ring-ring" : ""}`}
              draggable
              onClick={() => props.onSelectIndex?.(index)}
              onDragStart={() => {
                setDragIndex(index);
                setOverIndex(null);
              }}
              onDragOver={(e) => {
                e.preventDefault();
                setOverIndex(index);
              }}
              onDragEnd={() => {
                setDragIndex(null);
                setOverIndex(null);
              }}
              onDrop={(e) => {
                e.preventDefault();
                if (dragIndex != null) reorder(dragIndex, index);
                setDragIndex(null);
                setOverIndex(null);
              }}
            >
              <div className="grid gap-2 md:grid-cols-7">
                <div className="flex items-end justify-center">
                  <div className="h-9 w-9 flex items-center justify-center text-muted-foreground">
                    <GripVertical className="h-4 w-4" />
                  </div>
                </div>
                <div className="space-y-1">
                  <div className="text-xs text-muted-foreground">fieldCode</div>
                  <Input
                    value={col.fieldCode}
                    onChange={(e) => update(index, { fieldCode: e.target.value })}
                    onClick={stopPropagation}
                    placeholder="name"
                    className={isDuplicate ? "border-destructive focus-visible:ring-destructive" : undefined}
                  />
                </div>
                <div className="space-y-1">
                  <div className="text-xs text-muted-foreground">الاسم</div>
                  <Input value={col.nameAr} onChange={(e) => update(index, { nameAr: e.target.value })} onClick={stopPropagation} placeholder="الاسم" />
                </div>
                <div className="space-y-1">
                  <div className="text-xs text-muted-foreground">النوع</div>
                  <Select value={String(col.columnType ?? "text")} onValueChange={(v) => update(index, { columnType: v as any })}>
                    <SelectTrigger onClick={stopPropagation}>
                      <SelectValue placeholder="اختر..." />
                    </SelectTrigger>
                    <SelectContent>
                      {COLUMN_TYPE_OPTIONS.map((opt) => (
                        <SelectItem key={opt.value} value={opt.value}>
                          {opt.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1">
                  <div className="text-xs text-muted-foreground">Lookup</div>
                  <Select value={lookupValue} onValueChange={(v) => update(index, { lookupTypeId: v === "none" ? undefined : Number(v) })} disabled={!showLookup}>
                    <SelectTrigger onClick={stopPropagation}>
                      <SelectValue placeholder={showLookup ? "اختر..." : "غير متاح"} />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">بدون</SelectItem>
                      {lookupTypeItems.map((opt) => (
                        <SelectItem key={opt.value} value={opt.value}>
                          {opt.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1">
                  <div className="text-xs text-muted-foreground">width</div>
                  <Input value={col.width ?? ""} onChange={(e) => update(index, { width: e.target.value || undefined })} onClick={stopPropagation} placeholder="160px" />
                </div>
                <div className="flex items-end justify-end gap-2">
                  <Button
                    type="button"
                    variant="outline"
                    size="icon"
                    onClick={(e) => {
                      stopPropagation(e);
                      moveUp(index);
                    }}
                    disabled={index === 0}
                  >
                    <ChevronUp className="h-4 w-4" />
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    size="icon"
                    onClick={(e) => {
                      stopPropagation(e);
                      moveDown(index);
                    }}
                    disabled={index === props.value.length - 1}
                  >
                    <ChevronDown className="h-4 w-4" />
                  </Button>
                  <Button
                    type="button"
                    variant="destructive"
                    size="icon"
                    onClick={(e) => {
                      stopPropagation(e);
                      remove(index);
                    }}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              <div className="flex items-center gap-6">
                <label className="flex items-center gap-2 text-sm">
                  <Checkbox checked={Boolean(col.isVisible)} onCheckedChange={(v) => update(index, { isVisible: Boolean(v) })} onClick={stopPropagation} />
                  ظاهر
                </label>
                <label className="flex items-center gap-2 text-sm">
                  <Checkbox checked={Boolean(col.isSortable)} onCheckedChange={(v) => update(index, { isSortable: Boolean(v) })} onClick={stopPropagation} />
                  قابل للفرز
                </label>
                <label className="flex items-center gap-2 text-sm">
                  <Checkbox checked={Boolean(col.isFilterable)} onCheckedChange={(v) => update(index, { isFilterable: Boolean(v) })} onClick={stopPropagation} />
                  قابل للتصفية
                </label>
              </div>
            </div>
          );
        })}

        {(props.value?.length ?? 0) === 0 ? <div className="text-sm text-muted-foreground border rounded-md p-4">لا توجد أعمدة حالياً</div> : null}
      </div>
    </div>
  );
}

