import { PersonsManagementView } from "@/features/persons/PersonsManagementView";

export default function PersonsManagementPage() {
  return <PersonsManagementView />;
}
