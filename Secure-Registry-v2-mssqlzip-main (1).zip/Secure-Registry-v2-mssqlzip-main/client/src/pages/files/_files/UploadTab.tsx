import {
  Button,
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  Input,
  Label,
  Textarea,
} from "@secure-registry/components-ui";
import { Upload } from "lucide-react";
import { DEFAULT_MAX_FILE_SIZE_MB, DEFAULT_RELATIVE_DIRECTORY } from "./config";
import type { FilesPageController } from "./useFilesPage";

export function UploadTab({ ctrl }: { ctrl: FilesPageController }) {
  const { settingsQuery, form, setForm, uploadMutation } = ctrl;
  const relativeDirectory =
    settingsQuery.data?.data.relativeDirectory ?? DEFAULT_RELATIVE_DIRECTORY;
  const maxFileSizeMB = settingsQuery.data?.data.maxFileSizeMB ?? DEFAULT_MAX_FILE_SIZE_MB;

  return (
    <Card>
      <CardHeader>
        <CardTitle>رفع ملف جديد</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="text-xs text-muted-foreground mb-4">
          المسار: {relativeDirectory} | الحد الأقصى: {maxFileSizeMB}MB
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2 md:col-span-2">
            <Label>الملف</Label>
            <Input
              type="file"
              onChange={(e) =>
                setForm((prev) => ({ ...prev, file: e.target.files?.[0] ?? null }))
              }
            />
          </div>

          <div className="space-y-2">
            <Label>العنوان</Label>
            <Input
              value={form.title}
              onChange={(e) => setForm((p) => ({ ...p, title: e.target.value }))}
            />
          </div>

          <div className="space-y-2">
            <Label>المجلد (ID)</Label>
            <Input
              value={form.folder}
              onChange={(e) => setForm((p) => ({ ...p, folder: e.target.value }))}
            />
          </div>

          <div className="space-y-2 md:col-span-2">
            <Label>الوصف</Label>
            <Textarea
              value={form.description}
              onChange={(e) => setForm((p) => ({ ...p, description: e.target.value }))}
            />
          </div>

          <div className="space-y-2 md:col-span-2">
            <Label>الوسوم</Label>
            <Textarea
              value={form.tags}
              onChange={(e) => setForm((p) => ({ ...p, tags: e.target.value }))}
            />
          </div>
        </div>

        <div className="flex justify-end pt-4">
          <Button
            disabled={uploadMutation.isPending}
            onClick={() => uploadMutation.mutate(undefined)}
          >
            <Upload className="me-2 h-4 w-4" />
            {uploadMutation.isPending ? "جاري الرفع..." : "رفع"}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
