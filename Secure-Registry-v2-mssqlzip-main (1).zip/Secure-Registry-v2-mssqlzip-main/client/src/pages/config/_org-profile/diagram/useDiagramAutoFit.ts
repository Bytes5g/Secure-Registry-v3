import { useEffect, type MutableRefObject } from "react";

interface AutoFitArgs {
  flowRef: MutableRefObject<any>;
  focusOnly: boolean;
  scope: "org" | "branch" | "unit";
  effectiveBranchId: number | null;
  effectiveNodeId: number | null;
  highlightedCount: number;
  selectedUnitId: number | null;
  visibleNodeCount: number;
  layoutNonce: number;
}

/**
 * Re-centers the canvas whenever the *meaningful* view context changes:
 * view-mode toggle, selected branch/unit, focus subset, or relayout nonce.
 * Fires regardless of focusOnly so users always land on a sensible viewport
 * after switching modes (was previously gated to focusOnly only).
 */
export function useDiagramAutoFit(args: AutoFitArgs) {
  useEffect(() => {
    const instance = args.flowRef.current;
    if (!instance?.fitView) return;
    if (args.visibleNodeCount === 0) return;

    // Defer to next tick so React Flow has applied node positions first.
    const t = setTimeout(() => instance.fitView({ padding: 0.2, duration: 250 }), 0);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    args.effectiveBranchId,
    args.effectiveNodeId,
    args.focusOnly,
    args.highlightedCount,
    args.layoutNonce,
    args.selectedUnitId,
    args.scope,
    args.visibleNodeCount,
  ]);
}
