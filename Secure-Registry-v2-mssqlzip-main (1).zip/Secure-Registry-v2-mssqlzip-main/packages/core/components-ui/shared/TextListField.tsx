import { X } from "lucide-react";
import { Badge } from "../ui/badge";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Label } from "../ui/label";
import { cn } from "../lib/utils";

interface TextListFieldProps {
  label: string;
  value: string[];
  onChange: (value: string[]) => void;
  placeholder?: string;
  helperText?: string;
  className?: string;
}

function normalizeList(input: string[]): string[] {
  return Array.from(new Set(input.map((entry) => entry.trim()).filter(Boolean)));
}

export function TextListField({
  label,
  value,
  onChange,
  placeholder = "أدخل قيمة ثم اضغط إضافة",
  helperText,
  className,
}: TextListFieldProps) {
  const items = normalizeList(value);

  return (
    <div className={cn("space-y-3", className)}>
      <Label>{label}</Label>
      <div className="flex gap-2">
        <Input
          placeholder={placeholder}
          onKeyDown={(event) => {
            if (event.key !== "Enter") {
              return;
            }

            event.preventDefault();
            const target = event.currentTarget;
            const nextValue = target.value.trim();
            if (!nextValue) {
              return;
            }

            onChange(normalizeList([...items, nextValue]));
            target.value = "";
          }}
        />
        <Button
          type="button"
          variant="outline"
          onClick={(event) => {
            const root = event.currentTarget.parentElement;
            const input = root?.querySelector("input");
            const nextValue = input?.value?.trim();
            if (!nextValue) {
              return;
            }

            onChange(normalizeList([...items, nextValue]));
            if (input) {
              input.value = "";
            }
          }}
        >
          إضافة
        </Button>
      </div>

      {helperText ? <p className="text-sm text-muted-foreground">{helperText}</p> : null}

      <div className="flex min-h-10 flex-wrap gap-2 rounded-md border border-dashed p-3">
        {items.length > 0 ? (
          items.map((item) => (
            <Badge key={item} variant="secondary" className="gap-1">
              {item}
              <button
                type="button"
                className="rounded-full hover:text-destructive"
                onClick={() => onChange(items.filter((entry) => entry !== item))}
              >
                <X className="h-3 w-3" />
              </button>
            </Badge>
          ))
        ) : (
          <span className="text-sm text-muted-foreground">لا توجد عناصر مضافة</span>
        )}
      </div>
    </div>
  );
}
