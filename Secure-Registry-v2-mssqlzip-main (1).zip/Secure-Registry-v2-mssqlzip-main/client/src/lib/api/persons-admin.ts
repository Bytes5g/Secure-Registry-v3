import type { InsertPerson, Person, PersonPhoto } from "@shared/schema";

export interface PersonListItem {
  id: number;
  fullName: string;
  genderName: string | null;
  nationalityName: string | null;
  maritalName: string | null;
  dateOfBirth: string | null;
  isActive: boolean;
}

export interface PersonContactItem {
  id: number;
  categoryId: number;
  categoryName: string | null;
  typeId: number;
  typeName: string | null;
  providerId: number | null;
  providerName: string | null;
  contactValue: string;
  countryCode: string | null;
  isWorkRelated: boolean;
  notes: string | null;
  createdAt: string | null;
}

export interface PersonAssignmentItem {
  id: number;
  orgId: number;
  orgName: string | null;
  branchId: number;
  branchName: string | null;
  orgStructureId: number;
  orgStructureName: string | null;
  isManager: boolean;
  createdAt: string | null;
}

export interface PersonLinkedFileItem {
  id: number;
  role: string;
  isPrimary: boolean;
  createdAt: string | null;
  file: {
    id: number;
    filePath: string;
    fileName: string | null;
    title: string | null;
    mimeType: string | null;
    size: number | null;
    description: string | null;
    uploadedOn: string | null;
  };
}

export async function fetchPersons(params?: { search?: string; limit?: number }): Promise<PersonListItem[]> {
  const qs = new URLSearchParams();
  if (params?.search) qs.set("search", params.search);
  if (params?.limit) qs.set("limit", String(params.limit));
  const url = qs.toString() ? `/api/persons?${qs.toString()}` : "/api/persons";
  const response = await fetch(url);
  if (!response.ok) throw new Error("Failed to fetch persons");
  const json = await response.json();
  return Array.isArray(json?.data) ? json.data : [];
}

export interface PersonsSearchParams {
  q?: string;
  firstName?: string;
  familyName?: string;
  personId?: number;
  orgId?: number;
  branchId?: number;
  orgStructureId?: number;
  genderId?: number;
  nationalityId?: number;
  maritalStatusId?: number;
  isActive?: boolean;
  cursor?: number;
  limit?: number;
}

export interface PersonsSearchResult {
  data: Array<PersonListItem & {
    orgId: number | null;
    orgName: string | null;
    branchId: number | null;
    branchName: string | null;
    orgStructureId: number | null;
    orgStructureName: string | null;
    isManager: boolean | null;
  }>;
  nextCursor: number | null;
}

export async function searchPersons(params: PersonsSearchParams): Promise<PersonsSearchResult> {
  const qs = new URLSearchParams();
  if (params.q) qs.set("q", params.q);
  if (params.firstName) qs.set("firstName", params.firstName);
  if (params.familyName) qs.set("familyName", params.familyName);
  if (params.personId != null) qs.set("personId", String(params.personId));
  if (params.orgId != null) qs.set("orgId", String(params.orgId));
  if (params.branchId != null) qs.set("branchId", String(params.branchId));
  if (params.orgStructureId != null) qs.set("orgStructureId", String(params.orgStructureId));
  if (params.genderId != null) qs.set("genderId", String(params.genderId));
  if (params.nationalityId != null) qs.set("nationalityId", String(params.nationalityId));
  if (params.maritalStatusId != null) qs.set("maritalStatusId", String(params.maritalStatusId));
  if (typeof params.isActive === "boolean") qs.set("isActive", params.isActive ? "1" : "0");
  if (params.cursor != null) qs.set("cursor", String(params.cursor));
  if (params.limit != null) qs.set("limit", String(params.limit));
  const url = `/api/persons/search?${qs.toString()}`;
  const response = await fetch(url);
  if (!response.ok) throw new Error("Failed to search persons");
  return response.json();
}

export async function fetchPerson(id: number): Promise<Person> {
  const response = await fetch(`/api/persons/${id}`);
  if (!response.ok) throw new Error("Failed to fetch person");
  return response.json();
}

export async function updatePerson(id: number, patch: Partial<InsertPerson>): Promise<Person> {
  const response = await fetch(`/api/persons/${id}`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(patch),
  });
  if (!response.ok) throw new Error("Failed to update person");
  return response.json();
}

export async function fetchPersonPhoto(personId: number): Promise<PersonPhoto | null> {
  const response = await fetch(`/api/persons/${personId}/photo`);
  if (!response.ok) throw new Error("Failed to fetch person photo");
  return response.json();
}

export async function uploadPersonPhoto(personId: number, file: File, description?: string): Promise<PersonPhoto> {
  const formData = new FormData();
  formData.append("photo", file);
  if (description) {
    formData.append("description", description);
  }

  const response = await fetch(`/api/persons/${personId}/photo`, {
    method: "POST",
    body: formData,
  });
  if (!response.ok) throw new Error("Failed to upload person photo");
  return response.json();
}

export async function setPersonPhotoFromExisting(personId: number, fileId: number): Promise<PersonPhoto> {
  const response = await fetch(`/api/persons/${personId}/photo`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ fileId }),
  });
  if (!response.ok) throw new Error("Failed to set person photo");
  return response.json();
}

export async function deletePersonPhoto(personId: number): Promise<void> {
  const response = await fetch(`/api/persons/${personId}/photo`, { method: "DELETE" });
  if (!response.ok) throw new Error("Failed to delete person photo");
}

export async function fetchPersonContacts(personId: number): Promise<PersonContactItem[]> {
  const response = await fetch(`/api/persons/${personId}/contacts`);
  if (!response.ok) throw new Error("Failed to fetch person contacts");
  const json = await response.json();
  return Array.isArray(json?.data) ? json.data : [];
}

export async function fetchPersonAssignments(personId: number): Promise<PersonAssignmentItem[]> {
  const response = await fetch(`/api/persons/${personId}/assignments`);
  if (!response.ok) throw new Error("Failed to fetch person assignments");
  const json = await response.json();
  return Array.isArray(json?.data) ? json.data : [];
}

export async function createPersonAssignment(
  personId: number,
  payload: { orgId: number; branchId: number; orgStructureId: number; isManager?: boolean },
): Promise<PersonAssignmentItem> {
  const response = await fetch(`/api/persons/${personId}/assignments`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  if (!response.ok) throw new Error("Failed to create person assignment");
  return response.json();
}

export async function fetchPersonFiles(personId: number, role?: string): Promise<PersonLinkedFileItem[]> {
  const qs = new URLSearchParams();
  if (role) qs.set("role", role);
  const url = qs.toString() ? `/api/persons/${personId}/files?${qs.toString()}` : `/api/persons/${personId}/files`;
  const response = await fetch(url);
  if (!response.ok) throw new Error("Failed to fetch person files");
  const json = await response.json();
  return Array.isArray(json?.data) ? json.data : [];
}
