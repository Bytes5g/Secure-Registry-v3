import helmet from "helmet";
import compression from "compression";
import cors from "cors";
import rateLimit from "express-rate-limit";
import type { Express } from "express";

export function applySecurityMiddleware(app: Express): void {
  app.use(
    helmet({
      contentSecurityPolicy:
        process.env.NODE_ENV === "development"
          ? {
              useDefaults: true,
              directives: {
                "default-src": ["'self'"],
                "script-src": ["'self'", "'unsafe-inline'"],
                "style-src": ["'self'", "'unsafe-inline'"],
                "style-src-elem": ["'self'", "'unsafe-inline'"],
                "img-src": ["'self'", "data:"],
                "font-src": ["'self'", "data:"],
                "connect-src": ["'self'", "ws://localhost:*", "http://localhost:*"],
                "worker-src": ["'self'", "blob:"],
                "frame-ancestors": ["'self'"],
              },
            }
          : false,
      crossOriginEmbedderPolicy: false,
    }),
  );

  app.use(compression());

  app.use(
    cors({
      origin: process.env.CORS_ORIGIN ? new RegExp(process.env.CORS_ORIGIN) : true,
      credentials: true,
    }),
  );

  app.use(
    rateLimit({
      windowMs: 60 * 1000,
      max: 2000,
      standardHeaders: true,
      legacyHeaders: false,
    }),
  );
}
