import { useCallback } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import type { InsertGeoAdminUnit } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { createGeoUnit, deleteGeoUnit, updateGeoUnit } from "@/lib/api/geo-admin";

interface Options {
  onCreateSuccess?: () => void;
  onUpdateSuccess?: () => void;
  onDeleteSuccess?: () => void;
}

export function useGeoMutations(options: Options = {}) {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const invalidate = useCallback(
    () => queryClient.invalidateQueries({ queryKey: ["geo"] }),
    [queryClient],
  );

  const onError = useCallback(
    (e: Error) => toast({ title: "خطأ", description: e.message, variant: "destructive" }),
    [toast],
  );

  const create = useMutation({
    mutationFn: createGeoUnit,
    onSuccess: () => {
      invalidate();
      options.onCreateSuccess?.();
      toast({ title: "تمت الإضافة بنجاح" });
    },
    onError,
  });

  const update = useMutation({
    mutationFn: ({ id, data }: { id: number; data: Partial<InsertGeoAdminUnit> }) =>
      updateGeoUnit(id, data),
    onSuccess: () => {
      invalidate();
      options.onUpdateSuccess?.();
      toast({ title: "تم التحديث بنجاح" });
    },
    onError,
  });

  const remove = useMutation({
    mutationFn: deleteGeoUnit,
    onSuccess: () => {
      invalidate();
      options.onDeleteSuccess?.();
      toast({ title: "تم الحذف بنجاح" });
    },
    onError,
  });

  return { create, update, remove };
}
