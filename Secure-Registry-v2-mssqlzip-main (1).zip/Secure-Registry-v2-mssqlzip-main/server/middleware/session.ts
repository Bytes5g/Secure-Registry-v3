import session from "express-session";
import type { Express } from "express";
import { MssqlSessionStore } from "../session-store";

export function applySessionMiddleware(app: Express): void {
  if (process.env.NODE_ENV === "production" && !process.env.SESSION_SECRET) {
    throw new Error("SESSION_SECRET is required in production");
  }

  app.use(
    session({
      store: new MssqlSessionStore(),
      secret: process.env.SESSION_SECRET || "dev_session_secret_change_me",
      cookie: {
        maxAge: 7 * 24 * 60 * 60 * 1000,
        httpOnly: true,
        secure: process.env.NODE_ENV === "production",
        sameSite: "lax",
      },
      resave: false,
      saveUninitialized: false,
      rolling: true,
      name: "sr.sid",
    }),
  );
}
