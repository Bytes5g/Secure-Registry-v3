import { FormSection } from "@/components/shared";
import { LookupTypeInputField, LookupTypeStrategyField } from "./LookupTypeFormFields";
import type { LookupTypeSectionProps } from "./LookupTypeSection.types";

export function LookupTypeProviderSection({ value, setField }: LookupTypeSectionProps) {
  return (
    <FormSection
      title="مزود القيم"
      description="تحديد مزود قيم افتراضي وآلية الدمج عندما تكون القيم مصدرها provider أو fallback."
    >
      <div className="grid gap-4 md:grid-cols-2">
        <LookupTypeInputField
          id="provider-key"
          label="مفتاح المزود"
          value={value.valueProviderKey}
          placeholder="مثال: geo:levels"
          onChange={(valueProviderKey) => setField("valueProviderKey", valueProviderKey)}
        />
        <LookupTypeStrategyField
          value={value.providerStrategy}
          onChange={(providerStrategy) => setField("providerStrategy", providerStrategy)}
        />
      </div>
    </FormSection>
  );
}
