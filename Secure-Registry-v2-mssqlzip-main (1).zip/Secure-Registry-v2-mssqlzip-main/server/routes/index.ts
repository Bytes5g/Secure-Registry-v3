import type { Express } from "express";
import { lookupModule } from "@core/database";
import lookupsRouter from "./lookups";
import geoRouter from "./geo";
import orgStructureRouter from "./org-structure";
import branchRouter from "./branch";
import authRouter from "./auth";
import filesRouter from "./files";
import dashboardRouter from "./dashboard";
import mapsRouter from "./maps";
import uiRouter from "./ui";
import personsRouter from "./persons";
import { requireApiAuth } from "../middleware/authz";

export async function registerRoutes(app: Express) {
  app.use((req, res, next) => {
    const u = req.originalUrl || req.url;
    if (u.startsWith("/api/vw-") && req.method !== "GET") {
      return res.status(405).json({ error: "Method not allowed" });
    }
    next();
  });

  app.use(requireApiAuth);

  const { default: autoApiRouter } = await import("./auto-api");
  app.use("/api", autoApiRouter);

  app.get("/api/org-structure-codes", async (req, res) => {
    try {
      res.json(await lookupModule.getOrgStructureCodesDecorations());
    } catch (error) {
      console.error("Error fetching org_structure_codes:", error);
      res.status(500).json({ error: "Failed to fetch org structure codes" });
    }
  });

  // Custom/Legacy Routes (Preserved for custom business logic)
  app.use("/api/files", filesRouter);
  app.use("/api/dashboard", dashboardRouter);
  app.use("/api/lookups", lookupsRouter);
  app.use("/api/geo", geoRouter);
  app.use("/api/org", orgStructureRouter);
  app.use("/api/branches", branchRouter);
  app.use("/api/maps", mapsRouter);
  app.use("/api/ui", uiRouter);
  app.use("/api/auth", authRouter);
  app.use("/api/persons", personsRouter);
}
