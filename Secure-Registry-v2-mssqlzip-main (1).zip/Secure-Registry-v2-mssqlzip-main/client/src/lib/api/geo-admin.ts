import type { GeoAdminUnit, InsertGeoAdminUnit, LookupValue } from "@shared/schema";

export interface GeoCountry {
  id: number;
  parentId: number | null;
  lookupId: number;
  code: string;
  isoAlpha2: string | null;
  isoAlpha3: string | null;
  name: string;
  latitude: number | null;
  longitude: number | null;
  orderIndex: number;
  isActive: boolean;
}

export interface PaginatedResponse<T> {
  data: T[];
  pagination: {
    page: number;
    limit: number;
    total: number;
    totalPages: number;
  };
}

export interface GeoQueryParams {
  page?: number;
  limit?: number;
  search?: string;
  level?: number;
  lookupId?: number;
  parentId?: number | "null";
  countryId?: number;
}

export async function fetchGeoUnits(params: GeoQueryParams = {}): Promise<PaginatedResponse<GeoAdminUnit>> {
  const searchParams = new URLSearchParams();
  if (params.page) searchParams.set("page", String(params.page));
  if (params.limit) searchParams.set("limit", String(params.limit));
  if (params.search) searchParams.set("search", params.search);
  if (params.level !== undefined) searchParams.set("level", String(params.level));
  if (params.lookupId !== undefined) searchParams.set("lookupId", String(params.lookupId));
  if (params.parentId !== undefined) searchParams.set("parentId", String(params.parentId));
  if (params.countryId !== undefined) searchParams.set("countryId", String(params.countryId));
  
  const url = `/api/geo/units?${searchParams.toString()}`;
  const response = await fetch(url);
  if (!response.ok) throw new Error("Failed to fetch geo units");
  return response.json();
}

export async function fetchGeoCountries(): Promise<GeoCountry[]> {
  const response = await fetch("/api/geo/countries");
  if (!response.ok) throw new Error("Failed to fetch geo countries");
  return response.json();
}

export async function updateGeoCountryOrderIndex(id: number, orderIndex: number): Promise<GeoCountry> {
  const response = await fetch(`/api/geo/countries/${id}`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ orderIndex }),
  });
  if (!response.ok) throw new Error("Failed to update geo country order");
  return response.json();
}

export async function fetchGeoUnitsByLevel(level: number): Promise<GeoAdminUnit[]> {
  const response = await fetch(`/api/geo/units/level/${level}`);
  if (!response.ok) throw new Error("Failed to fetch geo units");
  return response.json();
}

export async function fetchGeoUnitChildren(parentId: number | null): Promise<GeoAdminUnit[]> {
  const pid = parentId === null ? "null" : parentId;
  const response = await fetch(`/api/geo/units/children/${pid}`);
  if (!response.ok) throw new Error("Failed to fetch geo unit children");
  return response.json();
}

export async function fetchGeoUnit(id: number): Promise<GeoAdminUnit> {
  const response = await fetch(`/api/geo/units/${id}`);
  if (!response.ok) throw new Error("Failed to fetch geo unit");
  return response.json();
}

export async function createGeoUnit(data: InsertGeoAdminUnit): Promise<GeoAdminUnit> {
  const response = await fetch("/api/geo/units", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
  if (!response.ok) throw new Error("Failed to create geo unit");
  return response.json();
}

export async function updateGeoUnit(id: number, data: Partial<InsertGeoAdminUnit>): Promise<GeoAdminUnit> {
  const response = await fetch(`/api/geo/units/${id}`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
  if (!response.ok) throw new Error("Failed to update geo unit");
  return response.json();
}

export async function deleteGeoUnit(id: number): Promise<void> {
  const response = await fetch(`/api/geo/units/${id}`, { method: "DELETE" });
  if (!response.ok) throw new Error("Failed to delete geo unit");
}

export async function fetchGeoLevels(): Promise<LookupValue[]> {
  const response = await fetch("/api/lookups/types/by-code/GEO_CODES/values");
  if (!response.ok) throw new Error("Failed to fetch geo levels");
  return response.json();
}
