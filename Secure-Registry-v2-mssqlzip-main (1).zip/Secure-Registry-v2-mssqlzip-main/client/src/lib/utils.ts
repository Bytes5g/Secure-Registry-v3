export { cn } from "@secure-registry/components-ui"
