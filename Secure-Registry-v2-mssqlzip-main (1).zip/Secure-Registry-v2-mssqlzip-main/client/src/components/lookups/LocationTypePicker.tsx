import { LookupValuePicker } from "./LookupValuePicker";
import { LOOKUP_CODES } from "@shared/constants/lookup-codes";

interface LocationTypePickerProps {
  value?: number | null;
  onValueChange: (value: number | null) => void;
  placeholder?: string;
  disabled?: boolean;
  className?: string;
  dialogTitle?: string;
}

/**
 * Picker for `org_entities.location_id` — backed by the `ORG_LOCATION_TYPE`
 * lookup. Distinct from `GeoLocationPicker`, which targets `geo_admin_units`
 * (used by `org_branches.geo_unit_id`).
 */
export function LocationTypePicker(props: LocationTypePickerProps) {
  return (
    <LookupValuePicker
      {...props}
      typeCode={LOOKUP_CODES.org.location}
      placeholder={props.placeholder ?? "اختر نطاق الموقع..."}
      dialogTitle={props.dialogTitle ?? "اختيار نطاق الموقع"}
    />
  );
}
