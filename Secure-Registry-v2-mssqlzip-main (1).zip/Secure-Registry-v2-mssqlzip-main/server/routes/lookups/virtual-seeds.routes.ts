import { Router, type Request } from "express";
import { storage } from "../../storage";
import { insertLookupVirtualValuesSchema } from "@shared/schema";
import { getErrorMessage, normalizeVirtualSeedBody } from "./helpers";
import { requireWriteContext } from "../_internals";

const router = Router();

router.get("/types/:typeId/virtual-seeds", async (req, res) => {
  try {
    const typeId = parseInt(req.params.typeId);
    const seeds = await storage.getLookupVirtualValuesByTypeId(typeId);
    res.json(seeds);
  } catch (error) {
    console.error("Error fetching lookup virtual value seeds:", error);
    res
      .status(500)
      .json({ error: getErrorMessage(error, "Failed to fetch lookup virtual value seeds") });
  }
});

router.get("/virtual-seeds/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const seed = await storage.getLookupVirtualValue(id);
    if (!seed) return res.status(404).json({ error: "Lookup virtual value seed not found" });
    res.json(seed);
  } catch (error) {
    console.error("Error fetching lookup virtual value seed:", error);
    res
      .status(500)
      .json({ error: getErrorMessage(error, "Failed to fetch lookup virtual value seed") });
  }
});

router.post("/types/:typeId/virtual-seeds", async (req, res) => {
  try {
    const typeId = parseInt(req.params.typeId);
    const parsed = insertLookupVirtualValuesSchema.safeParse(
      normalizeVirtualSeedBody(req.body ?? {}, typeId),
    );
    if (!parsed.success) {
      return res
        .status(400)
        .json({ error: "Invalid virtual value seed data", details: parsed.error });
    }
    const ctx = await requireWriteContext(req as any);
    const seed = await storage.createLookupVirtualValue({
      ...(parsed.data as any),
      workContextBy: ctx.workContextBy,
      createdBy: ctx.userId,
    } as any);
    res.status(201).json(seed);
  } catch (error) {
    console.error("Error creating lookup virtual value seed:", error);
    res
      .status(500)
      .json({ error: getErrorMessage(error, "Failed to create lookup virtual value seed") });
  }
});

router.patch("/virtual-seeds/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const parsed = insertLookupVirtualValuesSchema
      .partial()
      .safeParse(normalizeVirtualSeedBody(req.body ?? {}));
    if (!parsed.success) {
      return res
        .status(400)
        .json({ error: "Invalid virtual value seed data", details: parsed.error });
    }
    const ctx = await requireWriteContext(req as any);
    const seed = await storage.updateLookupVirtualValue(id, {
      ...(parsed.data as any),
      workContextBy: (parsed.data as any).workContextBy ?? ctx.workContextBy,
      updatedBy: ctx.userId,
    } as any);
    if (!seed) return res.status(404).json({ error: "Lookup virtual value seed not found" });
    res.json(seed);
  } catch (error) {
    console.error("Error updating lookup virtual value seed:", error);
    res
      .status(500)
      .json({ error: getErrorMessage(error, "Failed to update lookup virtual value seed") });
  }
});

router.delete("/virtual-seeds/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const ctx = await requireWriteContext(req as any);
    const success = await storage.deleteLookupVirtualValue(id, {
      workContextBy: ctx.workContextBy,
      updatedBy: ctx.userId,
    });
    if (!success) return res.status(404).json({ error: "Lookup virtual value seed not found" });
    res.status(204).send();
  } catch (error) {
    console.error("Error deleting lookup virtual value seed:", error);
    res
      .status(500)
      .json({ error: getErrorMessage(error, "Failed to delete lookup virtual value seed") });
  }
});

export default router;
