import { useEffect, useMemo, useRef, useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { genericApi } from "@/lib/api/generic";
import { mergeUiConfig, normalizeOrder, toOverridePayload } from "@/lib/ui/uiConfigOverrides";
import type { UiPageConfig } from "@/types/ui";
import { PAGE_CODES } from "@/lib/constants";

type OverrideResponse = { pageCode: string; override: Record<string, unknown> | null };

export function useUiPageOverridesEditor(options?: {
  initialPageCode?: string;
  initialEntityType?: string;
  autoLoad?: boolean;
}) {
  const { toast } = useToast();
  const [pageCode, setPageCode] = useState<string>(options?.initialPageCode ?? PAGE_CODES.ORG_STRUCTURE);
  const [entityType, setEntityType] = useState<string>(options?.initialEntityType ?? "organizationalStructure");
  const [baseConfig, setBaseConfig] = useState<UiPageConfig | null>(null);
  const [draft, setDraft] = useState<UiPageConfig | null>(null);
  const [loadedOverride, setLoadedOverride] = useState<Record<string, unknown> | null>(null);
  const didAutoLoadRef = useRef(false);

  const canLoad = useMemo(() => pageCode.trim().length > 0 && entityType.trim().length > 0, [pageCode, entityType]);

  const overrideQuery = useQuery({
    queryKey: ["ui-page-override", pageCode],
    enabled: false,
    queryFn: async () => genericApi.getUiPageOverride(pageCode) as Promise<OverrideResponse>,
  });

  const baseQuery = useQuery({
    queryKey: ["ui-page-config", "base", pageCode, entityType],
    enabled: false,
    queryFn: async () => {
      try {
        return await genericApi.getUiPageConfig(pageCode, entityType, { ignoreOverride: true });
      } catch (error: any) {
        if (error?.status === 404) return null;
        throw error;
      }
    },
  });

  useEffect(() => {
    if (!overrideQuery.data) return;
    setLoadedOverride(overrideQuery.data.override ?? null);
  }, [overrideQuery.data]);

  useEffect(() => {
    if (baseQuery.data === undefined) return;
    setBaseConfig((baseQuery.data as UiPageConfig) ?? null);
  }, [baseQuery.data]);

  useEffect(() => {
    if (!baseConfig) return;
    const merged = mergeUiConfig(baseConfig, loadedOverride);
    setDraft({
      ...merged,
      columns: Array.isArray(merged.columns) ? normalizeOrder(merged.columns) : [],
      formFields: Array.isArray(merged.formFields) ? normalizeOrder(merged.formFields) : [],
      filters: Array.isArray((merged as any).filters) ? (merged as any).filters : [],
    });
  }, [baseConfig, loadedOverride]);

  const validation = useMemo(() => {
    const errors: string[] = [];
    if (!draft) return { isValid: true, errors };

    const columns = Array.isArray(draft.columns) ? draft.columns : [];
    const formFields = Array.isArray(draft.formFields) ? draft.formFields : [];

    const findDuplicates = (items: Array<{ fieldCode: string }>, label: string) => {
      const counts = new Map<string, number>();
      for (const it of items) {
        const k = String(it?.fieldCode ?? "").trim();
        if (!k) continue;
        counts.set(k, (counts.get(k) ?? 0) + 1);
      }
      const dup = Array.from(counts.entries())
        .filter(([, cnt]) => cnt > 1)
        .map(([k]) => k);
      if (dup.length > 0) errors.push(`تكرار ${label}: ${dup.join("، ")}`);
    };

    const hasEmpty = (items: Array<{ fieldCode: string }>, label: string) => {
      const emptyCount = items.filter((it) => !String(it?.fieldCode ?? "").trim()).length;
      if (emptyCount > 0) errors.push(`${label}: يوجد ${emptyCount} عنصر بدون fieldCode`);
    };

    hasEmpty(columns as any, "الأعمدة");
    hasEmpty(formFields as any, "الحقول");
    findDuplicates(columns as any, "الأعمدة");
    findDuplicates(formFields as any, "الحقول");

    return { isValid: errors.length === 0, errors };
  }, [draft]);

  const saveMutation = useMutation({
    mutationFn: async () => {
      if (!draft) throw new Error("لا توجد تهيئة للحفظ");
      if (!validation.isValid) throw new Error(validation.errors.join(" | "));
      return genericApi.setUiPageOverride(pageCode, toOverridePayload(draft));
    },
    onSuccess: async () => {
      toast({ title: "تم الحفظ", description: "تم تحديث override بنجاح" });
      await overrideQuery.refetch();
    },
    onError: (error: any) => {
      toast({ title: "فشل الحفظ", description: error?.message ?? "تعذر حفظ override", variant: "destructive" });
    },
  });

  const clearMutation = useMutation({
    mutationFn: async () => genericApi.setUiPageOverride(pageCode, null),
    onSuccess: async () => {
      toast({ title: "تم الإزالة", description: "تم حذف override" });
      await overrideQuery.refetch();
    },
    onError: (error: any) => {
      toast({ title: "فشل الإزالة", description: error?.message ?? "تعذر حذف override", variant: "destructive" });
    },
  });

  const seedMutation = useMutation({
    mutationFn: async (args?: { force?: boolean; scope?: "all" | "columns" | "formFields" }) => {
      return genericApi.seedUiPageOverride(pageCode, { entityType, force: args?.force, scope: args?.scope });
    },
    onSuccess: async (data: any) => {
      const mode = String(data?.mode ?? "");
      const columnsInserted = Number(data?.columnsInserted ?? 0);
      const formFieldsInserted = Number(data?.formFieldsInserted ?? 0);
      toast({
        title: "تم التوليد",
        description: `columns: ${columnsInserted}, fields: ${formFieldsInserted}${mode ? ` (${mode})` : ""}`,
      });
      await loadAll();
    },
    onError: (error: any) => {
      toast({ title: "فشل التوليد", description: error?.message ?? "تعذر توليد override", variant: "destructive" });
    },
  });

  const loadAll = async () => {
    if (!canLoad) return;
    await Promise.all([overrideQuery.refetch(), baseQuery.refetch()]);
  };

  useEffect(() => {
    if (!options?.autoLoad) return;
    if (!canLoad) return;
    if (didAutoLoadRef.current) return;
    didAutoLoadRef.current = true;
    void loadAll();
  }, [canLoad, options?.autoLoad]);

  const resetToBase = () => {
    if (!baseConfig) return;
    setLoadedOverride(null);
    setDraft({
      ...baseConfig,
      columns: Array.isArray(baseConfig.columns) ? normalizeOrder(baseConfig.columns) : [],
      formFields: Array.isArray(baseConfig.formFields) ? normalizeOrder(baseConfig.formFields) : [],
      filters: Array.isArray((baseConfig as any).filters) ? (baseConfig as any).filters : [],
    });
  };

  const sanitizeDraft = () => {
    if (!draft) return;
    const dedupeByFieldCode = <T extends { fieldCode: string }>(items: T[]) => {
      const seen = new Set<string>();
      const next: T[] = [];
      let removed = 0;
      for (const it of items) {
        const k = String(it?.fieldCode ?? "").trim();
        if (!k) {
          next.push(it);
          continue;
        }
        if (seen.has(k)) {
          removed += 1;
          continue;
        }
        seen.add(k);
        next.push(it);
      }
      return { next, removed };
    };

    const cols = Array.isArray(draft.columns) ? draft.columns : [];
    const fields = Array.isArray(draft.formFields) ? draft.formFields : [];
    const colsResult = dedupeByFieldCode(cols as any);
    const fieldsResult = dedupeByFieldCode(fields as any);

    setDraft({
      ...(draft as any),
      columns: normalizeOrder(colsResult.next as any),
      formFields: normalizeOrder(fieldsResult.next as any),
      filters: Array.isArray((draft as any).filters) ? (draft as any).filters : [],
    });

    toast({
      title: "تم التنظيف",
      description: `تمت إزالة تكرارات: الأعمدة ${colsResult.removed}، الحقول ${fieldsResult.removed}`,
    });
  };

  const isBusy = saveMutation.isPending || clearMutation.isPending || overrideQuery.isFetching || baseQuery.isFetching;
  const isSeeding = seedMutation.isPending;

  const isDirty = useMemo(() => {
    if (!draft) return false;
    const payload = toOverridePayload(draft);
    const normalizedLoaded = loadedOverride && typeof loadedOverride === "object" ? loadedOverride : null;
    const payloadComparable: any = { columns: (payload as any).columns ?? undefined, formFields: (payload as any).formFields ?? undefined };
    const loadedComparable: any = normalizedLoaded
      ? { columns: (normalizedLoaded as any).columns ?? undefined, formFields: (normalizedLoaded as any).formFields ?? undefined }
      : null;
    return JSON.stringify(payloadComparable) !== JSON.stringify(loadedComparable);
  }, [draft, loadedOverride]);

  return {
    pageCode,
    setPageCode,
    entityType,
    setEntityType,
    canLoad,
    baseConfig,
    draft,
    setDraft,
    loadedOverride,
    loadAll,
    loadOverrideOnly: overrideQuery.refetch,
    resetToBase,
    save: () => saveMutation.mutate(),
    clear: () => clearMutation.mutate(),
    seed: (args?: { force?: boolean; scope?: "all" | "columns" | "formFields" }) => seedMutation.mutate(args),
    sanitizeDraft,
    isBusy,
    isSeeding,
    isDirty,
    isLoaded: Boolean(baseConfig),
    isValid: validation.isValid,
    validationErrors: validation.errors,
  };
}
