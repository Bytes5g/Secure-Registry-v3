import { Router } from "express";
import providersRouter from "./providers.routes";

const router = Router();

router.use(providersRouter);

export default router;

