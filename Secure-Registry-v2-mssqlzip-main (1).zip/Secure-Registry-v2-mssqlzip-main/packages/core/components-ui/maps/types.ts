export type MapTileProvider = {
  id: number | string
  name: string
  tileUrl: string
  isOverlay?: boolean
  orderIndex?: number
}

