import { FlowLegend } from "@secure-registry/components-ui";
import { BRANCH_NODE_COLOR } from "./constants";

interface DiagramLegendProps {
  showHierarchyEdges: boolean;
  setShowHierarchyEdges: (v: boolean) => void;
  showCoverageEdges: boolean;
  setShowCoverageEdges: (v: boolean) => void;
  showDependencyEdges: boolean;
  setShowDependencyEdges: (v: boolean) => void;
}

export function DiagramLegend(props: DiagramLegendProps) {
  return (
    <FlowLegend
      items={[
        {
          key: "hierarchy",
          label: "تبعية (هيكل)",
          color: "#334155",
          checked: props.showHierarchyEdges,
          onCheckedChange: props.setShowHierarchyEdges,
        },
        {
          key: "coverage",
          label: "يغطيها (فرع)",
          color: BRANCH_NODE_COLOR,
          checked: props.showCoverageEdges,
          onCheckedChange: props.setShowCoverageEdges,
        },
        {
          key: "dependency",
          label: "اعتماد (قريباً)",
          color: "#7c3aed",
          checked: props.showDependencyEdges,
          onCheckedChange: props.setShowDependencyEdges,
          disabled: true,
          hint: "ميزة قيد التطوير — لا توجد بيانات اعتماد بعد.",
        },
      ]}
      className="max-w-md"
    />
  );
}
