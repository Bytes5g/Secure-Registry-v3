import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { ArrowRight } from "lucide-react";
import { useLocation } from "wouter";
import { Button, EntityMediaManagerDialog } from "@secure-registry/components-ui";
import {
  deleteOrganizationCover,
  deleteOrganizationLogo,
  fetchOrganizationCoverHistory,
  fetchOrganizationLogoHistory,
  setOrganizationCoverFromExisting,
  setOrganizationLogoFromExisting,
  uploadOrganizationCover,
  uploadOrganizationLogo,
} from "@/lib/api/org-admin";
import { updateFileMetadata } from "@/lib/api/files-admin";

interface OrgProfileHeaderActionsProps {
  orgId: number;
  backHref?: string;
}

export function OrgProfileHeaderActions({
  orgId,
  backHref = "/config/org-entities",
}: OrgProfileHeaderActionsProps) {
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const [open, setOpen] = useState(false);

  const logoHistoryQuery = useQuery({
    queryKey: ["org-entity-logo-history", orgId],
    queryFn: () => fetchOrganizationLogoHistory(orgId),
    enabled: Number.isFinite(orgId) && orgId > 0,
  });
  const coverHistoryQuery = useQuery({
    queryKey: ["org-entity-cover-history", orgId],
    queryFn: () => fetchOrganizationCoverHistory(orgId),
    enabled: Number.isFinite(orgId) && orgId > 0,
  });

  const invalidate = (kind: "logo" | "cover") => {
    queryClient.invalidateQueries({ queryKey: [`org-entity-${kind}`, orgId] });
    queryClient.invalidateQueries({ queryKey: [`org-entity-${kind}-history`, orgId] });
  };

  const uploadLogo = useMutation({
    mutationFn: (file: File) => uploadOrganizationLogo(orgId, file),
    onSuccess: () => invalidate("logo"),
  });
  const uploadCover = useMutation({
    mutationFn: (file: File) => uploadOrganizationCover(orgId, file),
    onSuccess: () => invalidate("cover"),
  });

  const selectLogo = useMutation({
    mutationFn: (fileId: number) => setOrganizationLogoFromExisting(orgId, fileId),
    onSuccess: () => invalidate("logo"),
  });
  const selectCover = useMutation({
    mutationFn: (fileId: number) => setOrganizationCoverFromExisting(orgId, fileId),
    onSuccess: () => invalidate("cover"),
  });

  const deleteLogo = useMutation({
    mutationFn: () => deleteOrganizationLogo(orgId),
    onSuccess: () => invalidate("logo"),
  });
  const deleteCover = useMutation({
    mutationFn: () => deleteOrganizationCover(orgId),
    onSuccess: () => invalidate("cover"),
  });

  const updateMeta = useMutation({
    mutationFn: (payload: { fileId: number; title?: string | null; description?: string | null }) =>
      updateFileMetadata(payload.fileId, { title: payload.title, description: payload.description }),
    onSuccess: () => {
      invalidate("logo");
      invalidate("cover");
    },
  });

  return (
    <>
      <Button variant="secondary" onClick={() => setOpen(true)}>
        إدارة الصور
      </Button>
      <Button variant="ghost" onClick={() => setLocation(backHref)}>
        <ArrowRight className="h-4 w-4" />
        <span className="ms-2">رجوع</span>
      </Button>

      <EntityMediaManagerDialog
        open={open}
        onOpenChange={setOpen}
        title="إدارة صور الجهة"
        slots={[
          {
            key: "logo",
            label: "الشعار",
            accept: "image/png,image/jpeg,image/webp",
            maxSizeMb: 5,
            items: (logoHistoryQuery.data?.history ?? []).map((it) => ({
              id: it.id,
              fileId: it.fileId,
              url: it.filePath,
              fileName: it.title ?? it.fileName,
              mimeType: it.mimeType,
              description: it.description,
              createdAt: it.createdAt,
              isPrimary: it.isPrimary,
            })),
            onUpload: async (file) => {
              await uploadLogo.mutateAsync(file);
            },
            onSelectAsPrimary: async (fileId) => {
              await selectLogo.mutateAsync(fileId);
            },
            onDeletePrimary: async () => {
              await deleteLogo.mutateAsync();
            },
            onUpdateMetadata: async (fileId, patch) => {
              await updateMeta.mutateAsync({ fileId, title: patch.title, description: patch.description });
            },
          },
          {
            key: "cover",
            label: "الغلاف",
            accept: "image/png,image/jpeg,image/webp",
            maxSizeMb: 5,
            items: (coverHistoryQuery.data?.history ?? []).map((it) => ({
              id: it.id,
              fileId: it.fileId,
              url: it.filePath,
              fileName: it.title ?? it.fileName,
              mimeType: it.mimeType,
              description: it.description,
              createdAt: it.createdAt,
              isPrimary: it.isPrimary,
            })),
            onUpload: async (file) => {
              await uploadCover.mutateAsync(file);
            },
            onSelectAsPrimary: async (fileId) => {
              await selectCover.mutateAsync(fileId);
            },
            onDeletePrimary: async () => {
              await deleteCover.mutateAsync();
            },
            onUpdateMetadata: async (fileId, patch) => {
              await updateMeta.mutateAsync({ fileId, title: patch.title, description: patch.description });
            },
          },
        ]}
        defaultSlotKey="cover"
      />
    </>
  );
}
