import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
import path from "path";

function getViteAllowedHosts(): true | string[] {
  const raw = process.env.VITE_ALLOWED_HOSTS;
  if (!raw) return true;
  if (raw.trim().toLowerCase() === "true") return true;
  const list = raw
    .split(",")
    .map((h) => h.trim())
    .filter(Boolean);
  return list.length ? list : true;
}

export default defineConfig({
  plugins: [
    react(),
    tailwindcss(),
  ],
  resolve: {
    alias: {
      "@": path.resolve(import.meta.dirname, "client", "src"),
      "@shared": path.resolve(import.meta.dirname, "shared"),
      "@assets": path.resolve(import.meta.dirname, "attached_assets"),
      "@secure-registry/ui": path.resolve(import.meta.dirname, "packages", "core", "components-ui", "index.ts"),
    },
  },
  css: {
    postcss: {
      plugins: [],
    },
  },
  root: path.resolve(import.meta.dirname, "client"),
  publicDir: path.resolve(import.meta.dirname, "public"),
  build: {
    outDir: path.resolve(import.meta.dirname, "dist/public"),
    emptyOutDir: true,
    rollupOptions: {
      output: {
        manualChunks(id) {
          if (id.includes("node_modules")) {
            if (id.includes("framer-motion")) return "framer-motion";
            if (id.includes("recharts")) return "recharts";
            if (id.includes("lucide-react")) return "lucide-react";
            if (id.includes("@radix-ui")) return "radix-ui";
            if (id.includes("@tanstack")) return "tanstack-query";
            if (id.includes("date-fns") || id.includes("react-day-picker")) return "date-utils";
            if (id.includes("react-hook-form") || id.includes("zod") || id.includes("@hookform")) return "forms";
            if (id.includes("react") || id.includes("react-dom") || id.includes("wouter")) return "vendor";
            return "vendor-utils";
          }
        },
      },
    },
  },
  server: {
    host: "0.0.0.0",
    port: Number(process.env.VITE_DEV_PORT ?? 5001),
    strictPort: false,
    allowedHosts: getViteAllowedHosts(),
    proxy: {
      "/api": {
        target: process.env.VITE_API_PROXY_TARGET ?? "http://localhost:3001",
        changeOrigin: true,
      },
      "/uploads": {
        target: process.env.VITE_API_PROXY_TARGET ?? "http://localhost:3001",
        changeOrigin: true,
      },
    },
    fs: {
      strict: true,
      allow: [path.resolve(import.meta.dirname)],
      deny: ["**/.*"],
    },
  },
});
