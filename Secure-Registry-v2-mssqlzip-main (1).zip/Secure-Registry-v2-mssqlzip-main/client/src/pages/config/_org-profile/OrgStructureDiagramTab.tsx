import { useEffect, useMemo, useRef, useState } from "react";
import {
  FlowCanvas,
  FlowCardNode,
  FlowCoverageEdge,
  FlowDependencyEdge,
  FlowHierarchyEdge,
} from "@secure-registry/components-ui";
import { OrgDiagramControls } from "./OrgDiagramControls";
import {
  useAutoSelectFirstBranch,
  useOrgDiagramData,
  type DiagramScope,
} from "./useOrgDiagramData";
import { useDiagramFlowGraph } from "./diagram/useDiagramFlowGraph";
import { useDiagramAutoFit } from "./diagram/useDiagramAutoFit";
import { DiagramLegend } from "./diagram/DiagramLegend";
import {
  CoveringBranchesPanel,
  DiagramEmptyMessage,
  DiagramLoading,
} from "./diagram/DiagramStates";

export function OrgStructureDiagramTab({
  orgId,
  requestedScope,
  requestedNodeId,
  requestedShowOrgChartStaff,
  requestNonce,
}: {
  orgId: number;
  requestedScope?: DiagramScope;
  requestedNodeId?: number | null;
  requestedShowOrgChartStaff?: boolean;
  requestNonce?: number;
}) {
  // Filter state
  const [scope, setScope] = useState<DiagramScope>(requestedScope ?? "branch");
  const [selectedBranchValue, setSelectedBranchValue] = useState("none");
  const [selectedNodeId, setSelectedNodeId] = useState<number | null>(requestedNodeId ?? null);
  const [nodeSearch, setNodeSearch] = useState("");

  // Display toggles
  const [showBranchAssignments, setShowBranchAssignments] = useState(true);
  const [focusOnly, setFocusOnly] = useState(true);
  const [showOnlySelectedUnitChildren, setShowOnlySelectedUnitChildren] = useState(true);
  const [showUnitBranchesOnDiagram, setShowUnitBranchesOnDiagram] = useState(true);
  const [showOrgChartStaff, setShowOrgChartStaff] = useState(requestedShowOrgChartStaff ?? false);
  const [showMiniMap, setShowMiniMap] = useState(true);
  const [showBackground, setShowBackground] = useState(true);
  const [snapToGrid, setSnapToGrid] = useState(true);
  const [nodesDraggable, setNodesDraggable] = useState(true);
  const [showEdgeLabels, setShowEdgeLabels] = useState(true);
  const [colorEdges, setColorEdges] = useState(true);
  const [showHierarchyEdges, setShowHierarchyEdges] = useState(true);
  const [showCoverageEdges, setShowCoverageEdges] = useState(true);
  const [showDependencyEdges, setShowDependencyEdges] = useState(false);
  const [layoutNonce, setLayoutNonce] = useState(0);

  const flowRef = useRef<any>(null);

  useEffect(() => {
    if (requestNonce == null) return;
    if (requestedScope) setScope(requestedScope);
    if (requestedNodeId !== undefined) setSelectedNodeId(requestedNodeId ?? null);
    if (requestedShowOrgChartStaff !== undefined) setShowOrgChartStaff(Boolean(requestedShowOrgChartStaff));
  }, [requestNonce, requestedNodeId, requestedScope, requestedShowOrgChartStaff]);

  const data = useOrgDiagramData(orgId, {
    scope,
    selectedBranchValue,
    selectedNodeId,
    nodeSearch,
    showBranchAssignments,
    showOnlySelectedUnitChildren,
    showUnitBranchesOnDiagram,
    showOrgChartStaff,
  });

  useAutoSelectFirstBranch(
    scope,
    selectedBranchValue,
    data.branchesForOrg,
    setSelectedBranchValue,
  );

  const {
    treeNodes,
    branchesForOrg,
    branchesByNode,
    structureById,
    nodeTypeByNodeId,
    employeesByUnitId,
    managerByUnitId,
    assignedNodeIds,
    highlightedNodeIds,
    selectedUnitChildrenIds,
    effectiveBranchId,
    effectiveNodeId,
    selectedUnitId,
    filteredNodes,
    isLoading,
    treeLoading,
  } = data;

  const totalNodeCount = treeNodes.length;
  const assignedCount = assignedNodeIds.size;
  const branchHasNoExtensions =
    scope === "branch" &&
    effectiveBranchId != null &&
    showBranchAssignments &&
    assignedCount === 0;
  const selectedUnitStaffCount =
    selectedUnitId != null
      ? (employeesByUnitId.get(selectedUnitId) ?? []).filter((r) => !Boolean(r.isManager ?? r.is_manager)).length
      : 0;
  const selectedUnitHasNoChildren =
    showOnlySelectedUnitChildren &&
    selectedUnitId != null &&
    selectedUnitChildrenIds.length === 0 &&
    (!showOrgChartStaff || selectedUnitStaffCount === 0);
  const isEmpty = !treeLoading && treeNodes.length === 0;

  const { nodes, edges } = useDiagramFlowGraph({
    treeNodes,
    branchesByNode,
    structureById,
    nodeTypeByNodeId,
    employeesByUnitId,
    managerByUnitId,
    assignedNodeIds,
    highlightedNodeIds,
    selectedUnitId,
    effectiveBranchId,
    effectiveNodeId,
    scope,
    showBranchAssignments,
    showOnlySelectedUnitChildren,
    showUnitBranchesOnDiagram,
    showOrgChartStaff,
    showHierarchyEdges,
    showCoverageEdges,
    showEdgeLabels,
    colorEdges,
    focusOnly,
    layoutNonce,
  });

  const nodeTypes = useMemo(() => ({ card: FlowCardNode }), []);
  const edgeTypes = useMemo(
    () => ({
      hierarchy: FlowHierarchyEdge,
      coverage: FlowCoverageEdge,
      dependency: FlowDependencyEdge,
    }),
    [],
  );

  useDiagramAutoFit({
    flowRef,
    focusOnly,
    scope,
    effectiveBranchId,
    effectiveNodeId,
    highlightedCount: highlightedNodeIds.size,
    selectedUnitId,
    visibleNodeCount: nodes.length,
    layoutNonce,
  });

  return (
    <div className="space-y-4" dir="rtl">
      <OrgDiagramControls
        scope={scope}
        setScope={setScope}
        selectedBranchValue={selectedBranchValue}
        setSelectedBranchValue={setSelectedBranchValue}
        selectedNodeId={selectedNodeId}
        setSelectedNodeId={setSelectedNodeId}
        nodeSearch={nodeSearch}
        setNodeSearch={setNodeSearch}
        showBranchAssignments={showBranchAssignments}
        setShowBranchAssignments={setShowBranchAssignments}
        showOnlySelectedUnitChildren={showOnlySelectedUnitChildren}
        setShowOnlySelectedUnitChildren={setShowOnlySelectedUnitChildren}
        showUnitBranchesOnDiagram={showUnitBranchesOnDiagram}
        setShowUnitBranchesOnDiagram={setShowUnitBranchesOnDiagram}
        showOrgChartStaff={showOrgChartStaff}
        setShowOrgChartStaff={setShowOrgChartStaff}
        focusOnly={focusOnly}
        setFocusOnly={setFocusOnly}
        showMiniMap={showMiniMap}
        setShowMiniMap={setShowMiniMap}
        showBackground={showBackground}
        setShowBackground={setShowBackground}
        snapToGrid={snapToGrid}
        setSnapToGrid={setSnapToGrid}
        nodesDraggable={nodesDraggable}
        setNodesDraggable={setNodesDraggable}
        showEdgeLabels={showEdgeLabels}
        setShowEdgeLabels={setShowEdgeLabels}
        colorEdges={colorEdges}
        setColorEdges={setColorEdges}
        branchesForOrg={branchesForOrg}
        filteredNodes={filteredNodes}
        effectiveBranchId={effectiveBranchId}
        effectiveNodeId={effectiveNodeId}
        selectedUnitId={selectedUnitId}
        totalNodeCount={totalNodeCount}
        assignedCount={assignedCount}
        branchHasNoExtensions={branchHasNoExtensions}
        onFitView={() => flowRef.current?.fitView?.({ padding: 0.2 })}
        onRelayout={() => setLayoutNonce((v) => v + 1)}
      />

      <DiagramLegend
        showHierarchyEdges={showHierarchyEdges}
        setShowHierarchyEdges={setShowHierarchyEdges}
        showCoverageEdges={showCoverageEdges}
        setShowCoverageEdges={setShowCoverageEdges}
        showDependencyEdges={showDependencyEdges}
        setShowDependencyEdges={setShowDependencyEdges}
      />

      {scope === "unit" && showUnitBranchesOnDiagram && effectiveNodeId ? (
        <CoveringBranchesPanel branchesByNode={branchesByNode} />
      ) : null}

      {isLoading ? <DiagramLoading /> : null}

      {isEmpty ? (
        <DiagramEmptyMessage>
          لا يوجد هيكل تنظيمي لهذه الجهة بعد. قم بإضافة وحدات من تبويب "تهيئة الهيكل".
        </DiagramEmptyMessage>
      ) : branchHasNoExtensions ? (
        <DiagramEmptyMessage>
          لا توجد امتدادات لهذا الفرع. لا يتم عرض هيكل المركز الرئيسي في هذا الوضع.
        </DiagramEmptyMessage>
      ) : selectedUnitHasNoChildren ? (
        <DiagramEmptyMessage>لا توجد وحدات فرعية لهذه الوحدة.</DiagramEmptyMessage>
      ) : (
        <FlowCanvas
          nodes={nodes}
          edges={edges}
          nodeTypes={nodeTypes}
          edgeTypes={edgeTypes}
          forceSyncKey={layoutNonce}
          fitView
          fitViewOptions={{ padding: 0.2 }}
          onInit={(instance) => {
            flowRef.current = instance;
          }}
          nodesConnectable={false}
          elementsSelectable={true}
          nodesDraggable={nodesDraggable}
          showMiniMap={showMiniMap}
          showControls={true}
          showBackground={showBackground}
          snapToGrid={snapToGrid}
          canvasClassName="h-[720px]"
        />
      )}
    </div>
  );
}
