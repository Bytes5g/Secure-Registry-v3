import type { SqlExecutor } from "../config/connection";
import { insertRow, mapRow, mapRows, runQuery, runQueryOne, toSnakeCase, updateRow } from "./helpers";

export interface PersonListRecord {
  id: number;
  fullName: string;
  genderName: string | null;
  nationalityName: string | null;
  maritalName: string | null;
  dateOfBirth: string | null;
  isActive: boolean;
}

export interface PersonSearchRecord extends PersonListRecord {
  orgId: number | null;
  orgName: string | null;
  branchId: number | null;
  branchName: string | null;
  orgStructureId: number | null;
  orgStructureName: string | null;
  isManager: boolean | null;
}

export interface PersonDetailsRecord {
  id: number;
  firstName: string;
  fatherName: string | null;
  grandfatherName: string | null;
  greatGfName: string | null;
  greatGreatGfName: string | null;
  familyName: string | null;
  fullName: string;
  dateOfBirth: string | null;
  genderId: number | null;
  genderName: string | null;
  nationalityId: number | null;
  nationalityName: string | null;
  maritalStatusId: number | null;
  maritalName: string | null;
  isActive: boolean;
  createdAt: string | null;
  updatedAt: string | null;
}

export interface PersonContactRecord {
  id: number;
  categoryId: number;
  categoryName: string | null;
  typeId: number;
  typeName: string | null;
  providerId: number | null;
  providerName: string | null;
  contactValue: string;
  countryCode: string | null;
  isWorkRelated: boolean;
  notes: string | null;
  createdAt: string | null;
}

export interface PersonAssignmentRecord {
  id: number;
  orgId: number;
  orgName: string | null;
  branchId: number;
  branchName: string | null;
  orgStructureId: number;
  orgStructureName: string | null;
  isManager: boolean;
  createdAt: string | null;
}

export interface PersonAssignmentCreatePayload {
  orgId: number;
  branchId: number;
  orgStructureId: number;
  isManager?: boolean;
}

type WriteContext = {
  workContextBy?: number | null;
  createdBy?: number | null;
  updatedBy?: number | null;
};

const ownerTypeIdCache = new Map<string, Promise<number | undefined>>();

async function getOwnerTypeIdByCode(code: string): Promise<number | undefined> {
  const key = code.trim().toUpperCase();
  const cached = ownerTypeIdCache.get(key);
  if (cached) return cached;

  const promise = (async () => {
    const row = await runQueryOne<{ id: number }>(
      "SELECT TOP 1 id FROM dbo.system_owner_types WHERE code = @code AND is_deleted = 0",
      { code: key },
    );
    return row ? Number((row as any).id) : undefined;
  })();

  ownerTypeIdCache.set(key, promise);
  return promise;
}

function toDbPatch(patch: Record<string, unknown>): Record<string, unknown> {
  return Object.fromEntries(Object.entries(patch).map(([k, v]) => [toSnakeCase(k), v]));
}

export class PersonsModule {
  async listPersons(params: { search?: string | null; limit?: number }, executor?: SqlExecutor): Promise<PersonListRecord[]> {
    const limit = Math.max(1, Math.min(500, Number(params.limit ?? 100)));
    const search = params.search != null && String(params.search).trim().length > 0 ? String(params.search).trim() : null;

    const rows = await runQuery(
      `
        SELECT TOP (@limit)
          id,
          full_name,
          gender_name,
          nationality_name,
          marital_name,
          date_of_birth,
          is_active
        FROM dbo.vm_persons
        WHERE is_deleted = 0
          AND (@search IS NULL OR full_name LIKE N'%' + @search + N'%')
        ORDER BY id DESC
      `,
      { limit, search },
      executor,
    );

    return mapRows<PersonListRecord>(rows);
  }

  async searchPersons(
    params: {
      q?: string | null;
      firstName?: string | null;
      familyName?: string | null;
      orgId?: number | null;
      branchId?: number | null;
      orgStructureId?: number | null;
      genderId?: number | null;
      nationalityId?: number | null;
      maritalStatusId?: number | null;
      isActive?: boolean | null;
      cursor?: number | null;
      limit?: number;
    },
    executor?: SqlExecutor,
  ): Promise<PersonSearchRecord[]> {
    const limit = Math.max(1, Math.min(200, Number(params.limit ?? 50)));
    const q = params.q != null && String(params.q).trim().length > 0 ? String(params.q).trim() : null;
    const firstName = params.firstName != null && String(params.firstName).trim().length > 0 ? String(params.firstName).trim() : null;
    const familyName = params.familyName != null && String(params.familyName).trim().length > 0 ? String(params.familyName).trim() : null;

    const orgId = params.orgId != null && Number.isFinite(params.orgId) ? Number(params.orgId) : null;
    const branchId = params.branchId != null && Number.isFinite(params.branchId) ? Number(params.branchId) : null;
    const orgStructureId = params.orgStructureId != null && Number.isFinite(params.orgStructureId) ? Number(params.orgStructureId) : null;
    const genderId = params.genderId != null && Number.isFinite(params.genderId) ? Number(params.genderId) : null;
    const nationalityId = params.nationalityId != null && Number.isFinite(params.nationalityId) ? Number(params.nationalityId) : null;
    const maritalStatusId = params.maritalStatusId != null && Number.isFinite(params.maritalStatusId) ? Number(params.maritalStatusId) : null;
    const isActive = typeof params.isActive === "boolean" ? params.isActive : null;
    const cursor = params.cursor != null && Number.isFinite(params.cursor) ? Number(params.cursor) : null;

    const where: string[] = ["p.is_deleted = 0"];
    const sqlParams: Record<string, unknown> = {
      limit,
      q,
      firstName,
      familyName,
      orgId,
      branchId,
      orgStructureId,
      genderId,
      nationalityId,
      maritalStatusId,
      isActive,
      cursor,
    };

    if (q) {
      where.push("p.full_name LIKE N'%' + @q + N'%'");
    }

    if (firstName) {
      where.push("p.first_name LIKE N'%' + @firstName + N'%'");
    }

    if (familyName) {
      where.push("p.family_name LIKE N'%' + @familyName + N'%'");
    }

    if (cursor != null) {
      where.push("p.id < @cursor");
    }

    if (genderId != null) {
      where.push("p.gender_id = @genderId");
    }

    if (nationalityId != null) {
      where.push("p.nationality_id = @nationalityId");
    }

    if (maritalStatusId != null) {
      where.push("p.marital_status_id = @maritalStatusId");
    }

    if (isActive != null) {
      where.push("p.is_active = @isActive");
    }

    if (orgId != null || branchId != null || orgStructureId != null) {
      const clauses: string[] = ["a.is_deleted = 0", "a.person_id = p.id"];
      if (orgId != null) clauses.push("a.org_id = @orgId");
      if (branchId != null) clauses.push("a.branch_id = @branchId");
      if (orgStructureId != null) clauses.push("a.org_structure_id = @orgStructureId");
      where.push(`EXISTS (SELECT 1 FROM dbo.person_assignments a WHERE ${clauses.join(" AND ")})`);
    }

    const rows = await runQuery(
      `
        SELECT TOP (@limit)
          p.id,
          p.full_name,
          p.gender_name,
          p.nationality_name,
          p.marital_name,
          p.date_of_birth,
          p.is_active,
          last_a.org_id,
          o.name AS org_name,
          last_a.branch_id,
          b.name AS branch_name,
          last_a.org_structure_id,
          s.name AS org_structure_name,
          last_a.is_manager
        FROM dbo.vm_persons p
        OUTER APPLY (
          SELECT TOP 1
            a.org_id,
            a.branch_id,
            a.org_structure_id,
            a.is_manager,
            a.created_at,
            a.id
          FROM dbo.person_assignments a
          WHERE a.person_id = p.id AND a.is_deleted = 0
          ORDER BY a.is_manager DESC, a.created_at DESC, a.id DESC
        ) last_a
        LEFT JOIN dbo.org_entities o ON o.id = last_a.org_id
        LEFT JOIN dbo.org_branches b ON b.id = last_a.branch_id
        LEFT JOIN dbo.org_entity_structure s ON s.id = last_a.org_structure_id
        WHERE ${where.join(" AND ")}
        ORDER BY p.id DESC
      `,
      sqlParams,
      executor,
    );

    return mapRows<PersonSearchRecord>(rows);
  }

  async getPersonById(personId: number, executor?: SqlExecutor): Promise<PersonDetailsRecord | undefined> {
    const row = await runQueryOne(
      `
        SELECT TOP 1
          id,
          first_name,
          father_name,
          grandfather_name,
          great_gf_name,
          great_great_gf_name,
          family_name,
          full_name,
          date_of_birth,
          gender_id,
          gender_name,
          nationality_id,
          nationality_name,
          marital_status_id,
          marital_name,
          is_active,
          created_at,
          updated_at
        FROM dbo.vm_persons
        WHERE id = @personId AND is_deleted = 0
      `,
      { personId },
      executor,
    );

    return mapRow<PersonDetailsRecord>(row);
  }

  async getPersonContacts(personId: number, executor?: SqlExecutor): Promise<PersonContactRecord[]> {
    const ownerTypeId = await getOwnerTypeIdByCode("PERSON");
    if (!ownerTypeId) return [];

    const rows = await runQuery(
      `
        SELECT
          c.id,
          c.category_id,
          cat.name AS category_name,
          c.type_id,
          t.name AS type_name,
          c.provider_id,
          p.name AS provider_name,
          c.contact_value,
          c.country_code,
          c.is_work_related,
          c.notes,
          c.created_at
        FROM dbo.contacts_registry c
        LEFT JOIN dbo.contact_type cat ON cat.id = c.category_id
        LEFT JOIN dbo.lookup_contact_types t ON t.id = c.type_id
        LEFT JOIN dbo.lookup_contact_providers p ON p.id = c.provider_id
        WHERE c.is_deleted = 0
          AND c.owner_type_id = @ownerTypeId
          AND c.owner_id = @personId
        ORDER BY c.created_at DESC, c.id DESC
      `,
      { ownerTypeId, personId },
      executor,
    );

    return mapRows<PersonContactRecord>(rows);
  }

  async getPersonAssignments(personId: number, executor?: SqlExecutor): Promise<PersonAssignmentRecord[]> {
    const rows = await runQuery(
      `
        SELECT
          a.id,
          a.org_id,
          o.name AS org_name,
          a.branch_id,
          b.name AS branch_name,
          a.org_structure_id,
          s.name AS org_structure_name,
          a.is_manager,
          a.created_at
        FROM dbo.person_assignments a
        LEFT JOIN dbo.org_entities o ON o.id = a.org_id
        LEFT JOIN dbo.org_branches b ON b.id = a.branch_id
        LEFT JOIN dbo.org_entity_structure s ON s.id = a.org_structure_id
        WHERE a.is_deleted = 0 AND a.person_id = @personId
        ORDER BY a.is_manager DESC, a.created_at DESC, a.id DESC
      `,
      { personId },
      executor,
    );

    return mapRows<PersonAssignmentRecord>(rows);
  }

  async createPersonAssignment(
    personId: number,
    payload: PersonAssignmentCreatePayload,
    ctx: WriteContext,
    executor?: SqlExecutor,
  ): Promise<PersonAssignmentRecord> {
    const inserted = await insertRow<Record<string, unknown>>(
      "person_assignments",
      {
        person_id: personId,
        org_id: payload.orgId,
        branch_id: payload.branchId,
        org_structure_id: payload.orgStructureId,
        is_manager: payload.isManager ? 1 : 0,
        work_context_by: ctx.workContextBy,
        created_by: ctx.createdBy ?? 1,
      },
      executor,
    );

    const insertedId = inserted?.id == null ? NaN : Number((inserted as any).id);
    if (!Number.isFinite(insertedId)) {
      throw new Error("Failed to create person assignment");
    }

    const row = await runQueryOne(
      `
        SELECT TOP 1
          a.id,
          a.org_id,
          o.name AS org_name,
          a.branch_id,
          b.name AS branch_name,
          a.org_structure_id,
          s.name AS org_structure_name,
          a.is_manager,
          a.created_at
        FROM dbo.person_assignments a
        LEFT JOIN dbo.org_entities o ON o.id = a.org_id
        LEFT JOIN dbo.org_branches b ON b.id = a.branch_id
        LEFT JOIN dbo.org_entity_structure s ON s.id = a.org_structure_id
        WHERE a.id = @id AND a.is_deleted = 0 AND a.person_id = @personId
      `,
      { id: insertedId, personId },
      executor,
    );

    const mapped = mapRow<PersonAssignmentRecord>(row);
    if (!mapped) throw new Error("Failed to map person assignment");
    return mapped;
  }

  async updatePerson(personId: number, patch: Record<string, unknown>, ctx: WriteContext, executor?: SqlExecutor): Promise<PersonDetailsRecord | undefined> {
    const dbPatch = toDbPatch(patch);
    dbPatch.updated_at = new Date();
    if (ctx.updatedBy != null) dbPatch.updated_by = ctx.updatedBy;
    if (ctx.workContextBy != null) dbPatch.work_context_by = ctx.workContextBy;

    const updated = await updateRow<Record<string, unknown>>({ schemaName: "dbo", tableName: "persons" }, personId, dbPatch, executor);
    if (!updated) return this.getPersonById(personId, executor);
    return this.getPersonById(personId, executor);
  }
}

export const personsModule = new PersonsModule();
