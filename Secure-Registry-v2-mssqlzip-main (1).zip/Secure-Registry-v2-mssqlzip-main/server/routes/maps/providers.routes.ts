import { Router } from "express";
import { storage } from "../../storage";

const router = Router();

router.get("/providers", async (_req, res) => {
  try {
    const providers = await storage.getEnabledMapProviders();
    res.json(providers);
  } catch (error) {
    console.error("Error fetching map providers:", error);
    res.status(500).json({ error: "Failed to fetch map providers" });
  }
});

export default router;

