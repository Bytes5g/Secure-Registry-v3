import { EntityDeleteDialog, EntityEditorSheet } from "@/components/shared";
import type { UseMutationResult } from "@tanstack/react-query";
import type { LookupType, LookupValue, LookupVirtualValue } from "@shared/schema";
import type { LookupsAdminController } from "../hooks/useLookupsAdminController";
import { LookupTypeForm } from "./LookupTypeForm";
import { LookupValueDialog, LookupVirtualSeedDialog } from "./LookupAdminDialogs";

interface LookupAdminDialogStackProps {
  controller: LookupsAdminController;
}

interface DeleteDialogConfig {
  key: string;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title: string;
  description: string;
  onConfirm: () => void;
  isSubmitting: boolean;
}

function createDialogCloseHandler(clear: () => void) {
  return (open: boolean) => {
    if (!open) {
      clear();
    }
  };
}

function isMutationPending(...mutations: Array<UseMutationResult<any, Error, any, unknown>>) {
  return mutations.some((mutation) => mutation.isPending);
}

function createDeleteDialog<TRecord extends { id: number }>({
  key,
  record,
  clearRecord,
  title,
  description,
  confirmDelete,
  isSubmitting,
}: {
  key: string;
  record: TRecord | null;
  clearRecord: () => void;
  title: string;
  description: string;
  confirmDelete: (id: number) => void;
  isSubmitting: boolean;
}): DeleteDialogConfig {
  return {
    key,
    open: Boolean(record),
    onOpenChange: createDialogCloseHandler(clearRecord),
    title,
    description,
    onConfirm: () => {
      if (record) {
        confirmDelete(record.id);
      }
    },
    isSubmitting,
  };
}

export function LookupAdminDialogStack({ controller }: LookupAdminDialogStackProps) {
  const typeDialogSubmitting = isMutationPending(controller.createTypeMutation, controller.updateTypeMutation);
  const valueDialogSubmitting = isMutationPending(controller.createValueMutation, controller.updateValueMutation);
  const virtualSeedDialogSubmitting = isMutationPending(
    controller.createVirtualSeedMutation,
    controller.updateVirtualSeedMutation,
  );

  const deleteDialogs = [
    createDeleteDialog<LookupType>({
      key: "lookup-type",
      record: controller.lookupToDelete,
      clearRecord: () => controller.setLookupToDelete(null),
      title: "حذف نوع القائمة",
      description: "سيتم حذف النوع وسجلاته التابعة من البذور الافتراضية.",
      confirmDelete: (id) => controller.deleteTypeMutation.mutate(id),
      isSubmitting: controller.deleteTypeMutation.isPending,
    }),
    createDeleteDialog<LookupValue>({
      key: "value",
      record: controller.valueToDelete,
      clearRecord: () => controller.setValueToDelete(null),
      title: "حذف القيمة",
      description: "سيتم حذف القيمة من الجدول المرتبط.",
      confirmDelete: (id) => controller.deleteValueMutation.mutate(id),
      isSubmitting: controller.deleteValueMutation.isPending,
    }),
    createDeleteDialog<LookupVirtualValue>({
      key: "virtual-seed",
      record: controller.virtualSeedToDelete,
      clearRecord: () => controller.setVirtualSeedToDelete(null),
      title: "حذف البذرة الافتراضية",
      description: "سيتم حذف السجل من `lookup_virtual_values`.",
      confirmDelete: (id) => controller.deleteVirtualSeedMutation.mutate(id),
      isSubmitting: controller.deleteVirtualSeedMutation.isPending,
    }),
  ];

  return (
    <>
      <EntityEditorSheet
        open={controller.lookupDialogOpen}
        onOpenChange={controller.setLookupDialogOpen}
        title={controller.lookupMode === "edit" ? "تحرير نوع قائمة" : "إضافة نوع قائمة"}
        description="إدارة الحقول الوصفية والربط الجدولي ومزود القيم من نموذج موحد قابل لإعادة الاستخدام."
      >
        <LookupTypeForm
          value={controller.lookupForm}
          onChange={controller.setLookupForm}
          onSubmit={controller.submitLookupType}
          isSubmitting={typeDialogSubmitting}
        />
      </EntityEditorSheet>

      <LookupValueDialog
        open={controller.valueDialogOpen}
        onOpenChange={controller.setValueDialogOpen}
        value={controller.valueForm}
        onChange={controller.setValueForm}
        onSubmit={controller.submitValue}
        isSubmitting={valueDialogSubmitting}
        isEditing={Boolean(controller.editingValue)}
      />

      <LookupVirtualSeedDialog
        open={controller.virtualSeedDialogOpen}
        onOpenChange={controller.setVirtualSeedDialogOpen}
        value={controller.virtualSeedForm}
        onChange={controller.setVirtualSeedForm}
        onSubmit={controller.submitVirtualSeed}
        isSubmitting={virtualSeedDialogSubmitting}
        isEditing={Boolean(controller.editingVirtualSeed)}
      />

      {deleteDialogs.map((dialog) => (
        <EntityDeleteDialog
          key={dialog.key}
          open={dialog.open}
          onOpenChange={dialog.onOpenChange}
          title={dialog.title}
          description={dialog.description}
          onConfirm={dialog.onConfirm}
          isSubmitting={dialog.isSubmitting}
        />
      ))}
    </>
  );
}
