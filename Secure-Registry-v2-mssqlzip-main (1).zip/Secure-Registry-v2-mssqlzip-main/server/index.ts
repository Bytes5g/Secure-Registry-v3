import "@core/database";
import express from "express";
import path from "path";
import { createServer } from "http";

import { registerRoutes } from "./routes";
import { serveStatic } from "./static";
import { responseSanitizer } from "./utils/response";
import { applySecurityMiddleware } from "./middleware/security";
import { applySessionMiddleware } from "./middleware/session";
import { applyErrorHandler } from "./middleware/errors";
import { applyRequestLogger, log } from "./utils/log";

declare module "http" {
  interface IncomingMessage {
    rawBody: unknown;
  }
}

const app = express();
const httpServer = createServer(app);

app.set("trust proxy", 1);
app.disable("etag");
app.use("/uploads", express.static(path.join(process.cwd(), "uploads")));

app.use(
  express.json({
    limit: "1mb",
    verify: (req, _res, buf) => {
      req.rawBody = buf;
    },
  }),
);
app.use(express.urlencoded({ extended: false, limit: "1mb" }));

applySecurityMiddleware(app);
app.use(responseSanitizer);
applySessionMiddleware(app);
applyRequestLogger(app);

(async () => {
  await registerRoutes(httpServer, app);
  applyErrorHandler(app);

  if (process.env.NODE_ENV === "production") {
    serveStatic(app);
  }

  const port = parseInt(process.env.PORT || "3001", 10);
  const listenOptions: any = { port, host: "0.0.0.0" };
  if (process.platform !== "win32") listenOptions.reusePort = true;

  httpServer.listen(listenOptions, () => log(`serving on port ${port}`));
})();

export { log };
