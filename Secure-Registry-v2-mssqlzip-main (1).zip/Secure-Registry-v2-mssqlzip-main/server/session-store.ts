import session from "express-session";
import { deleteSession, getSessionPayload, touchSession, upsertSession } from "@core/database";

const DEFAULT_MAX_AGE_MS = 7 * 24 * 60 * 60 * 1000;

function resolveExpires(sess: session.SessionData): Date {
  const cookieExpires = sess.cookie?.expires;
  if (cookieExpires instanceof Date) {
    return cookieExpires;
  }

  const maxAge = typeof sess.cookie?.maxAge === "number"
    ? sess.cookie.maxAge
    : DEFAULT_MAX_AGE_MS;

  return new Date(Date.now() + maxAge);
}

export class MssqlSessionStore extends session.Store {
  override get(
    sid: string,
    callback: (err?: unknown, sessionData?: session.SessionData | null) => void,
  ): void {
    void (async () => {
      try {
        const row = await getSessionPayload(sid);
        if (!row?.payload) {
          callback(undefined, null);
          return;
        }

        callback(undefined, JSON.parse(row.payload) as session.SessionData);
      } catch (error) {
        callback(error);
      }
    })();
  }

  override set(
    sid: string,
    sess: session.SessionData,
    callback?: (err?: unknown) => void,
  ): void {
    void (async () => {
      try {
        const expires = resolveExpires(sess);
        const payload = JSON.stringify(sess);
        const sessionUser = (sess as session.SessionData & { user?: Record<string, unknown> }).user;
        const userId = sessionUser?.id ? Number(sessionUser.id) : null;
        const workContextBy = sessionUser?.workContextBy == null ? null : Number(sessionUser.workContextBy);

        if (!Number.isFinite(userId as number)) {
          callback?.(new Error("لا يمكن حفظ الجلسة بدون userId صالح"));
          return;
        }
        if (!Number.isFinite(workContextBy as number)) {
          callback?.(new Error("لا يمكن حفظ الجلسة بدون سياق عمل work_context_by صالح"));
          return;
        }

        await upsertSession({
          sid,
          userId: Number.isFinite(userId as number) ? userId : null,
          expires,
          payload,
          workContextBy: workContextBy as number,
          createdBy: userId as number,
        });

        callback?.();
      } catch (error) {
        callback?.(error);
      }
    })();
  }

  override destroy(sid: string, callback?: (err?: unknown) => void): void {
    void (async () => {
      try {
        await deleteSession(sid);
        callback?.();
      } catch (error) {
        callback?.(error);
      }
    })();
  }

  override touch(
    sid: string,
    sess: session.SessionData,
    callback?: () => void,
  ): void {
    void (async () => {
      try {
        await touchSession(sid, resolveExpires(sess));
        callback?.();
      } catch {
        callback?.();
      }
    })();
  }
}
