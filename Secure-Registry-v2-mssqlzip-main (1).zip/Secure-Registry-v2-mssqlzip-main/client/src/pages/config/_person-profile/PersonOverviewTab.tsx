import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Badge, Input, Switch } from "@secure-registry/components-ui";
import { EditableInfoCard, InfoRow, ProfileOverviewTemplate } from "@/components/profile";
import { updatePerson } from "@/lib/api/persons-admin";
import type { Person } from "@shared/schema";

export function PersonOverviewTab({ person }: { person: Person }) {
  const queryClient = useQueryClient();
  const personId = person.id;
  const [isEditing, setIsEditing] = useState(false);
  const [draft, setDraft] = useState({
    firstName: person.firstName ?? "",
    fatherName: person.fatherName ?? "",
    grandfatherName: person.grandfatherName ?? "",
    familyName: person.familyName ?? "",
    dateOfBirth: person.dateOfBirth ?? "",
    isActive: !!person.isActive,
  });

  const updateMutation = useMutation({
    mutationFn: (patch: any) => updatePerson(personId, patch),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["person", personId] });
      setIsEditing(false);
    },
  });

  const handleSave = () => {
    const patch: Record<string, unknown> = {};
    if (draft.firstName !== person.firstName) patch.firstName = draft.firstName;
    if ((draft.fatherName || null) !== (person.fatherName ?? null)) patch.fatherName = draft.fatherName || null;
    if ((draft.grandfatherName || null) !== (person.grandfatherName ?? null)) patch.grandfatherName = draft.grandfatherName || null;
    if ((draft.familyName || null) !== (person.familyName ?? null)) patch.familyName = draft.familyName || null;
    if ((draft.dateOfBirth || null) !== (person.dateOfBirth ?? null)) patch.dateOfBirth = draft.dateOfBirth || null;
    if (draft.isActive !== !!person.isActive) patch.isActive = draft.isActive;
    if (Object.keys(patch).length === 0) {
      setIsEditing(false);
      return;
    }
    updateMutation.mutate(patch);
  };

  const handleCancel = () => {
    setDraft({
      firstName: person.firstName ?? "",
      fatherName: person.fatherName ?? "",
      grandfatherName: person.grandfatherName ?? "",
      familyName: person.familyName ?? "",
      dateOfBirth: person.dateOfBirth ?? "",
      isActive: !!person.isActive,
    });
    setIsEditing(false);
  };

  return (
    <ProfileOverviewTemplate
      sections={
        <EditableInfoCard
          title="البيانات الأساسية"
          isEditing={isEditing}
          isSaving={updateMutation.isPending}
          errorMessage={updateMutation.isError ? "تعذّر الحفظ. الرجاء المحاولة مرة أخرى." : null}
          onEdit={() => setIsEditing(true)}
          onSave={handleSave}
          onCancel={handleCancel}
        >
          <div className="grid md:grid-cols-2 gap-x-8">
            <div>
              <InfoRow label="الاسم الأول">
                {isEditing ? (
                  <Input
                    value={draft.firstName}
                    onChange={(e) => setDraft({ ...draft, firstName: e.target.value })}
                    className="h-8"
                  />
                ) : (
                  person.firstName || "—"
                )}
              </InfoRow>
              <InfoRow label="اسم الأب">
                {isEditing ? (
                  <Input
                    value={draft.fatherName}
                    onChange={(e) => setDraft({ ...draft, fatherName: e.target.value })}
                    className="h-8"
                  />
                ) : (
                  person.fatherName || "—"
                )}
              </InfoRow>
              <InfoRow label="اسم الجد">
                {isEditing ? (
                  <Input
                    value={draft.grandfatherName}
                    onChange={(e) => setDraft({ ...draft, grandfatherName: e.target.value })}
                    className="h-8"
                  />
                ) : (
                  person.grandfatherName || "—"
                )}
              </InfoRow>
              <InfoRow label="اللقب / اسم العائلة">
                {isEditing ? (
                  <Input
                    value={draft.familyName}
                    onChange={(e) => setDraft({ ...draft, familyName: e.target.value })}
                    className="h-8"
                  />
                ) : (
                  person.familyName || "—"
                )}
              </InfoRow>
            </div>
            <div>
              <InfoRow label="الاسم الكامل">
                <span className="font-medium">{person.fullName || "—"}</span>
              </InfoRow>
              <InfoRow label="تاريخ الميلاد">
                {isEditing ? (
                  <Input
                    value={draft.dateOfBirth}
                    onChange={(e) => setDraft({ ...draft, dateOfBirth: e.target.value })}
                    className="h-8"
                    placeholder="yyyy-mm-dd"
                  />
                ) : (
                  <span className="text-muted-foreground">{person.dateOfBirth || "—"}</span>
                )}
              </InfoRow>
              <InfoRow label="الجنس">
                <Badge variant="outline">{person.genderName ?? "—"}</Badge>
              </InfoRow>
              <InfoRow label="الجنسية">
                <Badge variant="outline">{person.nationalityName ?? "—"}</Badge>
              </InfoRow>
              <InfoRow label="الحالة الاجتماعية">
                <Badge variant="outline">{person.maritalName ?? "—"}</Badge>
              </InfoRow>
              <InfoRow label="الحالة">
                {isEditing ? (
                  <Switch checked={draft.isActive} onCheckedChange={(v) => setDraft({ ...draft, isActive: v })} />
                ) : (
                  <Badge variant={person.isActive ? "secondary" : "outline"}>
                    {person.isActive ? "فعّال" : "موقوف"}
                  </Badge>
                )}
              </InfoRow>
              <InfoRow label="المعرّف">
                <span className="tabular-nums text-muted-foreground">#{person.id}</span>
              </InfoRow>
            </div>
          </div>
        </EditableInfoCard>
      }
    />
  );
}
