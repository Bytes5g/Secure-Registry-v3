import type { SqlExecutor } from "../config/connection";
import {
  getLookupVirtualValues,
  type LookupConfig,
} from "./lookup-registry";
import type { LookupValueRecord } from "./lookup-records";

type LookupProvider = {
  getAll: (config: LookupConfig, executor?: SqlExecutor) => Promise<LookupValueRecord[]>;
  getById: (config: LookupConfig, id: number, executor?: SqlExecutor) => Promise<LookupValueRecord | undefined>;
};

function buildSeededLookupValue(
  typeId: number,
  seed: {
    valueId: number;
    code: string;
    nameAr: string;
    orderIndex: number;
    aliases: string[];
    createdAt: string | null;
  },
): LookupValueRecord {
  return {
    id: seed.valueId,
    typeId,
    code: seed.code,
    nameAr: seed.nameAr,
    orderIndex: seed.orderIndex,
    isActive: true,
    parentId: null,
    metadata: seed.aliases.length > 0 ? { aliases: seed.aliases } : null,
    createdAt: seed.createdAt,
  };
}

async function getSeededLookupValues(typeId: number): Promise<LookupValueRecord[]> {
  const seeds = await getLookupVirtualValues(typeId);
  return seeds.map((seed) => buildSeededLookupValue(typeId, seed));
}


async function getSeededValueById(typeId: number, id: number): Promise<LookupValueRecord | undefined> {
  return (await getSeededLookupValues(typeId)).find((value) => value.id === id);
}

const providers: Record<string, LookupProvider> = {};

export async function getProvidedLookupValues(
  config: LookupConfig,
  executor?: SqlExecutor,
): Promise<LookupValueRecord[]> {
  if (!config.valueProviderKey) {
    return getSeededLookupValues(config.id);
  }

  const provider = providers[config.valueProviderKey];
  if (!provider) {
    return getSeededLookupValues(config.id);
  }

  return provider.getAll(config, executor);
}

export async function getProvidedLookupValueById(
  config: LookupConfig,
  id: number,
  executor?: SqlExecutor,
): Promise<LookupValueRecord | undefined> {
  if (!config.valueProviderKey) {
    return getSeededValueById(config.id, id);
  }

  const provider = providers[config.valueProviderKey];
  if (!provider) {
    return getSeededValueById(config.id, id);
  }

  return provider.getById(config, id, executor);
}
