import { Router, type Request } from "express";
import { storage } from "../../storage";
import { insertLookupValueSchema } from "@shared/schema";
import { requireWriteContext } from "../_internals";
import {
  isAmbiguousLookupError,
  isReadOnlyLookupError,
  normalizeLookupValueBody,
  parseOptionalTypeId,
} from "./helpers";

const router = Router();

// Get values by type ID (alternative route used by admin UI)
router.get("/types/:typeId/values", async (req, res) => {
  try {
    const typeId = parseInt(req.params.typeId);
    const values = await storage.getLookupValuesByTypeId(typeId);
    res.json(values);
  } catch (error) {
    console.error("Error fetching lookup values:", error);
    res.status(500).json({ error: "Failed to fetch lookup values" });
  }
});

router.get("/values/type/:typeId", async (req, res) => {
  try {
    const typeId = parseInt(req.params.typeId);
    const values = await storage.getLookupValuesByTypeId(typeId);
    res.json(values);
  } catch (error) {
    console.error("Error fetching lookup values:", error);
    res.status(500).json({ error: "Failed to fetch lookup values" });
  }
});

router.get("/values/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const typeId = parseOptionalTypeId(req.query.typeId);
    const value = await storage.getLookupValue(id, typeId);
    if (!value) return res.status(404).json({ error: "Lookup value not found" });
    res.json(value);
  } catch (error) {
    if (isAmbiguousLookupError(error)) return res.status(400).json({ error: error.message });
    console.error("Error fetching lookup value:", error);
    res.status(500).json({ error: "Failed to fetch lookup value" });
  }
});

router.post("/values", async (req, res) => {
  try {
    const body = normalizeLookupValueBody(req.body ?? {});
    const parsed = insertLookupValueSchema.safeParse(body);
    if (!parsed.success) {
      return res.status(400).json({ error: "Invalid lookup value data", details: parsed.error });
    }
    const ctx = await requireWriteContext(req);
    const value = await storage.createLookupValue({
      ...(parsed.data as any),
      workContextBy: ctx.workContextBy,
      createdBy: ctx.userId,
    } as any);
    res.status(201).json(value);
  } catch (error) {
    if (isReadOnlyLookupError(error)) return res.status(403).json({ error: error.message });
    console.error("Error creating lookup value:", error);
    res.status(500).json({ error: "Failed to create lookup value" });
  }
});

router.patch("/values/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const body = normalizeLookupValueBody(req.body ?? {});
    body.typeId = parseOptionalTypeId(body.typeId ?? req.query.typeId);
    const ctx = await requireWriteContext(req);
    const value = await storage.updateLookupValue(
      id,
      {
        ...(body as any),
        workContextBy: (body as any).workContextBy ?? ctx.workContextBy,
        updatedBy: ctx.userId,
        updatedAt: new Date(),
      } as any,
      body.typeId as number | undefined,
    );
    if (!value) return res.status(404).json({ error: "Lookup value not found" });
    res.json(value);
  } catch (error) {
    if (isAmbiguousLookupError(error)) return res.status(400).json({ error: error.message });
    if (isReadOnlyLookupError(error)) return res.status(403).json({ error: error.message });
    console.error("Error updating lookup value:", error);
    res.status(500).json({ error: "Failed to update lookup value" });
  }
});

router.delete("/values/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const typeId = parseOptionalTypeId(req.query.typeId);
    const ctx = await requireWriteContext(req);
    const success = await storage.deleteLookupValue(id, typeId, {
      workContextBy: ctx.workContextBy,
      updatedBy: ctx.userId,
    });
    if (!success) return res.status(404).json({ error: "Lookup value not found" });
    res.status(204).send();
  } catch (error) {
    if (isAmbiguousLookupError(error)) return res.status(400).json({ error: error.message });
    if (isReadOnlyLookupError(error)) return res.status(403).json({ error: error.message });
    console.error("Error deleting lookup value:", error);
    res.status(500).json({ error: "Failed to delete lookup value" });
  }
});

export default router;
