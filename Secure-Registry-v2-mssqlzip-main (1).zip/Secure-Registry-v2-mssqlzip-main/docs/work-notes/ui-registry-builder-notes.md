# ملاحظات تنفيذ (Work Notes): UI Registry / Builder

هذا الملف مخصص لملاحظات التنفيذ المتغيرة (Execution Notes) الخاصة بتأسيس UI Registry وواجهة الـ Builder. لا يُعامل كوثيقة معمارية نهائية؛ الوثائق المرجعية ثابتة في `docs/frontend-modules/` وملفات الحوكمة داخل `docs/`.

سجل الإنجاز المختصر (ما تم تنفيذه فعلياً) موجود هنا:
- [progress.md](./progress.md)

مرجع القوالب/الـ runtime/`mapping_json`:
- [04-ui-templates-and-runtime-contract.md](../frontend-modules/04-ui-templates-and-runtime-contract.md)

## المحتويات

- [1) ما لدينا اليوم](#1-ما-لدينا-اليوم-قابل-لإعادة-الاستخدام-مباشرة)
- [2) Dictionary-first](#2-dictionary-first-مصدر-الحقيقة-للعرض)
- [3) قواعد توليد مثبتة حالياً](#3-قواعد-توليد-مثبتة-حالياً-generator-rules)
- [4) ما الذي ينقص قبل أي توسعة DDL](#4-الخطوة-2-من-roadmap-تأسيس-registry-ديناميكي-قبل-أي-ddl)

## 1) ما لدينا اليوم (قابل لإعادة الاستخدام مباشرة)

### 1.1 CRUD عام (Config-driven)
- القالب: `GenericEntityPage` + `DynamicForm` مبنيان على `UiPageConfig`.
- الهدف: جعل `UiPageConfig` يأتي من Registry في DB بدل تعريفات ثابتة في الملفات.

مراجع:
- [GenericEntityPage.tsx](../../client/src/components/generic/GenericEntityPage.tsx)
- [DynamicForm.tsx](../../client/src/components/forms/DynamicForm.tsx)
- [ui.ts](../../client/src/types/ui.ts)

### 1.2 Profile (Shell + Tabs)
- بروفايل الجهة يثبت نمط: صفحة رئيسية + Header + Tabs.
- كل Tab إمّا:
  - Generic CRUD (بـ `entityType` + `apiParams` + `UiPageConfig`)
  - أو Tab خاص (overview/diagram/employees) يحتاج Data Sources + Runtime injections

مراجع:
- [org-entity-profile.tsx](../../client/src/pages/config/org-entity-profile.tsx)
- [EntityRelationsTabs.tsx](../../packages/core/components-ui/shared/EntityRelationsTabs.tsx)

## 2) Dictionary-first (مصدر الحقيقة للعرض)

المرجع الأول لبناء أسماء العرض والأنواع والعلاقات:
- `[secure_registry_v4].[dbo].[v_schema_dictionary_columns]`

نستفيد من:
- `formatted_table_name` و`formatted_name` لتوحيد مفاتيح/تسميات UI
- `object_description` و`column_description` لاسم الصفحة والحقل
- `ui_column_type` لتحديد نوع العمود/الحقل في UI دون استنتاج من `data_type`
- FK/PK metadata لتجهيز روابط lookup وdetail panels لاحقاً

## 2.1) Standard Fields (Cross-cutting)

لتقليل التكرار في أسماء الحقول وHints عبر النظام، تم اعتماد مصدر إضافي أعلى أولوية للعرض:

- `dbo.standard_field_dictionary`:
  - `name` لمسمى الحقل
  - `description` لتلميح الحقل (يمرر كـ `placeholder`)
  - `ui_column_type` لنوع العرض

هرمية المصدر الافتراضي:
- `standard_field_dictionary` → `v_schema_dictionary_columns` → fallback لاسم الحقل.

## 3) قواعد توليد مثبتة حالياً (Generator Rules)

### 3.1) ui_column_type → UI
- القيم الحالية: `text` / `number` / `boolean` / `date`
- الترجمة:
  - `text` → Column: `text` / Field: `text` (وقد يتحول إلى `textarea` إذا كان الطول كبيراً)
  - `number` → Column: `number` / Field: `number`
  - `boolean` → Column: `boolean` / Field: `boolean`
  - `date` → Column: `date` / Field: `text` (إلى أن يتم دعم date input في `DynamicForm`)

### 3.2) FK → Select عبر lookup_types
إذا كان العمود FK ويشير إلى جدول مُعرّف داخل `dbo.lookup_types` (schema_name + table_name)، فيتم توليد:
- Column: `select` مع `lookupTypeId = lookup_types.id`
- Field: `select` مع `lookupTypeId = lookup_types.id`

## 4) الخطوة 2 (من Roadmap): تأسيس Registry ديناميكي (قبل أي DDL)

الهدف في هذه المرحلة هو بناء Registry حقيقي **بدون تكرار** عبر استخراج Inventory من الشاشات الموجودة وربطه بالقاموس، مع مراعاة أن طبقة Overrides الأساسية تم تنفيذها بالفعل.

1) **Inventory extraction من الواجهة الحالية**
- قائمة الصفحات (pages) + تبويباتها (tabs) + القوالب المستخدمة (Generic/Custom)
- مصادر البيانات المستخدمة لكل تبويب (endpoints + params + response mapping)
  - معيار `mapping_json` موحّد في: [04-ui-templates-and-runtime-contract.md](../frontend-modules/04-ui-templates-and-runtime-contract.md#4-معيار-mapping_json-ui_tab_data_sourcesmapping_json)

2) **Dictionary binding**
- مطابقة كل `entityType/table` مع `v_schema_dictionary_columns` لتحديد:
  - التسميات الافتراضية
  - الأنواع الافتراضية (ui_column_type)
  - علاقات FK التي تتحول إلى Select عبر lookup_types

3) **ما هو منفّذ فعلياً اليوم**
- API:
  - `/api/ui/pages/:pageCode` لتوليد `UiPageConfig` من القاموس
  - `/api/ui/pages/:pageCode/override` لإدارة override
- جداول DB:
  - مستخدمة: `ui_page_tabs`, `ui_page_columns`, `ui_page_form_fields`
  - مربوطة جزئياً: `ui_data_sources`, `ui_tab_data_sources` (تعريف مصادر البيانات في DB + تنفيذها مع allowlist للباراميترات + حوكمة تنفيذ)

4) **ما الذي ينقص قبل أي توسعة DDL**
- تم البدء باستهلاك `ui_tab_data_sources` على مستوى UI Runtime (بدءاً بصفحة الأشخاص) لاختيار `dataSourceKey` حسب `tabKey/purpose`.
- المتبقي: تعميم قوالب صفحات /config وفق `pageTemplateKey` (Page Templates) وإضافة شاشة Catalog للقوالب (Read-only) قبل التفكير بأي DDL إضافي.
- تثبيت حوكمة تنفيذ `ui_data_sources`:
  - التنفيذ يتطلب مستخدم مصادق، مع سماح عبر `isSuperAdmin` أو عبر `parameters_json.allowedRoles/allowedPermissions` بحسب تعريف الـ DataSource.
- تقليل hardcoding في الواجهة تدريجياً لصالح config القابل للتهيئة (أمثلة: بحث الأشخاص، أعمدة الجداول، حقول النماذج).
- بعد إثبات الحاجة فقط: إضافة ما ينقص من registry الأعلى (مثل `ui_modules/ui_pages` + draft/publish/versioning) مع الالتزام بـ entry/audit و`is_active/is_deleted`.
