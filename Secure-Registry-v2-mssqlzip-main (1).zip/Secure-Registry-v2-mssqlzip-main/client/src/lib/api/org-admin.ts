import type { OrganizationalStructure, InsertOrganizationalStructure, OrgStructureTree, InsertOrgStructureTree, LookupValue, OrgLogo, OrgCover } from "@shared/schema";
import { LOOKUP_CODES } from "@shared/constants/lookup-codes";

export interface OrgQueryParams {
  page?: number;
  limit?: number;
  search?: string;
  sectorId?: number;
  categoryId?: number;
  isActive?: boolean;
}

export interface PaginatedOrgResponse<T> {
  data: T[];
  pagination: {
    page: number;
    limit: number;
    total: number;
    totalPages: number;
  };
}

export interface OrgWithDetails extends OrganizationalStructure {
  sector?: LookupValue;
  location?: LookupValue;
  category?: LookupValue;
}

export interface TreeNodeWithChildren extends OrgStructureTree {
  structure?: LookupValue;
  children: TreeNodeWithChildren[];
}

// Organizations API
export async function fetchOrganizations(details?: false): Promise<OrganizationalStructure[]>;
export async function fetchOrganizations(details: true): Promise<OrgWithDetails[]>;
export async function fetchOrganizations(details = false): Promise<OrganizationalStructure[] | OrgWithDetails[]> {
  const url = details ? "/api/org/organizations?details=true" : "/api/org/organizations";
  const response = await fetch(url);
  if (!response.ok) throw new Error("Failed to fetch organizations");
  return response.json();
}

export async function fetchOrganization(id: number, details?: false): Promise<OrganizationalStructure>;
export async function fetchOrganization(id: number, details: true): Promise<OrgWithDetails>;
export async function fetchOrganization(id: number, details = false): Promise<OrganizationalStructure | OrgWithDetails> {
  const url = details ? `/api/org/organizations/${id}?details=true` : `/api/org/organizations/${id}`;
  const response = await fetch(url);
  if (!response.ok) throw new Error("Failed to fetch organization");
  return response.json();
}

export async function fetchOrganizationChildren(
  parentId: number | null,
  options?: { includeInactive?: boolean },
): Promise<OrganizationalStructure[]> {
  const pid = parentId === null ? "null" : parentId;
  const includeInactive = options?.includeInactive ? "1" : undefined;
  const url = new URL(`/api/org/organizations/children/${pid}`, window.location.origin);
  if (includeInactive) url.searchParams.set("includeInactive", includeInactive);
  const response = await fetch(url.toString());
  if (!response.ok) throw new Error("Failed to fetch organization children");
  return response.json();
}

export async function createOrganization(data: InsertOrganizationalStructure): Promise<OrganizationalStructure> {
  const response = await fetch("/api/org/organizations", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
  if (!response.ok) throw new Error("Failed to create organization");
  return response.json();
}

export async function updateOrganization(id: number, data: Partial<InsertOrganizationalStructure>): Promise<OrganizationalStructure> {
  const response = await fetch(`/api/org/organizations/${id}`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
  if (!response.ok) throw new Error("Failed to update organization");
  return response.json();
}

export async function deleteOrganization(id: number): Promise<void> {
  const response = await fetch(`/api/org/organizations/${id}`, { method: "DELETE" });
  if (!response.ok) throw new Error("Failed to delete organization");
}

export async function fetchOrganizationLogo(orgId: number): Promise<OrgLogo | null> {
  const response = await fetch(`/api/org/organizations/${orgId}/logo`);
  if (!response.ok) throw new Error("Failed to fetch organization logo");
  return response.json();
}

export type OrgMediaHistoryItem = {
  id: number;
  fileId: number;
  orgId: number;
  filePath: string;
  fileName: string | null;
  title?: string | null;
  mimeType: string | null;
  size: number | null;
  isPrimary: boolean;
  description: string | null;
  createdAt: string | null;
};

export type OrgMediaHistoryResponse = {
  current: OrgMediaHistoryItem | null;
  history: OrgMediaHistoryItem[];
};

export async function fetchOrganizationLogoHistory(orgId: number): Promise<OrgMediaHistoryResponse> {
  const response = await fetch(`/api/org/organizations/${orgId}/logo?includeHistory=1`);
  if (!response.ok) throw new Error("Failed to fetch organization logo history");
  return response.json();
}

export async function uploadOrganizationLogo(orgId: number, file: File, description?: string): Promise<OrgLogo> {
  const formData = new FormData();
  formData.append("logo", file);
  if (description) {
    formData.append("description", description);
  }

  const response = await fetch(`/api/org/organizations/${orgId}/logo`, {
    method: "POST",
    body: formData,
  });
  if (!response.ok) throw new Error("Failed to upload organization logo");
  return response.json();
}

export async function setOrganizationLogoFromExisting(orgId: number, fileId: number): Promise<OrgLogo> {
  const response = await fetch(`/api/org/organizations/${orgId}/logo`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ fileId }),
  });
  if (!response.ok) throw new Error("Failed to set organization logo");
  return response.json();
}

export async function deleteOrganizationLogo(orgId: number): Promise<void> {
  const response = await fetch(`/api/org/organizations/${orgId}/logo`, { method: "DELETE" });
  if (!response.ok) throw new Error("Failed to delete organization logo");
}

export async function fetchOrganizationCover(orgId: number): Promise<OrgCover | null> {
  const response = await fetch(`/api/org/organizations/${orgId}/cover`);
  if (!response.ok) throw new Error("Failed to fetch organization cover");
  return response.json();
}

export async function fetchOrganizationCoverHistory(orgId: number): Promise<OrgMediaHistoryResponse> {
  const response = await fetch(`/api/org/organizations/${orgId}/cover?includeHistory=1`);
  if (!response.ok) throw new Error("Failed to fetch organization cover history");
  return response.json();
}

export async function uploadOrganizationCover(orgId: number, file: File, description?: string): Promise<OrgCover> {
  const formData = new FormData();
  formData.append("cover", file);
  if (description) {
    formData.append("description", description);
  }

  const response = await fetch(`/api/org/organizations/${orgId}/cover`, {
    method: "POST",
    body: formData,
  });
  if (!response.ok) throw new Error("Failed to upload organization cover");
  return response.json();
}

export async function setOrganizationCoverFromExisting(orgId: number, fileId: number): Promise<OrgCover> {
  const response = await fetch(`/api/org/organizations/${orgId}/cover`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ fileId }),
  });
  if (!response.ok) throw new Error("Failed to set organization cover");
  return response.json();
}

export async function deleteOrganizationCover(orgId: number): Promise<void> {
  const response = await fetch(`/api/org/organizations/${orgId}/cover`, { method: "DELETE" });
  if (!response.ok) throw new Error("Failed to delete organization cover");
}

// Org Tree API
export async function fetchOrgTree(
  orgId: number,
  options?: { includeInactive?: boolean },
): Promise<TreeNodeWithChildren[]> {
  const includeInactive = options?.includeInactive ? "1" : undefined;
  const url = new URL(`/api/org/organizations/${orgId}/tree`, window.location.origin);
  if (includeInactive) url.searchParams.set("includeInactive", includeInactive);
  const response = await fetch(url.toString());
  if (!response.ok) throw new Error("Failed to fetch org tree");
  return response.json();
}

export async function fetchOrgTreeFlat(
  orgId: number,
  options?: { includeInactive?: boolean },
): Promise<OrgStructureTree[]> {
  const includeInactive = options?.includeInactive ? "1" : undefined;
  const url = new URL(`/api/org/organizations/${orgId}/tree/flat`, window.location.origin);
  if (includeInactive) url.searchParams.set("includeInactive", includeInactive);
  const response = await fetch(url.toString());
  if (!response.ok) throw new Error("Failed to fetch org tree nodes");
  return response.json();
}

export async function fetchOrgTreeChildren(
  orgId: number,
  parentId: number | null,
  options?: { includeInactive?: boolean },
): Promise<OrgStructureTree[]> {
  const pid = parentId === null ? "null" : parentId;
  const includeInactive = options?.includeInactive ? "1" : undefined;
  const url = new URL(`/api/org/organizations/${orgId}/tree/children/${pid}`, window.location.origin);
  if (includeInactive) url.searchParams.set("includeInactive", includeInactive);
  const response = await fetch(url.toString());
  if (!response.ok) throw new Error("Failed to fetch tree children");
  return response.json();
}

export async function fetchOrgEmployees(orgId: number): Promise<any[]> {
  const response = await fetch(`/api/org/organizations/${orgId}/employees`);
  if (!response.ok) throw new Error("Failed to fetch org employees");
  return response.json();
}

export async function fetchTreeNode(id: number): Promise<OrgStructureTree> {
  const response = await fetch(`/api/org/tree-nodes/${id}`);
  if (!response.ok) throw new Error("Failed to fetch tree node");
  return response.json();
}

export async function createTreeNode(data: InsertOrgStructureTree): Promise<OrgStructureTree> {
  const response = await fetch("/api/org/tree-nodes", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
  if (!response.ok) throw new Error("Failed to create tree node");
  return response.json();
}

export async function updateTreeNode(id: number, data: Partial<InsertOrgStructureTree>): Promise<OrgStructureTree> {
  const response = await fetch(`/api/org/tree-nodes/${id}`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
  if (!response.ok) throw new Error("Failed to update tree node");
  return response.json();
}

export async function deleteTreeNode(id: number): Promise<void> {
  const response = await fetch(`/api/org/tree-nodes/${id}`, { method: "DELETE" });
  if (!response.ok) throw new Error("Failed to delete tree node");
}

// Lookup helpers — codes resolved from the shared constants registry
async function fetchLookupValuesByCode(typeCode: string, errorLabel: string): Promise<LookupValue[]> {
  const response = await fetch(`/api/lookups/types/by-code/${typeCode}/values`);
  if (!response.ok) throw new Error(`Failed to fetch ${errorLabel}`);
  return response.json();
}

export function fetchOrgSectors(): Promise<LookupValue[]> {
  return fetchLookupValuesByCode(LOOKUP_CODES.org.sector, "org sectors");
}

export function fetchOrgCategories(): Promise<LookupValue[]> {
  return fetchLookupValuesByCode(LOOKUP_CODES.org.category, "org categories");
}

export function fetchStructureCodes(): Promise<LookupValue[]> {
  return fetchLookupValuesByCode(LOOKUP_CODES.org.structure, "structure codes");
}
