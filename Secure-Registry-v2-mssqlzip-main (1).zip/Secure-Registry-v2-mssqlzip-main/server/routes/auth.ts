import { Router } from "express";
import { z } from "zod";
import { authModule, userContextModule } from "@core/database";
import { comparePassword } from "../utils/password";

const router = Router();

router.use((_req, res, next) => {
  res.setHeader("Cache-Control", "no-store");
  next();
});

const loginSchema = z.object({
  username: z.string().min(1),
  password: z.string().min(1),
});

router.post("/login", async (req, res) => {
  const parsed = loginSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: "بيانات دخول غير صالحة" });
  }

  const { username, password } = parsed.data;

  try {
    const user = await authModule.findUserByLogin(username);
    if (!user || user.status !== "active") {
      return res.status(401).json({ error: "اسم المستخدم أو كلمة المرور غير صحيحة" });
    }

    const isValid = user.password
      ? await comparePassword(password, user.password)
      : false;
    if (!isValid) {
      return res.status(401).json({ error: "اسم المستخدم أو كلمة المرور غير صحيحة" });
    }

    const roleRecord = user.roleId ? await authModule.getRoleById(user.roleId) : undefined;
    const roleName = (roleRecord?.name || "").toLowerCase();
    const normalizedRole =
      roleName.includes("admin") ? "admin" :
      roleName.includes("invest") ? "investigator" :
      "analyst";
    const isSuperAdmin = normalizedRole === "admin";
    const displayName = [user.firstName, user.lastName].filter(Boolean).join(" ").trim() || user.email || username;

    const context = await userContextModule.getUserEntryContext(user.id);
    if (!context?.workContext) {
      return res.status(403).json({ error: "لا يوجد سياق عمل (work_context) صالح لهذا المستخدم" });
    }

    const sessionUser = {
      id: String(user.id),
      name: displayName,
      role: normalizedRole,
      roles: roleRecord ? [roleRecord.name] : [],
      isSuperAdmin,
      permissions: isSuperAdmin ? ["*"] : [],
      orgId: context.orgId,
      branchId: context.branchId,
      ...(context.orgStructureId != null ? { orgStructureId: context.orgStructureId } : {}),
      workContextBy: context.workContext,
      isManager: context.isManager,
    };

    await authModule.updateLastAccess(user.id);

    // @ts-ignore
    req.session.user = sessionUser;
    req.session.save((err) => {
      if (err) {
        return res.status(500).json({ error: "تعذر حفظ الجلسة" });
      }
      return res.json({ success: true, user: sessionUser, context });
    });
  } catch (error) {
    console.error("Login error:", error);
    res.status(500).json({ error: "حدث خطأ أثناء تسجيل الدخول" });
  }
});

router.post("/logout", (req, res) => {
  req.session.destroy((err) => {
    if (err) {
      return res.status(500).json({ error: "فشل في إنهاء الجلسة" });
    }
    res.json({ success: true });
  });
});

router.get("/me", (req, res) => {
  // @ts-ignore
  const user = req.session.user;
  if (!user) {
    return res.json({ authenticated: false, user: null });
  }
  res.json({ authenticated: true, user });
});

router.get("/context", async (req, res) => {
  // @ts-ignore
  const user = req.session.user;
  if (!user?.id) {
    return res.json({ authenticated: false, user: null, context: null });
  }

  const userId = Number(user.id);
  if (!Number.isFinite(userId)) {
    return res.status(400).json({ error: "معرف مستخدم غير صالح" });
  }

  try {
    const context = await userContextModule.getUserEntryContext(userId);
    if (context) {
      user.orgId = context.orgId;
      user.branchId = context.branchId;
      (user as any).orgStructureId = context.orgStructureId;
      (user as any).workContextBy = context.workContext;
      (user as any).isManager = context.isManager;
    }
    res.json({ authenticated: true, user, context: context ?? null });
  } catch (error) {
    console.error("Context error:", error);
    res.status(500).json({ error: "فشل في جلب سياق المستخدم" });
  }
});

export default router;
