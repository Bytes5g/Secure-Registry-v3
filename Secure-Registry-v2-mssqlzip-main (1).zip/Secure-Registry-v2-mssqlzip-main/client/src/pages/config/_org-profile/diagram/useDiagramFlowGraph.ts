import { useMemo } from "react";
import { MarkerType, layoutTreeTidy } from "@secure-registry/components-ui";
import {
  BRANCH_NODE_COLOR,
  BRANCH_NODE_OFFSET_X,
  BRANCH_NODE_OFFSET_Y,
  TIDY_LAYOUT_OPTIONS,
} from "./constants";

interface UseDiagramFlowGraphArgs {
  treeNodes: any[];
  branchesByNode: any[];
  structureById: Map<number, any>;
  nodeTypeByNodeId?: Map<number, string>;
  managerByUnitId?: Map<number, { fullName: string; roleTitleName: string | null }>;
  employeesByUnitId?: Map<number, any[]>;
  assignedNodeIds: Set<number>;
  highlightedNodeIds: Set<number>;
  selectedUnitId: number | null;
  effectiveBranchId: number | null;
  effectiveNodeId: number | null;
  scope: "org" | "branch" | "unit";
  showBranchAssignments: boolean;
  showOnlySelectedUnitChildren: boolean;
  showUnitBranchesOnDiagram: boolean;
  showOrgChartStaff: boolean;
  showHierarchyEdges: boolean;
  showCoverageEdges: boolean;
  showEdgeLabels: boolean;
  colorEdges: boolean;
  focusOnly: boolean;
  layoutNonce: number;
}

interface NormalizedItem {
  id: string;
  parentId: string | null;
  order: number;
  level: number | null;
}

function normalizeItems(treeNodes: any[]): NormalizedItem[] {
  return treeNodes.map((raw) => {
    const rawParent = raw?.parentId ?? raw?.parent_id ?? null;
    return {
      id: String(raw?.id),
      parentId: rawParent == null ? null : String(rawParent),
      order: raw?.orderIndex ?? raw?.order_index ?? 0,
      level: raw?.level ?? null,
    };
  });
}

function buildNode(
  item: NormalizedItem,
  raw: any,
  position: { x: number; y: number } | undefined,
  ctx: UseDiagramFlowGraphArgs,
): any {
  if (raw?.kind === "employee") {
    const unitId = Number(raw.unitId);
    const isInFocus = Number.isFinite(unitId) ? ctx.highlightedNodeIds.has(unitId) : false;
    const title = String(raw.fullName ?? "");
    const subtitle = raw.branchName ? String(raw.branchName) : undefined;
    const roleTitleName = raw.roleTitleName ? String(raw.roleTitleName) : "";
    const badgeValue = roleTitleName.trim() ? roleTitleName : "موظف";
    return {
      id: item.id,
      type: "card",
      position: position ?? { x: 0, y: 0 },
      data: {
        title,
        subtitle,
        badge: badgeValue,
        highlighted: isInFocus,
        dimmed: false,
        tone: isInFocus ? "default" : "muted",
      },
    };
  }

  const numericId = Number(item.id);
  const isAssigned = ctx.assignedNodeIds.has(numericId);
  const isHighlighted = ctx.highlightedNodeIds.has(numericId);
  const branchTypeName =
    ctx.scope === "branch" && ctx.showBranchAssignments && ctx.effectiveBranchId && isAssigned
      ? ctx.nodeTypeByNodeId?.get(numericId) ?? null
      : null;

  const structureId = raw?.structureId ?? raw?.structure_id ?? null;
  const structureInfo = structureId == null ? undefined : ctx.structureById.get(Number(structureId));
  const fallbackStructureName = structureInfo?.name ?? structureInfo?.name_ar ?? structureInfo?.nameAr ?? null;
  const structureName = branchTypeName ?? fallbackStructureName;

  const badgeParts: string[] = [];
  if (structureName) badgeParts.push(String(structureName));
  const levelValue = raw?.level ?? raw?.level_value;
  if (levelValue != null) badgeParts.push(`L${levelValue}`);

  const clare = structureInfo?.clare ? String(structureInfo.clare) : null;
  const toneFromClare =
    clare === "accent" || clare === "muted" || clare === "danger" || clare === "default"
      ? clare
      : undefined;
  const color = structureInfo?.color ? String(structureInfo.color) : undefined;

  const highlight =
    ctx.scope === "branch"
      ? ctx.showBranchAssignments && ctx.effectiveBranchId
        ? isAssigned
        : false
      : ctx.effectiveNodeId
        ? numericId === ctx.effectiveNodeId
        : false;

  const subtitleParts: string[] = [];
  if (raw?.code) subtitleParts.push(String(raw.code));
  const manager = ctx.managerByUnitId?.get(numericId);
  if (manager?.fullName) {
    subtitleParts.push(
      manager.roleTitleName ? `${manager.fullName} (${manager.roleTitleName})` : manager.fullName,
    );
  }

  return {
    id: item.id,
    type: "card",
    position: position ?? { x: 0, y: 0 },
    data: {
      title: String(raw?.name ?? ""),
      subtitle: subtitleParts.length ? subtitleParts.join(" · ") : undefined,
      badge: badgeParts.length ? badgeParts.join(" · ") : undefined,
      color,
      highlighted: highlight,
      dimmed: false,
      tone:
        ctx.showBranchAssignments && ctx.effectiveBranchId
          ? isAssigned
            ? "accent"
            : isHighlighted
              ? "default"
              : "muted"
          : (toneFromClare ?? (item.parentId ? "default" : "accent")),
    },
  };
}

function buildHierarchyEdge(
  item: NormalizedItem,
  rawById: Map<string, any>,
  ctx: UseDiagramFlowGraphArgs,
): any {
  const targetRaw = rawById.get(item.id);
  const isEmployee = targetRaw?.kind === "employee";
  const targetStructureId = targetRaw?.structureId ?? targetRaw?.structure_id ?? null;
  const targetStructureInfo =
    targetStructureId == null ? undefined : ctx.structureById.get(Number(targetStructureId));
  const edgeColor =
    isEmployee
      ? (ctx.colorEdges ? "#94a3b8" : undefined)
      : (ctx.colorEdges && targetStructureInfo?.color ? String(targetStructureInfo.color) : undefined);
  const focusId = isEmployee ? Number(targetRaw?.unitId) : Number(item.id);
  const isInFocus = Number.isFinite(focusId) ? ctx.highlightedNodeIds.has(focusId) : false;

  return {
    id: `e:${item.parentId}:${item.id}`,
    source: String(item.parentId),
    target: String(item.id),
    type: "hierarchy",
    animated: false,
    data: { label: ctx.showEdgeLabels ? (isEmployee ? "يتبع" : "تبعية") : undefined, color: edgeColor, dashed: false },
    markerEnd: { type: MarkerType.ArrowClosed, width: 18, height: 18 },
    style: {
      strokeWidth: isInFocus ? 2.5 : 1.5,
      opacity: 1,
      ...(edgeColor ? { stroke: edgeColor } : null),
    },
  };
}

function buildBranchOverlay(
  anchorId: string,
  anchorPos: { x: number; y: number },
  ctx: UseDiagramFlowGraphArgs,
) {
  const branchFlowNodes = ctx.branchesByNode.map((b, index) => ({
    id: `branch-${String(b.id)}`,
    type: "card",
    position: {
      x: anchorPos.x + BRANCH_NODE_OFFSET_X,
      y: anchorPos.y + index * BRANCH_NODE_OFFSET_Y,
    },
    data: {
      title: String(b.name ?? b.nameAr ?? `فرع ${b.id}`),
      subtitle: b.code ? String(b.code) : undefined,
      badge: "فرع",
      color: BRANCH_NODE_COLOR,
      highlighted: true,
      dimmed: false,
      tone: "accent",
    },
  }));

  const branchEdges = ctx.branchesByNode.map((b) => ({
    id: `e:node:${anchorId}:branch:${String(b.id)}`,
    source: anchorId,
    target: `branch-${String(b.id)}`,
    type: "coverage",
    animated: false,
    data: {
      label: ctx.showEdgeLabels ? "يغطيها" : undefined,
      color: ctx.colorEdges ? BRANCH_NODE_COLOR : undefined,
      dashed: true,
    },
    markerEnd: { type: MarkerType.ArrowClosed, width: 18, height: 18 },
    style: {
      strokeWidth: 2,
      opacity: 1,
      ...(ctx.colorEdges ? { stroke: BRANCH_NODE_COLOR } : null),
    },
  }));

  return { branchFlowNodes, branchEdges };
}

export function useDiagramFlowGraph(args: UseDiagramFlowGraphArgs) {
  return useMemo(() => {
    const items = normalizeItems(args.treeNodes);

    const baseItems =
      args.showOnlySelectedUnitChildren && args.selectedUnitId
        ? items.filter(
            (item) =>
              Number(item.id) === args.selectedUnitId ||
              (item.parentId != null && Number(item.parentId) === args.selectedUnitId),
          )
        : items;

    const focusSet =
      args.focusOnly && args.highlightedNodeIds.size > 0 ? args.highlightedNodeIds : null;
    const visibleItems = focusSet
      ? baseItems.filter((item) => focusSet.has(Number(item.id)))
      : baseItems;

    const rawById = new Map<string, any>(args.treeNodes.map((n) => [String(n?.id), n] as const));

    let layoutItems = visibleItems;
    if (args.scope === "unit" && args.showOrgChartStaff && args.employeesByUnitId) {
      const staffItems: NormalizedItem[] = [];
      for (const unit of visibleItems) {
        const unitId = Number(unit.id);
        if (!Number.isFinite(unitId)) continue;
        const employees = args.employeesByUnitId.get(unitId) ?? [];
        const staff = employees.filter((e) => !Boolean(e.isManager ?? e.is_manager));
        staff.forEach((e, index) => {
          const assignmentId = Number(e.assignmentId ?? e.assignment_id);
          const id = Number.isFinite(assignmentId) ? `emp:${assignmentId}` : `emp:${unitId}:${index}`;
          staffItems.push({ id, parentId: unit.id, order: index + 1, level: null });
          const roleTitleNameRaw = e.roleTitleName ?? e.role_title_name ?? null;
          const roleTitleName =
            roleTitleNameRaw && String(roleTitleNameRaw).trim() ? String(roleTitleNameRaw) : null;
          rawById.set(id, {
            kind: "employee",
            unitId,
            fullName: String(e.fullName ?? e.full_name ?? ""),
            branchName: e.branchName ?? e.branch_name ?? null,
            roleTitleName,
          });
        });
      }
      layoutItems = [...visibleItems, ...staffItems];
    }

    const positions = layoutTreeTidy(layoutItems, TIDY_LAYOUT_OPTIONS);

    const flowNodes = layoutItems.map((item) =>
      buildNode(item, rawById.get(item.id), positions[item.id], args),
    );

    const allowedIds = new Set(layoutItems.map((i) => i.id));
    const flowEdges = args.showHierarchyEdges
      ? layoutItems
          .filter((item) => item.parentId != null && allowedIds.has(item.parentId))
          .map((item) => buildHierarchyEdge(item, rawById, args))
      : [];

    const shouldOverlayBranches =
      args.scope === "unit" &&
      args.showCoverageEdges &&
      args.showUnitBranchesOnDiagram &&
      args.effectiveNodeId &&
      args.branchesByNode.length > 0;

    if (shouldOverlayBranches) {
      const anchorId = String(args.effectiveNodeId);
      const anchorPos = positions[anchorId] ?? { x: 0, y: 0 };
      const { branchFlowNodes, branchEdges } = buildBranchOverlay(anchorId, anchorPos, args);
      return {
        nodes: [...flowNodes, ...branchFlowNodes],
        edges: [...flowEdges, ...branchEdges],
      };
    }

    return { nodes: flowNodes, edges: flowEdges };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    args.treeNodes,
    args.assignedNodeIds,
    args.branchesByNode,
    args.employeesByUnitId,
    args.managerByUnitId,
    args.highlightedNodeIds,
    args.showBranchAssignments,
    args.effectiveBranchId,
    args.structureById,
    args.colorEdges,
    args.focusOnly,
    args.showCoverageEdges,
    args.showEdgeLabels,
    args.showHierarchyEdges,
    args.showOnlySelectedUnitChildren,
    args.showUnitBranchesOnDiagram,
    args.showOrgChartStaff,
    args.scope,
    args.effectiveNodeId,
    args.selectedUnitId,
    args.layoutNonce,
  ]);
}
