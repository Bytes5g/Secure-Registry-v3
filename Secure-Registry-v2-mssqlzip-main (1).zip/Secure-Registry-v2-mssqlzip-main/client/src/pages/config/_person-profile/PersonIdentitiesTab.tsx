import { EntityContentCard } from "@secure-registry/components-ui";

export function PersonIdentitiesTab() {
  return (
    <EntityContentCard contentClassName="p-6">
      <div className="text-sm text-muted-foreground">
        تبويب الهويات سيُفعّل لاحقاً بعد إضافة الجداول/المصادر الخاصة بالهويات.
      </div>
    </EntityContentCard>
  );
}

