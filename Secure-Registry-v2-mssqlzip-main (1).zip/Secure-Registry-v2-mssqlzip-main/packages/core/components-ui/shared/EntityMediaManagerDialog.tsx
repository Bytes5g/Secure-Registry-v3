import { useEffect, useMemo, useRef, useState } from "react"
import { Check, ImagePlus, Trash2 } from "lucide-react"
import { cn } from "../lib/utils"
import { Button } from "../ui/button"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "../ui/dialog"
import { Input } from "../ui/input"
import { ScrollArea } from "../ui/scroll-area"
import { Separator } from "../ui/separator"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../ui/tabs"
import { Textarea } from "../ui/textarea"

export type EntityMediaKind = "auto" | "image" | "video"

export type EntityMediaItem = {
  id: number
  fileId: number
  url: string
  fileName?: string | null
  mimeType?: string | null
  description?: string | null
  createdAt?: string | null
  isPrimary: boolean
}

export type EntityMediaSlot = {
  key: string
  label: string
  accept?: string
  maxSizeMb?: number
  items: EntityMediaItem[]
  onUpload: (file: File) => Promise<void>
  onSelectAsPrimary: (fileId: number) => Promise<void>
  onDeletePrimary: () => Promise<void>
  onUpdateMetadata: (fileId: number, patch: { title?: string | null; description?: string | null }) => Promise<void>
}

function resolveKind(item: EntityMediaItem): Exclude<EntityMediaKind, "auto"> {
  const mime = (item.mimeType ?? "").toLowerCase()
  if (mime.startsWith("video/")) return "video"
  if (mime.startsWith("image/")) return "image"

  const url = item.url.toLowerCase()
  const ext = url.split("?")[0]?.split("#")[0]?.split(".").pop() ?? ""
  if (["mp4", "webm", "ogg", "mov"].includes(ext)) return "video"
  return "image"
}

function formatCreatedAt(value: string | null | undefined) {
  if (!value) return "—"
  const d = new Date(value)
  if (Number.isNaN(d.getTime())) return value
  return d.toLocaleString()
}

export function EntityMediaManagerDialog(props: {
  open: boolean
  onOpenChange: (open: boolean) => void
  title: string
  slots: EntityMediaSlot[]
  defaultSlotKey?: string
}) {
  const { open, onOpenChange, title, slots, defaultSlotKey } = props
  const initialSlotKey = defaultSlotKey ?? slots[0]?.key ?? "media"
  const [activeSlotKey, setActiveSlotKey] = useState(initialSlotKey)

  useEffect(() => {
    if (!open) return
    setActiveSlotKey((k) => k || initialSlotKey)
  }, [open, initialSlotKey])

  const activeSlot = useMemo(() => slots.find((s) => s.key === activeSlotKey) ?? slots[0], [slots, activeSlotKey])
  const items = activeSlot?.items ?? []
  const primary = items.find((x) => x.isPrimary) ?? null

  const [selectedFileId, setSelectedFileId] = useState<number | null>(null)
  const selected = useMemo(() => items.find((x) => x.fileId === selectedFileId) ?? primary ?? items[0] ?? null, [items, selectedFileId, primary])

  useEffect(() => {
    if (!open) return
    setSelectedFileId(primary?.fileId ?? items[0]?.fileId ?? null)
  }, [open, activeSlotKey, primary?.fileId, items])

  const [editTitle, setEditTitle] = useState<string>("")
  const [editDescription, setEditDescription] = useState<string>("")
  useEffect(() => {
    setEditTitle(selected?.fileName ?? "")
    setEditDescription(selected?.description ?? "")
  }, [selected?.fileId])

  const fileInputRef = useRef<HTMLInputElement | null>(null)
  const [busy, setBusy] = useState(false)

  const previewKind = selected ? resolveKind(selected) : "image"

  const canSelectPrimary = Boolean(selected && !selected.isPrimary)
  const canDeletePrimary = Boolean(primary)
  const canSaveMeta = Boolean(selected)

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-5xl p-0 overflow-hidden">
        <DialogHeader className="p-4">
          <DialogTitle>{title}</DialogTitle>
        </DialogHeader>
        <Separator />

        <div className="grid grid-cols-1 lg:grid-cols-[1fr_360px]">
          <div className="bg-black">
            <div className="min-h-[280px] max-h-[70vh] flex items-center justify-center">
              {selected ? (
                previewKind === "video" ? (
                  <video className="max-h-[70vh] w-full" controls src={selected.url} />
                ) : (
                  <img className="max-h-[70vh] w-full object-contain" src={selected.url} alt="" />
                )
              ) : (
                <div className="p-6 text-sm text-white/70">لا توجد وسائط</div>
              )}
            </div>
          </div>

          <div className="bg-background">
            <Tabs value={activeSlotKey} onValueChange={setActiveSlotKey} className="w-full">
              <TabsList className={cn("w-full rounded-none justify-start", "border-b")}>
                {slots.map((s) => (
                  <TabsTrigger key={s.key} value={s.key}>
                    {s.label}
                  </TabsTrigger>
                ))}
              </TabsList>

              {slots.map((slot) => (
                <TabsContent key={slot.key} value={slot.key} className="m-0">
                  <div className="p-4 space-y-4">
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept={slot.accept ?? "image/png,image/jpeg,image/webp,video/mp4,video/webm"}
                      className="hidden"
                      onChange={async (e) => {
                        const file = e.target.files?.[0]
                        e.target.value = ""
                        if (!file) return
                        setBusy(true)
                        try {
                          await slot.onUpload(file)
                        } finally {
                          setBusy(false)
                        }
                      }}
                    />

                    <div className="flex flex-wrap gap-2">
                      <Button variant="secondary" disabled={busy} onClick={() => fileInputRef.current?.click()}>
                        <ImagePlus className="h-4 w-4" />
                        <span className="ms-2">{busy ? "جاري الرفع..." : "رفع جديد"}</span>
                      </Button>

                      <Button
                        variant="default"
                        disabled={busy || !canSelectPrimary || selectedFileId == null}
                        onClick={async () => {
                          if (!selected) return
                          setBusy(true)
                          try {
                            await slot.onSelectAsPrimary(selected.fileId)
                          } finally {
                            setBusy(false)
                          }
                        }}
                      >
                        <Check className="h-4 w-4" />
                        <span className="ms-2">تعيين كحالي</span>
                      </Button>

                      <Button
                        variant="ghost"
                        disabled={busy || !canDeletePrimary}
                        onClick={async () => {
                          if (!primary) return
                          setBusy(true)
                          try {
                            await slot.onDeletePrimary()
                          } finally {
                            setBusy(false)
                          }
                        }}
                      >
                        <Trash2 className="h-4 w-4" />
                        <span className="ms-2">حذف الحالي</span>
                      </Button>
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <div className="space-y-1">
                        <div className="text-xs text-muted-foreground">التاريخ</div>
                        <div className="text-sm">{formatCreatedAt(selected?.createdAt)}</div>
                      </div>
                      <div className="space-y-1">
                        <div className="text-xs text-muted-foreground">النوع</div>
                        <div className="text-sm">{selected?.mimeType ?? "—"}</div>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <div className="text-sm font-medium">المكتبة</div>
                      <ScrollArea className="h-[200px] rounded-md border">
                        <div className="p-3 grid grid-cols-3 gap-2">
                          {items.length === 0 ? (
                            <div className="col-span-3 text-sm text-muted-foreground">لا توجد عناصر</div>
                          ) : (
                            items.map((it) => {
                              const isSelected = selected?.fileId === it.fileId
                              return (
                                <button
                                  key={it.fileId}
                                  type="button"
                                  className={cn(
                                    "relative overflow-hidden rounded-md border bg-muted aspect-square",
                                    isSelected ? "ring-2 ring-ring" : "",
                                  )}
                                  onClick={() => setSelectedFileId(it.fileId)}
                                >
                                  <img src={it.url} alt="" className="h-full w-full object-cover" />
                                  {it.isPrimary ? (
                                    <div className="absolute top-1 start-1 rounded bg-black/70 text-white text-[10px] px-1.5 py-0.5">
                                      الحالي
                                    </div>
                                  ) : null}
                                </button>
                              )
                            })
                          )}
                        </div>
                      </ScrollArea>
                    </div>

                    <div className="space-y-2">
                      <div className="text-sm font-medium">البيانات الوصفية</div>
                      <div className="space-y-2">
                        <Input
                          placeholder="العنوان"
                          value={editTitle}
                          onChange={(e) => setEditTitle(e.target.value)}
                          disabled={!selected}
                        />
                        <Textarea
                          placeholder="الوصف"
                          value={editDescription}
                          onChange={(e) => setEditDescription(e.target.value)}
                          disabled={!selected}
                        />
                        <Button
                          variant="secondary"
                          disabled={busy || !canSaveMeta || selected == null}
                          onClick={async () => {
                            if (!selected) return
                            setBusy(true)
                            try {
                              await slot.onUpdateMetadata(selected.fileId, {
                                title: editTitle || null,
                                description: editDescription || null,
                              })
                            } finally {
                              setBusy(false)
                            }
                          }}
                        >
                          حفظ
                        </Button>
                      </div>
                    </div>
                  </div>
                </TabsContent>
              ))}
            </Tabs>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}

