import type { SqlExecutor } from "../config/connection";
import {
  deleteRow,
  insertRow,
  qualifyTableName,
  runQuery,
  runQueryOne,
  selectRows,
  selectSingleRow,
  updateRow,
  type TableReference,
} from "./helpers";
import { lookupModule } from "./lookups";

export interface GeoAdminUnitRecord {
  id: number;
  parentId: number | null;
  countryId: number;
  level: number | null;
  codes: string | null;
  name: string;
  nameEn: string | null;
  adminTypeAr: string | null;
  adminTypeEn: string | null;
  isActive: boolean;
  geometryType: string | null;
  latitude: number | null;
  longitude: number | null;
  bboxMinLon: number | null;
  bboxMinLat: number | null;
  bboxMaxLon: number | null;
  bboxMaxLat: number | null;
  geometryAreaSqm: number | null;
  geometryPerimeterM: number | null;
  geometryJson: string | null;
  geom: string | null;
  numVertices: number | null;
  isValid: boolean | null;
  createdAt: string | null;
  workContextBy?: number | null;
  createdBy?: number | null;
  updatedAt?: string | Date | null;
  updatedBy?: number | null;
  isDeleted?: boolean | null;
}

export interface GeoCountryRecord {
  id: number;
  parentId: number | null;
  lookupId: number;
  code: string;
  isoAlpha2: string | null;
  isoAlpha3: string | null;
  name: string;
  latitude: number | null;
  longitude: number | null;
  orderIndex: number;
  isActive: boolean;
}

export interface GeoAdminUnitQuery {
  page: number;
  limit: number;
  search?: string;
  level?: number;
  parentId?: number | null;
  countryId?: number;
}

export interface GeoAdminUnitQueryResult {
  data: GeoAdminUnitRecord[];
  total: number;
}

function asNumber(value: unknown): number | null {
  return value == null ? null : Number(value);
}

function mapGeo(row: Record<string, unknown>): GeoAdminUnitRecord {
  return {
    id: Number(row.id),
    parentId: asNumber(row.parent_id),
    countryId: Number(row.country_id),
    level: asNumber(row.admin_level),
    codes: row.unit_code == null ? null : String(row.unit_code),
    name: String(row.name || ""),
    nameEn: row.name_en == null ? null : String(row.name_en),
    adminTypeAr: row.admin_type_ar == null ? null : String(row.admin_type_ar),
    adminTypeEn: row.admin_type_en == null ? null : String(row.admin_type_en),
    isActive: row.is_active == null ? true : Boolean(row.is_active),
    geometryType: row.geometry_type == null ? null : String(row.geometry_type),
    latitude: asNumber(row.latitude),
    longitude: asNumber(row.longitude),
    bboxMinLon: asNumber(row.bbox_min_lon),
    bboxMinLat: asNumber(row.bbox_min_lat),
    bboxMaxLon: asNumber(row.bbox_max_lon),
    bboxMaxLat: asNumber(row.bbox_max_lat),
    geometryAreaSqm: asNumber(row.geometry_area_sqm),
    geometryPerimeterM: asNumber(row.geometry_perimeter_m),
    geometryJson: row.geometry_json == null ? null : String(row.geometry_json),
    geom: row.geom == null ? null : String(row.geom),
    numVertices: asNumber(row.num_vertices),
    isValid: row.is_valid == null ? null : Boolean(row.is_valid),
    createdAt: row.created_at == null ? null : String(row.created_at),
    workContextBy: asNumber(row.work_context_by),
    createdBy: asNumber(row.created_by),
    updatedAt: row.updated_at == null ? null : (row.updated_at as any),
    updatedBy: asNumber(row.updated_by),
    isDeleted: row.is_deleted == null ? null : Boolean(row.is_deleted),
  };
}

function mapGeoCountry(row: Record<string, unknown>): GeoCountryRecord {
  return {
    id: Number(row.id),
    parentId: asNumber(row.parent_id),
    lookupId: Number(row.lookup_id),
    code: String(row.code || ""),
    isoAlpha2: row.iso_alpha2 == null ? null : String(row.iso_alpha2),
    isoAlpha3: row.iso_alpha3 == null ? null : String(row.iso_alpha3),
    name: String(row.name || ""),
    latitude: asNumber(row.latitude),
    longitude: asNumber(row.longitude),
    orderIndex: row.order_index == null ? 0 : Number(row.order_index),
    isActive: row.is_active == null ? true : Boolean(row.is_active),
  };
}

const GEO_ADMIN_UNITS_TABLE: TableReference = {
  schemaName: "dbo",
  tableName: "geo_admin_units",
};

const GEO_COUNTRIES_TABLE: TableReference = {
  schemaName: "dbo",
  tableName: "geo_continent_country",
};

async function getNextGeoAdminUnitId(executor?: SqlExecutor): Promise<number> {
  const row = await runQueryOne<{ next_id: number }>(
    `SELECT ISNULL(MAX(id), 0) + 1 AS next_id FROM ${qualifyTableName(GEO_ADMIN_UNITS_TABLE)}`,
    {},
    executor,
  );
  return Number(row?.next_id ?? 1);
}

export class GeoModule {
  async getById(id: number): Promise<GeoAdminUnitRecord | undefined> {
    const row = await selectSingleRow<Record<string, unknown>>(GEO_ADMIN_UNITS_TABLE, {
      whereClause: "WHERE id = @id AND (is_deleted = 0 OR is_deleted IS NULL)",
      params: { id },
    });
    return row ? mapGeo(row) : undefined;
  }

  async getAll(): Promise<GeoAdminUnitRecord[]> {
    const rows = await selectRows<Record<string, unknown>>(GEO_ADMIN_UNITS_TABLE, {
      whereClause: "WHERE (is_deleted = 0 OR is_deleted IS NULL)",
      orderByClause: "ORDER BY admin_level, name",
    });
    return rows.map(mapGeo);
  }

  async getByLevel(level: number): Promise<GeoAdminUnitRecord[]> {
    const rows = await selectRows<Record<string, unknown>>(GEO_ADMIN_UNITS_TABLE, {
      whereClause: "WHERE admin_level = @level AND (is_deleted = 0 OR is_deleted IS NULL)",
      orderByClause: "ORDER BY name",
      params: { level },
    });
    return rows.map(mapGeo);
  }

  async getByParentId(parentId: number | null): Promise<GeoAdminUnitRecord[]> {
    const rows = parentId === null
      ? await selectRows<Record<string, unknown>>(GEO_ADMIN_UNITS_TABLE, {
          whereClause: "WHERE parent_id IS NULL AND (is_deleted = 0 OR is_deleted IS NULL)",
          orderByClause: "ORDER BY name",
        })
      : await selectRows<Record<string, unknown>>(GEO_ADMIN_UNITS_TABLE, {
          whereClause: "WHERE parent_id = @parentId AND (is_deleted = 0 OR is_deleted IS NULL)",
          orderByClause: "ORDER BY name",
          params: { parentId },
        });

    return rows.map(mapGeo);
  }

  async query(params: GeoAdminUnitQuery): Promise<GeoAdminUnitQueryResult> {
    const clauses: string[] = ["(is_deleted = 0 OR is_deleted IS NULL)"];
    const queryParams: Record<string, unknown> = {
      offset: Math.max(0, (params.page - 1) * params.limit),
      limit: params.limit,
    };

    if (params.countryId !== undefined) {
      clauses.push("country_id = @countryId");
      queryParams.countryId = params.countryId;
    }

    if (params.level !== undefined) {
      clauses.push("admin_level = @level");
      queryParams.level = params.level;
    }

    if (params.parentId !== undefined) {
      if (params.parentId === null) {
        clauses.push("parent_id IS NULL");
      } else {
        clauses.push("parent_id = @parentId");
        queryParams.parentId = params.parentId;
      }
    }

    if (params.search && params.search.trim()) {
      clauses.push("(name LIKE @search OR unit_code LIKE @search OR name_en LIKE @search)");
      queryParams.search = `%${params.search.trim()}%`;
    }

    const whereClause = clauses.length > 0 ? `WHERE ${clauses.join(" AND ")}` : "";
    const tableName = qualifyTableName(GEO_ADMIN_UNITS_TABLE);

    const totalRow = await runQueryOne<{ total: number }>(
      `SELECT COUNT(1) AS total FROM ${tableName} ${whereClause}`,
      queryParams,
    );

    const rows = await runQuery<Record<string, unknown>>(
      `SELECT *
       FROM ${tableName}
       ${whereClause}
       ORDER BY name
       OFFSET @offset ROWS FETCH NEXT @limit ROWS ONLY`,
      queryParams,
    );

    return {
      data: rows.map(mapGeo),
      total: Number(totalRow?.total ?? 0),
    };
  }

  async getCountries(): Promise<GeoCountryRecord[]> {
    const rows = await selectRows<Record<string, unknown>>(GEO_COUNTRIES_TABLE, {
      whereClause: "WHERE lookup_id = 4 AND is_active = 1",
      orderByClause: "ORDER BY order_index, name",
    });
    return rows.map(mapGeoCountry);
  }

  async updateCountryOrderIndex(id: number, orderIndex: number, executor?: SqlExecutor): Promise<GeoCountryRecord | undefined> {
    const row = await updateRow<Record<string, unknown>>(
      GEO_COUNTRIES_TABLE,
      id,
      { order_index: orderIndex, updated_at: new Date() },
      executor,
    );
    return row ? mapGeoCountry(row) : undefined;
  }

  async create(payload: Omit<GeoAdminUnitRecord, "id" | "createdAt">, executor?: SqlExecutor): Promise<GeoAdminUnitRecord> {
    const nextId = await getNextGeoAdminUnitId(executor);
    const row = await insertRow<Record<string, unknown>>(
      GEO_ADMIN_UNITS_TABLE,
      {
        id: nextId,
        parent_id: payload.parentId,
        country_id: payload.countryId,
        admin_level: payload.level,
        unit_code: payload.codes,
        name: payload.name,
        name_en: payload.nameEn,
        admin_type_ar: payload.adminTypeAr,
        admin_type_en: payload.adminTypeEn,
        is_active: payload.isActive,
        geometry_type: payload.geometryType,
        latitude: payload.latitude,
        longitude: payload.longitude,
        bbox_min_lon: payload.bboxMinLon,
        bbox_min_lat: payload.bboxMinLat,
        bbox_max_lon: payload.bboxMaxLon,
        bbox_max_lat: payload.bboxMaxLat,
        geometry_area_sqm: payload.geometryAreaSqm,
        geometry_perimeter_m: payload.geometryPerimeterM,
        geometry_json: payload.geometryJson,
        geom: payload.geom,
        num_vertices: payload.numVertices,
        is_valid: payload.isValid,
        work_context_by: payload.workContextBy ?? null,
        created_by: payload.createdBy ?? null,
        is_deleted: payload.isDeleted ?? null,
      },
      executor,
    );

    return mapGeo(row);
  }

  async createMany(payload: Array<Omit<GeoAdminUnitRecord, "id" | "createdAt">>, executor?: SqlExecutor): Promise<GeoAdminUnitRecord[]> {
    const created: GeoAdminUnitRecord[] = [];
    for (const item of payload) {
      created.push(await this.create(item, executor));
    }
    return created;
  }

  async update(id: number, payload: Partial<GeoAdminUnitRecord>, executor?: SqlExecutor): Promise<GeoAdminUnitRecord | undefined> {
    const mappings: Array<[keyof GeoAdminUnitRecord, string]> = [
      ["parentId", "parent_id"],
      ["countryId", "country_id"],
      ["level", "admin_level"],
      ["codes", "unit_code"],
      ["name", "name"],
      ["nameEn", "name_en"],
      ["adminTypeAr", "admin_type_ar"],
      ["adminTypeEn", "admin_type_en"],
      ["isActive", "is_active"],
      ["geometryType", "geometry_type"],
      ["latitude", "latitude"],
      ["longitude", "longitude"],
      ["bboxMinLon", "bbox_min_lon"],
      ["bboxMinLat", "bbox_min_lat"],
      ["bboxMaxLon", "bbox_max_lon"],
      ["bboxMaxLat", "bbox_max_lat"],
      ["geometryAreaSqm", "geometry_area_sqm"],
      ["geometryPerimeterM", "geometry_perimeter_m"],
      ["geometryJson", "geometry_json"],
      ["geom", "geom"],
      ["numVertices", "num_vertices"],
      ["isValid", "is_valid"],
      ["workContextBy", "work_context_by"],
      ["updatedAt", "updated_at"],
      ["updatedBy", "updated_by"],
      ["isDeleted", "is_deleted"],
    ];

    const updatePayload: Record<string, unknown> = {};
    for (const [key, column] of mappings) {
      if ((payload as any)[key] !== undefined) {
        updatePayload[column] = (payload as any)[key] as unknown;
      }
    }

    const row = await updateRow<Record<string, unknown>>(GEO_ADMIN_UNITS_TABLE, id, updatePayload, executor);

    return row ? mapGeo(row) : undefined;
  }

  async delete(id: number, executor?: SqlExecutor): Promise<boolean> {
    return deleteRow(GEO_ADMIN_UNITS_TABLE, id, executor);
  }

  async getLevels() {
    return lookupModule.getValuesByTypeId(6);
  }
}

export const geoModule = new GeoModule();
