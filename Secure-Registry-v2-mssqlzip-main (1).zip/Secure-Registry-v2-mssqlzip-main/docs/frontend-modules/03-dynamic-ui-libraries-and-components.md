# المكتبات والمكونات المقترحة للبناء والتطوير الديناميكي للواجهات

## 1) الهدف من هذا المستند

تجميع مرجعي واضح يوضح:

- ما هو مستخدم حالياً من مكتبات/مكونات.
- ما الذي يُقترح إضافته أو توسيع استخدامه.
- من أين يتم الاستدعاء (packages أو مسارات client).
- أين وكيف يتم الاستخدام في الواجهات أو في أي طبقة أخرى.

> توحيد مفهوم “Templates” وربطه بالـ runtime و`mapping_json`:  
> [04-ui-templates-and-runtime-contract.md](./04-ui-templates-and-runtime-contract.md)

## 2) الوضع الحالي المختصر (As-Is)

### أ) الحزمة الأساسية للواجهة المشتركة

- المصدر: `packages/core/components-ui`
- اسم الحزمة: `@secure-registry/components-ui`
- نقطة التصدير: `packages/core/components-ui/index.ts`

تستخدم حالياً كحزمة أساسية لمكونات UI العامة (primitives + templates + shared layout helpers).

### ب) ملاحظة مهمة حول عدم الاتساق الحالي

يوجد مساران استدعاء للمكونات نفسها داخل الواجهة:

1. `@secure-registry/components-ui` (الاستيراد الصحيح المباشر)
2. `@secure-registry/ui` (alias محلي مرتبط فعلياً بنفس `components-ui` عبر `tsconfig.json` و`vite.admin.config.ts`)

تم إدخال هذا alias تاريخياً كاختصار محلي لتسهيل الربط قبل تثبيت نمط استيراد موحد، لكنه اليوم يسبب ازدواجية تسمية للمصدر نفسه.

هذا ليس خطأً تشغيلياً فورياً، لكنه يسبب:

- ازدواجية في أسلوب الاستيراد.
- تشويشاً على المصدر الرسمي للحزمة.
- صعوبة في مراجعة الالتزام بمعيار موحد.

## 3) المكونات والمكتبات المعتمدة والمقترح توحيد استخدامها

| الفئة | الاعتماد الحالي | المسار/الحزمة | التوصية |
| --- | --- | --- | --- |
| UI Primitives | موجود | `@secure-registry/components-ui` | اعتمادها كمصدر وحيد لمكونات العرض العامة |
| DataTable | موجود عبر مسارين | `@secure-registry/components-ui` + `client/src/components/tables/DataTable.tsx` | توحيد الاستخدام على import واحد قياسي من الحزمة المشتركة |
| Form البناء العام | موجود | `client/src/components/forms/DynamicForm.tsx` + components-ui form primitives | إبقاء منطق الدومين في client واستخراج أي سلوك عام reusable للحزمة المشتركة |
| Entity layout blocks | موجود | `@secure-registry/components-ui` (`EntityPageHeader`, `EntityContentCard`, ...) | فرض استخدامها في كل صفحات CRUD/Profile بدل إنشاء هياكل محلية مكررة |
| Sidebar/Toaster | موجود محلياً | `client/src/components/ui/*` | الإبقاء محلياً إذا مرتبط بسياق التطبيق، مع توثيق حد الفصل بدقة |

## 4) مكتبات مقترح إضافتها للبناء الديناميكي (Future-ready)

> هذه مقترحات تنظيمية مستقبلية؛ لا تعني إضافة فورية الآن.

### أ) بناء نماذج ديناميكية متقدمة

1. `@rjsf/core` + `@rjsf/validator-zod`
- الاستخدام: توليد نماذج من JSON Schema + zod.
- المكان المقترح:
  - wrapper داخل `packages/core/components-ui/forms/` (مثل `SchemaFormRenderer`).
  - orchestration في `client/src/features/module-builder`.

2. `react-hook-form` (موجود فعلياً)
- الاستمرار عليه كمحرك form state.
- ربطه ب metadata resolver بدل ربطه بإعدادات ثابتة في كل شاشة.

### ب) إدارة الجداول الديناميكية

1. `@tanstack/react-table` (إذا لم يكن مستغلاً بالكامل حالياً)
- الاستخدام: طبقة headless للجداول المتقدمة (grouping, column visibility, pinning).
- المكان المقترح:
  - abstraction في `packages/core/components-ui/tables/`.
  - config injection من `client/src/features/module-builder`.

### ج) محرك قواعد مرن (بدون كود)

1. `json-logic-js`
- الاستخدام: تقييم شروط إظهار/تعطيل/إلزام الحقول والأزرار ديناميكياً.
- المكان المقترح:
  - engine layer في `client/src/lib/rules` أو `packages/core/components-ui/lib/rules`.
  - ربطه ببيانات الصلاحيات/السياسات القادمة من API.

2. `ajv`
- الاستخدام: التحقق من metadata/rule schemas قبل تطبيقها runtime.
- المكان المقترح:
  - validation layer في server عند حفظ التهيئات.
  - optional guard في client قبل rendering.

### د) إدارة الحالة للمنشئ الديناميكي

1. `zustand` (مقترح)
- الاستخدام: إدارة state محلي ثقيل لشاشات module/screen builders (draft configs, staged edits).
- المكان المقترح:
  - `client/src/features/module-builder/state`.

## 5) نمط استخدام موحد مقترح (Packages → Client)

## 5.1 داخل packages/core/components-ui

يوضع فقط:

- المكونات العامة القابلة لإعادة الاستخدام.
- Wrappers عامة للجداول/النماذج/الـ renderers.
- أدوات helper غير مرتبطة بدومين محدد.

ولا يوضع:

- API calls.
- منطق صلاحيات خاص بدومين محدد.
- أي اعتماد على alias `@/`.

## 5.2 داخل client/src

يوضع:

- ربط المكونات العامة مع الدومين (org, branches, lookups, permissions).
- query hooks, route wiring, page orchestration.
- policy resolution القادمة من backend.

## 5.3 داخل packages/core/database

يوضع:

- metadata registries.
- permission/policy resolution contracts.
- rule schemas + persistence.

## 6) كيف يتم الاستدعاء عملياً (مرجعية مسارات)

### أ) المصدر القياسي للمكونات

- `@secure-registry/components-ui`

### ب) مسارات client التي يجب مراقبتها للتوحيد

- `client/src/components/tables/DataTable.tsx` (حالياً يعيد التصدير من `@secure-registry/ui` رغم أن المصدر القياسي المقترح هو `@secure-registry/components-ui`)
- `client/src/components/shared/index.ts` (re-export layer)
- صفحات geo/lookups التي تستورد DataTable من local wrapper بدل المصدر القياسي المباشر

### ج) التوصية التنفيذية للتوحيد

1. اعتماد اسم import موحد: `@secure-registry/components-ui`.
2. اعتبار `@secure-registry/ui` مساراً انتقالياً فقط (Deprecated for new code).
3. خطة ترحيل تدريجية: تحديث الاستيرادات الحالية إلى `@secure-registry/components-ui` عند أي تعديل على الملف نفسه، ثم إزالة alias لاحقاً من `tsconfig.json` و`vite.config.ts` بعد اكتمال الانتقال.
4. الإبقاء على wrappers محلية فقط إذا تضيف قيمة domain-specific فعلية، وليس مجرد إعادة تصدير.

## 7) قائمة أولويات عملية مقترحة

1. **توحيد الاستدعاء** للمكونات المشتركة (خصوصاً DataTable).
2. **تقليل wrappers الصورية** التي لا تضيف سلوكاً.
3. **تعريف معيار قبول** لأي مكون جديد:
   - عام → packages/core/components-ui
   - domain-specific → client/features
4. **تأسيس module-builder feature** منفصل في client لاحتواء البناء الديناميكي.
5. **إضافة rule engine + schema validation** قبل إطلاق أي واجهة إعداد صلاحيات متقدمة.

## 8) خلاصة

المشروع يملك أساساً ممتازاً للبناء الديناميكي بسبب وجود `components-ui` و`GenericEntityPage` و`DynamicForm`، لكن يلزم توحيد مسار الاستدعاء وتخفيف التكرارات ثم إدخال طبقة builder/rules بشكل منضبط ليصبح التهيئة من الواجهة قابلة للتوسع دون تضخم الكود.
