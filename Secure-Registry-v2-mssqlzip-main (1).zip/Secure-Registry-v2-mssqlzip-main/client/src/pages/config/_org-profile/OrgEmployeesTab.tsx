import { useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Badge, Button, EntityContentCard } from "@secure-registry/components-ui";
import { DataTable, type Column } from "@secure-registry/components-ui";
import { fetchOrgEmployees } from "@/lib/api/org-admin";
import { DynamicForm } from "@/components/forms/DynamicForm";
import type { UiPageFormField } from "@/types/ui";
import { createPersonAssignment } from "@/lib/api/persons-admin";
import { useToast } from "@/hooks/use-toast";
import { Eye } from "lucide-react";
import { useLocation } from "wouter";

function formatDateTime(value: unknown) {
  return value ? new Date(String(value)).toLocaleString("ar-SA") : "-";
}

export function OrgEmployeesTab({
  orgId,
  onOpenUnit,
}: {
  orgId: number;
  onOpenUnit?: (orgStructureId: number) => void;
}) {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [initialData, setInitialData] = useState<any>({ orgId });

  const { data = [], isLoading } = useQuery<any[]>({
    queryKey: ["org-employees", orgId],
    queryFn: () => fetchOrgEmployees(orgId),
    enabled: Number.isFinite(orgId) && orgId > 0,
  });

  const createMutation = useMutation({
    mutationFn: async (values: any) => {
      const personId = Number(values?.personId);
      const branchId = Number(values?.branchId);
      const orgStructureId = Number(values?.orgStructureId);
      const isManager = !!values?.isManager;
      if (!Number.isFinite(personId) || !Number.isFinite(branchId) || !Number.isFinite(orgStructureId)) {
        throw new Error("بيانات الإضافة غير مكتملة");
      }
      return createPersonAssignment(personId, { orgId, branchId, orgStructureId, isManager });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["org-employees", orgId] });
      setInitialData({ orgId, personQuery: "", personId: "", branchId: "", orgStructureId: "", isManager: false });
      toast({ title: "تمت الإضافة", description: "تم ربط الشخص بالجهة بنجاح" });
    },
    onError: (error: any) => {
      toast({
        title: "فشل في إضافة موظف",
        description: String(error?.message ?? "تعذر تنفيذ العملية"),
        variant: "destructive",
      });
    },
  });

  const formFields = useMemo<UiPageFormField[]>(
    () => [
      {
        fieldCode: "orgId",
        nameAr: "الجهة",
        fieldType: "number",
        isRequired: true,
        isVisible: false,
        isEditable: false,
        orderIndex: 1,
        gridCols: 4,
      },
      {
        fieldCode: "personQuery",
        nameAr: "بحث عن شخص",
        fieldType: "text",
        isRequired: false,
        isVisible: true,
        orderIndex: 2,
        gridCols: 4,
        placeholder: "اكتب الاسم للبحث...",
        config: {
          clearOnChange: ["personId"],
        },
      },
      {
        fieldCode: "personId",
        nameAr: "الشخص",
        fieldType: "select",
        isRequired: true,
        isVisible: true,
        orderIndex: 3,
        gridCols: 4,
        config: {
          remoteOptions: {
            variants: [
              {
                when: { field: "personQuery", op: "notEmpty" },
                path: "/api/persons/search",
                response: "paged",
                valueKey: "id",
                labelKey: "fullName",
                query: { q: "{personQuery}", limit: 50 },
              },
            ],
          },
        },
      },
      {
        fieldCode: "branchId",
        nameAr: "الفرع",
        fieldType: "select",
        isRequired: true,
        isVisible: true,
        orderIndex: 4,
        gridCols: 4,
        config: {
          remoteOptions: {
            variants: [
              {
                when: { field: "orgId", op: "notEmpty" },
                path: "/api/branches",
                response: "array",
                valueKey: "id",
                labelKey: "name",
                clientFilter: { field: "orgId", recordKey: "orgId" },
              },
            ],
          },
        },
      },
      {
        fieldCode: "orgStructureId",
        nameAr: "الوحدة",
        fieldType: "select",
        isRequired: true,
        isVisible: true,
        orderIndex: 5,
        gridCols: 4,
        config: {
          remoteOptions: {
            variants: [
              {
                when: { field: "orgId", op: "notEmpty" },
                path: "/api/org/organizations/{orgId}/tree/flat",
                response: "array",
                valueKey: "id",
                labelKey: "name",
                query: { includeInactive: 1 },
              },
            ],
          },
        },
      },
      { fieldCode: "isManager", nameAr: "مسؤول", fieldType: "boolean", isRequired: false, isVisible: true, orderIndex: 6, gridCols: 4 },
    ],
    [orgId],
  );

  const columns = useMemo<Column<any>[]>(
    () => [
      {
        key: "fullName",
        header: "الاسم",
        sortable: true,
        render: (_, row) => String(row.fullName ?? row.full_name ?? ""),
      },
      {
        key: "roleTitleName",
        header: "الصفة",
        render: (_, row) => {
          const title = row.roleTitleName ?? row.role_title_name ?? null;
          const value = title && String(title).trim() ? String(title) : "—";
          const isManager = Boolean(row.isManager ?? row.is_manager);
          return isManager ? <Badge>{value}</Badge> : <Badge variant="secondary">{value}</Badge>;
        },
      },
      {
        key: "orgStructureName",
        header: "الوحدة",
        sortable: true,
        render: (_, row) => String(row.orgStructureName ?? row.org_structure_name ?? "—"),
      },
      {
        key: "branchName",
        header: "الفرع",
        sortable: true,
        render: (_, row) => String(row.branchName ?? row.branch_name ?? "—"),
      },
      {
        key: "assignmentCreatedAt",
        header: "تاريخ التعيين",
        render: (_, row) => formatDateTime(row.assignmentCreatedAt ?? row.assignment_created_at),
      },
      {
        key: "profile",
        header: "عرض",
        width: "60px",
        render: (_: any, row: any) => {
          const personId = Number(row.personId ?? row.person_id);
          return (
            <Button
              variant="ghost"
              size="icon"
              onClick={(e) => {
                e.stopPropagation();
                if (Number.isFinite(personId)) setLocation(`/config/persons/${personId}`);
              }}
              title="فتح بروفايل الشخص"
            >
              <Eye className="h-4 w-4" />
            </Button>
          );
        },
      },
    ],
    [],
  );

  const normalized = useMemo(() => (Array.isArray(data) ? data : []), [data]);

  return (
    <EntityContentCard>
      <div className="p-4 border-b" dir="rtl">
        <div className="flex items-center justify-between mb-3">
          <div className="font-semibold text-sm">إضافة موظف للجهة</div>
          <Button type="button" variant="outline" onClick={() => setInitialData({ orgId })}>
            تفريغ
          </Button>
        </div>
        <DynamicForm
          fields={formFields}
          initialData={initialData}
          onSubmit={(values) => createMutation.mutate(values)}
          isSubmitting={createMutation.isPending}
          readOnly={false}
          submitLabel="إضافة"
          submitPendingLabel="جاري الإضافة..."
        />
      </div>
      <DataTable
        data={normalized}
        columns={columns}
        isLoading={isLoading}
        emptyMessage="لا توجد تعيينات موظفين لهذه الجهة"
        getRowId={(row) => String(row.assignmentId ?? row.assignment_id ?? row.personId ?? row.person_id ?? "")}
      />
    </EntityContentCard>
  );
}
