import { 
  type LookupType,
  type InsertLookupType,
  type LookupValue,
  type InsertLookupValue,
  type LookupTypeWithValues,
  type LookupTypeAlias,
  type InsertLookupTypeAlias,
  type LookupVirtualValue,
  type InsertLookupVirtualValue,
  type GeoAdminUnit,
  type InsertGeoAdminUnit,
  type MapProvider,
  type OrganizationalStructure,
  type InsertOrganizationalStructure,
  type OrganizationalStructureWithDetails,
  type OrgStructureTree,
  type InsertOrgStructureTree,
  type OrgStructureTreeWithChildren,
} from "@shared/schema";
import type { OrgEmployeeRecord } from "@core/database";

export interface ILookupTypesStorage {
  getLookupType(id: number): Promise<LookupType | undefined>;
  getLookupTypeByCode(code: string): Promise<LookupType | undefined>;
  getLookupTypeWithValues(id: number): Promise<LookupTypeWithValues | undefined>;
  getAllLookupTypes(): Promise<LookupType[]>;
  getAllLookupTypesWithValues(): Promise<LookupTypeWithValues[]>;
  createLookupType(lookupType: InsertLookupType): Promise<LookupType>;
  updateLookupType(id: number, lookupType: Partial<InsertLookupType>): Promise<LookupType | undefined>;
  deleteLookupType(
    id: number,
    context?: { workContextBy?: number | null; updatedBy?: number | null },
  ): Promise<boolean>;
}

export interface ILookupValuesStorage {
  getLookupValue(id: number, typeId?: number): Promise<LookupValue | undefined>;
  getLookupValuesByTypeId(typeId: number): Promise<LookupValue[]>;
  createLookupValue(lookupValue: InsertLookupValue): Promise<LookupValue>;
  updateLookupValue(id: number, lookupValue: Partial<InsertLookupValue>, typeId?: number): Promise<LookupValue | undefined>;
  deleteLookupValue(
    id: number,
    typeId?: number,
    context?: { workContextBy?: number | null; updatedBy?: number | null },
  ): Promise<boolean>;
}

export interface ILookupTypeAliasesStorage {
  getLookupTypeAlias(id: number): Promise<LookupTypeAlias | undefined>;
  getLookupTypeAliasesByTypeId(typeId: number): Promise<LookupTypeAlias[]>;
  createLookupTypeAlias(alias: InsertLookupTypeAlias): Promise<LookupTypeAlias>;
  updateLookupTypeAlias(id: number, alias: Partial<InsertLookupTypeAlias>): Promise<LookupTypeAlias | undefined>;
  deleteLookupTypeAlias(
    id: number,
    context?: { workContextBy?: number | null; updatedBy?: number | null },
  ): Promise<boolean>;
}

export interface ILookupVirtualValuesStorage {
  getLookupVirtualValue(id: number): Promise<LookupVirtualValue | undefined>;
  getLookupVirtualValuesByTypeId(typeId: number): Promise<LookupVirtualValue[]>;
  createLookupVirtualValue(seed: InsertLookupVirtualValue): Promise<LookupVirtualValue>;
  updateLookupVirtualValue(
    id: number,
    seed: Partial<InsertLookupVirtualValue>,
  ): Promise<LookupVirtualValue | undefined>;
  deleteLookupVirtualValue(
    id: number,
    context?: { workContextBy?: number | null; updatedBy?: number | null },
  ): Promise<boolean>;
}

export interface IGeoAdminUnitsStorage {
  getGeoAdminUnit(id: number): Promise<GeoAdminUnit | undefined>;
  getAllGeoAdminUnits(): Promise<GeoAdminUnit[]>;
  queryGeoAdminUnits(params: {
    page: number;
    limit: number;
    search?: string;
    level?: number;
    parentId?: number | null;
    countryId?: number;
  }): Promise<{
    data: GeoAdminUnit[];
    total: number;
  }>;
  getGeoAdminUnitsByLevel(level: number): Promise<GeoAdminUnit[]>;
  getGeoAdminUnitsByParentId(parentId: number | null): Promise<GeoAdminUnit[]>;
  getGeoCountries(): Promise<Array<{
    id: number;
    parentId: number | null;
    lookupId: number;
    code: string;
    isoAlpha2: string | null;
    isoAlpha3: string | null;
    name: string;
    latitude: number | null;
    longitude: number | null;
    orderIndex: number;
    isActive: boolean;
  }>>;
  updateGeoCountryOrderIndex(id: number, orderIndex: number): Promise<{
    id: number;
    parentId: number | null;
    lookupId: number;
    code: string;
    isoAlpha2: string | null;
    isoAlpha3: string | null;
    name: string;
    latitude: number | null;
    longitude: number | null;
    orderIndex: number;
    isActive: boolean;
  } | undefined>;
  createGeoAdminUnit(unit: InsertGeoAdminUnit): Promise<GeoAdminUnit>;
  createManyGeoAdminUnits(units: InsertGeoAdminUnit[]): Promise<GeoAdminUnit[]>;
  updateGeoAdminUnit(id: number, unit: Partial<InsertGeoAdminUnit>): Promise<GeoAdminUnit | undefined>;
  deleteGeoAdminUnit(id: number): Promise<boolean>;
  getGeoLevels(): Promise<LookupValue[]>;
}

export interface IMapProvidersStorage {
  getEnabledMapProviders(): Promise<MapProvider[]>;
}

export interface IOrganizationalStructureStorage {
  getOrganization(id: number): Promise<OrganizationalStructure | undefined>;
  getOrganizationWithDetails(id: number): Promise<OrganizationalStructureWithDetails | undefined>;
  getAllOrganizations(options?: { includeInactive?: boolean }): Promise<OrganizationalStructure[]>;
  getAllOrganizationsWithDetails(options?: { includeInactive?: boolean }): Promise<OrganizationalStructureWithDetails[]>;
  getOrganizationsByParentId(parentId: number | null, options?: { includeInactive?: boolean }): Promise<OrganizationalStructure[]>;
  getOrgEmployees(orgId: number): Promise<OrgEmployeeRecord[]>;
  createOrganization(org: InsertOrganizationalStructure): Promise<OrganizationalStructure>;
  updateOrganization(id: number, org: Partial<InsertOrganizationalStructure>): Promise<OrganizationalStructure | undefined>;
  deleteOrganization(id: number): Promise<boolean>;
}

export interface IOrgStructureTreeStorage {
  getTreeNode(id: number): Promise<OrgStructureTree | undefined>;
  getTreeNodesByOrgId(orgId: number, options?: { includeInactive?: boolean }): Promise<OrgStructureTree[]>;
  getTreeNodesByParentId(orgId: number, parentId: number | null, options?: { includeInactive?: boolean }): Promise<OrgStructureTree[]>;
  getTreeWithChildren(orgId: number, options?: { includeInactive?: boolean }): Promise<OrgStructureTreeWithChildren[]>;
  createTreeNode(node: InsertOrgStructureTree): Promise<OrgStructureTree>;
  createManyTreeNodes(nodes: InsertOrgStructureTree[]): Promise<OrgStructureTree[]>;
  updateTreeNode(id: number, node: Partial<InsertOrgStructureTree>): Promise<OrgStructureTree | undefined>;
  deleteTreeNode(id: number): Promise<boolean>;
}

export interface IStorage extends 
  ILookupTypesStorage,
  ILookupValuesStorage,
  ILookupTypeAliasesStorage,
  ILookupVirtualValuesStorage,
  IGeoAdminUnitsStorage,
  IMapProvidersStorage,
  IOrganizationalStructureStorage,
  IOrgStructureTreeStorage {}
