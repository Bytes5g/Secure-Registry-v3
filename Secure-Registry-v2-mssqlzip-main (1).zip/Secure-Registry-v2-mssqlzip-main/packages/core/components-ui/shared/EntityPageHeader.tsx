import type { ReactNode } from "react"
import { cn } from "../lib/utils"

interface EntityPageHeaderProps {
  title?: string
  description?: string
  hideTitle?: boolean
  actions?: ReactNode
  className?: string
}

export function EntityPageHeader({
  title,
  description,
  hideTitle = false,
  actions,
  className,
}: EntityPageHeaderProps) {
  return (
    <div className={cn("flex items-center justify-between gap-4", className)}>
      {!hideTitle ? (
        <div>
          {title ? <h1 className="text-2xl font-bold">{title}</h1> : null}
          {description ? <p className="text-muted-foreground">{description}</p> : null}
        </div>
      ) : (
        <div />
      )}
      <div className={hideTitle ? "w-full flex justify-end" : ""}>{actions}</div>
    </div>
  )
}

