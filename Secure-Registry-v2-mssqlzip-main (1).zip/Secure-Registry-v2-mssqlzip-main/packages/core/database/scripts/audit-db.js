#!/usr/bin/env node
import { connect } from "./_config.js";

const pool = await connect();
const q = (s) => pool.request().query(s);

console.log("\n=== TABLES ===");
const tables = await q(`SELECT TABLE_SCHEMA + '.' + TABLE_NAME AS name
  FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_TYPE='BASE TABLE' ORDER BY 1`);
console.log(tables.recordset.map(r => "  " + r.name).join("\n") || "  (none)");

console.log("\n=== VIEWS ===");
const views = await q(`SELECT TABLE_SCHEMA + '.' + TABLE_NAME AS name
  FROM INFORMATION_SCHEMA.VIEWS ORDER BY 1`);
console.log(views.recordset.map(r => "  " + r.name).join("\n") || "  (none)");

console.log("\n=== ROUTINES ===");
const routines = await q(`SELECT ROUTINE_SCHEMA + '.' + ROUTINE_NAME AS name, ROUTINE_TYPE
  FROM INFORMATION_SCHEMA.ROUTINES ORDER BY 1`);
console.log(routines.recordset.map(r => `  [${r.ROUTINE_TYPE}] ${r.name}`).join("\n") || "  (none)");

await pool.close();
