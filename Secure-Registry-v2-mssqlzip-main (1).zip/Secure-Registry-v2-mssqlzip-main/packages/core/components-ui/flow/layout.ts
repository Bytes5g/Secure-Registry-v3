export interface TreeLayoutItem {
  id: string
  parentId: string | null
  level?: number | null
  order?: number | null
}

export interface TreeLayoutOptions {
  nodeWidth?: number
  nodeHeight?: number
  levelGap?: number
  siblingGap?: number
}

export interface Point {
  x: number
  y: number
}

function normalizeNumber(value: unknown): number | null {
  if (value == null) return null
  const n = typeof value === "number" ? value : Number(value)
  return Number.isFinite(n) ? n : null
}

function computeDepths(items: TreeLayoutItem[]): Record<string, number> {
  const byId = new Map(items.map((item) => [item.id, item]))
  const memo = new Map<string, number>()
  const visiting = new Set<string>()

  const resolve = (id: string): number => {
    const cached = memo.get(id)
    if (cached != null) return cached
    if (visiting.has(id)) return 0
    visiting.add(id)

    const item = byId.get(id)
    if (!item) {
      visiting.delete(id)
      memo.set(id, 0)
      return 0
    }

    const explicit = normalizeNumber(item.level)
    if (explicit != null) {
      visiting.delete(id)
      memo.set(id, explicit)
      return explicit
    }

    if (!item.parentId) {
      visiting.delete(id)
      memo.set(id, 0)
      return 0
    }

    const parentDepth = resolve(item.parentId)
    const depth = parentDepth + 1
    visiting.delete(id)
    memo.set(id, depth)
    return depth
  }

  for (const item of items) {
    resolve(item.id)
  }

  return Object.fromEntries(memo.entries())
}

export function layoutTree(items: TreeLayoutItem[], options: TreeLayoutOptions = {}): Record<string, Point> {
  const nodeWidth = options.nodeWidth ?? 260
  const nodeHeight = options.nodeHeight ?? 72
  const levelGap = options.levelGap ?? 110
  const siblingGap = options.siblingGap ?? 40

  const depths = computeDepths(items)
  const grouped = new Map<number, TreeLayoutItem[]>()

  for (const item of items) {
    const depth = depths[item.id] ?? 0
    const bucket = grouped.get(depth)
    if (bucket) bucket.push(item)
    else grouped.set(depth, [item])
  }

  const sortedLevels = Array.from(grouped.keys()).sort((a, b) => a - b)
  const positions: Record<string, Point> = {}

  for (const depth of sortedLevels) {
    const levelItems = grouped.get(depth) ?? []
    levelItems.sort((a, b) => {
      const ao = normalizeNumber(a.order) ?? 0
      const bo = normalizeNumber(b.order) ?? 0
      if (ao !== bo) return ao - bo
      return a.id.localeCompare(b.id)
    })

    for (let i = 0; i < levelItems.length; i += 1) {
      const item = levelItems[i]
      positions[item.id] = {
        x: i * (nodeWidth + siblingGap),
        y: depth * (nodeHeight + levelGap),
      }
    }
  }

  return positions
}

export function layoutTreeTidy(items: TreeLayoutItem[], options: TreeLayoutOptions = {}): Record<string, Point> {
  const nodeWidth = options.nodeWidth ?? 260
  const nodeHeight = options.nodeHeight ?? 72
  const levelGap = options.levelGap ?? 110
  const siblingGap = options.siblingGap ?? 40

  const depths = computeDepths(items)
  const byId = new Map(items.map((item) => [item.id, item]))
  const childrenById = new Map<string, string[]>()

  for (const item of items) {
    if (item.parentId) {
      const bucket = childrenById.get(item.parentId)
      if (bucket) bucket.push(item.id)
      else childrenById.set(item.parentId, [item.id])
    }
  }

  childrenById.forEach((children, parentId) => {
    children.sort((a: string, b: string) => {
      const ia = byId.get(a)
      const ib = byId.get(b)
      const ao = normalizeNumber(ia?.order) ?? 0
      const bo = normalizeNumber(ib?.order) ?? 0
      if (ao !== bo) return ao - bo
      return a.localeCompare(b)
    })
    childrenById.set(parentId, children)
  })

  const roots = items
    .filter((item) => !item.parentId || !byId.has(item.parentId))
    .sort((a, b) => {
      const ao = normalizeNumber(a.order) ?? 0
      const bo = normalizeNumber(b.order) ?? 0
      if (ao !== bo) return ao - bo
      return a.id.localeCompare(b.id)
    })
    .map((item) => item.id)

  const widthMemo = new Map<string, number>()
  const computing = new Set<string>()

  const subtreeWidth = (id: string): number => {
    const cached = widthMemo.get(id)
    if (cached != null) return cached
    if (computing.has(id)) return nodeWidth
    computing.add(id)

    const children = childrenById.get(id) ?? []
    if (children.length === 0) {
      widthMemo.set(id, nodeWidth)
      computing.delete(id)
      return nodeWidth
    }

    let total = 0
    for (const childId of children) {
      total += subtreeWidth(childId)
    }
    total += siblingGap * (children.length - 1)
    total = Math.max(total, nodeWidth)

    widthMemo.set(id, total)
    computing.delete(id)
    return total
  }

  const positions: Record<string, Point> = {}
  const placed = new Set<string>()

  const place = (id: string, left: number) => {
    const item = byId.get(id)
    if (!item) return
    if (placed.has(id)) return
    placed.add(id)

    const depth = depths[id] ?? 0
    const children = childrenById.get(id) ?? []
    const myWidth = subtreeWidth(id)

    const y = depth * (nodeHeight + levelGap)
    const x = left + myWidth / 2 - nodeWidth / 2
    positions[id] = { x, y }

    let cursor = left
    for (const childId of children) {
      const w = subtreeWidth(childId)
      place(childId, cursor)
      cursor += w + siblingGap
    }
  }

  let cursor = 0
  for (const rootId of roots) {
    const w = subtreeWidth(rootId)
    place(rootId, cursor)
    cursor += w + siblingGap * 2
  }

  for (const item of items) {
    if (!positions[item.id]) {
      const depth = depths[item.id] ?? 0
      positions[item.id] = { x: 0, y: depth * (nodeHeight + levelGap) }
    }
  }

  return positions
}
