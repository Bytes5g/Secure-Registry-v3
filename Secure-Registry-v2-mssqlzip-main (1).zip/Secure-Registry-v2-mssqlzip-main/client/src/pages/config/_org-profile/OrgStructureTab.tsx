import { useCallback, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Network } from "lucide-react";
import { GenericEntityPage } from "@/components/generic/GenericEntityPage";
import { PAGE_CODES } from "@/lib/constants";
import { fetchOrgTreeChildren } from "@/lib/api/org-admin";
import {
  EntityContentCard,
  TreeNavigationPanel,
  type TreeNode,
} from "@secure-registry/components-ui";
import { ORG_UNITS_CONFIG } from "./configs";

function mapUnitToTreeNode(unit: any): TreeNode {
  const node = {
    id: unit.id,
    name: unit.name,
    parentId: unit.parentId ?? null,
    hasChildren: true,
  } as any;
  node.level = unit.level ?? null;
  return node as TreeNode;
}

export function OrgStructureTab({ orgId }: { orgId: number }) {
  const queryClient = useQueryClient();
  const [selectedNode, setSelectedNode] = useState<TreeNode | null>(null);
  const selectedUnitId = selectedNode?.id ?? null;
  const selectedUnitLevel = (selectedNode as any)?.level == null ? null : Number((selectedNode as any).level);

  const { data: rootNodes = [] } = useQuery<TreeNode[]>({
    queryKey: ["org-entity-units-root", orgId],
    queryFn: async () =>
      (await fetchOrgTreeChildren(orgId, null, { includeInactive: true })).map(mapUnitToTreeNode),
  });

  const loadChildren = useCallback(
    async (parentId: number): Promise<TreeNode[]> =>
      (await fetchOrgTreeChildren(orgId, parentId, { includeInactive: true })).map(mapUnitToTreeNode),
    [orgId],
  );

  const handleMutationSuccess = () => {
    queryClient.invalidateQueries({ queryKey: ["org-entity-units-root", orgId] });
    queryClient.invalidateQueries({ queryKey: ["orgStructureTree"] });
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
      <div className="lg:col-span-1">
        <TreeNavigationPanel
          title="الهيكل التنظيمي"
          icon={<Network className="h-4 w-4" />}
          rootNodes={rootNodes}
          selectedNodeId={selectedNode?.id}
          onSelectNode={setSelectedNode}
          loadChildren={loadChildren}
          rootLabel="جذر الهيكل"
          className="h-full"
        />
      </div>

      <div className="lg:col-span-3">
        <EntityContentCard>
          <GenericEntityPage
            key={`units-${orgId}-${selectedUnitId ?? "root"}`}
            entityType="orgStructureTree"
            pageCode={PAGE_CODES.ORG_STRUCTURE_TREE}
            staticConfig={ORG_UNITS_CONFIG}
            formCode="default"
            apiParams={{ orgId, parentId: selectedUnitId, includeInactive: 1 }}
            defaultValues={{
              orgId,
              parentId: selectedUnitId == null ? "null" : String(selectedUnitId),
              level:
                selectedUnitLevel != null && Number.isFinite(selectedUnitLevel)
                  ? selectedUnitLevel + 1
                  : 1,
            }}
            onMutationSuccess={handleMutationSuccess}
            hideTitle={true}
          />
        </EntityContentCard>
      </div>
    </div>
  );
}
