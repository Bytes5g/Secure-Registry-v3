import { lookupModule, orgModule, personnelModule, type OrgEmployeeRecord } from "@core/database";
import type { 
  OrganizationalStructure, 
  InsertOrganizationalStructure, 
  OrganizationalStructureWithDetails,
  OrgStructureTree,
  InsertOrgStructureTree,
  OrgStructureTreeWithChildren,
  LookupValue
} from "@shared/schema";
import { LOOKUP_CODES } from "@shared/constants/lookup-codes";
import type { IOrganizationalStructureStorage, IOrgStructureTreeStorage } from "./types";

type OrgCreatePayload = Parameters<typeof orgModule.createOrganization>[0];
type OrgUpdatePayload = Parameters<typeof orgModule.updateOrganization>[1];
type TreeCreatePayload = Parameters<typeof orgModule.createTreeNode>[0];
type TreeUpdatePayload = Parameters<typeof orgModule.updateTreeNode>[1];
type OrgRecord = NonNullable<Awaited<ReturnType<typeof orgModule.getOrganization>>>;

// هذه الدالة تُبقي قيمة lookup كما هي (مُهيأة للتوسعة لاحقاً دون تغيير العقد)
function toLookupMapValue(item: LookupValue): LookupValue {
  return item;
}

// هذه الدالة تحول payload الإدخال الخاص بالمنظمة إلى payload متوافق مع orgModule مع تمرير workContextBy وحقول التدقيق
function toOrgCreatePayload(org: InsertOrganizationalStructure): OrgCreatePayload {
  return {
    name: org.name,
    code: org.code,
    sectorId: org.sectorId ?? null,
    locationId: org.locationId ?? null,
    categoryId: org.categoryId ?? null,
    parentId: org.parentId ?? null,
    isActive: org.isActive ?? true,
    orderIndex: org.orderIndex ?? 0,
    workContextBy: (org as any).workContextBy ?? null,
    createdBy: (org as any).createdBy ?? null,
  };
}

// هذه الدالة تحول payload التحديث الخاص بالمنظمة إلى payload متوافق مع orgModule مع تمرير workContextBy وحقول التدقيق
function toOrgUpdatePayload(org: Partial<InsertOrganizationalStructure>): OrgUpdatePayload {
  return {
    name: org.name,
    code: org.code,
    sectorId: org.sectorId,
    locationId: org.locationId,
    categoryId: org.categoryId,
    parentId: org.parentId,
    isActive: org.isActive,
    orderIndex: org.orderIndex,
    workContextBy: (org as any).workContextBy,
    updatedAt: (org as any).updatedAt,
    updatedBy: (org as any).updatedBy,
  };
}

// هذه الدالة تحول payload إدخال عقدة الشجرة إلى payload متوافق مع orgModule مع تمرير workContextBy وحقول التدقيق
function toTreeCreatePayload(node: InsertOrgStructureTree): TreeCreatePayload {
  return {
    parentId: node.parentId ?? null,
    orgId: node.orgId,
    name: node.name,
    code: node.code,
    structureId: node.structureId ?? null,
    isActive: node.isActive ?? true,
    orderIndex: node.orderIndex ?? null,
    level: node.level ?? null,
    workContextBy: (node as any).workContextBy ?? null,
    createdBy: (node as any).createdBy ?? null,
  };
}

// هذه الدالة تحول payload تحديث عقدة الشجرة إلى payload متوافق مع orgModule مع تمرير workContextBy وحقول التدقيق
function toTreeUpdatePayload(node: Partial<InsertOrgStructureTree>): TreeUpdatePayload {
  return {
    parentId: node.parentId,
    orgId: node.orgId,
    name: node.name,
    code: node.code,
    structureId: node.structureId,
    isActive: node.isActive,
    orderIndex: node.orderIndex == null ? undefined : node.orderIndex,
    level: node.level == null ? undefined : node.level,
    workContextBy: (node as any).workContextBy,
    updatedAt: (node as any).updatedAt,
    updatedBy: (node as any).updatedBy,
  };
}

async function getLookupMap(): Promise<Map<number, LookupValue>> {
  const types = await lookupModule.getAllTypes();
  const lookups = await Promise.all(types.map((type) => lookupModule.getValuesByTypeId(type.id)));
  const map = new Map<number, LookupValue>();

  for (const items of lookups) {
    for (const item of items) {
      map.set(item.id, toLookupMapValue(item));
    }
  }

  return map;
}

type OrgLookupTypeIds = {
  sectorTypeId: number;
  locationTypeId: number;
  categoryTypeId: number;
};

const ORG_LOOKUP_CODES = LOOKUP_CODES.org;

let orgLookupTypeIdsCache: Promise<OrgLookupTypeIds> | null = null;

async function getOrgLookupTypeIds(): Promise<OrgLookupTypeIds> {
  orgLookupTypeIdsCache ??= (async () => {
    const [sector, location, category] = await Promise.all([
      lookupModule.getTypeByCode(ORG_LOOKUP_CODES.sector),
      lookupModule.getTypeByCode(ORG_LOOKUP_CODES.location),
      lookupModule.getTypeByCode(ORG_LOOKUP_CODES.category),
    ]);

    if (!sector || !location || !category) {
      throw new Error("Missing lookup type configuration for organization lookups.");
    }

    return {
      sectorTypeId: sector.id,
      locationTypeId: location.id,
      categoryTypeId: category.id,
    };
  })();

  return orgLookupTypeIdsCache;
}

let orgStructureLookupTypeIdCache: Promise<number> | null = null;

async function getOrgStructureLookupTypeId(): Promise<number> {
  orgStructureLookupTypeIdCache ??= (async () => {
    const structure = await lookupModule.getTypeByCode(ORG_LOOKUP_CODES.structure);
    if (!structure) {
      throw new Error("Missing lookup type configuration for org structure codes.");
    }
    return structure.id;
  })();

  return orgStructureLookupTypeIdCache;
}

async function getLookupValueMap(typeId: number): Promise<Map<number, LookupValue>> {
  const values = await lookupModule.getValuesByTypeId(typeId);
  const map = new Map<number, LookupValue>();
  for (const item of values) {
    map.set(item.id, toLookupMapValue(item));
  }
  return map;
}

export class OrganizationalStructureStorage implements IOrganizationalStructureStorage {
  async getOrganization(id: number): Promise<OrganizationalStructure | undefined> {
    return orgModule.getOrganization(id);
  }

  async getOrganizationWithDetails(id: number): Promise<OrganizationalStructureWithDetails | undefined> {
    const org = await orgModule.getOrganization(id);
    if (!org) return undefined;
    
    const details = await this.enrichWithLookups([org]);
    return details[0];
  }

  async getAllOrganizations(options?: { includeInactive?: boolean }): Promise<OrganizationalStructure[]> {
    return orgModule.getAllOrganizations(options);
  }

  async getAllOrganizationsWithDetails(options?: { includeInactive?: boolean }): Promise<OrganizationalStructureWithDetails[]> {
    const orgs = await orgModule.getAllOrganizations(options);
    return this.enrichWithLookups(orgs);
  }

  async getOrganizationsByParentId(parentId: number | null, options?: { includeInactive?: boolean }): Promise<OrganizationalStructure[]> {
    return orgModule.getOrganizationsByParentId(parentId, options);
  }

  async getOrgEmployees(orgId: number): Promise<OrgEmployeeRecord[]> {
    return personnelModule.getOrgEmployees(orgId);
  }

  async createOrganization(org: InsertOrganizationalStructure): Promise<OrganizationalStructure> {
    return orgModule.createOrganization(toOrgCreatePayload(org));
  }

  async updateOrganization(id: number, org: Partial<InsertOrganizationalStructure>): Promise<OrganizationalStructure | undefined> {
    return orgModule.updateOrganization(id, toOrgUpdatePayload(org));
  }

  async deleteOrganization(id: number): Promise<boolean> {
    return await orgModule.deleteOrganization(id);
  }

  private async enrichWithLookups(orgs: OrganizationalStructure[] | OrgRecord[]): Promise<OrganizationalStructureWithDetails[]> {
    const { sectorTypeId, locationTypeId, categoryTypeId } = await getOrgLookupTypeIds();
    const [sectorMap, locationMap, categoryMap] = await Promise.all([
      getLookupValueMap(sectorTypeId),
      getLookupValueMap(locationTypeId),
      getLookupValueMap(categoryTypeId),
    ]);

    return orgs.map((org) => ({
      ...org,
      sector: org.sectorId ? sectorMap.get(org.sectorId) : undefined,
      location: org.locationId ? locationMap.get(org.locationId) : undefined,
      category: org.categoryId ? categoryMap.get(org.categoryId) : undefined,
    }));
  }
}

export class OrgStructureTreeStorage implements IOrgStructureTreeStorage {
  async getTreeNode(id: number): Promise<OrgStructureTree | undefined> {
    return orgModule.getTreeNode(id);
  }

  async getTreeNodesByOrgId(orgId: number, options?: { includeInactive?: boolean }): Promise<OrgStructureTree[]> {
    return orgModule.getTreeNodesByOrgId(orgId, options);
  }

  async getTreeNodesByParentId(orgId: number, parentId: number | null, options?: { includeInactive?: boolean }): Promise<OrgStructureTree[]> {
    return orgModule.getTreeNodesByParentId(orgId, parentId, options);
  }

  async getTreeWithChildren(orgId: number, options?: { includeInactive?: boolean }): Promise<OrgStructureTreeWithChildren[]> {
    const allNodes = await this.getTreeNodesByOrgId(orgId, options);
    const structureTypeId = await getOrgStructureLookupTypeId();
    const structureMap = await getLookupValueMap(structureTypeId);

    const nodeMap = new Map<number, OrgStructureTreeWithChildren>();
    const roots: OrgStructureTreeWithChildren[] = [];

    allNodes.forEach(node => {
      const enrichedNode: OrgStructureTreeWithChildren = {
        ...node,
        structure: node.structureId ? structureMap.get(node.structureId) : undefined,
        children: []
      };
      nodeMap.set(node.id, enrichedNode);
    });

    allNodes.forEach(node => {
      const enrichedNode = nodeMap.get(node.id)!;
      if (node.parentId === null) {
        roots.push(enrichedNode);
      } else {
        const parent = nodeMap.get(node.parentId);
        if (parent) {
          parent.children = parent.children || [];
          parent.children.push(enrichedNode);
        }
      }
    });

    return roots;
  }

  async createTreeNode(node: InsertOrgStructureTree): Promise<OrgStructureTree> {
    return orgModule.createTreeNode(toTreeCreatePayload(node));
  }

  async createManyTreeNodes(nodes: InsertOrgStructureTree[]): Promise<OrgStructureTree[]> {
    return orgModule.createManyTreeNodes(nodes.map(toTreeCreatePayload));
  }

  async updateTreeNode(id: number, node: Partial<InsertOrgStructureTree>): Promise<OrgStructureTree | undefined> {
    return orgModule.updateTreeNode(id, toTreeUpdatePayload(node));
  }

  async deleteTreeNode(id: number): Promise<boolean> {
    return await orgModule.deleteTreeNode(id);
  }
}
