# @secure-registry/components-ui

حزمة مكونات UI عامة (قوالب/نماذج/Primitives) قابلة لإعادة الاستخدام في أي وحدة داخل المشروع.

## مبادئ ما يدخل الحزمة

- يجب أن يكون المكوّن “غبي/عرضي” قدر الإمكان: لا API, لا Routing, لا صلاحيات, لا معرفة بدومين (People/Org/…).
- مسموح بالتعامل مع state محلي داخل المكوّن (مثل فتح/إغلاق Dialog) إذا كان عاماً.
- ممنوع الاعتماد على مسارات alias الخاصة بالعميل مثل `@/…` داخل الحزمة.

## الاستيراد (مفضل)

```ts
import { Button, Dialog, DataTable, TreeNavigation } from "@secure-registry/components-ui"
```

## القوائم المتاحة حالياً

### UI Primitives (`./ui`)

- Dialog/Sheet/AlertDialog/ConfirmDialog
- Button/Badge/Input/Label/Select/Switch/Textarea
- Table/Tabs/Skeleton/Toast
- Avatar/Checkbox/Collapsible/Command/DropdownMenu/Popover/ScrollArea/Separator/Toggle/Tooltip
- Form (تكامل عام مع react-hook-form)

### Templates (`./forms`, `./tables`, `./trees`)

- FormTemplate
- DataTable
- TreeNavigation

### Shared Layout Helpers (`./shared`)

- EntityEditorSheet / EntityFormDialog / EntityDeleteDialog
- EntityPageHeader / EntityRelationsTabs / EntityContentCard
- FieldGroup / FormSection / TextListField
- InfoCard / InfoCardGrid
- RelatedRecordsPanel
- TreeNavigationPanel
- ToggleCard

## عناصر متروكة خارج الحزمة (حالياً)

هذه العناصر تُستخدم في `client/src` لكنها ليست “عامة” لأنها مرتبطة بتطبيق العميل أو hooks الخاصة به:

- `sidebar` (مرتبط بتخطيط التطبيق وتصفية القوائم)
- `toaster` (مرتبط بـ hooks وإدارة Toasts الخاصة بالعميل)

