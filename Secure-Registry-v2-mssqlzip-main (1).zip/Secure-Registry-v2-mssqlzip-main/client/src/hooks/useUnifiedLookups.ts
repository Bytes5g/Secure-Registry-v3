import { useQuery } from "@tanstack/react-query";
import { fetchLookupTypesWithValues } from "@/lib/api/lookups";

export function useUnifiedLookups() {
  const { data: lookups = [], isLoading } = useQuery({
    queryKey: ["lookupTypes"],
    queryFn: fetchLookupTypesWithValues,
  });

  return {
    lookups,
    isLoading,
  };
}
