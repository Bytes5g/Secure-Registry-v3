import { Response, NextFunction } from "express";

export function sanitizeValue(value: unknown): unknown {
  if (value === undefined) {
    return null;
  }
  
  if (typeof value === "number") {
    if (Number.isNaN(value) || !Number.isFinite(value)) {
      return null;
    }
    return value;
  }
  
  if (value === null) {
    return null;
  }
  
  if (Array.isArray(value)) {
    return value.map(sanitizeValue);
  }
  
  if (value instanceof Date) {
    return value.toISOString();
  }
  
  if (typeof value === "object" && value !== null) {
    const sanitized: Record<string, unknown> = {};
    for (const [key, val] of Object.entries(value)) {
      sanitized[key] = sanitizeValue(val);
    }
    return sanitized;
  }
  
  return value;
}

export function sanitizePayload<T>(data: T): T {
  return sanitizeValue(data) as T;
}

export function responseSanitizer(_req: unknown, res: Response, next: NextFunction) {
  const originalJson = res.json.bind(res);
  
  res.json = function(body: unknown) {
    const sanitizedBody = sanitizePayload(body);
    return originalJson(sanitizedBody);
  };
  
  next();
}

export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: {
    code: string;
    message: string;
    details?: unknown;
  };
}

export function successResponse<T>(data: T): ApiResponse<T> {
  return {
    success: true,
    data: sanitizePayload(data),
  };
}

export function errorResponse(code: string, message: string, details?: unknown): ApiResponse<never> {
  return {
    success: false,
    error: {
      code,
      message,
      details,
    },
  };
}

export class ApiError extends Error {
  public readonly statusCode: number;
  public readonly code: string;
  public readonly details?: unknown;

  constructor(statusCode: number, code: string, message: string, details?: unknown) {
    super(message);
    this.statusCode = statusCode;
    this.code = code;
    this.details = details;
    Object.setPrototypeOf(this, ApiError.prototype);
  }

  static badRequest(message: string, details?: unknown): ApiError {
    return new ApiError(400, "BAD_REQUEST", message, details);
  }

  static notFound(message: string): ApiError {
    return new ApiError(404, "NOT_FOUND", message);
  }

  static internal(message: string): ApiError {
    return new ApiError(500, "INTERNAL_ERROR", message);
  }

  static validation(details: unknown): ApiError {
    return new ApiError(400, "VALIDATION_ERROR", "Validation failed", details);
  }
}
