import { 
  LayoutDashboard, 
  Search, 
  BarChart3, 
  Settings, 
  Network, 
  Paperclip,
  List,
  Map,
  Users
} from "lucide-react";

export interface MenuItem {
  title: string;
  path: string;
  icon?: any;
  children?: MenuItem[];
}

export interface MenuSection {
  title: string;
  items: MenuItem[];
}

export const SIDEBAR_MENU: MenuSection[] = [
  {
    title: "الرئيسية",
    items: [
      {
        title: "لوحة المعلومات",
        path: "/",
        icon: LayoutDashboard
      },
      {
        title: "البحث المتقدم",
        path: "/search",
        icon: Search
      },
      {
        title: "الإحصائيات",
        path: "/statistics",
        icon: BarChart3
      }
    ]
  },
  {
    title: "إعدادات النظام",
    items: [
      {
        title: "القوائم المرجعية",
        path: "/config/lookups",
        icon: List
      },
      {
        title: "الوحدات الجغرافية",
        path: "/config/geo",
        icon: Map
      },
      {
        title: "إدارة الجهات",
        path: "/config/org-entities",
        icon: Network
      },
      {
        title: "الأشخاص",
        path: "/config/persons",
        icon: Users
      },
      {
        title: "تهيئات الصفحات",
        path: "/config/ui-page-overrides",
        icon: Settings
      },
      {
        title: "الملفات والمرفقات",
        path: "/files",
        icon: Paperclip,
      },
      {
        title: "الإعدادات العامة",
        path: "/settings",
        icon: Settings
      }
    ]
  }
];
