import { ArrowRight } from "lucide-react";
import { Badge, Button } from "@secure-registry/components-ui";
import type { GeoAdminUnit } from "@shared/schema";
import { DataTable, type Column } from "@secure-registry/components-ui";
import type { GeoCountry } from "@/lib/api/geo-admin";
import { LOCAL_LEVEL_MAX, LOCAL_LEVEL_MIN } from "./useGeoFormFields";
import type { GeoTreeNode } from "./types";

interface GeoDetailPaneProps {
  country: GeoCountry;
  selectedNode: GeoTreeNode | null;
  units: GeoAdminUnit[];
  isUnitsLoading: boolean;
  columns: Column<GeoAdminUnit>[];
  onBackToCountries: () => void;
  onAdd?: () => void;
  onEdit: (unit: GeoAdminUnit) => void;
  onDelete: (unit: GeoAdminUnit) => void;
}

export function GeoDetailPane({
  country,
  selectedNode,
  units,
  isUnitsLoading,
  columns,
  onBackToCountries,
  onAdd,
  onEdit,
  onDelete,
}: GeoDetailPaneProps) {
  const reachedMaxLevel = (selectedNode?.level ?? LOCAL_LEVEL_MIN - 1) >= LOCAL_LEVEL_MAX;

  return (
    <>
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={onBackToCountries}>
              <ArrowRight className="h-4 w-4 ms-1" /> العودة إلى الدول
            </Button>
            <Badge variant="outline">{country.code}</Badge>
            <Badge variant="secondary">
              {selectedNode ? `التابع لـ ${selectedNode.name}` : "الوحدات الرئيسية داخل الدولة"}
            </Badge>
          </div>
          <h2 className="text-lg font-semibold">{country.name}</h2>
          <p className="text-sm text-muted-foreground">
            يتم الآن جلب البيانات حسب الدولة والعقدة الحالية فقط، وليس كامل السجلات.
          </p>
        </div>
      </div>

      <DataTable
        data={units}
        columns={columns}
        isLoading={isUnitsLoading}
        searchable
        searchPlaceholder="ابحث داخل القائمة الحالية..."
        onAdd={reachedMaxLevel ? undefined : onAdd}
        onEdit={onEdit}
        onDelete={onDelete}
        addButtonLabel={selectedNode ? `إضافة تابع لـ ${selectedNode.name}` : "إضافة وحدة رئيسية"}
        emptyMessage="لا توجد وحدات في هذا المستوى"
      />
    </>
  );
}
