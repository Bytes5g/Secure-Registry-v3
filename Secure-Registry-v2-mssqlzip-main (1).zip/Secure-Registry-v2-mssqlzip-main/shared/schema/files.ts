import { z } from "zod";

const nullableInt = z.number().int().nullable();
const nullableBigInt = z.number().int().nullable();
const nullableString = z.string().nullable();
const optionalNullableString = nullableString.optional().default(null);
const optionalNullableInt = nullableInt.optional().default(null);
const optionalNullableBigInt = nullableBigInt.optional().default(null);

export const fileSchema = z.object({
  id: z.number().int(),
  storage: z.string().min(1),
  filenameDisk: nullableString,
  filenameDownload: z.string().min(1),
  title: nullableString,
  type: nullableString,
  folder: nullableInt,
  uploadedBy: nullableInt,
  createdOn: nullableString,
  modifiedBy: nullableInt,
  modifiedOn: nullableString,
  charset: nullableString,
  filesize: nullableBigInt,
  width: nullableInt,
  height: nullableInt,
  duration: nullableInt,
  embed: nullableString,
  description: nullableString,
  location: nullableString,
  tags: nullableString,
  metadata: nullableString,
  focalPointX: nullableInt,
  focalPointY: nullableInt,
  tusId: nullableString,
  tusData: nullableString,
  uploadedOn: nullableString,
});
export type FileRecord = z.infer<typeof fileSchema>;

export const insertFileSchema = z.object({
  storage: z.string().min(1).optional().default("local"),
  filenameDisk: optionalNullableString,
  filenameDownload: z.string().min(1),
  title: optionalNullableString,
  type: optionalNullableString,
  folder: optionalNullableInt,
  uploadedBy: optionalNullableInt,
  modifiedBy: optionalNullableInt,
  charset: optionalNullableString,
  filesize: optionalNullableBigInt,
  width: optionalNullableInt,
  height: optionalNullableInt,
  duration: optionalNullableInt,
  embed: optionalNullableString,
  description: optionalNullableString,
  location: optionalNullableString,
  tags: optionalNullableString,
  metadata: optionalNullableString,
  focalPointX: optionalNullableInt,
  focalPointY: optionalNullableInt,
  tusId: optionalNullableString,
  tusData: optionalNullableString,
  uploadedOn: optionalNullableString,
});
export type InsertFile = z.input<typeof insertFileSchema>;

