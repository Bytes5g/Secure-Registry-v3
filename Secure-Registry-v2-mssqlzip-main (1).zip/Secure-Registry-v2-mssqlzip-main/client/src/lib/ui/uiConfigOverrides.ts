import type { UiPageConfig } from "@/types/ui";

export function normalizeOrder<T extends { orderIndex?: number }>(items: T[]): T[] {
  return items.map((item, idx) => ({ ...item, orderIndex: idx + 1 }));
}

function mergeArrayByKey<T extends Record<string, any>>(
  baseArr: T[] | undefined,
  patchArr: T[] | undefined,
  key: keyof T,
): T[] {
  const base = Array.isArray(baseArr) ? baseArr : [];
  const patch = Array.isArray(patchArr) ? patchArr : [];

  const baseByKey = new Map<string, T>();
  const baseOrder: string[] = [];
  for (const item of base) {
    const k = String(item?.[key] ?? "");
    if (!k.trim()) continue;
    if (!baseByKey.has(k)) baseOrder.push(k);
    baseByKey.set(k, item);
  }

  const patchByKey = new Map<string, T>();
  const patchOrder: string[] = [];
  for (const item of patch) {
    const k = String(item?.[key] ?? "");
    if (!k.trim()) continue;
    if (!patchByKey.has(k)) patchOrder.push(k);
    patchByKey.set(k, item);
  }

  const merged: T[] = [];
  const used = new Set<string>();
  for (const k of baseOrder) {
    used.add(k);
    const b = baseByKey.get(k);
    const p = patchByKey.get(k);
    merged.push(p ? ({ ...(b as any), ...(p as any) } as T) : (b as T));
  }
  for (const k of patchOrder) {
    if (used.has(k)) continue;
    const p = patchByKey.get(k);
    if (p) merged.push(p);
  }

  const patchNoKey = patch.filter((it) => !String(it?.[key] ?? "").trim());
  return [...merged, ...patchNoKey];
}

export function mergeUiConfig(base: UiPageConfig, override: Record<string, unknown> | null): UiPageConfig {
  if (!override || typeof override !== "object") return base;
  const patch = override as any;
  const next: any = { ...base, ...patch };

  if (patch.columns !== undefined) next.columns = mergeArrayByKey(base.columns as any, patch.columns as any, "fieldCode");
  if (patch.formFields !== undefined) next.formFields = mergeArrayByKey(base.formFields as any, patch.formFields as any, "fieldCode");
  if (patch.filters !== undefined) next.filters = patch.filters;
  return next as UiPageConfig;
}

export function toOverridePayload(config: UiPageConfig): Record<string, unknown> {
  return {
    nameAr: config.nameAr,
    description: config.description,
    layoutType: config.layoutType,
    columns: config.columns,
    formFields: config.formFields,
    filters: config.filters ?? [],
  };
}
