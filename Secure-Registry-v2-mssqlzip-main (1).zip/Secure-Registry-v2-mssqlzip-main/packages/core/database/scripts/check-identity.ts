import { createRequest } from "../src/config/connection";

async function check() {
  try {
    const request = await createRequest();
    
    const result = await request.query("SELECT COLUMNPROPERTY(object_id('dbo.org_entity_structure'), 'id', 'IsIdentity') as isIdentity");
    console.log("org_entity_structure isIdentity:", result.recordset);
    
    const lookupTypesResult = await request.query("SELECT COLUMNPROPERTY(object_id('dbo.lookup_types'), 'id', 'IsIdentity') as isIdentity");
    console.log("lookup_types isIdentity:", lookupTypesResult.recordset);
    
    const foldersResult = await request.query("SELECT COLUMNPROPERTY(object_id('dbo.folders'), 'id', 'IsIdentity') as isIdentity");
    console.log("folders isIdentity:", foldersResult.recordset);
    
  } catch(e) {
    console.error(e);
  }
  process.exit(0);
}
check();