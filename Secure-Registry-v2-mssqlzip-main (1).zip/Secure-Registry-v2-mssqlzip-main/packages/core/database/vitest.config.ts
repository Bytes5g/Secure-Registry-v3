import { defineConfig } from "vitest/config";
import { fileURLToPath } from "node:url";
import path from "node:path";

const here = path.dirname(fileURLToPath(import.meta.url));

export default defineConfig({
  root: here,
  css: {
    postcss: {
      plugins: [],
    },
  },
  test: {
    include: ["src/**/*.test.ts"],
  },
});
