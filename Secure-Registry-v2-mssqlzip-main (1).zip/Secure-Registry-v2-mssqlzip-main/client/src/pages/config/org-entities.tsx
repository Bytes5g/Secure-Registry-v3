import { GenericEntityPage } from "@/components/generic/GenericEntityPage";
import { PAGE_CODES } from "@/lib/constants";
import { Button, EntityContentCard, type Column } from "@secure-registry/components-ui";
import { Eye } from "lucide-react";
import { useLocation } from "wouter";

export default function OrgEntitiesManagementPage() {
  const [, setLocation] = useLocation();

  const extraColumns: Column<any>[] = [
    {
      key: "profile",
      header: "عرض",
      width: "50px",
      render: (_, row) => (
        <Button
          variant="ghost"
          size="icon"
          onClick={() => setLocation(`/config/org-entities/${row.id}`)}
          title="فتح بروفايل الجهة"
        >
          <Eye className="h-4 w-4" />
        </Button>
      ),
    },
  ];

  return (
    <div className="p-6 space-y-4" dir="rtl">
      <EntityContentCard contentClassName="p-6">
        <GenericEntityPage
          entityType="organizationalStructure"
          pageCode={PAGE_CODES.ORG_STRUCTURE}
          extraColumns={extraColumns}
          apiParams={{ limit: 200, includeInactive: 1 }}
          hideTitle={true}
        />
      </EntityContentCard>
    </div>
  );
}
