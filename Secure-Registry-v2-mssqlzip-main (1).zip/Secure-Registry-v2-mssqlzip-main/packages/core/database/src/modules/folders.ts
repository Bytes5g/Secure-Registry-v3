import type { SqlExecutor } from "../config/connection";
import { deleteRow, insertRow, pickDefined, runQuery, runQueryOne, updateRow } from "./helpers";

export interface FolderRecord {
  id: number;
  name: string;
  parent: number | null;
}

export type FolderWriteContext = {
  workContextBy: number;
  createdBy: number;
};

export type FolderCreatePayload = Omit<FolderRecord, "id"> & {
  workContextBy?: number | null;
  createdBy?: number | null;
  isActive?: boolean | null;
  isDeleted?: boolean | null;
};
export type FolderUpdatePayload = Partial<FolderCreatePayload> & {
  updatedAt?: Date | string | null;
  updatedBy?: number | null;
};

function asString(value: unknown): string {
  return String(value ?? "");
}

function asNumber(value: unknown): number | null {
  if (value == null) return null;
  const numericValue = Number(value);
  return Number.isFinite(numericValue) ? numericValue : null;
}

function mapFolder(row: Record<string, unknown>): FolderRecord {
  return {
    id: Number(row.id),
    name: asString(row.name),
    parent: asNumber(row.parent),
  };
}

function buildFolderRow(payload: FolderCreatePayload | FolderUpdatePayload): Record<string, unknown> {
  return pickDefined({
    name: payload.name,
    parent: payload.parent,
    work_context_by: (payload as any).workContextBy,
    created_by: (payload as any).createdBy,
    updated_at: (payload as any).updatedAt,
    updated_by: (payload as any).updatedBy,
    is_active: (payload as any).isActive,
    is_deleted: (payload as any).isDeleted,
  });
}

export class FoldersModule {
  private async getNextFolderId(executor?: SqlExecutor): Promise<number> {
    const row = await runQueryOne<{ id: unknown }>("SELECT NEXT VALUE FOR dbo.seq_folders_id AS id", {}, executor);
    const id = row?.id == null ? NaN : Number(row.id);
    if (!Number.isFinite(id)) {
      throw new Error("Failed to allocate folder id");
    }
    return id;
  }

  async getFolder(id: number): Promise<FolderRecord | undefined> {
    const row = await runQueryOne<Record<string, unknown>>("SELECT TOP 1 * FROM dbo.folders WHERE id = @id", { id });
    return row ? mapFolder(row) : undefined;
  }

  async getFolderBreadcrumbs(id: number): Promise<FolderRecord[]> {
    const rows = await runQuery<Record<string, unknown>>(
      `WITH folder_chain AS (
        SELECT id, name, parent, 0 AS depth
        FROM dbo.folders
        WHERE id = @id
        UNION ALL
        SELECT f.id, f.name, f.parent, fc.depth + 1 AS depth
        FROM dbo.folders f
        INNER JOIN folder_chain fc ON f.id = fc.parent
      )
      SELECT id, name, parent
      FROM folder_chain
      ORDER BY depth DESC
      OPTION (MAXRECURSION 100);`,
      { id },
    );

    return rows.map(mapFolder);
  }

  async getFolders(filters: { parent?: number | null; search?: string; limit?: number } = {}): Promise<FolderRecord[]> {
    const clauses: string[] = [];
    const params: Record<string, unknown> = {};

    if (filters.parent === null) {
      clauses.push("parent IS NULL");
    } else if (filters.parent != null) {
      clauses.push("parent = @parent");
      params.parent = filters.parent;
    }

    if (filters.search) {
      clauses.push("name LIKE @q");
      params.q = `%${filters.search}%`;
    }

    const where = clauses.length ? `WHERE ${clauses.join(" AND ")}` : "";
    const top = filters.limit != null ? `TOP ${Math.min(filters.limit, 500)}` : "";
    const rows = await runQuery<Record<string, unknown>>(
      `SELECT ${top} * FROM dbo.folders ${where} ORDER BY name ASC, id ASC`,
      params,
    );
    return rows.map(mapFolder);
  }

  async createFolder(payload: FolderCreatePayload, executor?: SqlExecutor): Promise<FolderRecord> {
    const id = await this.getNextFolderId(executor);
    const row = await insertRow<Record<string, unknown>>(
      "folders",
      {
        id,
        ...buildFolderRow(payload),
      },
      executor,
    );
    return mapFolder(row);
  }

  async updateFolder(
    id: number,
    payload: FolderUpdatePayload,
    executor?: SqlExecutor,
  ): Promise<FolderRecord | undefined> {
    const row = await updateRow<Record<string, unknown>>("folders", id, buildFolderRow(payload), executor);
    return row ? mapFolder(row) : undefined;
  }

  async deleteFolder(id: number, executor?: SqlExecutor): Promise<boolean> {
    return deleteRow("folders", id, executor);
  }

  async getFolderByNameAndParent(name: string, parent: number | null, executor?: SqlExecutor): Promise<FolderRecord | undefined> {
    const clauses: string[] = ["name = @name"];
    const params: Record<string, unknown> = { name };
    if (parent == null) {
      clauses.push("parent IS NULL");
    } else {
      clauses.push("parent = @parent");
      params.parent = parent;
    }

    const row = await runQueryOne<Record<string, unknown>>(
      `SELECT TOP 1 * FROM dbo.folders WHERE ${clauses.join(" AND ")} ORDER BY id ASC`,
      params,
      executor,
    );
    return row ? mapFolder(row) : undefined;
  }

  async ensureFolderPath(
    pathParts: string[],
    ctx: FolderWriteContext,
    rootParent: number | null = null,
    executor?: SqlExecutor,
  ): Promise<FolderRecord> {
    let parent: number | null = rootParent;
    let current: FolderRecord | undefined;

    for (const part of pathParts) {
      const name = part.trim();
      if (!name) {
        throw new Error("Invalid folder name");
      }

      current = await this.getFolderByNameAndParent(name, parent, executor);
      if (!current) {
        current = await this.createFolder(
          {
            name,
            parent,
            workContextBy: ctx.workContextBy,
            createdBy: ctx.createdBy,
            isActive: true,
            isDeleted: false,
          },
          executor,
        );
      }

      parent = current.id;
    }

    if (!current) {
      throw new Error("Folder path cannot be empty");
    }

    return current;
  }
}

export const foldersModule = new FoldersModule();
