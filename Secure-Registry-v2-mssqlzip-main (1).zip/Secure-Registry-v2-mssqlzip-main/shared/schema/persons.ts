import { z } from "zod";

const nullableInt = z.number().int().nullable();
const nullableString = z.string().nullable();

export const personSchema = z.object({
  id: z.number().int(),
  firstName: z.string().min(1),
  fatherName: nullableString,
  grandfatherName: nullableString,
  greatGfName: nullableString,
  greatGreatGfName: nullableString,
  familyName: nullableString,
  fullName: z.string().min(1),
  dateOfBirth: nullableString,
  genderId: nullableInt,
  genderName: nullableString,
  nationalityId: nullableInt,
  nationalityName: nullableString,
  maritalStatusId: nullableInt,
  maritalName: nullableString,
  isActive: z.boolean(),
  createdAt: nullableString,
  updatedAt: nullableString,
});
export type Person = z.infer<typeof personSchema>;

export const insertPersonSchema = z.object({
  firstName: z.string().min(1).optional(),
  fatherName: nullableString.optional(),
  grandfatherName: nullableString.optional(),
  greatGfName: nullableString.optional(),
  greatGreatGfName: nullableString.optional(),
  familyName: nullableString.optional(),
  dateOfBirth: nullableString.optional(),
  genderId: nullableInt.optional(),
  nationalityId: nullableInt.optional(),
  maritalStatusId: nullableInt.optional(),
  isActive: z.boolean().optional(),
});
export type InsertPerson = z.input<typeof insertPersonSchema>;

export const personPhotoSchema = z.object({
  id: z.number().int(),
  personId: z.number().int(),
  filePath: z.string().min(1),
  fileName: nullableString,
  mimeType: nullableString,
  size: z.number().int().nullable(),
  isPrimary: z.boolean(),
  description: nullableString,
  createdAt: nullableString,
});
export type PersonPhoto = z.infer<typeof personPhotoSchema>;

