import { Loader2 } from "lucide-react";
import { Badge } from "@secure-registry/components-ui";

export function DiagramLoading() {
  return (
    <div className="flex items-center gap-2 text-sm text-muted-foreground">
      <Loader2 className="h-4 w-4 animate-spin" />
      جاري التحميل...
    </div>
  );
}

export function DiagramEmptyMessage({ children }: { children: React.ReactNode }) {
  return (
    <div className="rounded-md border p-6 text-center text-muted-foreground">{children}</div>
  );
}

interface CoveringBranchesPanelProps {
  branchesByNode: any[];
}

export function CoveringBranchesPanel({ branchesByNode }: CoveringBranchesPanelProps) {
  return (
    <div className="rounded-md border p-3">
      <div className="text-sm font-medium mb-2">الفروع التي تغطي هذه الوحدة</div>
      <div className="flex flex-wrap gap-2">
        {branchesByNode.length === 0 ? (
          <span className="text-sm text-muted-foreground">لا توجد فروع مرتبطة</span>
        ) : (
          branchesByNode.map((b) => (
            <Badge key={String(b.id)} variant="secondary">
              {String(b.name ?? b.nameAr ?? `فرع ${b.id}`)}
            </Badge>
          ))
        )}
      </div>
    </div>
  );
}
