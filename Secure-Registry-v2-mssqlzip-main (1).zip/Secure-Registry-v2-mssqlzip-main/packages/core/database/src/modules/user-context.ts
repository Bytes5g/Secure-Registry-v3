import { runQueryOne } from "./helpers";

export interface UserWorkContextRecord {
  userId: number;
  personId: number | null;
  fullName: string | null;
  orgId: number | null;
  branchId: number | null;
  orgStructureId: number | null;
  isManager: boolean;
  workContext: number | null;
}

function mapUserEntryContext(row: Record<string, unknown>): UserWorkContextRecord {
  const orgId = row.org_id == null ? null : Number(row.org_id);
  const branchId = row.branch_id == null ? null : Number(row.branch_id);
  const orgStructureId = row.org_structure_id == null ? null : Number(row.org_structure_id);

  return {
    userId: Number(row.user_id),
    personId: row.person_id == null ? null : Number(row.person_id),
    fullName: row.full_name == null ? null : String(row.full_name),
    orgId,
    branchId,
    orgStructureId,
    isManager: Boolean(row.is_manager),
    workContext: row.work_context == null ? null : Number(row.work_context),
  };
}

export class UserContextModule {
  async getUserEntryContext(userId: number): Promise<UserWorkContextRecord | undefined> {
    const row = await runQueryOne<Record<string, unknown>>(
      `
      SELECT TOP 1
        u.user_id,
        u.person_id,
        u.full_name,
        u.org_id,
        u.branch_id,
        u.org_structure_id,
        u.is_manager,
        u.work_context
      FROM dbo.vw_users_with_person_org_info u
      WHERE u.user_id = @userId
        AND u.is_active = 1
      ORDER BY u.assignment_created_at DESC
      `,
      { userId },
    );

    return row ? mapUserEntryContext(row) : undefined;
  }
}

export const userContextModule = new UserContextModule();
