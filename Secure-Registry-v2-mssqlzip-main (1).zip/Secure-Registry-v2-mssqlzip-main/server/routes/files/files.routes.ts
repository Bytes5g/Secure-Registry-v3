import { Router } from "express";
import { filesModule, foldersModule, withTransaction } from "@core/database";
import { insertFileSchema } from "@shared/schema";
import {
  buildPublicFileUrl,
  getLocalStorage,
} from "../../files/storage";
import { asyncHandler } from "../../utils/asyncHandler";
import {
  buildCreateFilePayload,
  buildUpdateFilePayload,
  ensureFolderExists,
  parseFolderFilter,
  parseId,
  parseOptionalNumber,
} from "./helpers";
import { requireWriteContext } from "../_internals";

const router = Router();
const localStorage = getLocalStorage();

router.get(
  "/",
  asyncHandler(async (req, res) => {
    const folder = parseOptionalNumber(req.query.folder);
    const uploadedBy = parseOptionalNumber(req.query.uploadedBy);
    const limit = parseOptionalNumber(req.query.limit);
    const search = typeof req.query.search === "string" ? req.query.search : undefined;

    const files = await filesModule.getFiles({
      folder: typeof folder === "number" ? folder : undefined,
      uploadedBy: typeof uploadedBy === "number" ? uploadedBy : undefined,
      limit: typeof limit === "number" ? limit : undefined,
      search,
    });
    res.json({ data: files });
  }),
);

router.get(
  "/browse",
  asyncHandler(async (req, res) => {
    const folderFilter = parseFolderFilter(req.query.folder);
    const folder = folderFilter === undefined ? null : folderFilter;
    const limit = parseOptionalNumber(req.query.limit);
    const search = typeof req.query.search === "string" ? req.query.search : undefined;

    await ensureFolderExists(folder);

    const breadcrumbs = folder != null ? await foldersModule.getFolderBreadcrumbs(folder) : [];
    const folders = await foldersModule.getFolders({
      parent: folder,
      limit: typeof limit === "number" ? limit : undefined,
      search,
    });
    const files = await filesModule.getFiles({
      folder,
      limit: typeof limit === "number" ? limit : undefined,
      search,
    });

    res.json({ data: { folder, breadcrumbs, folders, files } });
  }),
);

router.get(
  "/:id",
  asyncHandler(async (req, res) => {
    const id = parseId(req.params.id);
    if (!id) return res.status(400).json({ error: "Invalid id" });
    const file = await filesModule.getFile(id);
    if (!file) return res.status(404).json({ error: "Not found" });
    res.json(file);
  }),
);

router.get(
  "/:id/download",
  asyncHandler(async (req, res) => {
    const id = parseId(req.params.id);
    if (!id) return res.status(400).json({ error: "Invalid id" });
    const file = await filesModule.getFile(id);
    if (!file) return res.status(404).json({ error: "Not found" });
    if (file.storage !== "local" || !file.filenameDisk) {
      return res.status(400).json({ error: "File storage is not downloadable" });
    }
    res.redirect(buildPublicFileUrl(file.filenameDisk));
  }),
);

router.post(
  "/",
  // هذا المسار ينشئ ملف جديد ويحقن workContextBy و createdBy من session عبر requireWriteContext
  asyncHandler(async (req, res) => {
    const parsed = insertFileSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: "Invalid file payload", details: parsed.error });
    }
    await ensureFolderExists(parsed.data.folder ?? null);
    const ctx = await requireWriteContext(req as any);
    const created = await filesModule.createFile({
      ...(buildCreateFilePayload(parsed.data) as any),
      workContextBy: ctx.workContextBy,
      createdBy: ctx.userId,
      isActive: true,
      isDeleted: false,
    } as any);
    res.status(201).json(created);
  }),
);

router.put(
  "/:id",
  asyncHandler(async (req, res) => {
    const id = parseId(req.params.id);
    if (!id) return res.status(400).json({ error: "Invalid id" });
    const parsed = insertFileSchema.partial().safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: "Invalid file payload", details: parsed.error });
    }
    if (parsed.data.folder !== undefined) {
      await ensureFolderExists(parsed.data.folder);
    }
    const ctx = await requireWriteContext(req as any);
    const updated = await filesModule.updateFile(id, {
      ...(buildUpdateFilePayload(parsed.data) as any),
      updatedBy: ctx.userId,
      updatedAt: new Date(),
    } as any);
    if (!updated) return res.status(404).json({ error: "Not found" });
    res.json(updated);
  }),
);

router.delete(
  "/:id",
  asyncHandler(async (req, res) => {
    const id = parseId(req.params.id);
    if (!id) return res.status(400).json({ error: "Invalid id" });
    const file = await filesModule.getFile(id);
    if (!file) return res.status(404).json({ error: "Not found" });

    await withTransaction(async (tx) => {
      await filesModule.deleteFile(id, tx);
      if (file.storage === "local" && file.filenameDisk) {
        try {
          await localStorage.delete(file.filenameDisk);
        } catch {
          // Keep database deletion authoritative.
        }
      }
    });

    res.sendStatus(204);
  }),
);

export default router;
