import { useEffect, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { useWatch, type UseFormReturn } from "react-hook-form";
import type { LookupTypeWithValues } from "@shared/schema";

import type { UiPageFormField } from "@/types/ui";

type OptionItem = { label: string; value: string; parentValue: string | null };

type RemoteQueryInfo = {
  url: string;
  responseType: string;
  valueKey: string;
  labelKey: string;
  clientFilter: any;
  onSelectSet: any;
  isReady: boolean;
};

export function useDynamicFormFieldOptions(args: {
  field: UiPageFormField;
  form: UseFormReturn<any>;
  lookupTypes: LookupTypeWithValues[];
}): {
  options: OptionItem[];
  usePicker: boolean;
  clearOnChange: string[];
  remoteSelectDisabled: boolean;
  remoteQueryInfo: RemoteQueryInfo | null;
  remoteOptionsQuery: ReturnType<typeof useQuery<{ records: any[] }>>;
} {
  const { field, form, lookupTypes } = args;

  const remoteOptionsConfig = (field.config as any)?.remoteOptions ?? null;
  const clearOnChange: string[] = Array.isArray((field.config as any)?.clearOnChange) ? (field.config as any).clearOnChange : [];

  const watchedFields = useMemo(() => {
    const set = new Set<string>();
    for (const c of clearOnChange) set.add(String(c));
    const variants: any[] = Array.isArray(remoteOptionsConfig?.variants) ? remoteOptionsConfig.variants : [];
    for (const v of variants) {
      const whenField = v?.when?.field ? String(v.when.field) : null;
      if (whenField) set.add(whenField);
      const query = v?.query && typeof v.query === "object" ? v.query : null;
      if (query) {
        for (const val of Object.values(query)) {
          const m = typeof val === "string" ? val.match(/^\{(.+)\}$/) : null;
          if (m?.[1]) set.add(String(m[1]));
        }
      }
      const clientFilterField = v?.clientFilter?.field ? String(v.clientFilter.field) : null;
      if (clientFilterField) set.add(clientFilterField);
    }
    return Array.from(set);
  }, [clearOnChange, remoteOptionsConfig]);

  const watchedValues = useWatch({
    control: form.control,
    name: watchedFields as any,
  });

  const getWatchedValue = (name: string) => {
    const idx = watchedFields.indexOf(name);
    return idx >= 0 ? (Array.isArray(watchedValues) ? watchedValues[idx] : (watchedValues as any)) : undefined;
  };

  useEffect(() => {
    if (!import.meta.env.DEV) return;
    if (!remoteOptionsConfig) return;
    if (field.lookupTypeId != null) {
      console.warn(
        `DynamicFormField: field '${field.fieldCode}' has both lookupTypeId and remoteOptions; remoteOptions will take precedence.`
      );
    }
    if (Array.isArray(field.options) && field.options.length > 0) {
      console.warn(
        `DynamicFormField: field '${field.fieldCode}' has both static options and remoteOptions; remoteOptions will take precedence.`
      );
    }
  }, [remoteOptionsConfig, field.fieldCode, field.lookupTypeId, field.options]);

  const selectedVariant = useMemo(() => {
    const variants: any[] = Array.isArray(remoteOptionsConfig?.variants) ? remoteOptionsConfig.variants : [];
    const matchesWhen = (v: any): boolean => {
      const when = v?.when;
      if (!when) return false;
      const whenField = when?.field ? String(when.field) : "";
      const op = String(when?.op || "");
      const expected = when?.value;
      const value = whenField ? getWatchedValue(whenField) : undefined;
      const notEmpty = value != null && String(value).trim() !== "" && String(value) !== "null";
      if (op === "notEmpty") return notEmpty;
      if (op === "equals") return String(value ?? "") === String(expected ?? "");
      return false;
    };

    const conditional = variants.find((v) => matchesWhen(v));
    if (conditional) return conditional;
    const fallback = variants.find((v) => !v?.when);
    return fallback ?? null;
  }, [remoteOptionsConfig, watchedFields, watchedValues]);

  const remoteQueryInfo = useMemo<RemoteQueryInfo | null>(() => {
    const v = selectedVariant;
    if (!v || !v.path) return null;
    const pathTemplate = String(v.path);
    const responseType = String(v.response || "paged");
    const valueKey = String(v.valueKey || "id");
    const labelKey = String(v.labelKey || "name");
    const clientFilter = v.clientFilter && typeof v.clientFilter === "object" ? v.clientFilter : null;
    const onSelectSet = v.onSelectSet && typeof v.onSelectSet === "object" ? v.onSelectSet : null;
    const rawQuery = v.query && typeof v.query === "object" ? v.query : {};

    const query: Record<string, any> = {};
    for (const [k, val] of Object.entries(rawQuery)) {
      if (typeof val === "string") {
        const m = val.match(/^\{(.+)\}$/);
        if (m?.[1]) {
          const dep = getWatchedValue(String(m[1]));
          if (dep == null || String(dep).trim() === "" || String(dep) === "null") continue;
          query[k] = dep;
          continue;
        }
      }
      query[k] = val;
    }

    let missingPlaceholder = false;
    const path = pathTemplate.replace(/\{([^}]+)\}/g, (_: string, name: string) => {
      const v = getWatchedValue(String(name));
      if (v == null || String(v).trim() === "" || String(v) === "null") {
        missingPlaceholder = true;
        return "";
      }
      return encodeURIComponent(String(v));
    });

    const qs = new URLSearchParams();
    for (const [k, val] of Object.entries(query)) {
      if (val === undefined || val === null || val === "") continue;
      qs.set(k, String(val));
    }
    const url = qs.toString() ? `${path}?${qs.toString()}` : path;
    const isReady = Boolean(path) && !missingPlaceholder;
    return { url, responseType, valueKey, labelKey, clientFilter, onSelectSet, isReady };
  }, [selectedVariant, watchedFields, watchedValues]);

  const remoteOptionsQuery = useQuery({
    queryKey: ["dynamic-form", "remote-options", field.fieldCode, remoteQueryInfo?.url ?? ""],
    queryFn: async () => {
      if (!remoteQueryInfo?.url) return { records: [] as any[] };
      const res = await fetch(remoteQueryInfo.url);
      if (!res.ok) throw new Error("Failed to load options");
      const json = await res.json();
      const records =
        remoteQueryInfo.responseType === "array"
          ? Array.isArray(json)
            ? json
            : []
          : Array.isArray(json?.data)
            ? json.data
            : [];
      return { records };
    },
    enabled: Boolean(remoteQueryInfo?.url) && Boolean(remoteQueryInfo?.isReady),
    staleTime: 60_000,
  });

  const remoteOptions = useMemo(() => {
    const records = remoteOptionsQuery.data?.records ?? [];
    const v = remoteQueryInfo;
    if (!v) return [];
    let filtered = records;
    if (v.clientFilter?.field && v.clientFilter?.recordKey) {
      const current = getWatchedValue(String(v.clientFilter.field));
      if (current != null && String(current).trim() !== "" && String(current) !== "null") {
        filtered = records.filter((r: any) => String(r?.[v.clientFilter.recordKey] ?? "") === String(current));
      }
    }
    return filtered
      .map((r: any) => ({
        label: String(r?.[v.labelKey] ?? ""),
        value: String(r?.[v.valueKey] ?? ""),
        parentValue: null,
      }))
      .filter((o: OptionItem) => o.value && o.label);
  }, [remoteOptionsQuery.data, remoteQueryInfo, watchedFields, watchedValues]);

  const lookupType = lookupTypes.find((lt) => lt.id === field.lookupTypeId);
  const lookupOptions =
    lookupType?.values.map((val) => ({
      label: val.nameAr,
      value: String(val.id),
      parentValue: val.parentId == null ? null : String(val.parentId),
    })) ?? [];
  const staticOptions =
    field.options?.map((option) => ({
      label: option.label,
      value: String(option.value),
      parentValue: null,
    })) ?? [];

  const configTreeOptions =
    (field.config?.treeOptions as Array<{ value: string; label: string; parentValue?: string | null }> | undefined) ??
    undefined;

  const options: OptionItem[] =
    (configTreeOptions as any) ??
    (remoteOptionsConfig
      ? (remoteOptions as any)
      : field.options
        ? (staticOptions as any)
        : (lookupOptions as any));
  const hasHierarchy = options.some((option: OptionItem) => option.parentValue != null);
  const usePicker = hasHierarchy || options.length > 25;
  const remoteSelectDisabled = Boolean(remoteOptionsConfig) && (!remoteQueryInfo?.isReady || remoteOptionsQuery.isLoading);

  useEffect(() => {
    if (!remoteOptionsConfig) return;
    if (!remoteQueryInfo?.isReady) return;
    if (remoteOptionsQuery.isLoading) return;
    const current = form.getValues(field.fieldCode);
    if (current == null || String(current).trim() === "" || String(current) === "null") return;
    if (options.some((o) => String(o.value) === String(current))) return;
    form.setValue(field.fieldCode, "", { shouldDirty: true, shouldTouch: true, shouldValidate: true });
  }, [remoteOptionsConfig, remoteQueryInfo?.isReady, remoteOptionsQuery.isLoading, options, form, field.fieldCode]);

  return {
    options,
    usePicker,
    clearOnChange,
    remoteSelectDisabled,
    remoteQueryInfo,
    remoteOptionsQuery: remoteOptionsQuery as any,
  };
}

