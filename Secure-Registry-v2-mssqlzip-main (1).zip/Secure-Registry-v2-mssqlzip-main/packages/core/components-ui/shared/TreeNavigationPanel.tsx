import type { ReactNode } from "react"
import type { TreeNode } from "../trees/TreeNavigation"
import { TreeNavigation } from "../trees/TreeNavigation"
import { Card, CardContent, CardHeader, CardTitle } from "../ui/card"
import { cn } from "../lib/utils"

interface TreeNavigationPanelProps {
  title: string
  icon?: ReactNode
  rootNodes: TreeNode[]
  selectedNodeId?: number | null
  onSelectNode: (node: TreeNode | null) => void
  loadChildren: (parentId: number, parentNode?: TreeNode) => Promise<TreeNode[]>
  rootLabel?: string
  className?: string
  headerClassName?: string
  contentClassName?: string
  treeClassName?: string
}

export function TreeNavigationPanel({
  title,
  icon,
  rootNodes,
  selectedNodeId = null,
  onSelectNode,
  loadChildren,
  rootLabel,
  className,
  headerClassName,
  contentClassName,
  treeClassName,
}: TreeNavigationPanelProps) {
  return (
    <Card className={className}>
      <CardHeader className={cn("py-3", headerClassName)}>
        <CardTitle className="text-base flex items-center gap-2">
          {icon}
          {title}
        </CardTitle>
      </CardHeader>
      <CardContent className={cn("p-2", contentClassName)}>
        <TreeNavigation
          rootNodes={rootNodes}
          selectedNodeId={selectedNodeId}
          onSelectNode={onSelectNode}
          loadChildren={loadChildren}
          rootLabel={rootLabel}
          className={treeClassName}
        />
      </CardContent>
    </Card>
  )
}

