import { Router, type Request } from "express";
import { storage } from "../../storage";
import { insertLookupTypeAliasSchema } from "@shared/schema";
import { getErrorMessage, normalizeLookupAliasBody } from "./helpers";
import { requireWriteContext } from "../_internals";

const router = Router();

router.get("/types/:typeId/aliases", async (req, res) => {
  try {
    const typeId = parseInt(req.params.typeId);
    const aliases = await storage.getLookupTypeAliasesByTypeId(typeId);
    res.json(aliases);
  } catch (error) {
    console.error("Error fetching lookup type aliases:", error);
    res.status(500).json({ error: getErrorMessage(error, "Failed to fetch lookup type aliases") });
  }
});

router.get("/aliases/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const alias = await storage.getLookupTypeAlias(id);
    if (!alias) return res.status(404).json({ error: "Lookup type alias not found" });
    res.json(alias);
  } catch (error) {
    console.error("Error fetching lookup type alias:", error);
    res.status(500).json({ error: getErrorMessage(error, "Failed to fetch lookup type alias") });
  }
});

router.post("/types/:typeId/aliases", async (req, res) => {
  try {
    const typeId = parseInt(req.params.typeId);
    const parsed = insertLookupTypeAliasSchema.safeParse(
      normalizeLookupAliasBody(req.body ?? {}, typeId),
    );
    if (!parsed.success) {
      return res
        .status(400)
        .json({ error: "Invalid lookup type alias data", details: parsed.error });
    }
    const ctx = await requireWriteContext(req as any);
    const alias = await storage.createLookupTypeAlias({
      ...(parsed.data as any),
      workContextBy: ctx.workContextBy,
      updatedBy: ctx.userId,
    } as any);
    res.status(201).json(alias);
  } catch (error) {
    console.error("Error creating lookup type alias:", error);
    res.status(500).json({ error: getErrorMessage(error, "Failed to create lookup type alias") });
  }
});

router.patch("/aliases/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const parsed = insertLookupTypeAliasSchema
      .partial()
      .safeParse(normalizeLookupAliasBody(req.body ?? {}));
    if (!parsed.success) {
      return res
        .status(400)
        .json({ error: "Invalid lookup type alias data", details: parsed.error });
    }
    const ctx = await requireWriteContext(req as any);
    const alias = await storage.updateLookupTypeAlias(id, {
      ...(parsed.data as any),
      workContextBy: (parsed.data as any).workContextBy ?? ctx.workContextBy,
      updatedBy: ctx.userId,
    } as any);
    if (!alias) return res.status(404).json({ error: "Lookup type alias not found" });
    res.json(alias);
  } catch (error) {
    console.error("Error updating lookup type alias:", error);
    res.status(500).json({ error: getErrorMessage(error, "Failed to update lookup type alias") });
  }
});

router.delete("/aliases/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const ctx = await requireWriteContext(req as any);
    const success = await storage.deleteLookupTypeAlias(id, {
      workContextBy: ctx.workContextBy,
      updatedBy: ctx.userId,
    } as any);
    if (!success) return res.status(404).json({ error: "Lookup type alias not found" });
    res.status(204).send();
  } catch (error) {
    console.error("Error deleting lookup type alias:", error);
    res.status(500).json({ error: getErrorMessage(error, "Failed to delete lookup type alias") });
  }
});

export default router;
