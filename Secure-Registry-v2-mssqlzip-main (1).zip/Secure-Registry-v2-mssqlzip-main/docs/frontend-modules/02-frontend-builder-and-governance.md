# تصور تطوير الواجهة الأمامية ومحرك البناء الديناميكي

## 1) الهدف

تحويل الواجهة من صفحات شبه ثابتة إلى واجهة مدفوعة بالتهيئة، بحيث يمكن إدارة:

- الشاشات
- الأعمدة
- الحقول
- التبويبات
- الإجراءات
- القوائم
- القواعد السلوكية

من قاعدة البيانات وواجهة الإدارة.

> مرجع معياري مختصر للقوالب + runtime + mapping_json:  
> [04-ui-templates-and-runtime-contract.md](./04-ui-templates-and-runtime-contract.md)

## 2) ما الذي يساعدنا حالياً

في المشروع الحالي توجد نقاط بداية جيدة:

- `GenericEntityPage`
- `DynamicForm`
- `UiPageConfig`
- lookup-driven fields
- تبويبات ملف الجهة
- Dictionary-first: `dbo.v_schema_dictionary_columns` (خصوصاً `formatted_table_name` و`formatted_name` و`object_description` و`column_description`) كمرجع لتوليد أسماء العرض وعلاقات الحقول

## 2.1) معيار ui_column_type (قاموس واجهات)

مصدر الحقيقة الأول لأنواع العرض هو `dbo.v_schema_dictionary_columns.ui_column_type`، وليس الاستنتاج من `data_type`.

### القيم الحالية (secure_registry_v4)

- `text` → Column: `text` / Field: `text` (وقد يتحول إلى `textarea` إذا كان الطول كبيراً)
- `number` → Column: `number` / Field: `number`
- `boolean` → Column: `boolean` / Field: `boolean`
- `date` → Column: `date` / Field: `text` (حالياً `DynamicForm` لا يملك input type=date، لذلك نعرضه كنص ويمكن تطويره لاحقاً)

### مبدأ التوسعة

أي قيمة جديدة مثل `select`/`lookup` تُضاف للقاموس لاحقاً يجب أن تُترجم إلى:
- Column: `select`
- Field: `select`
مع ربط `lookupTypeId` عبر Registry (لا يتم توليدها تلقائياً بدون قرار أعمال).

### قاعدة توليد إضافية (FK → Select)

إذا كان العمود Foreign Key ويشير إلى جدول له تعريف في `dbo.lookup_types` (schema_name + table_name)، فيتم توليد الحقل كـ `select` تلقائياً مع `lookupTypeId` الموافق. هذا يقلل التهيئة اليدوية بشكل كبير.

وهذا يعني أن المشروع لا يحتاج إعادة اختراع كاملة، بل يحتاج Registry وتوحيداً أشمل.

## 3) ما الذي ينقص لبناء Frontend Builder حقيقي

1. Registry للشاشات والوحدات.
2. Registry للعناصر داخل الشاشة:
   - الحقول
   - الأعمدة
   - الأزرار
   - التبويبات
   - المرشحات
3. ربط كل عنصر بمفتاح مورد وصلاحية.
4. دعم القواعد الديناميكية:
   - visible
   - disabled
   - readOnly
   - required
   - masked
   - defaultValue
5. دعم versioning للتهيئات.

## 4) نموذج البناء المقترح

### أ. طبقة تعريف الموارد

تحدد:

- module_code
- screen_code
- element_code
- action_key
- data_resource_key

### ب. طبقة تعريف العرض

تحدد:

- layout type
- tabs
- sections
- cards
- tables
- forms
- filters
- detail panels

### ج. طبقة السلوك

تحدد:

- متى يظهر العنصر
- متى يُعطّل
- متى يصبح إلزامياً
- متى تتغير قائمة الخيارات
- متى يتم إخفاء القيم الحساسة

## 5) ربط الـ Builder بالصلاحيات

يجب أن يكون لكل عنصر قابل للتحكم:

- resource key
- action key
- scope key
- optional condition set

وبذلك يمكن لمدير النظام تغيير صلاحية شاشة أو حقل أو زر دون تعديل كود.

## 6) ربط الـ Builder بالفروع والجهات

ينبغي أن تسمح التهيئة بما يلي:

- شاشة مفعلة للجهة المالكة فقط
- شاشة مفعلة لكل الجهات لكن بوظائف مختلفة
- تبويب ظاهر لفروع معينة فقط
- نموذج يستخدم حقولاً إضافية أو مخفية حسب نوع الوحدة أو الجهة أو الفرع

## 6.1) مبادئ تطبيقية مثبتة حالياً (Org Profile)

هذه مبادئ تشغيلية تم تثبيتها في التطبيق الحالي ويجب أن يستوعبها أي Builder/Registry لاحقاً:

1. مصدر “الصفة” (Role Title) في شاشات الهيكل/الكادر يجب أن يكون مبنياً على `dbo.vw_org_structure_roles` (مباشرة أو عبر Views مبنية عليها مثل `vw_org_entity_structure_branch_nodes` و`vw_org_employees`).
2. عند عرض امتدادات الفرع (branch scope)، اختيار “مدير الوحدة” يجب أن يكون مقيداً بـ `branch_id` لتجنب سحب صفة من فرع آخر لنفس الوحدة.
3. عرض الهيكل يجب أن يكون Canvas واحد مع نطاق عرض (Scope): `org` / `branch` / `unit` مع ميزات قابلة للتفعيل حسب النطاق (إبراز امتدادات الفرع، عرض فروع الوحدة، عرض الكادر، التركيز...).

## 6.2) مبادئ تطبيقية مثبتة حالياً (Person Profile + Persons Search)

هذه أمثلة إضافية مثبتة في التطبيق الحالي ويجب أن يستوعبها أي Builder/Registry لاحقاً:

1. بروفايل الشخص يتبع نفس نمط Shell + Tabs (Header + Tabs) مع فصل واضح بين:
   - البيانات الأساسية (جدول persons)
   - العلاقات: `contacts_registry`, `person_assignments`, `entity_files`
2. البحث عن الأشخاص يجب أن يكون قابلاً للتوسع (ملايين السجلات) عبر:
   - endpoint بحث مخصص يدعم `LIKE` + paging عبر cursor (keyset)
   - نموذج بحث قابل للتهيئة من الواجهة (formFields) عبر `UiPageConfig`
3. يتم تقليل hardcoding تدريجياً لصالح config:
   - نموذج بحث الأشخاص مثال أولي لاستهلاك config من API وتخصيصه عبر overrides.

## 7) قواعد الحوكمة المقترحة

1. لا تُنشر أي تهيئة مباشرة دون نسخة Draft ونسخة Published.
2. أي تغيير على شاشة سيادية أو lookup سيادي يحتاج صلاحية أعلى أو موافقة.
3. يجب حفظ سجل تغييرات لكل تهيئة منشورة.
4. يجب دعم Rollback عند الحاجة.

## 8) النتيجة المستهدفة

واجهة يمكن أن تُدار تشغيلياً من الإدارة، وتستجيب لـ:

- نوع المستخدم
- الجهة المالكة
- فرعه
- وحدته
- دوره
- سياسات الحوكمة
- حالة السجل

وذلك مع تقليل الحاجة إلى بناء صفحات جديدة لكل اختلاف تشغيلي.
