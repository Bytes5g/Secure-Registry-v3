import type { ReactNode } from "react";
import { EntityContentCard } from "@secure-registry/components-ui";

interface MasterDetailBrowserProps {
  master?: ReactNode;
  detail: ReactNode;
  masterWidthClass?: string;
  containerClassName?: string;
  cardClassName?: string;
  cardContentClassName?: string;
}

export function MasterDetailBrowser({
  master,
  detail,
  masterWidthClass = "w-1/4 min-w-[300px]",
  containerClassName = "flex h-[calc(100vh-8rem)] gap-4",
  cardClassName = "flex h-full flex-col overflow-hidden bg-card shadow-sm",
  cardContentClassName = "flex-1 overflow-auto p-4",
}: MasterDetailBrowserProps) {
  return (
    <div className={containerClassName}>
      {master ? <div className={masterWidthClass}>{master}</div> : null}
      <div className="flex-1">
        <EntityContentCard className={cardClassName} contentClassName={cardContentClassName}>
          {detail}
        </EntityContentCard>
      </div>
    </div>
  );
}
