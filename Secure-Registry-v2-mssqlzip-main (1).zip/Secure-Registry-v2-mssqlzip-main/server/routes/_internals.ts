import type { Request } from "express";
import { userContextModule } from "@core/database";
import { ApiError } from "../utils/response";

// هذه الدالة توحّد تمثيل القيم الفارغة إلى null لتسهيل التحقق (validation) وتفادي إرسال "" إلى قاعدة البيانات
export function normalizeNulls<T extends Record<string, any>>(obj: T, fields: string[]): T {
  const out: Record<string, any> = { ...obj };
  for (const f of fields) {
    if (out[f] === "" || out[f] === undefined) out[f] = null;
    if (out[f] === "null") out[f] = null;
  }
  return out as T;
}

// هذه الدالة تقوم بتحويل الحقول الرقمية/المنطقية القادمة كنصوص من الواجهة إلى الأنواع الصحيحة قبل تمريرها إلى Zod
export function normalizeInputTypes<T extends Record<string, any>>(
  obj: T,
  options: { intFields?: string[]; boolFields?: string[] },
): T {
  const out: Record<string, any> = { ...obj };

  for (const f of options.intFields ?? []) {
    const v = out[f];
    if (v === null || v === undefined || v === "") continue;
    if (typeof v === "number") continue;
    const parsed = parseInt(String(v), 10);
    if (Number.isFinite(parsed)) out[f] = parsed;
  }

  for (const f of options.boolFields ?? []) {
    const v = out[f];
    if (v === null || v === undefined || v === "") continue;
    if (typeof v === "boolean") continue;
    const text = String(v).trim().toLowerCase();
    if (text === "true" || text === "1") out[f] = true;
    if (text === "false" || text === "0") out[f] = false;
  }

  return out as T;
}

// هذه الدالة تستخرج سياق المستخدم (work_context) وهو مصدر الحقيقة لحقول التدقيق في عمليات الكتابة
export async function getWriteContext(req: Request): Promise<{
  userId: number | null;
  workContextBy: number | null;
}> {
  // @ts-ignore
  const userIdRaw = req.session?.user?.id;
  const parsedUserId = userIdRaw == null ? NaN : Number(userIdRaw);
  if (!Number.isFinite(parsedUserId)) {
    return { userId: null, workContextBy: null };
  }

  const userId = parsedUserId;
  const ctx = await userContextModule.getUserEntryContext(userId);
  return {
    userId,
    workContextBy: ctx?.workContext ?? null,
  };
}

// هذه الدالة تفرض توفر سياق المستخدم (work_context_by + userId) وتعيده للاستخدام في جميع عمليات الإدراج/التعديل.
export async function requireWriteContext(req: Request): Promise<{
  userId: number;
  workContextBy: number;
}> {
  const ctx = await getWriteContext(req);
  if (!Number.isFinite(ctx.userId as number)) {
    throw ApiError.badRequest("معرف المستخدم غير صالح");
  }
  if (!Number.isFinite(ctx.workContextBy as number)) {
    throw ApiError.badRequest("work_context_by غير متوفر لسياق المستخدم");
  }

  return {
    userId: ctx.userId as number,
    workContextBy: ctx.workContextBy as number,
  };
}

// هذه الدالة تُرجع معرّف المستخدم من session إن توفر وبصيغة رقمية صحيحة
export function getSessionUserId(req: Request): number | null {
  // @ts-ignore
  const userIdRaw = req.session?.user?.id;
  const parsed = userIdRaw == null ? NaN : Number(userIdRaw);
  return Number.isFinite(parsed) ? parsed : null;
}

// هذه الدالة تقوم بحقن work_context_by وحقول التدقيق داخل body حسب الأعمدة المتاحة في الجدول
export async function applyWriteContextToBody(
  req: Request,
  body: Record<string, unknown>,
  columnMap: Pick<Map<string, unknown>, "has">,
  mode: "insert" | "update",
): Promise<void> {
  const sessionUserId = getSessionUserId(req);
  if (sessionUserId == null) return;

  const context = await userContextModule.getUserEntryContext(sessionUserId);
  if (context) {
    if (columnMap.has("workContextBy") && (body as any).workContextBy == null) (body as any).workContextBy = context.workContext;
  }

  if (mode === "insert") {
    if (columnMap.has("createdBy") && body.createdBy == null) body.createdBy = sessionUserId;
    if (columnMap.has("updatedBy") && body.updatedBy == null) body.updatedBy = sessionUserId;
    return;
  }

  if (columnMap.has("updatedBy")) body.updatedBy = sessionUserId;
  if (columnMap.has("updatedAt")) body.updatedAt = new Date();
}
