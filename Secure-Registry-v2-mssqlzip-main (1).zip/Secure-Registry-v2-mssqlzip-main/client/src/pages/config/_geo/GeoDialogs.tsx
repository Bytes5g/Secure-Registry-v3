import type { GeoAdminUnit } from "@shared/schema";
import { EntityDeleteDialog } from "@/components/shared";
import { CrudDialog } from "@/components/data-explorer";
import type { UiPageFormField } from "@/types/ui";
import type { DialogState } from "./types";
import type { MapProvider } from "@shared/schema";
import { MapCanvas } from "@secure-registry/components-ui";
import { useMemo } from "react";

interface GeoDialogsProps {
  countryName: string;
  dialogState: DialogState;
  onDialogOpenChange: (open: boolean) => void;
  fields: UiPageFormField[];
  initialData: Record<string, unknown>;
  mapProviders: MapProvider[];
  onSubmit: (values: Record<string, unknown>) => void;
  isSubmitting: boolean;
  deleteTarget: GeoAdminUnit | null;
  onDeleteOpenChange: (open: boolean) => void;
  onConfirmDelete: () => void;
  isDeleting: boolean;
}

export function GeoDialogs({
  countryName,
  dialogState,
  onDialogOpenChange,
  fields,
  initialData,
  mapProviders,
  onSubmit,
  isSubmitting,
  deleteTarget,
  onDeleteOpenChange,
  onConfirmDelete,
  isDeleting,
}: GeoDialogsProps) {
  const geoJson = useMemo(() => {
    const raw = dialogState.unit?.geometryJson;
    if (!raw) return null;
    try {
      return JSON.parse(raw);
    } catch {
      return null;
    }
  }, [dialogState.unit]);

  const tileProviders = useMemo(() => {
    return (mapProviders ?? []).map((p) => ({
      id: p.id,
      name: p.providerName,
      tileUrl: p.tileUrl,
      isOverlay: p.isOverlay,
      orderIndex: p.orderIndex,
    }));
  }, [mapProviders]);

  const labelPoints = useMemo(() => {
    const unit = dialogState.unit;
    if (!unit) return [];
    const lat = unit.latitude;
    const lon = unit.longitude;
    if (lat == null || lon == null) return [];
    if (!Number.isFinite(lat) || !Number.isFinite(lon)) return [];
    return [{ id: unit.id, lat, lon, label: unit.name }];
  }, [dialogState.unit]);

  const showMap = dialogState.mode !== "create" && tileProviders.length > 0;

  return (
    <>
      <CrudDialog
        open={dialogState.open}
        mode={dialogState.mode}
        onOpenChange={onDialogOpenChange}
        titles={{
          create: "إضافة وحدة جغرافية",
          edit: "تعديل الوحدة الجغرافية",
          view: "عرض بيانات الوحدة",
        }}
        descriptions={{
          create: `سيتم حفظ الوحدة داخل دولة ${countryName}.`,
          edit: `سيتم حفظ الوحدة داخل دولة ${countryName}.`,
          view: "هذه البطاقة تعرض نفس بيانات الفورم ولكن بوضع القراءة فقط.",
        }}
        fields={fields}
        initialData={initialData}
        onSubmit={onSubmit}
        isSubmitting={isSubmitting}
        extraContent={
          showMap ? (
            <div className="pt-4">
              <MapCanvas providers={tileProviders} geoJson={geoJson} labelPoints={labelPoints} />
            </div>
          ) : null
        }
      />

      <EntityDeleteDialog
        open={!!deleteTarget}
        onOpenChange={onDeleteOpenChange}
        title="حذف الوحدة الجغرافية"
        description={deleteTarget ? `سيتم حذف "${deleteTarget.name}" نهائياً.` : ""}
        onConfirm={onConfirmDelete}
        isSubmitting={isDeleting}
      />
    </>
  );
}
