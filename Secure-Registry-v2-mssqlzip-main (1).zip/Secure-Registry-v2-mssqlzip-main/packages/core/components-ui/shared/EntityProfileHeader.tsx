import type { ReactNode } from "react"
import { cn } from "../lib/utils"
import { Avatar, AvatarFallback, AvatarImage } from "../ui/avatar"
import { Badge } from "../ui/badge"
import { Card, CardContent } from "../ui/card"
import { useMediaPreviewDialog } from "./MediaPreviewDialog"

export interface EntityProfileMetaItem {
  label: string
  value?: ReactNode
}

interface EntityProfileHeaderProps {
  title: ReactNode
  subtitle?: ReactNode
  status?: { label: string; variant?: "default" | "secondary" | "destructive" | "outline" }
  meta?: EntityProfileMetaItem[]
  actions?: ReactNode
  icon?: ReactNode
  coverImageUrl?: string | null
  avatarImageUrl?: string | null
  avatarFallback?: ReactNode
  showCoverPlaceholder?: boolean
  enableMediaPreview?: boolean
  coverHeightClassName?: string
  avatarClassName?: string
  avatarOverlapClassName?: string
  className?: string
}

// هذا المكوّن وظيفته عرض هيدر بروفايل عام مع دعم معاينة الصورة/الغلاف داخل Dialog
// هذه الدالة وظيفتها عرض هيدر بروفايل عام مع مؤثرات غلاف احترافية ومعاينة الصور داخل Dialog
export function EntityProfileHeader({
  title,
  subtitle,
  status,
  meta = [],
  actions,
  icon,
  coverImageUrl,
  avatarImageUrl,
  avatarFallback,
  showCoverPlaceholder,
  enableMediaPreview = true,
  coverHeightClassName = "h-36 sm:h-44 md:h-52",
  avatarClassName = "h-20 w-20 sm:h-24 sm:w-24",
  avatarOverlapClassName = "-mt-10 sm:-mt-12",
  className,
}: EntityProfileHeaderProps) {
  const preview = useMediaPreviewDialog()

  return (
    <Card className={className}>
      {coverImageUrl || showCoverPlaceholder ? (
        <div className={cn("relative w-full overflow-hidden rounded-t-xl", coverHeightClassName)}>
          {coverImageUrl ? (
            <button
              type="button"
              className="absolute inset-0 block h-full w-full"
              onClick={() => {
                if (!enableMediaPreview) return
                preview.open({ url: coverImageUrl, title: "الغلاف", kind: "image" })
              }}
            >
              <img src={coverImageUrl} alt="" className="h-full w-full object-cover" />
            </button>
          ) : avatarImageUrl ? (
            <div className="absolute inset-0">
              <img
                src={avatarImageUrl}
                alt=""
                className="h-full w-full object-cover blur-md scale-100 opacity-90  "
              />
            </div>
          ) : (
            <div className="absolute inset-0 bg-muted" />
          )}

          <div className="absolute inset-0 bg-gradient-to-b from-black/5 via-black/15 to-black/35" />
          <div className="relative h-full w-full" />
        </div>
      ) : null}

      <CardContent className={cn("p-6", coverImageUrl || showCoverPlaceholder ? "" : "")}>
        {avatarImageUrl || avatarFallback ? (
          <div className={cn("flex", avatarOverlapClassName)}>
            <button
              type="button"
              className={cn(avatarImageUrl && enableMediaPreview ? "cursor-zoom-in" : "")}
              onClick={() => {
                if (!avatarImageUrl) return
                if (!enableMediaPreview) return
                preview.open({ url: avatarImageUrl, title: "الصورة", kind: "image" })
              }}
            >
              <Avatar className={cn("ring-4 ring-background", avatarClassName)}>
                {avatarImageUrl ? <AvatarImage src={avatarImageUrl} alt="" /> : null}
                {avatarFallback ? <AvatarFallback>{avatarFallback}</AvatarFallback> : <AvatarFallback />}
              </Avatar>
            </button>
          </div>
        ) : null}

        <div className={cn("flex flex-col gap-4", avatarImageUrl || avatarFallback ? "pt-3" : "", "lg:flex-row lg:items-start lg:justify-between")}>
          <div className="flex items-start gap-3">
            {icon ? (
              <div className="mt-0.5 flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 text-primary">
                {icon}
              </div>
            ) : null}
            <div className="space-y-1">
              <div className="flex flex-wrap items-center gap-2">
                <h1 className="text-2xl font-bold leading-tight">{title}</h1>
                {status ? <Badge variant={status.variant || "secondary"}>{status.label}</Badge> : null}
              </div>
              {subtitle ? <div className="text-sm text-muted-foreground">{subtitle}</div> : null}
              {meta.length ? (
                <div className="mt-3 grid grid-cols-1 gap-2 sm:grid-cols-2">
                  {meta.map((m, idx) => (
                    <div key={idx} className="flex items-center gap-2 text-sm">
                      <span className="text-muted-foreground">{m.label}</span>
                      <span className={cn("font-medium", m.value ? "" : "text-muted-foreground")}>{m.value ?? "—"}</span>
                    </div>
                  ))}
                </div>
              ) : null}
            </div>
          </div>

          {actions ? <div className="flex flex-wrap gap-2 justify-start lg:justify-end">{actions}</div> : null}
        </div>
      </CardContent>

      {preview.dialog}
    </Card>
  )
}
