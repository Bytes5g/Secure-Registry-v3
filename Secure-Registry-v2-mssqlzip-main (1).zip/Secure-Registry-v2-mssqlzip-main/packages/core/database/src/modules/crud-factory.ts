import { createRequest, type SqlExecutor } from "../config/connection";
import { normalizeForDb, quoteIdentifier } from "./helpers";

export type CrudColumnInfo = {
  propKey: string;
  dbKey: string;
  isIdentity?: boolean;
  hasDefault?: boolean;
};

export type CrudTableInfo = {
  schemaName: string;
  tableName: string;
  columns: CrudColumnInfo[];
  columnMap: Map<string, CrudColumnInfo>;
};

export type PickedColumn = CrudColumnInfo & { value: unknown };

export function buildWhereFromQuery(queryParams: Record<string, any>, columnMap: Map<string, CrudColumnInfo>) {
  const clauses: string[] = [];
  const params: Record<string, unknown> = {};
  let index = 0;

  for (const [key, value] of Object.entries(queryParams)) {
    if (["page", "limit", "sort", "order"].includes(key) || value === undefined) continue;
    const column = columnMap.get(key);
    if (!column) continue;

    const paramName = `filter_${index++}`;
    clauses.push(`${quoteIdentifier(column.dbKey)} = @${paramName}`);
    params[paramName] = value;
  }

  return {
    whereClause: clauses.length > 0 ? ` WHERE ${clauses.join(" AND ")}` : "",
    params,
  };
}

export function resolveIdCondition(paramId: string, columnMap: Map<string, CrudColumnInfo>) {
  const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
  const uuidColumn = columnMap.get("uuid");
  const idColumn = columnMap.get("id");

  if (uuidRegex.test(paramId)) {
    if (!uuidColumn) {
      throw new Error("Invalid ID format (UUID not supported for this table)");
    }
    return {
      clause: `${quoteIdentifier(uuidColumn.dbKey)} = @lookupId`,
      params: { lookupId: paramId },
    };
  }

  const id = parseInt(paramId, 10);
  if (Number.isNaN(id)) throw new Error("Invalid ID format");
  if (!idColumn) throw new Error("Table does not have an ID column");

  return {
    clause: `${quoteIdentifier(idColumn.dbKey)} = @lookupId`,
    params: { lookupId: id },
  };
}

export function pickBodyColumns(
  body: Record<string, unknown>,
  columnMap: Map<string, CrudColumnInfo>,
  excludeKeys: string[] = [],
): PickedColumn[] {
  const excluded = new Set(excludeKeys);
  return Object.entries(body)
    .filter(([key, value]) => !excluded.has(key) && value !== undefined && columnMap.has(key))
    .map(([key, value]) => ({
      ...(columnMap.get(key) as CrudColumnInfo),
      value: normalizeForDb(value),
    }))
    .filter((column) => !column.isIdentity);
}

function fullTableName(tableInfo: CrudTableInfo): string {
  return `${quoteIdentifier(tableInfo.schemaName)}.${quoteIdentifier(tableInfo.tableName)}`;
}

function selectList(columns: CrudColumnInfo[]): string {
  return columns.map((c) => `${quoteIdentifier(c.dbKey)} AS ${quoteIdentifier(c.propKey)}`).join(", ");
}

function deletedSelectList(columns: CrudColumnInfo[]): string {
  return columns.map((c) => `DELETED.${quoteIdentifier(c.dbKey)} AS ${quoteIdentifier(c.propKey)}`).join(", ");
}

type InsertPlan = {
  sql: string;
  extraInputs: Array<{ name: string; value: unknown }>;
};

export function buildInsertPlan(args: {
  tableInfo: CrudTableInfo;
  values: PickedColumn[];
  body: Record<string, unknown>;
}): InsertPlan {
  const { tableInfo, values, body } = args;
  const { columns, columnMap } = tableInfo;
  const idColumn = columnMap.get("id");
  const uuidColumn = columnMap.get("uuid");
  const createdAtColumn = columnMap.get("createdAt");
  const idDbKey = idColumn ? quoteIdentifier(idColumn.dbKey) : null;
  const uuidDbKey = uuidColumn ? quoteIdentifier(uuidColumn.dbKey) : null;
  const createdAtDbKey = createdAtColumn ? quoteIdentifier(createdAtColumn.dbKey) : null;
  const tableName = fullTableName(tableInfo);
  const selectClause = `SELECT TOP 1 ${selectList(columns)} FROM ${tableName}`;

  const hasCreatedAtValue = values.some((c) => c.dbKey === createdAtColumn?.dbKey);
  const insertDbKeys = values.map((c) => quoteIdentifier(c.dbKey));
  const insertTokens = values.map((_, i) => `@value_${i}`);
  if (createdAtDbKey && !hasCreatedAtValue && !createdAtColumn?.hasDefault) {
    insertDbKeys.push(createdAtDbKey);
    insertTokens.push("SYSUTCDATETIME()");
  }
  const insertColumns = insertDbKeys.join(", ");
  const insertValues = insertTokens.join(", ");

  const extraInputs: Array<{ name: string; value: unknown }> = [];

  if (idColumn?.isIdentity && idDbKey) {
    return {
      sql: `DECLARE @__sr_id bigint;
            INSERT INTO ${tableName} (${insertColumns}) VALUES (${insertValues});
            SET @__sr_id = CONVERT(bigint, SCOPE_IDENTITY());
            ${selectClause} WHERE ${idDbKey} = @__sr_id;`,
      extraInputs,
    };
  }

  if (idDbKey && idColumn && !idColumn.isIdentity && !idColumn.hasDefault && body.id == null) {
    return {
      sql: `DECLARE @__sr_id bigint;
            SELECT @__sr_id = ISNULL(MAX(${idDbKey}), 0) + 1
            FROM ${tableName} WITH (UPDLOCK, HOLDLOCK);
            INSERT INTO ${tableName} (${idDbKey}${insertColumns ? `, ${insertColumns}` : ""})
            VALUES (@__sr_id${insertValues ? `, ${insertValues}` : ""});
            ${selectClause} WHERE ${idDbKey} = @__sr_id;`,
      extraInputs,
    };
  }

  if (uuidDbKey && typeof body.uuid === "string" && body.uuid) {
    extraInputs.push({ name: "__sr_uuid", value: body.uuid });
    return {
      sql: `INSERT INTO ${tableName} (${insertColumns}) VALUES (${insertValues});
            ${selectClause} WHERE ${uuidDbKey} = @__sr_uuid;`,
      extraInputs,
    };
  }

  if (idDbKey && body.id != null) {
    extraInputs.push({ name: "__sr_id", value: body.id });
    return {
      sql: `INSERT INTO ${tableName} (${insertColumns}) VALUES (${insertValues});
            ${selectClause} WHERE ${idDbKey} = @__sr_id;`,
      extraInputs,
    };
  }

  const filterCandidates = ["orgId", "code", "name"]
    .map((key) => columnMap.get(key))
    .filter((entry): entry is CrudColumnInfo => Boolean(entry))
    .map((entry) => entry.dbKey);

  const filterDbKeys = Array.from(new Set([...filterCandidates, ...values.map((c) => c.dbKey)]));
  const filters: Array<{ dbKey: string; value: unknown; param: string }> = [];
  for (const dbKey of filterDbKeys) {
    if (filters.length >= 3) break;
    if (dbKey.toLowerCase() === "metadata") continue;
    const match = values.find((c) => c.dbKey === dbKey);
    if (!match) continue;
    const value = match.value;
    if (value == null) continue;
    if (typeof value !== "string" && typeof value !== "number" && typeof value !== "boolean") continue;
    if (typeof value === "string" && value.length > 2000) continue;
    const param = `__sr_f_${filters.length}`;
    filters.push({ dbKey, value, param });
    extraInputs.push({ name: param, value });
  }

  const fallbackWhere =
    filters.length > 0
      ? `WHERE ${filters.map((f) => `${quoteIdentifier(f.dbKey)} = @${f.param}`).join(" AND ")}`
      : "";
  const fallbackOrderBy = idDbKey
    ? `ORDER BY ${idDbKey} DESC`
    : createdAtDbKey
      ? `ORDER BY ${createdAtDbKey} DESC`
      : "";

  return {
    sql: `INSERT INTO ${tableName} (${insertColumns}) VALUES (${insertValues});
          ${selectClause} ${fallbackWhere} ${fallbackOrderBy};`,
    extraInputs,
  };
}

type SqlRequestLike = {
  input: (name: string, value: unknown) => unknown;
};

export function bindValues(request: SqlRequestLike, values: PickedColumn[]) {
  values.forEach((column, i) => request.input(`value_${i}`, column.value));
}

export async function executeList(args: {
  tableInfo: CrudTableInfo;
  whereClause: string;
  params: Record<string, unknown>;
  sortDbKey: string;
  order: "ASC" | "DESC";
  offset: number;
  limit: number;
  executor?: SqlExecutor;
}) {
  const request = await createRequest(args.executor);
  Object.entries({ ...args.params, offset: args.offset, limit: args.limit }).forEach(([name, value]) => {
    request.input(name, value as never);
  });
  const result = await request.query(
    `SELECT ${selectList(args.tableInfo.columns)}
     FROM ${fullTableName(args.tableInfo)}${args.whereClause}
     ORDER BY ${quoteIdentifier(args.sortDbKey)} ${args.order}
     OFFSET @offset ROWS FETCH NEXT @limit ROWS ONLY`,
  );
  return result.recordset ?? [];
}

export async function executeGetById(args: {
  tableInfo: CrudTableInfo;
  clause: string;
  params: Record<string, unknown>;
  executor?: SqlExecutor;
}) {
  const request = await createRequest(args.executor);
  Object.entries(args.params).forEach(([name, value]) => request.input(name, value as never));
  const result = await request.query(
    `SELECT TOP 1 ${selectList(args.tableInfo.columns)}
     FROM ${fullTableName(args.tableInfo)}
     WHERE ${args.clause}`,
  );
  return result.recordset?.[0] ?? null;
}

export async function executeUpdate(args: {
  tableInfo: CrudTableInfo;
  clause: string;
  params: Record<string, unknown>;
  values: PickedColumn[];
  executor?: SqlExecutor;
}) {
  const request = await createRequest(args.executor);
  Object.entries(args.params).forEach(([name, value]) => request.input(name, value as never));
  args.values.forEach((column, i) => request.input(`value_${i}`, column.value as never));

  await request.query(
    `UPDATE ${fullTableName(args.tableInfo)}
     SET ${args.values.map((c, i) => `${quoteIdentifier(c.dbKey)} = @value_${i}`).join(", ")}
     WHERE ${args.clause}`,
  );

  const read = await request.query(
    `SELECT TOP 1 ${selectList(args.tableInfo.columns)}
     FROM ${fullTableName(args.tableInfo)}
     WHERE ${args.clause}`,
  );

  return read.recordset?.[0] ?? null;
}

export async function executeInsert(args: {
  tableInfo: CrudTableInfo;
  values: PickedColumn[];
  body: Record<string, unknown>;
  executor?: SqlExecutor;
}) {
  const plan = buildInsertPlan(args);
  const request = await createRequest(args.executor);
  bindValues(request, args.values);
  plan.extraInputs.forEach((p) => request.input(p.name, p.value as never));
  const result = await request.query<Record<string, unknown>>(plan.sql);
  return result.recordset?.[0] ?? null;
}

export async function executeSoftDelete(args: {
  tableInfo: CrudTableInfo;
  clause: string;
  params: Record<string, unknown>;
  sessionUserId?: number | null;
  executor?: SqlExecutor;
}) {
  const { tableInfo } = args;
  const { columnMap } = tableInfo;
  if (!columnMap.has("isDeleted")) {
    throw new Error("Table does not have isDeleted (soft delete required; hard delete disabled)");
  }

  const request = await createRequest(args.executor);
  Object.entries(args.params).forEach(([name, value]) => request.input(name, value as never));

  const sessionUserId = args.sessionUserId == null ? null : Number(args.sessionUserId);
  const canWriteUserId = Number.isFinite(sessionUserId) && columnMap.has("updatedBy");
  if (canWriteUserId) {
    request.input("__updated_by", sessionUserId as never);
  }

  const setParts: string[] = [];
  setParts.push(`${quoteIdentifier(columnMap.get("isDeleted")!.dbKey)} = 1`);
  if (columnMap.has("isActive")) {
    setParts.push(`${quoteIdentifier(columnMap.get("isActive")!.dbKey)} = 0`);
  }
  if (columnMap.has("updatedAt")) {
    setParts.push(`${quoteIdentifier(columnMap.get("updatedAt")!.dbKey)} = GETDATE()`);
  }
  if (canWriteUserId) {
    setParts.push(`${quoteIdentifier(columnMap.get("updatedBy")!.dbKey)} = @__updated_by`);
  }

  const result = await request.query<Record<string, unknown>>(
    `UPDATE ${fullTableName(tableInfo)}
     SET ${setParts.join(", ")}
     OUTPUT ${deletedSelectList(tableInfo.columns)}
     WHERE ${args.clause}`,
  );

  return result.recordset?.[0] ?? null;
}

