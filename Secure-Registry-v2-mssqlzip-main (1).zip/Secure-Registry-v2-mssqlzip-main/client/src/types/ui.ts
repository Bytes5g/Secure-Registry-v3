import { z } from "zod";

export interface UiPageColumn {
  fieldCode: string;
  nameAr: string;
  columnType: string; // "text" | "number" | "date" | "boolean" | "select"
  isVisible: boolean;
  isSortable?: boolean;
  isFilterable?: boolean;
  width?: string;
  orderIndex?: number;
  lookupTypeId?: number;
  options?: { label: string; value: any }[]; // Added for static options
}

export interface UiPageFilter {
  id: number | string;
  fieldCode: string;
  nameAr: string;
  filterType: "text" | "select";
  lookupTypeId?: number;
  orderIndex: number;
}

export interface UiPageFormField {
  fieldCode: string;
  nameAr: string;
  fieldType: string; // "text" | "number" | "date" | "boolean" | "select" | "textarea" | "password"
  isRequired: boolean;
  isVisible?: boolean;
  gridCols?: number;
  orderIndex?: number;
  lookupTypeId?: number;
  isEditable?: boolean; 
  defaultValue?: string; 
  placeholder?: string; 
  config?: Record<string, any>; 
  options?: { label: string; value: any }[]; // Added for static options
}

export interface UiPageConfig {
  id?: number | string;
  code: string;
  nameAr: string;
  entityType: string;
  layoutType: "list" | "card"; // "list" | "card"
  columns: UiPageColumn[];
  formFields: UiPageFormField[];
  description?: string;
  filters?: any[]; // Added to support filters property
  zodSchema?: z.ZodType<any>;
}

export interface UiPageConfigWithDetails {
  id?: number;
  pageCode: string;
  config: UiPageConfig;
}
