import fs from "fs";
import fsPromises from "fs/promises";
import path from "path";
import { fileTypeFromFile } from "file-type";

type DriverFactory = (options: Record<string, unknown>) => FileStorageDriver;

export interface FileStorageDriver {
  readonly publicBasePath: string;
  ensureDirectory(relativeDirectory?: string): Promise<void>;
  resolveAbsolutePath(relativePath: string): string;
  publicUrl(relativePath: string): string;
  relativePathFromPublicUrl(publicUrl: string): string | null;
  moveFromTemp(tempPath: string, relativePath: string): Promise<void>;
  delete(relativePath: string): Promise<void>;
  exists(relativePath: string): Promise<boolean>;
}

type DriverConfig = {
  driver: string;
  options: Record<string, unknown>;
};

export class StorageManager {
  private readonly drivers = new Map<string, DriverFactory>();
  private readonly locations = new Map<string, FileStorageDriver>();

  registerDriver(name: string, factory: DriverFactory) {
    this.drivers.set(name, factory);
  }

  registerLocation(name: string, config: DriverConfig) {
    const driverFactory = this.drivers.get(config.driver);

    if (!driverFactory) {
      throw new Error(`Driver "${config.driver}" is not registered.`);
    }

    this.locations.set(name, driverFactory(config.options));
  }

  location(name: string): FileStorageDriver {
    const driver = this.locations.get(name);

    if (!driver) {
      throw new Error(`Storage location "${name}" does not exist.`);
    }

    return driver;
  }
}

type LocalDriverConfig = {
  root: string;
  publicBasePath?: string;
};

class LocalFileStorageDriver implements FileStorageDriver {
  readonly publicBasePath: string;
  private readonly root: string;

  constructor(config: LocalDriverConfig) {
    this.root = path.resolve(config.root);
    this.publicBasePath = config.publicBasePath ?? "/uploads";
  }

  private sanitizeRelativePath(relativePath: string): string {
    const normalized = relativePath.replace(/\\/g, "/").replace(/^\/+/, "");
    const resolved = path.posix.normalize(normalized);

    if (!resolved || resolved === "." || resolved.startsWith("../") || resolved.includes("/../")) {
      throw new Error("Invalid storage path");
    }

    return resolved;
  }

  private sanitizeRelativeDirectory(relativeDirectory = ""): string {
    if (!relativeDirectory) {
      return "";
    }

    return this.sanitizeRelativePath(relativeDirectory);
  }

  async ensureDirectory(relativeDirectory = ""): Promise<void> {
    const targetDirectory = relativeDirectory
      ? this.resolveAbsolutePath(this.sanitizeRelativeDirectory(relativeDirectory))
      : this.root;

    await fsPromises.mkdir(targetDirectory, { recursive: true });
  }

  resolveAbsolutePath(relativePath: string): string {
    const sanitizedPath = this.sanitizeRelativePath(relativePath);
    return path.join(this.root, ...sanitizedPath.split("/"));
  }

  publicUrl(relativePath: string): string {
    const sanitizedPath = this.sanitizeRelativePath(relativePath);
    return `${this.publicBasePath}/${sanitizedPath}`;
  }

  relativePathFromPublicUrl(publicUrl: string): string | null {
    if (!publicUrl.startsWith(this.publicBasePath)) {
      return null;
    }

    const relativePath = publicUrl.slice(this.publicBasePath.length).replace(/^\/+/, "");
    return relativePath ? this.sanitizeRelativePath(relativePath) : null;
  }

  async moveFromTemp(tempPath: string, relativePath: string): Promise<void> {
    const absoluteTargetPath = this.resolveAbsolutePath(relativePath);
    await fsPromises.mkdir(path.dirname(absoluteTargetPath), { recursive: true });
    await fsPromises.rename(tempPath, absoluteTargetPath);
  }

  async delete(relativePath: string): Promise<void> {
    const absoluteTargetPath = this.resolveAbsolutePath(relativePath);
    await fsPromises.unlink(absoluteTargetPath);
  }

  async exists(relativePath: string): Promise<boolean> {
    try {
      await fsPromises.access(this.resolveAbsolutePath(relativePath));
      return true;
    } catch {
      return false;
    }
  }
}

const storageManager = new StorageManager();

storageManager.registerDriver("local", (options) => {
  const config = options as LocalDriverConfig;
  return new LocalFileStorageDriver(config);
});

storageManager.registerLocation("local", {
  driver: "local",
  options: {
    root: path.join(process.cwd(), "uploads"),
    publicBasePath: "/uploads",
  },
});

export const fileStorage = storageManager;

export function getLocalStorage() {
  return fileStorage.location("local");
}

export async function ensureLocalStorageDirectory(relativeDirectory = ""): Promise<void> {
  await getLocalStorage().ensureDirectory(relativeDirectory);
}

export function buildPublicFileUrl(relativePath: string): string {
  return getLocalStorage().publicUrl(relativePath);
}

export async function deleteStoredFileByPublicUrl(publicUrl: string): Promise<void> {
  const relativePath = getLocalStorage().relativePathFromPublicUrl(publicUrl);

  if (!relativePath) {
    return;
  }

  try {
    await getLocalStorage().delete(relativePath);
  } catch {
    return;
  }
}

export async function deleteAbsoluteFileSafely(absolutePath: string): Promise<void> {
  try {
    if (fs.existsSync(absolutePath)) {
      await fsPromises.unlink(absolutePath);
    }
  } catch {
    return;
  }
}

export async function assertDetectedMime(
  absoluteFilePath: string,
  allowedMimes: string[],
  fallbackMime?: string | null,
): Promise<string> {
  const detected = await fileTypeFromFile(absoluteFilePath).catch(() => null);
  const mime = detected?.mime ?? fallbackMime ?? "";

  if (!mime || !allowedMimes.includes(mime)) {
    throw new Error(`File content does not match allowed types (${allowedMimes.join(", ")})`);
  }

  return mime;
}
