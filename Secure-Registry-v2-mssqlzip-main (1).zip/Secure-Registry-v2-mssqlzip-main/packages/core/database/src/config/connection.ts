import type * as Sql from "mssql";
import mssql from "mssql";
import { getEnv, getEnvBool, getEnvInt } from "./env";

const sql = mssql;

export interface DbConfigOverrides {
  server?: string;
  port?: number;
  database?: string;
  user?: string;
  password?: string;
  encrypt?: boolean;
  trustServerCertificate?: boolean;
  pool?: { max?: number; min?: number; idleTimeoutMillis?: number };
  connectTimeout?: number;
  requestTimeout?: number;
}

export function buildDbConfig(overrides: DbConfigOverrides = {}): Sql.config {
  return {
    server: overrides.server ?? getEnv("DB_SERVER"),
    port: overrides.port ?? getEnvInt("DB_PORT", 1433),
    database: overrides.database ?? getEnv("DB_DATABASE"),
    user: overrides.user ?? getEnv("DB_USER"),
    password: overrides.password ?? getEnv("DB_PASSWORD"),
    options: {
      encrypt: overrides.encrypt ?? getEnvBool("DB_ENCRYPT", true),
      trustServerCertificate:
        overrides.trustServerCertificate ?? getEnvBool("DB_TRUST_SERVER_CERTIFICATE", false),
      enableArithAbort: true,
    },
    pool: {
      max: overrides.pool?.max ?? getEnvInt("DB_POOL_MAX", 10),
      min: overrides.pool?.min ?? getEnvInt("DB_POOL_MIN", 0),
      idleTimeoutMillis:
        overrides.pool?.idleTimeoutMillis ?? getEnvInt("DB_POOL_IDLE_MS", 30000),
    },
    connectionTimeout: overrides.connectTimeout ?? getEnvInt("DB_CONNECT_TIMEOUT_MS", 15000),
    requestTimeout: overrides.requestTimeout ?? getEnvInt("DB_REQUEST_TIMEOUT_MS", 30000),
  };
}

let pool: Sql.ConnectionPool | null = null;
let connecting: Promise<Sql.ConnectionPool> | null = null;

export type SqlExecutor = Sql.ConnectionPool | Sql.Transaction;

export async function getPool(): Promise<Sql.ConnectionPool> {
  if (pool?.connected) return pool;
  if (connecting) return connecting;

  connecting = (async () => {
    const cfg = buildDbConfig();
    pool = await new sql.ConnectionPool(cfg).connect();
    return pool;
  })();

  try {
    return await connecting;
  } finally {
    connecting = null;
  }
}

export async function createRequest(executor?: SqlExecutor): Promise<Sql.Request> {
  if (executor && typeof (executor as Sql.Transaction).request === "function") {
    return executor.request();
  }
  const activePool = await getPool();
  return activePool.request();
}

export async function withTransaction<T>(
  callback: (tx: Sql.Transaction) => Promise<T>,
): Promise<T> {
  const activePool = await getPool();
  const transaction = new sql.Transaction(activePool);

  await transaction.begin();
  try {
    const result = await callback(transaction);
    await transaction.commit();
    return result;
  } catch (error) {
    try {
      await transaction.rollback();
    } catch {
    }
    throw error;
  }
}

export async function closePool(): Promise<void> {
  if (pool) {
    await pool.close();
    pool = null;
  }
}

export async function pingDb(): Promise<{ db: string; user: string; version: string }> {
  const p = await getPool();
  const r = await p
    .request()
    .query("SELECT DB_NAME() AS db, SUSER_NAME() AS who, @@VERSION AS v");
  const row = r.recordset[0];
  return { db: row.db, user: row.who, version: String(row.v).split("\n")[0].trim() };
}

export { sql };
