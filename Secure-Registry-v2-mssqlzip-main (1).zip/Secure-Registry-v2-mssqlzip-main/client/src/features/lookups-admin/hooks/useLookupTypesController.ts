import { useMemo, useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import {
  createLookupType,
  deleteLookupType,
  fetchAllLookupTypes,
  updateLookupType,
} from "@/lib/api/lookups-admin";
import type { InsertLookupType, LookupType } from "@shared/schema";
import {
  createEmptyLookupTypeForm,
  createLookupTypeFormFromRecord,
  mapLookupTypePayload,
  type LookupTypeFormState,
} from "../models/lookups-admin-models";
import {
  createMutationFeedbackHandlers,
  ensureRequiredLookupFields,
  type EditMode,
  type SharedDeps,
} from "./_internals/shared";

export function useLookupTypesController({ toast, invalidateAll }: SharedDeps) {
  const [selectedTypeId, setSelectedTypeId] = useState<number | null>(null);
  const [lookupDialogOpen, setLookupDialogOpen] = useState(false);
  const [lookupMode, setLookupMode] = useState<EditMode>("create");
  const [lookupForm, setLookupForm] = useState<LookupTypeFormState>(createEmptyLookupTypeForm());
  const [lookupToDelete, setLookupToDelete] = useState<LookupType | null>(null);

  const { data: lookupTypes = [], isLoading: lookupTypesLoading } = useQuery({
    queryKey: ["lookup-admin", "types"],
    queryFn: fetchAllLookupTypes,
  });

  const selectedType = useMemo(
    () => lookupTypes.find((type) => type.id === selectedTypeId) ?? null,
    [lookupTypes, selectedTypeId],
  );

  const createTypeMutation = useMutation({
    mutationFn: (payload: InsertLookupType) => createLookupType(payload),
    ...createMutationFeedbackHandlers<LookupType>({
      invalidate: invalidateAll,
      toast,
      successTitle: "تم إنشاء نوع القائمة",
      successDescription: "أصبح النوع جاهزاً لإدارة القيم والأسماء البديلة.",
      errorTitle: "تعذر إنشاء النوع",
      onSuccess: (created) => {
        setLookupDialogOpen(false);
        setSelectedTypeId(created.id);
      },
    }),
  });

  const updateTypeMutation = useMutation({
    mutationFn: ({ id, payload }: { id: number; payload: Partial<InsertLookupType> }) =>
      updateLookupType(id, payload),
    ...createMutationFeedbackHandlers<LookupType>({
      invalidate: invalidateAll,
      toast,
      successTitle: "تم تحديث النوع",
      successDescription: "حُفظت إعدادات metadata بنجاح.",
      errorTitle: "تعذر تحديث النوع",
      onSuccess: (updated) => {
        setLookupDialogOpen(false);
        setSelectedTypeId(updated.id);
      },
    }),
  });

  const deleteTypeMutation = useMutation({
    mutationFn: (id: number) => deleteLookupType(id),
    ...createMutationFeedbackHandlers({
      invalidate: invalidateAll,
      toast,
      successTitle: "تم حذف النوع",
      successDescription: "حُذفت السجلات التابعة المرتبطة به أيضاً.",
      errorTitle: "تعذر حذف النوع",
      onSuccess: () => {
        if (lookupToDelete && selectedType?.id === lookupToDelete.id) {
          setSelectedTypeId(null);
        }
        setLookupToDelete(null);
      },
    }),
  });

  const selectedTypeSummary = useMemo(
    () =>
      selectedType
        ? `${selectedType.code} - ${selectedType.nameAr}`
        : "اختر نوعاً من القائمة لعرض التفاصيل",
    [selectedType],
  );

  const canManageValues = useMemo(
    () => Boolean(selectedType?.writable && selectedType?.tableName),
    [selectedType],
  );

  const openCreateTypeDialog = () => {
    setLookupMode("create");
    setLookupForm(createEmptyLookupTypeForm());
    setLookupDialogOpen(true);
  };

  const openEditTypeDialog = (record: LookupType) => {
    setLookupMode("edit");
    setSelectedTypeId(record.id);
    setLookupForm(createLookupTypeFormFromRecord(record));
    setLookupDialogOpen(true);
  };

  const submitLookupType = () => {
    const payload = mapLookupTypePayload(lookupForm);
    const validationMessage = ensureRequiredLookupFields(payload);
    if (validationMessage) {
      toast({ title: "بيانات ناقصة", description: validationMessage, variant: "destructive" });
      return;
    }
    if (lookupMode === "edit" && selectedType) {
      updateTypeMutation.mutate({ id: selectedType.id, payload });
      return;
    }
    createTypeMutation.mutate(payload);
  };

  return {
    selectedTypeId,
    setSelectedTypeId,
    selectedType,
    setSelectedType: (record: LookupType | null) => setSelectedTypeId(record?.id ?? null),
    selectedTypeSummary,
    canManageValues,
    lookupTypes,
    lookupTypesLoading,
    lookupDialogOpen,
    setLookupDialogOpen,
    lookupMode,
    lookupForm,
    setLookupForm,
    lookupToDelete,
    setLookupToDelete,
    openCreateTypeDialog,
    openEditTypeDialog,
    submitLookupType,
    deleteTypeMutation,
    createTypeMutation,
    updateTypeMutation,
  };
}
