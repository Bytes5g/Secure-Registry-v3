import { useEffect, useMemo, useRef, useState } from "react"
import type { Layer } from "leaflet"
import { circleMarker, control, geoJSON, layerGroup, map as createLeafletMap, tileLayer } from "leaflet"
import { Button } from "../ui/button"
import { cn } from "../lib/utils"
import type { MapTileProvider } from "./types"

import "leaflet/dist/leaflet.css"

export type MapGeoJson = unknown
export type MapLabelPoint = {
  id: number | string
  lat: number
  lon: number
  label: string
  selected?: boolean
}

export interface MapCanvasProps {
  providers: MapTileProvider[]
  geoJson?: MapGeoJson | null
  labelPoints?: MapLabelPoint[]
  onSelectLabelPoint?: (id: number | string) => void
  className?: string
  mapClassName?: string
  defaultZoom?: number
  defaultCenter?: [number, number]
  fitPadding?: number
  fitMaxZoom?: number
  height?: number
}

function normalizeProviders(providers: MapTileProvider[]): { base: MapTileProvider[]; overlays: MapTileProvider[] } {
  const normalized = (providers ?? []).slice().sort((a, b) => (a.orderIndex ?? 0) - (b.orderIndex ?? 0))
  return {
    base: normalized.filter((p) => !p.isOverlay),
    overlays: normalized.filter((p) => Boolean(p.isOverlay)),
  }
}

export function MapCanvas({
  providers,
  geoJson = null,
  labelPoints = [],
  onSelectLabelPoint,
  className,
  mapClassName,
  defaultZoom = 5,
  defaultCenter = [24.0, 45.0],
  fitPadding = 16,
  fitMaxZoom,
  height = 420,
}: MapCanvasProps) {
  const rootRef = useRef<HTMLDivElement | null>(null)
  const mapRef = useRef<ReturnType<typeof createLeafletMap> | null>(null)
  const [map, setMap] = useState<ReturnType<typeof createLeafletMap> | null>(null)
  const geoLayerRef = useRef<Layer | null>(null)
  const labelLayerRef = useRef<Layer | null>(null)
  const layerControlRef = useRef<ReturnType<typeof control.layers> | null>(null)

  const { base, overlays } = useMemo(() => normalizeProviders(providers), [providers])

  useEffect(() => {
    if (!rootRef.current || mapRef.current) return
    const instance = createLeafletMap(rootRef.current, {
      zoomControl: true,
      attributionControl: true,
    }).setView(defaultCenter as any, defaultZoom)
    mapRef.current = instance
    setMap(instance)
    return () => {
      mapRef.current = null
      instance.remove()
    }
  }, [])

  useEffect(() => {
    if (!mapRef.current) return
    mapRef.current.setView(defaultCenter as any, defaultZoom)
  }, [defaultCenter, defaultZoom])

  useEffect(() => {
    if (!map) return

    if (layerControlRef.current) {
      layerControlRef.current.remove()
      layerControlRef.current = null
    }

    const baseLayers: Record<string, Layer> = {}
    const overlayLayers: Record<string, Layer> = {}

    const baseList = base.length > 0 ? base : overlays
    const defaultBase = baseList[0]

    for (const p of baseList) {
      baseLayers[p.name] = tileLayer(p.tileUrl)
    }

    for (const p of overlays) {
      if (baseList.some((b) => String(b.id) === String(p.id))) continue
      overlayLayers[p.name] = tileLayer(p.tileUrl)
    }

    if (defaultBase) {
      baseLayers[defaultBase.name]?.addTo(map)
    }

    const ctl = control.layers(baseLayers, overlayLayers, { position: "topright" }).addTo(map)
    layerControlRef.current = ctl

    return () => {
      ctl.remove()
      if (layerControlRef.current === ctl) {
        layerControlRef.current = null
      }
    }
  }, [map, base, overlays])

  useEffect(() => {
    if (!map) return
    if (geoLayerRef.current) {
      geoLayerRef.current.remove()
      geoLayerRef.current = null
    }
    if (!geoJson) return

    let layer: Layer
    try {
      layer = geoJSON(geoJson as any)
    } catch {
      return
    }

    layer.addTo(map)
    geoLayerRef.current = layer

    try {
      const bounds = (layer as any).getBounds?.()
      if (bounds?.isValid?.()) {
        map.fitBounds(bounds, { padding: [fitPadding, fitPadding], maxZoom: fitMaxZoom })
      }
    } catch {
    }

    return () => {
      layer.remove()
      if (geoLayerRef.current === layer) {
        geoLayerRef.current = null
      }
    }
  }, [map, geoJson, fitPadding, fitMaxZoom])

  useEffect(() => {
    if (!map) return
    if (labelLayerRef.current) {
      labelLayerRef.current.remove()
      labelLayerRef.current = null
    }
    if (!labelPoints || labelPoints.length === 0) return

    const group = layerGroup()
    for (const p of labelPoints) {
      const isSelected = Boolean(p.selected)
      const marker = circleMarker([p.lat, p.lon] as any, {
        radius: 6,
        color: isSelected ? "#e11d48" : "#0ea5e9",
        weight: 2,
        fillColor: isSelected ? "#fb7185" : "#38bdf8",
        fillOpacity: 0.65,
      })
      if (onSelectLabelPoint) {
        marker.on("click", () => onSelectLabelPoint(p.id))
      }
      marker.bindTooltip(String(p.label), { permanent: true, direction: "top", offset: [0, -8] } as any)
      marker.addTo(group)
    }

    group.addTo(map)
    labelLayerRef.current = group

    return () => {
      group.remove()
      if (labelLayerRef.current === group) {
        labelLayerRef.current = null
      }
    }
  }, [map, labelPoints, onSelectLabelPoint])

  const canFit = Boolean(map && geoJson)

  return (
    <div className={cn("space-y-2", className)}>
      <div className="flex items-center justify-end gap-2">
        <Button
          type="button"
          variant="outline"
          size="sm"
          onClick={() => {
            const activeLayer = geoLayerRef.current
            if (!map || !activeLayer) return
            const bounds = (activeLayer as any).getBounds?.()
            if (!bounds?.isValid?.()) return
            map.fitBounds(bounds, { padding: [fitPadding, fitPadding], maxZoom: fitMaxZoom })
          }}
          disabled={!canFit}
        >
          ملاءمة العرض
        </Button>
      </div>

      <div className={cn("rounded-md border overflow-hidden", mapClassName)} style={{ height }}>
        <div ref={rootRef} style={{ height: "100%", width: "100%" }} />
      </div>
    </div>
  )
}
