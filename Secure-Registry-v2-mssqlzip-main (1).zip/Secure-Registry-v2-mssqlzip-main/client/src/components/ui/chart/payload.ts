import type { ChartConfig } from "./types";

export function getPayloadConfigFromPayload(config: ChartConfig, payload: unknown, key: string) {
  if (typeof payload !== "object" || payload === null) {
    return undefined;
  }

  const payloadPayload =
    "payload" in payload && typeof (payload as any).payload === "object" && (payload as any).payload !== null
      ? (payload as any).payload
      : undefined;

  let configLabelKey: string = key;

  if (key in (payload as any) && typeof (payload as any)[key] === "string") {
    configLabelKey = (payload as any)[key] as string;
  } else if (payloadPayload && key in payloadPayload && typeof (payloadPayload as any)[key] === "string") {
    configLabelKey = (payloadPayload as any)[key] as string;
  }

  return configLabelKey in config ? (config as any)[configLabelKey] : (config as any)[key];
}

