import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useEffect, useMemo, useRef } from "react";
import { Button, Form, Tabs, TabsContent, TabsList, TabsTrigger } from "@secure-registry/components-ui";
import { Save } from "lucide-react";
import type { UiPageFormField } from "@/types/ui";
import type { LookupTypeWithValues } from "@shared/schema";
import { DynamicFormField } from "./DynamicFormField";

interface DynamicFormProps {
  fields: UiPageFormField[];
  lookupTypes?: LookupTypeWithValues[];
  initialData?: any;
  onSubmit: (data: any) => void;
  isSubmitting?: boolean;
  serverErrors?: Record<string, string> | null;
  zodSchema?: z.ZodType<any>;
  readOnly?: boolean;
  submitLabel?: string;
  submitPendingLabel?: string;
  onFieldClick?: (fieldCode: string) => void;
  selectedFieldCode?: string | null;
}

function buildSchema(fields: UiPageFormField[]) {
  return z.object(
    fields.reduce((acc, field) => {
      let validator: z.ZodTypeAny;
      
      switch (field.fieldType) {
        case "text":
        case "textarea":
          validator = field.isRequired 
            ? z.string().min(1, "هذا الحقل مطلوب") 
            : z.string().optional().or(z.literal(""));
          break;
        case "number":
          validator = z.preprocess(
            (value) => {
              if (value === "" || value === undefined || value === null) {
                return field.isRequired ? undefined : null;
              }

              if (typeof value === "string") {
                const trimmed = value.trim();
                if (!trimmed) {
                  return field.isRequired ? undefined : null;
                }
                const parsed = Number(trimmed);
                return Number.isFinite(parsed) ? parsed : value;
              }

              if (typeof value === "number") {
                return value;
              }

              return value;
            },
            field.isRequired
              ? z.number({ required_error: "هذا الحقل مطلوب", invalid_type_error: "يجب أن يكون رقماً" })
              : z.number({ invalid_type_error: "يجب أن يكون رقماً" }).nullable().optional(),
          );
          break;
        case "select":
          validator = field.isRequired 
            ? z.string().min(1, "هذا الحقل مطلوب").or(z.number())
            : z.string().optional().or(z.number().optional()).nullable();
          break;
        case "switch":
        case "boolean":
          validator = z.boolean().optional().default(field.defaultValue === "true");
          break;
        default:
          validator = z.any();
      }
      
      acc[field.fieldCode] = validator;
      return acc;
    }, {} as Record<string, z.ZodTypeAny>)
  );
}

function getDefaultValues(fields: UiPageFormField[], existingValues?: Record<string, any>) {
  const defaults: Record<string, any> = {};
  
  fields.forEach(field => {
    if (existingValues && field.fieldCode in existingValues) {
      defaults[field.fieldCode] = existingValues[field.fieldCode];
    } else if (field.defaultValue) {
      if (field.fieldType === "number") {
        defaults[field.fieldCode] = parseInt(field.defaultValue) || null;
      } else if (field.fieldType === "switch" || field.fieldType === "boolean") {
        defaults[field.fieldCode] = field.defaultValue === "true";
      } else {
        defaults[field.fieldCode] = field.defaultValue;
      }
    } else {
      defaults[field.fieldCode] = field.fieldType === "switch" || field.fieldType === "boolean" ? false : "";
    }
  });
  
  return defaults;
}

const EMPTY_INITIAL_DATA: Record<string, any> = {};

export function DynamicForm({
  fields,
  lookupTypes = [],
  initialData,
  onSubmit,
  isSubmitting = false,
  serverErrors,
  zodSchema,
  readOnly = false,
  submitLabel = "حفظ",
  submitPendingLabel = "جاري الحفظ...",
  onFieldClick,
  selectedFieldCode = null,
}: DynamicFormProps) {
  const resolvedInitialData = initialData ?? EMPTY_INITIAL_DATA;
  const visibleFields = useMemo(
    () => fields.filter((field) => field.isVisible !== false),
    [fields],
  );
  const sortedFields = useMemo(
    () => [...visibleFields].sort((a, b) => (a.orderIndex || 0) - (b.orderIndex || 0)),
    [visibleFields],
  );
  const advancedFields = useMemo(
    () => sortedFields.filter((f) => String((f.config as any)?.section || "") === "advanced"),
    [sortedFields],
  );
  const basicFields = useMemo(
    () => sortedFields.filter((f) => String((f.config as any)?.section || "") !== "advanced"),
    [sortedFields],
  );
  const hasAdvancedTab = advancedFields.length > 0;
  const schema = useMemo(() => zodSchema || buildSchema(sortedFields), [zodSchema, sortedFields]);
  const entityKey = useMemo(() => {
    const rawId = (resolvedInitialData as any)?.id ?? (resolvedInitialData as any)?._id;
    return rawId == null ? "new" : String(rawId);
  }, [resolvedInitialData]);
  const fieldsKey = useMemo(() => sortedFields.map((f) => String(f.fieldCode)).join("|"), [sortedFields]);
  const defaultValues = useMemo(
    () => getDefaultValues(sortedFields, resolvedInitialData),
    [sortedFields, resolvedInitialData],
  );

  const form = useForm({
    resolver: zodResolver(schema),
    defaultValues,
  });

  const lastResetRef = useRef<{ entityKey: string; fieldsKey: string } | null>(null);

  useEffect(() => {
    const nextDefaults = getDefaultValues(sortedFields, resolvedInitialData);
    const prev = lastResetRef.current;
    if (!prev || prev.entityKey !== entityKey) {
      form.reset(nextDefaults);
      lastResetRef.current = { entityKey, fieldsKey };
      return;
    }

    if (prev.fieldsKey !== fieldsKey) {
      const merged = { ...nextDefaults, ...form.getValues() };
      form.reset(merged, { keepDirtyValues: true } as any);
      lastResetRef.current = { entityKey, fieldsKey };
    }
  }, [entityKey, fieldsKey, form, resolvedInitialData, sortedFields]);

  // Handle server-side errors
  useEffect(() => {
    if (serverErrors) {
      Object.entries(serverErrors).forEach(([field, message]) => {
        form.setError(field, {
          type: "server",
          message: message,
        });
      });
    }
  }, [serverErrors, form]);

  const handleSubmit = (data: any) => {
    // Process data before submission if needed (e.g. number conversion)
    const cleanedData = { ...data };
    sortedFields.forEach(field => {
      if (field.fieldType === "number" && typeof cleanedData[field.fieldCode] === "string") {
        const parsed = parseFloat(cleanedData[field.fieldCode]);
        cleanedData[field.fieldCode] = isNaN(parsed) ? null : parsed;
      }
      if (field.fieldType === "select") {
        const value = cleanedData[field.fieldCode];
        if (value === "" || value === "null") {
          cleanedData[field.fieldCode] = null;
          return;
        }
        if (typeof value === "string" && /^\d+$/.test(value)) {
          cleanedData[field.fieldCode] = Number(value);
        }
      }
    });
    onSubmit(cleanedData);
  };

  const getGridCols = (field: UiPageFormField): number => {
    const raw = field.gridCols;
    if (raw == null) return 6;
    const n = Number(raw);
    if (!Number.isFinite(n)) return 6;
    if (n <= 1) return 6;
    if (n === 2) return 12;
    const clamped = Math.max(1, Math.min(12, Math.floor(n)));
    return clamped;
  };

  const renderField = (field: UiPageFormField) => {
    const span = getGridCols(field);
    const isSelected = selectedFieldCode != null && String(selectedFieldCode) === String(field.fieldCode);
    const handleSelect = readOnly
      ? (e: { preventDefault: () => void; stopPropagation: () => void }) => {
          e.preventDefault();
          e.stopPropagation();
          onFieldClick?.(field.fieldCode);
        }
      : undefined;

    return (
      <div
        key={field.fieldCode}
        className={isSelected ? "rounded-md ring-2 ring-ring p-2" : "p-2"}
        style={{ gridColumn: `span ${span} / span ${span}` }}
        onMouseDown={handleSelect}
      >
        <DynamicFormField field={field} form={form} lookupTypes={lookupTypes} isReadOnly={readOnly} />
      </div>
    );
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-6">
        {hasAdvancedTab ? (
          <Tabs defaultValue="basic">
            <TabsList>
              <TabsTrigger value="basic">بحث</TabsTrigger>
              <TabsTrigger value="advanced">خيارات متقدمة</TabsTrigger>
            </TabsList>
            <TabsContent value="basic">
              <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
                {basicFields.map(renderField)}
              </div>
            </TabsContent>
            <TabsContent value="advanced">
              <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
                {advancedFields.map(renderField)}
              </div>
            </TabsContent>
          </Tabs>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
            {sortedFields.map(renderField)}
          </div>
        )}

        {!readOnly && (
          <div className="flex justify-end">
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting ? (
                submitPendingLabel
              ) : (
                <>
                  <Save className="me-2 h-4 w-4" />
                  {submitLabel}
                </>
              )}
            </Button>
          </div>
        )}
      </form>
    </Form>
  );
}
