import { z } from "zod";

const nullableInt = z.number().int().nullable();
const nullableString = z.string().nullable();

export const userSchema = z.object({
  id: z.number().int(),
  firstName: nullableString,
  lastName: nullableString,
  email: nullableString,
  password: nullableString,
  location: nullableString,
  title: nullableString,
  description: nullableString,
  tags: nullableString,
  avatar: nullableInt,
  language: nullableString,
  tfaSecret: nullableString,
  status: nullableString,
  role: nullableInt,
  token: nullableString,
  lastAccess: nullableString,
  lastPage: nullableString,
  provider: nullableString,
  externalIdentifier: nullableString,
  authData: nullableString,
  emailNotifications: z.boolean().nullable(),
  appearance: nullableString,
  themeDark: nullableString,
  themeLight: nullableString,
  themeLightOverrides: nullableString,
  themeDarkOverrides: nullableString,
  textDirection: nullableString,
});
export type User = z.infer<typeof userSchema>;

export const insertUserSchema = userSchema.omit({
  id: true,
  lastAccess: true,
});
export type InsertUser = z.input<typeof insertUserSchema>;

export const roleSchema = z.object({
  id: z.number().int(),
  name: z.string().min(1),
  icon: nullableString,
  description: nullableString,
});
export type Role = z.infer<typeof roleSchema>;

export const insertRoleSchema = roleSchema.omit({
  id: true,
});
export type InsertRole = z.input<typeof insertRoleSchema>;
