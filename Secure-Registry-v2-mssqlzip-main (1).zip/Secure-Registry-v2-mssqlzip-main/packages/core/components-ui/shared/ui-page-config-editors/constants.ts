export const COLUMN_TYPE_OPTIONS: Array<{ value: string; label: string }> = [
  { value: "text", label: "نص" },
  { value: "number", label: "رقم" },
  { value: "date", label: "تاريخ" },
  { value: "boolean", label: "نعم/لا" },
  { value: "select", label: "اختيار" },
];

export const FIELD_TYPE_OPTIONS: Array<{ value: string; label: string }> = [
  { value: "text", label: "نص" },
  { value: "textarea", label: "نص متعدد" },
  { value: "number", label: "رقم" },
  { value: "boolean", label: "نعم/لا" },
  { value: "select", label: "اختيار" },
];

