#!/usr/bin/env node
import { connect } from "./_config.js";

const pool = await connect();

const u = await pool.request().query(
  `SELECT id, email, first_name, last_name, status, role,
          LEFT(password, 7) AS pwd_prefix, LEN(password) AS pwd_len,
          last_access, failed_attempts, is_locked
     FROM dbo.users`
);
console.log("USERS:");
for (const r of u.recordset) console.log(JSON.stringify(r, null, 2));

const roles = await pool.request().query(`SELECT id, name, parent FROM dbo.roles`);
console.log("\nROLES:");
roles.recordset.forEach(r => console.log(`  ${r.id}: ${r.name} (parent=${r.parent})`));

await pool.close();
