import { apiRequest } from "../queryClient";

// Generic API utilities using fetch

// Converting entityType (e.g. org_branches or orgBranches) to kebab-case (org-branches)
export const toKebabCase = (str: string) => {
    return str
        .replace(/_/g, '-')
        .replace(/([a-z0-9])([A-Z])/g, '$1-$2')
        .toLowerCase();
};

type EntityOverride = {
    getAll?: (params?: Record<string, any>) => Promise<any>;
    getOne?: (id: number | string) => Promise<any>;
    create?: (data: any) => Promise<any>;
    update?: (id: number | string, data: any) => Promise<any>;
    delete?: (id: number | string) => Promise<any>;
};

function buildUrl(path: string, params?: Record<string, any>) {
    const url = new URL(path, window.location.origin);
    if (params) {
        Object.entries(params).forEach(([key, value]) => {
            if (value !== undefined && value !== null) {
                url.searchParams.append(key, String(value));
            }
        });
    }
    return url.toString();
}

const entityOverrides: Record<string, EntityOverride> = {
    organizationalStructure: {
        getAll: (params) => apiRequest("GET", buildUrl("/api/org/organizations", params)),
        getOne: (id) => apiRequest("GET", `/api/org/organizations/${id}`),
        create: (data) => apiRequest("POST", "/api/org/organizations", data),
        update: (id, data) => apiRequest("PATCH", `/api/org/organizations/${id}`, data),
        delete: (id) => apiRequest("DELETE", `/api/org/organizations/${id}`),
    },
    orgStructureTree: {
        getAll: async (params) => {
            const rawOrgId = params?.orgId ?? params?.org_id ?? null;
            const orgId = Number(rawOrgId);
            if (!Number.isFinite(orgId)) return [];
            const includeInactive = params?.includeInactive ?? params?.include_inactive ?? undefined;
            const rows = await apiRequest(
              "GET",
              buildUrl(`/api/org/organizations/${orgId}/tree/flat`, { includeInactive }),
            );
            const parentRaw = params?.parentId ?? params?.parent_id ?? undefined;
            if (parentRaw === undefined) return rows;
            const parentId = parentRaw === "null" || parentRaw === "" || parentRaw == null ? null : Number(parentRaw);
            if (parentId == null) {
                return Array.isArray(rows) ? rows.filter((n: any) => (n.parentId ?? n.parent_id) == null) : rows;
            }
            if (!Number.isFinite(parentId)) return rows;
            return Array.isArray(rows) ? rows.filter((n: any) => Number(n.parentId ?? n.parent_id) === parentId) : rows;
        },
        getOne: (id) => apiRequest("GET", `/api/org/tree-nodes/${id}`),
        create: (data) => apiRequest("POST", "/api/org/tree-nodes", data),
        update: (id, data) => apiRequest("PATCH", `/api/org/tree-nodes/${id}`, data),
        delete: (id) => apiRequest("DELETE", `/api/org/tree-nodes/${id}`),
    },
    orgBranches: {
        getAll: async (params) => {
            const rows = await apiRequest("GET", buildUrl("/api/branches", params));
            const orgIdRaw = params?.orgId ?? params?.org_id ?? null;
            const orgId = Number(orgIdRaw);
            if (!Number.isFinite(orgId)) return rows;
            return Array.isArray(rows) ? rows.filter((b: any) => Number(b.orgId ?? b.org_id) === orgId) : rows;
        },
        getOne: (id) => apiRequest("GET", `/api/branches/${id}`),
        create: (data) => apiRequest("POST", "/api/branches", data),
        update: (id, data) => apiRequest("PATCH", `/api/branches/${id}`, data),
        delete: (id) => apiRequest("PATCH", `/api/branches/${id}`, { isDeleted: true, isActive: false }),
    },
    orgStructureRoleTitles: {
        getAll: (params) => apiRequest("GET", buildUrl("/api/org/structure-role-titles", params)),
        getOne: (id) => apiRequest("GET", `/api/org/structure-role-titles/${id}`),
        create: (data) => apiRequest("POST", "/api/org/structure-role-titles", data),
        update: (id, data) => apiRequest("PATCH", `/api/org/structure-role-titles/${id}`, data),
        delete: (id) => apiRequest("DELETE", `/api/org/structure-role-titles/${id}`),
    },
};

export const genericApi = {
    getAll: async (entityType: string, params?: Record<string, any>) => {
        const override = entityOverrides[entityType];
        if (override?.getAll) {
            const rows = await override.getAll(params);
            return Array.isArray(rows) ? rows : (rows?.data ?? []);
        }
        const route = toKebabCase(entityType);
        const json = await apiRequest("GET", buildUrl(`/api/${route}`, params));
        return Array.isArray(json) ? json : (json?.data ?? []);
    },

    getOne: async (entityType: string, id: number | string) => {
        const override = entityOverrides[entityType];
        if (override?.getOne) return override.getOne(id);
        const route = toKebabCase(entityType);
        return apiRequest("GET", `/api/${route}/${id}`);
    },

    create: async (entityType: string, data: any) => {
        const override = entityOverrides[entityType];
        if (override?.create) return override.create(data);
        const route = toKebabCase(entityType);
        return apiRequest("POST", `/api/${route}`, data);
    },

    update: async (entityType: string, id: number | string, data: any) => {
        const override = entityOverrides[entityType];
        if (override?.update) return override.update(id, data);
        const route = toKebabCase(entityType);
        return apiRequest("PUT", `/api/${route}/${id}`, data);
    },

    delete: async (entityType: string, id: number | string) => {
        const override = entityOverrides[entityType];
        if (override?.delete) return override.delete(id);
        const route = toKebabCase(entityType);
        return apiRequest("DELETE", `/api/${route}/${id}`);
    },

    getDbMeta: async (entityType: string) => {
        // This endpoint might not exist yet, but we'll add the client method for it
        // If it doesn't exist on server, it will throw 404 which we can handle or implement server side later
        const route = toKebabCase(entityType);
        return apiRequest("GET", `/api/meta/${route}`);
    },

    getUiPageConfig: async (pageCode: string, entityType: string, options?: { ignoreOverride?: boolean }) => {
        return apiRequest(
            "GET",
            buildUrl(`/api/ui/pages/${encodeURIComponent(pageCode)}`, { entityType, ignoreOverride: options?.ignoreOverride ? 1 : undefined }),
        );
    },

    getUiPageDetails: async (pageCode: string, entityType: string, options?: { ignoreOverride?: boolean }) => {
        return apiRequest(
            "GET",
            buildUrl(`/api/ui/pages/${encodeURIComponent(pageCode)}/details`, { entityType, ignoreOverride: options?.ignoreOverride ? 1 : undefined }),
        );
    },

    executeUiDataSource: async (dataSourceKey: string, params?: Record<string, any>) => {
        return apiRequest(
            "GET",
            buildUrl(`/api/ui/data-sources/${encodeURIComponent(dataSourceKey)}/execute`, params),
        );
    },

    getUiPageOverride: async (pageCode: string) => {
        return apiRequest("GET", `/api/ui/pages/${encodeURIComponent(pageCode)}/override`);
    },

    setUiPageOverride: async (pageCode: string, override: any | null) => {
        return apiRequest("PUT", `/api/ui/pages/${encodeURIComponent(pageCode)}/override`, override);
    },

    getUiPagesRegistry: async () => {
        return apiRequest("GET", "/api/ui/pages/registry");
    },

    getUiPageRegistryInfo: async (pageCode: string) => {
        return apiRequest("GET", `/api/ui/pages/${encodeURIComponent(pageCode)}/registry-info`);
    },

    seedUiPageOverride: async (pageCode: string, args?: { entityType?: string; force?: boolean; scope?: "all" | "columns" | "formFields" }) => {
        const url = buildUrl(`/api/ui/pages/${encodeURIComponent(pageCode)}/override/seed`, {
            force: args?.force ? 1 : undefined,
            scope: args?.scope && args.scope !== "all" ? args.scope : undefined,
        });
        return apiRequest("POST", url, { entityType: args?.entityType });
    },
};
