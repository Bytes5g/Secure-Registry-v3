import { useMemo } from "react";
import { useQuery } from "@tanstack/react-query";

import { Button, Input, MapCanvas } from "@secure-registry/components-ui";
import { fetchGeoUnits } from "@/lib/api/geo-admin";
import { fetchMapProviders } from "@/lib/api/maps";

export function GeoUnitMapPicker(props: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  search: string;
  onSearchChange: (value: string) => void;
  selectedValue: string;
  onSelectValue: (value: string) => void;
}) {
  const searchEnabled = props.open && props.search.trim().length >= 2;

  const mapProvidersQuery = useQuery({
    queryKey: ["maps", "providers"],
    queryFn: fetchMapProviders,
    enabled: props.open,
  });

  const geoUnitsQuery = useQuery({
    queryKey: ["geo", "units", "search", props.search.trim()],
    queryFn: async () => fetchGeoUnits({ page: 1, limit: 60, search: props.search.trim() }),
    enabled: searchEnabled,
  });

  const tileProviders = useMemo(() => {
    return (mapProvidersQuery.data ?? []).map((p) => ({
      id: p.id,
      name: p.providerName,
      tileUrl: p.tileUrl,
      isOverlay: p.isOverlay,
      orderIndex: p.orderIndex,
    }));
  }, [mapProvidersQuery.data]);

  const selectedId = props.selectedValue ? Number(props.selectedValue) : null;
  const selectedUnit = useMemo(() => {
    if (!geoUnitsQuery.data?.data || selectedId == null) return null;
    return geoUnitsQuery.data.data.find((u) => u.id === selectedId) ?? null;
  }, [geoUnitsQuery.data, selectedId]);

  const geoJson = useMemo(() => {
    const raw = selectedUnit?.geometryJson;
    if (!raw) return null;
    try {
      return JSON.parse(raw);
    } catch {
      return null;
    }
  }, [selectedUnit]);

  const labelPoints = useMemo(() => {
    const list = geoUnitsQuery.data?.data ?? [];
    return list
      .filter((u) => u.latitude != null && u.longitude != null)
      .map((u) => ({
        id: u.id,
        lat: Number(u.latitude),
        lon: Number(u.longitude),
        label: u.name,
        selected: selectedId != null && u.id === selectedId,
      }))
      .filter((p) => Number.isFinite(p.lat) && Number.isFinite(p.lon));
  }, [geoUnitsQuery.data, selectedId]);

  return (
    <div className="rounded-md border p-3 space-y-3">
      <div className="flex items-center justify-between gap-2">
        <Button type="button" variant="outline" size="sm" onClick={() => props.onOpenChange(!props.open)}>
          {props.open ? "إخفاء الخريطة" : "اختيار من الخريطة"}
        </Button>
      </div>

      {props.open ? (
        <>
          <Input
            type="text"
            value={props.search}
            onChange={(e) => props.onSearchChange(e.target.value)}
            placeholder="ابحث عن وحدة جغرافية (اكتب حرفين على الأقل)..."
          />

          <div className="text-sm text-muted-foreground">
            انقر على النقطة في الخريطة لاختيار الوحدة. سيتم تمييز المختار باللون الأحمر.
          </div>

          <MapCanvas
            providers={tileProviders}
            geoJson={geoJson}
            labelPoints={labelPoints}
            onSelectLabelPoint={(id) => props.onSelectValue(String(id))}
            height={360}
          />
        </>
      ) : null}
    </div>
  );
}

