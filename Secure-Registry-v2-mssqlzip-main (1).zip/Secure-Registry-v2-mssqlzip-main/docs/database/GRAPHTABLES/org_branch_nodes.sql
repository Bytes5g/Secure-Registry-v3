USE [secure_registry_v4]
GO

-- 1. حذف الجداول القديمة
IF OBJECT_ID('dbo.tge_org_branch_edges', 'U') IS NOT NULL DROP TABLE dbo.tge_org_branch_edges;
IF OBJECT_ID('dbo.tgn_org_branch_nodes', 'U') IS NOT NULL DROP TABLE dbo.tgn_org_branch_nodes;
GO

-- 2. إنشاء جدول العقد (Nodes) لتمثيل "تواجد وحدة في فرع"
CREATE TABLE dbo.tgn_org_branch_nodes
(
    node_internal_id INT NOT NULL,     -- المعرف id من org_branch_nodes
    org_id INT NULL,
    org_structure_node_id INT NULL,    -- كود الوحدة التنظيمية (إدارة، شعبة، إلخ)
    branch_id INT NULL,                -- كود الفرع (مركز، محافظة، مديرية)
    is_active BIT NULL,
    created_at DATETIME NULL,
    created_by INT NULL,
    updated_at DATETIME NULL,
    updated_by INT NULL,
    is_deleted BIT NULL,
    work_context_by INT NOT NULL,


    INDEX ix_graphid UNIQUE ($node_id),
    INDEX ix_internal_id (node_internal_id)
) AS NODE;
GO

ALTER TABLE dbo.tgn_org_branch_nodes
ADD CONSTRAINT FK_tgn_org_branch_nodes_work_context_by
FOREIGN KEY (work_context_by) REFERENCES dbo.org_branch_nodes(id);
GO

-- 3. إنشاء جدول الحواف (Edges) لتمثيل العلاقات المصفوفة
CREATE TABLE dbo.tge_org_branch_edges
(
    relation_type NVARCHAR(50) NOT NULL, -- 'Administrative' (رأسي) أو 'Geographic' (أفقي)
    work_context_by INT NOT NULL,
    created_at DATETIME NULL,
    created_by INT NULL,

    INDEX ix_edge_graphid UNIQUE ($edge_id),
    INDEX ix_fromid ($from_id, $to_id),
    INDEX ix_toid ($to_id, $from_id)
) AS EDGE;
GO
USE [secure_registry_v4]
GO
/****** Object:  Trigger [dbo].[trg_Sync_Org_Hierarchy_FullMatrix]    Script Date: 2026-05-13 11:19:56 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

ALTER   TRIGGER [dbo].[trg_Sync_Org_Hierarchy_FullMatrix]
ON [dbo].[org_branch_nodes]
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;
    -- هذا الشرط يمنع تكرار التنفيذ إذا حدث تداخل/تشغيل متسلسل للتريقر داخل نفس العملية
    IF TRIGGER_NESTLEVEL() > 1 RETURN;

    -- أولاً: معالجة الحذف
    IF EXISTS (SELECT * FROM deleted) AND NOT EXISTS (SELECT * FROM inserted)
    BEGIN
        DELETE FROM dbo.tge_org_branch_edges 
        WHERE $from_id IN (SELECT $node_id FROM dbo.tgn_org_branch_nodes WHERE node_internal_id IN (SELECT id FROM deleted))
           OR $to_id IN (SELECT $node_id FROM dbo.tgn_org_branch_nodes WHERE node_internal_id IN (SELECT id FROM deleted));

        DELETE FROM dbo.tgn_org_branch_nodes WHERE node_internal_id IN (SELECT id FROM deleted);
    END

    -- ثانياً: معالجة الإضافة والتحديث
    IF EXISTS (SELECT * FROM inserted)
    BEGIN
        DECLARE @affected TABLE (id INT NOT NULL PRIMARY KEY);
        INSERT INTO @affected (id)
        SELECT DISTINCT id FROM inserted;

        -- مزامنة العقد
        MERGE dbo.tgn_org_branch_nodes AS target
        USING (
          SELECT
            id,
            org_id,
            org_structure_node_id,
            branch_id,
            is_active,
            created_at,
            created_by,
            updated_at,
            updated_by,
            is_deleted,
            work_context_by
          FROM inserted
        ) AS source
        ON (target.node_internal_id = source.id)
        WHEN MATCHED THEN
            UPDATE SET target.org_id = source.org_id,
                       target.org_structure_node_id = source.org_structure_node_id,
                       target.branch_id = source.branch_id,
                       target.is_active = source.is_active,
                       target.created_at = COALESCE(target.created_at, source.created_at),
                       target.created_by = COALESCE(target.created_by, source.created_by),
                       target.updated_at = source.updated_at,
                       target.updated_by = source.updated_by,
                       target.is_deleted = source.is_deleted,
                       target.work_context_by = COALESCE(source.work_context_by, source.id)
        WHEN NOT MATCHED THEN
            INSERT (
              node_internal_id,
              org_id,
              org_structure_node_id,
              branch_id,
              is_active,
              created_at,
              created_by,
              updated_at,
              updated_by,
              is_deleted,
              work_context_by
            )
            VALUES (
              source.id,
              source.org_id,
              source.org_structure_node_id,
              source.branch_id,
              source.is_active,
              source.created_at,
              source.created_by,
              source.updated_at,
              source.updated_by,
              source.is_deleted,
              COALESCE(source.work_context_by, source.id)
            );

        -- تنظيف العلاقات للسجلات المتأثرة
        DELETE FROM dbo.tge_org_branch_edges 
        WHERE $from_id IN (SELECT $node_id FROM dbo.tgn_org_branch_nodes WHERE node_internal_id IN (SELECT id FROM @affected))
           OR $to_id IN (SELECT $node_id FROM dbo.tgn_org_branch_nodes WHERE node_internal_id IN (SELECT id FROM @affected));

        -- أ. بناء التبعية الإدارية (رأسياً): قطاع -> دائرة -> شعبة -> إدارة
        -- يغطي التبعية داخل نفس الفرع أو من مديرية لمحفظة
        INSERT INTO dbo.tge_org_branch_edges ($from_id, $to_id, relation_type, work_context_by, created_at, created_by)
        SELECT DISTINCT p.$node_id, c.$node_id, 'Administrative', COALESCE(c.work_context_by, c.node_internal_id), GETDATE(), c.created_by
        FROM dbo.tgn_org_branch_nodes c
        JOIN dbo.org_entity_structure s ON c.org_structure_node_id = s.id
        JOIN dbo.tgn_org_branch_nodes p ON s.parent_id = p.org_structure_node_id
        JOIN dbo.org_branches bc ON c.branch_id = bc.id
        JOIN dbo.org_branches bp ON p.branch_id = bp.id
        WHERE (bc.id = bp.id OR bc.parent_branch_id = bp.id) -- يدعم نفس الفرع أو تبعية المديرية للمحافظة
          AND ISNULL(c.is_deleted, 0) = 0 AND ISNULL(c.is_active, 1) = 1
          AND ISNULL(p.is_deleted, 0) = 0 AND ISNULL(p.is_active, 1) = 1
          AND (
            c.node_internal_id IN (SELECT id FROM @affected)
            OR p.node_internal_id IN (SELECT id FROM @affected)
          )
         
          ;

        -- ب. بناء الامتداد الجغرافي (أفقياً): من المركز الرئيسي للفروع
        INSERT INTO dbo.tge_org_branch_edges ($from_id, $to_id, relation_type, work_context_by, created_at, created_by)
        SELECT DISTINCT p.$node_id, c.$node_id, 'Geographic', COALESCE(p.work_context_by, p.node_internal_id), GETDATE(), p.created_by
        FROM dbo.tgn_org_branch_nodes p
        JOIN dbo.tgn_org_branch_nodes c ON p.org_structure_node_id = c.org_structure_node_id
        JOIN dbo.org_branches b ON p.branch_id = b.id
        WHERE b.branch_scope_lookup_id = 4 -- المركز الرئيسي
          AND p.branch_id <> c.branch_id
          AND ISNULL(c.is_deleted, 0) = 0 AND ISNULL(c.is_active, 1) = 1
          AND ISNULL(p.is_deleted, 0) = 0 AND ISNULL(p.is_active, 1) = 1
          AND (
            c.node_internal_id IN (SELECT id FROM @affected)
            OR p.node_internal_id IN (SELECT id FROM @affected)
          );
    END
END;
GO

USE [secure_registry_v4]
GO

-- تنظيف الجدول قبل الإدراج لضمان عدم التكرار
TRUNCATE TABLE dbo.tgn_org_branch_nodes;
GO

-- إدراج البيانات من الجدول الأساسي
INSERT INTO dbo.tgn_org_branch_nodes 
(
    node_internal_id, 
    org_id, 
    org_structure_node_id, 
    branch_id, 
    is_active,
    created_at,
    created_by,
    updated_at,
    updated_by,
    is_deleted,
    work_context_by
)
SELECT 
    id, 
    org_id, 
    org_structure_node_id, 
    branch_id, 
    is_active,
    created_at,
    created_by,
    updated_at,
    updated_by,
    is_deleted,
    COALESCE(work_context_by, id)
FROM dbo.org_branch_nodes
WHERE is_deleted = 0; -- إدراج السجلات غير المحذوفة فقط

--------
----------
-- بناء العلاقات الإدارية صعوداً (داخل نفس الفرع أو للمديريات)
INSERT INTO dbo.tge_org_branch_edges ($from_id, $to_id, relation_type, 
    work_context_by, created_at, created_by)
SELECT DISTINCT p.$node_id, c.$node_id, 'Administrative', 
    COALESCE(c.work_context_by, c.node_internal_id), GETDATE(), c.created_by
FROM dbo.tgn_org_branch_nodes c
JOIN dbo.org_entity_structure s ON c.org_structure_node_id = s.id
JOIN dbo.tgn_org_branch_nodes p ON s.parent_id = p.org_structure_node_id
JOIN dbo.org_branches bc ON c.branch_id = bc.id
JOIN dbo.org_branches bp ON p.branch_id = bp.id
WHERE (bc.id = bp.id OR bc.parent_branch_id = bp.id) 
  ;

-- بناء علاقات الامتداد الجغرافي (من المركز الرئيسي للفروع)
INSERT INTO dbo.tge_org_branch_edges ($from_id, $to_id, relation_type, 
    work_context_by, created_at, created_by)
SELECT DISTINCT p.$node_id, c.$node_id, 'Geographic', 
    COALESCE(p.work_context_by, p.node_internal_id), GETDATE(), p.created_by
FROM dbo.tgn_org_branch_nodes p
JOIN dbo.tgn_org_branch_nodes c ON p.org_structure_node_id = c.org_structure_node_id
JOIN dbo.org_branches b ON p.branch_id = b.id
WHERE b.branch_scope_lookup_id = 4 -- المركز الرئيسي حسب ملفاتك
  AND p.branch_id <> c.branch_id
  ;
GO
-----------
-----------
GO
WITH OrgPathCTE AS (
    -- 1. نقطة البداية (الوحدة التي تريد تتبعها)
    SELECT 
        node_internal_id,
        org_structure_node_id,
        branch_id,
        CAST(node_internal_id AS NVARCHAR(MAX)) AS PathIDs,
        1 AS Level,
        $node_id AS CurrentNodeID
    FROM dbo.tgn_org_branch_nodes

    UNION ALL

    -- 2. الربط التكراري صعوداً للأعلى (Administrative Hierarchy)
    SELECT 
        p.node_internal_id,
        p.org_structure_node_id,
        p.branch_id,
        CTE.PathIDs + ' -> ' + CAST(p.node_internal_id AS NVARCHAR(MAX)),
        CTE.Level + 1,
        p.$node_id
    FROM dbo.tgn_org_branch_nodes p
    JOIN dbo.tge_org_branch_edges e ON e.$to_id = p.$node_id
    JOIN OrgPathCTE CTE ON e.$from_id = CTE.CurrentNodeID
    WHERE e.relation_type = 'Administrative'
)
-- 3. عرض النتيجة النهائية مع الأسماء من الجداول الأصلية
SELECT 
    CTE.Level,
    CTE.PathIDs AS [مسار الأرقام],
    S.name AS [اسم الوحدة],
    B.name AS [الفرع الجغرافي]
FROM OrgPathCTE CTE
JOIN dbo.org_entity_structure S ON CTE.org_structure_node_id = S.id
JOIN dbo.org_branches B ON CTE.branch_id = B.id
ORDER BY CTE.Level DESC; -- يعرض أعلى سلطة أولاً
GO
