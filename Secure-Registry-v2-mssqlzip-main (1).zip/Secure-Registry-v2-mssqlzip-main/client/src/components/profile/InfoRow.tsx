import type { ReactNode } from "react";

export interface InfoRowProps {
  label: string;
  children: ReactNode;
  labelMinWidth?: string;
  className?: string;
}

/**
 * Generic label/value row used inside any profile/overview card.
 * Pure presentation — no logic, no entity-specific knowledge.
 */
export function InfoRow({
  label,
  children,
  labelMinWidth = "7rem",
  className = "",
}: InfoRowProps) {
  return (
    <div
      className={`flex items-start justify-between gap-4 py-2 border-b last:border-0 ${className}`}
    >
      <span className="text-sm text-muted-foreground" style={{ minWidth: labelMinWidth }}>
        {label}
      </span>
      <div className="text-sm font-medium text-end flex-1">{children}</div>
    </div>
  );
}
