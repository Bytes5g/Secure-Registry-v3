import fs from "fs";
import path from "path";
import type { Request } from "express";
import multer from "multer";
import { entityFilesModule, filesModule, foldersModule, settingsModule, withTransaction } from "@core/database";
import { assertDetectedMime, buildPublicFileUrl, deleteAbsoluteFileSafely, deleteStoredFileByPublicUrl, getLocalStorage } from "../../files/storage";
import { requireWriteContext } from "../_internals";

export type OrgMediaKind = "logo" | "cover";

const localStorage = getLocalStorage();
const tempRelativeDirectory = "_tmp/org-media";
const tempUploadDirectory = localStorage.resolveAbsolutePath(tempRelativeDirectory);

if (!fs.existsSync(tempUploadDirectory)) {
  fs.mkdirSync(tempUploadDirectory, { recursive: true });
}

export function parseOrgId(req: Request): number {
  const orgId = Number((req.params as any).id);
  if (!Number.isInteger(orgId) || orgId <= 0) {
    throw new Error("Invalid organization ID");
  }
  return orgId;
}

export function createOrgMediaUploader(maxFileSizeBytes: number, fieldName: string) {
  const upload = multer({
    storage: multer.diskStorage({
      destination: (_req, _file, cb) => cb(null, tempUploadDirectory),
      filename: (_req, file, cb) => {
        const uniqueSuffix = `${Date.now()}-${Math.round(Math.random() * 1e9)}`;
        cb(null, `${uniqueSuffix}${path.extname(file.originalname)}`);
      },
    }),
    limits: { fileSize: maxFileSizeBytes },
  });
  return upload.single(fieldName);
}

export async function ensureOrgMediaFolderId(orgId: number, kind: OrgMediaKind): Promise<number> {
  throw new Error("ensureOrgMediaFolderId requires write context. Use ensureOrgMediaFolderIdWithContext.");
}

// هذه الدالة تضمن مسار مجلد وسائط الجهة مع تمرير workContextBy و createdBy إلى طبقة البيانات
export async function ensureOrgMediaFolderIdWithContext(
  orgId: number,
  kind: OrgMediaKind,
  ctx: { workContextBy: number; createdBy: number },
): Promise<number> {
  const root = await foldersModule.ensureFolderPath(["الجهات", `org_${orgId}`, kind], ctx);
  return root.id;
}

export async function createOrgMediaFile(params: {
  orgId: number;
  kind: OrgMediaKind;
  absoluteTempFilePath: string;
  originalName: string;
  declaredMime: string | undefined;
  size: number;
  description?: string | null;
}): Promise<{ fileId: number; publicUrl: string }> {
  throw new Error("createOrgMediaFile requires request-scoped write context. Use createOrgMediaFileFromRequest.");
}

export async function createOrgMediaFileFromRequest(
  req: Request,
  params: {
    orgId: number;
    kind: OrgMediaKind;
    absoluteTempFilePath: string;
    originalName: string;
    declaredMime: string | undefined;
    size: number;
    description?: string | null;
  },
): Promise<{ fileId: number; publicUrl: string }> {
  const writeCtx = await requireWriteContext(req);
  const allowed = ["image/jpeg", "image/png", "image/webp"];
  const detectedMime = await assertDetectedMime(params.absoluteTempFilePath, allowed, params.declaredMime);
  const settings = await settingsModule.getFileUploadSettings();
  const folderId = await ensureOrgMediaFolderIdWithContext(params.orgId, params.kind, {
    workContextBy: writeCtx.workContextBy,
    createdBy: writeCtx.userId,
  });

  const relativeDirectory = settings.relativeDirectory || "files";
  const folderKey = `folder-${folderId}`;
  await localStorage.ensureDirectory(`${relativeDirectory}/${folderKey}`);

  const storedRelativePath = `${relativeDirectory}/${folderKey}/${path.basename(params.absoluteTempFilePath)}`;
  await localStorage.moveFromTemp(params.absoluteTempFilePath, storedRelativePath);

  const created = await filesModule.createFile({
    storage: "local",
    filenameDisk: storedRelativePath,
    filenameDownload: params.originalName,
    title: params.originalName,
    type: detectedMime,
    folder: folderId,
    uploadedBy: null,
    modifiedBy: null,
    charset: null,
    filesize: params.size,
    width: null,
    height: null,
    duration: null,
    embed: null,
    description: params.description ?? null,
    location: buildPublicFileUrl(storedRelativePath),
    tags: null,
    metadata: null,
    focalPointX: null,
    focalPointY: null,
    tusId: null,
    tusData: null,
    uploadedOn: new Date().toISOString(),
    workContextBy: writeCtx.workContextBy,
    createdBy: writeCtx.userId,
    isActive: true,
    isDeleted: false,
  });

  return { fileId: created.id, publicUrl: created.location ?? buildPublicFileUrl(storedRelativePath) };
}

export async function getPrimaryOrgMedia(orgId: number, kind: OrgMediaKind) {
  return entityFilesModule.getPrimaryLinkedFile("org_entities", orgId, kind);
}

export async function setPrimaryOrgMedia(orgId: number, kind: OrgMediaKind, fileId: number) {
  throw new Error("setPrimaryOrgMedia requires request-scoped write context. Use setPrimaryOrgMediaFromRequest.");
}

// هذه الدالة تربط ملف كملف أساسي للجهة مع تمرير workContextBy و createdBy المستخرجة من session
export async function setPrimaryOrgMediaFromRequest(req: Request, orgId: number, kind: OrgMediaKind, fileId: number) {
  const writeCtx = await requireWriteContext(req);
  return entityFilesModule.linkFileWithContext(
    { entityType: "org_entities", entityId: orgId, role: kind, fileId, isPrimary: true },
    {
      workContextBy: writeCtx.workContextBy,
      createdBy: writeCtx.userId,
    },
  );
}

export async function deletePrimaryOrgMedia(orgId: number, kind: OrgMediaKind): Promise<boolean> {
  const existing = await getPrimaryOrgMedia(orgId, kind);
  if (!existing) return false;

  await withTransaction(async (tx) => {
    await entityFilesModule.deleteLink(existing.link.id, tx);
    await filesModule.deleteFile(existing.file.id, tx);
  });

  if (existing.file.location) {
    await deleteStoredFileByPublicUrl(existing.file.location);
  } else if (existing.file.filenameDisk) {
    await localStorage.delete(existing.file.filenameDisk);
  }

  return true;
}

export async function cleanupTempFile(absoluteTempFilePath: string | undefined) {
  if (!absoluteTempFilePath) return;
  await deleteAbsoluteFileSafely(absoluteTempFilePath);
}
