# فهرس توثيق التحليل والمقترحات

هذا المجلد يجمع وثائق التحليل/التصميم/الحوكمة وخطة التنفيذ للمشروع.

## محتويات المجلد

1. [01-project-analysis.md](./01-project-analysis.md)
   - نظرة عامة على المشروع وبنيته الحالية ومسارات تدفق العمل بين الواجهة والخادم وطبقة قاعدة البيانات.
2. [02-structure-audit.md](./02-structure-audit.md)
   - تدقيق تنظيم الملفات، نقاط القوة والضعف، التكرارات، والتعارضات الحالية.
3. [03-permissions-governance-blueprint.md](./03-permissions-governance-blueprint.md)
   - تصور شامل ومرن لوحدة إدارة الصلاحيات والإجراءات والأدوار والسياسات متعددة المستويات.
4. [04-data-governance-and-temporal-standards.md](./04-data-governance-and-temporal-standards.md)
   - معايير الجداول، التدقيق، النسخ التاريخية، الحذف المنطقي، وقواعد عدم التكرار.
5. [05-execution-roadmap.md](./05-execution-roadmap.md)
   - خطة مرحلية لتنفيذ المقترحات لاحقاً بشكل تدريجي ومنضبط.
6. [frontend-modules/README.md](./frontend-modules/README.md)
   - فهرس مجلد توثيق تطوير الواجهة الأمامية وتقسيم الوحدات.
7. [frontend-modules/03-dynamic-ui-libraries-and-components.md](./frontend-modules/03-dynamic-ui-libraries-and-components.md)
   - مرجع تفصيلي للمكتبات والمكونات المقترحة للبناء الديناميكي ومسارات استخدامها.
8. [work-notes/ui-registry-builder-notes.md](./work-notes/ui-registry-builder-notes.md)
   - ملاحظات تنفيذ متغيرة خاصة بتأسيس UI Registry/Builder (ليست وثيقة معمارية نهائية).
9. [work-notes/progress.md](./work-notes/progress.md)
   - سجل الإنجاز المختصر (ما تم تنفيذه فعلياً) مع نقاط تحقق ومخاطر ظاهرة.

## مبادئ إعداد هذا التوثيق

- الاعتماد على تحليل البنية الحالية في المستودع قبل اقتراح أي توسعة.
- عدم تكرار الملاحظات بين الملفات إلا عند الحاجة للربط المرجعي.
- اعتبار قاعدة البيانات و`sys_action_types` والحقول `entry_*` وحقول التدقيق مرجعاً حاكماً للتصميم المستقبلي.
- دعم الجهة المالكة للنظام مع المحافظة على عزل الفروع والاختصاص التشغيلي.
