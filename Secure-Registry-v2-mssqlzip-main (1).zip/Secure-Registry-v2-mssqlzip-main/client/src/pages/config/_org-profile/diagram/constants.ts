export const BRANCH_NODE_COLOR = "#f97316";

export const TIDY_LAYOUT_OPTIONS = {
  nodeWidth: 260,
  nodeHeight: 72,
  levelGap: 110,
  siblingGap: 40,
} as const;

export const BRANCH_NODE_OFFSET_X = 320;
export const BRANCH_NODE_OFFSET_Y = 92;
