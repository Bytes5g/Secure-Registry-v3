import { useMemo } from "react";
import {
  EntityContentCard,
  EntityRelationsTabs,
} from "@secure-registry/components-ui";
import { GenericEntityPage } from "@/components/generic/GenericEntityPage";
import { FILES_CONFIG } from "./_files/config";
import { useFilesPage } from "./_files/useFilesPage";
import { ExplorerTab } from "./_files/ExplorerTab";
import { SettingsTab } from "./_files/SettingsTab";
import { UploadTab } from "./_files/UploadTab";

export default function FilesManagementPage() {
  const ctrl = useFilesPage();

  const tabs = useMemo(
    () => [
      { value: "explorer", label: "المتصفح", content: <ExplorerTab ctrl={ctrl} /> },
      { value: "settings", label: "إعدادات الرفع", content: <SettingsTab ctrl={ctrl} /> },
      {
        value: "list",
        label: "سجل الملفات",
        content: (
          <GenericEntityPage
            entityType="files"
            pageCode="files_management"
            staticConfig={FILES_CONFIG}
            hideTitle={true}
          />
        ),
      },
      { value: "upload", label: "رفع ملف", content: <UploadTab ctrl={ctrl} /> },
    ],
    [ctrl],
  );

  return (
    <div className="p-6" dir="rtl">
      <EntityContentCard contentClassName="p-6">
        <EntityRelationsTabs
          tabs={tabs}
          defaultValue="explorer"
          direction="rtl"
          tabsListClassName="mb-4 w-full overflow-x-auto"
        />
      </EntityContentCard>
    </div>
  );
}
