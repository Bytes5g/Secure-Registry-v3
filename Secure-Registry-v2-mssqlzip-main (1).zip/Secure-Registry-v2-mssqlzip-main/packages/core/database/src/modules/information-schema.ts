import { createRequest } from "../config/connection";

export type InformationSchemaColumn = {
  columnName: string;
  dataType: string;
  isNullable: boolean;
  columnDefault: string | null;
  characterMaximumLength: number | null;
};

export async function getInformationSchemaColumns(input: {
  tableName: string;
  schemaName?: string;
}): Promise<InformationSchemaColumn[]> {
  const request = await createRequest();
  request.input("tableName", input.tableName);
  request.input("schemaName", input.schemaName ?? null);

  const result = await request.query<{
    column_name: string;
    data_type: string;
    is_nullable: string | boolean;
    column_default: string | null;
    character_maximum_length: string | number | null;
  }>(
    `SELECT
       column_name,
       data_type,
       is_nullable,
       column_default,
       character_maximum_length
     FROM information_schema.columns
     WHERE table_name = @tableName
       AND (@schemaName IS NULL OR table_schema = @schemaName)
     ORDER BY ordinal_position`,
  );

  return result.recordset.map((row) => ({
    columnName: String(row.column_name),
    dataType: String(row.data_type),
    isNullable: String(row.is_nullable).toUpperCase() === "YES" || Boolean(row.is_nullable),
    columnDefault: row.column_default == null ? null : String(row.column_default),
    characterMaximumLength: row.character_maximum_length == null ? null : Number(row.character_maximum_length),
  }));
}
