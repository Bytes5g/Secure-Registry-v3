import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { genericApi } from "@/lib/api/generic";
import { useUnifiedLookups } from "@/hooks/useUnifiedLookups";
import { useToast } from "@/hooks/use-toast";
import type { UiPageConfig } from "@/types/ui";

interface UseGenericEntityProps {
  entityType: string;
  apiParams?: Record<string, any>;
  defaultValues?: Record<string, any>;
  onMutationSuccess?: (data: any) => void;
  staticConfig?: UiPageConfig;
}

export function useGenericEntity({
  entityType,
  apiParams,
  defaultValues,
  onMutationSuccess,
  staticConfig,
}: UseGenericEntityProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [selectedItem, setSelectedItem] = useState<any>(null);
  const [serverErrors, setServerErrors] = useState<Record<string, string>>({});

  const applyValidationDetails = (details: unknown) => {
    if (!Array.isArray(details)) return false;
    const nextErrors: Record<string, string> = {};
    for (const issue of details as any[]) {
      const path = Array.isArray(issue?.path) ? issue.path : [];
      const key = path.length > 0 ? String(path[0]) : "";
      const message = typeof issue?.message === "string" ? issue.message : "قيمة غير صالحة";
      if (key) nextErrors[key] = message;
    }
    if (Object.keys(nextErrors).length === 0) return false;
    setServerErrors(nextErrors);
    return true;
  };

  // Fetch Entity Data
  const { data: entities = [], isLoading: isLoadingData } = useQuery({
    queryKey: [entityType, apiParams],
    queryFn: () => genericApi.getAll(entityType, apiParams),
  });

  // Fetch DB Meta (if needed)
  const { data: dbMeta = [], isLoading: isLoadingMeta } = useQuery({
    queryKey: ["db-meta", entityType],
    enabled: !(staticConfig?.columns && staticConfig.columns.length > 0),
    queryFn: () => genericApi.getDbMeta(entityType), // Assuming getDbMeta is added to genericApi or we import fetchDbTableMeta
  });

  // Fetch Lookups
  const { lookups: lookupTypes, isLoading: isLoadingLookups } = useUnifiedLookups();

  // Helper for duplicate errors
  const handleDuplicateError = (error: any) => {
    let fieldName = "";
    if (error.details) {
      const match = error.details.match(/Key \(([^)]+)\)=/);
      if (match && match[1]) {
        fieldName = match[1];
      }
    }

    if (fieldName) {
      setServerErrors({
        [fieldName]: "هذه القيمة موجودة مسبقاً",
        [fieldName.replace(/_([a-z])/g, (g) => g[1].toUpperCase())]: "هذه القيمة موجودة مسبقاً"
      });
      toast({ title: "بيانات مكررة", description: `القيمة في الحقل "${fieldName}" موجودة مسبقاً`, variant: "destructive" });
    } else {
      toast({ title: "بيانات مكررة", description: error.message, variant: "destructive" });
    }
  };

  // Mutations
  const createMutation = useMutation({
    mutationFn: (data: any) => genericApi.create(entityType, { ...defaultValues, ...data }),
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: [entityType] });
      if (onMutationSuccess) onMutationSuccess(data);
      setIsDialogOpen(false);
      setServerErrors({});
      toast({ title: "تمت العملية بنجاح", description: "تم إضافة السجل الجديد" });
    },
    onError: (error: any) => {
      setServerErrors({});
      if (error.code === 'DUPLICATE_ENTRY') {
        handleDuplicateError(error);
      } else if (error.status === 400) {
        const mapped = applyValidationDetails(error.details);
        toast({
          title: "خطأ في البيانات",
          description: mapped ? "يرجى مراجعة الحقول المعلّمة بالأحمر" : "يرجى التأكد من صحة البيانات المدخلة",
          variant: "destructive",
        });
      } else {
        toast({ title: "خطأ", description: error.message || "حدث خطأ غير معروف", variant: "destructive" });
      }
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }: { id: number | string; data: any }) =>
      genericApi.update(entityType, id, data),
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: [entityType] });
      if (onMutationSuccess) onMutationSuccess(data);
      setIsDialogOpen(false);
      setSelectedItem(null);
      setServerErrors({});
      toast({ title: "تمت العملية بنجاح", description: "تم تحديث السجل" });
    },
    onError: (error: any) => {
      setServerErrors({});
      if (error.code === 'DUPLICATE_ENTRY') {
        handleDuplicateError(error);
      } else if (error.status === 400) {
        const mapped = applyValidationDetails(error.details);
        toast({
          title: "خطأ في البيانات",
          description: mapped ? "يرجى مراجعة الحقول المعلّمة بالأحمر" : "يرجى التأكد من صحة البيانات المدخلة",
          variant: "destructive",
        });
      } else {
        toast({ title: "خطأ", description: error.message || "حدث خطأ غير معروف", variant: "destructive" });
      }
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id: number | string) => genericApi.delete(entityType, id),
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: [entityType] });
      if (onMutationSuccess) onMutationSuccess(data);
      setIsDeleteDialogOpen(false);
      setSelectedItem(null);
      toast({ title: "تمت العملية بنجاح", description: "تم حذف السجل" });
    },
    onError: (error: any) => {
      if (error.code === 'DUPLICATE_ENTRY') {
        toast({ title: "بيانات مكررة", description: error.message, variant: "destructive" });
      } else if (error.status === 400) {
        toast({ title: "خطأ في البيانات", description: "يرجى التأكد من صحة البيانات المدخلة", variant: "destructive" });
      } else {
        toast({ title: "خطأ", description: error.message || "حدث خطأ غير معروف", variant: "destructive" });
      }
    },
  });

  return {
    entities,
    dbMeta,
    isLoading: isLoadingData || isLoadingMeta || isLoadingLookups,
    lookupTypes,
    isDialogOpen,
    setIsDialogOpen,
    isDeleteDialogOpen,
    setIsDeleteDialogOpen,
    selectedItem,
    setSelectedItem,
    serverErrors,
    createMutation,
    updateMutation,
    deleteMutation,
  };
}
