import { z } from "zod";
import type { LookupValue } from "./lookups";

const nullableInt = z.number().int().nullable();
const nullableString = z.string().nullable();

export const organizationalStructureSchema = z.object({
  id: z.number().int(),
  name: z.string().min(1),
  code: z.string().min(1),
  sectorId: nullableInt,
  locationId: nullableInt,
  categoryId: nullableInt,
  parentId: nullableInt,
  isActive: z.boolean(),
  orderIndex: z.number().int(),
  createdAt: nullableString,
});
export type OrganizationalStructure = z.infer<typeof organizationalStructureSchema>;

export const insertOrganizationalStructureSchema = z.object({
  name: z.string().min(1),
  code: z.string().min(1),
  sectorId: nullableInt.optional().default(null),
  locationId: nullableInt.optional().default(null),
  categoryId: nullableInt.optional().default(null),
  parentId: nullableInt.optional().default(null),
  isActive: z.boolean().optional().default(true),
  orderIndex: z.number().int().optional().default(0),
});
export type InsertOrganizationalStructure = z.input<typeof insertOrganizationalStructureSchema>;

export const orgStructureTreeSchema = z.object({
  id: z.number().int(),
  parentId: nullableInt,
  orgId: z.number().int(),
  name: z.string().min(1),
  code: z.string().min(1),
  structureId: nullableInt,
  isActive: z.boolean(),
  orderIndex: z.number().int(),
  level: z.number().int(),
  createdAt: nullableString,
});
export type OrgStructureTree = z.infer<typeof orgStructureTreeSchema>;

export const insertOrgStructureTreeSchema = z.object({
  parentId: nullableInt.optional().default(null),
  orgId: z.number().int(),
  name: z.string().min(1),
  code: z.string().min(1),
  structureId: nullableInt.optional().default(null),
  isActive: z.boolean().optional().default(true),
  orderIndex: nullableInt.optional().default(null),
  level: nullableInt.optional().default(null),
});
export type InsertOrgStructureTree = z.input<typeof insertOrgStructureTreeSchema>;

export const orgBranchSchema = z.object({
  id: z.number().int(),
  orgId: z.number().int(),
  geoUnitId: nullableInt,
  branchScopeLookupId: nullableInt,
  parentBranchId: nullableInt,
  name: z.string().min(1),
  code: nullableString,
  isActive: z.boolean(),
  metadata: z.unknown().nullable(),
  createdAt: nullableString,
  standardId: nullableInt,
});
export type OrgBranch = z.infer<typeof orgBranchSchema>;

export const insertOrgBranchesSchema = z.object({
  orgId: z.number().int(),
  geoUnitId: z.number().int().min(1),
  branchScopeLookupId: nullableInt.optional().default(null),
  parentBranchId: nullableInt.optional().default(null),
  name: z.string().min(1),
  code: nullableString.optional().default(null),
  isActive: z.boolean().optional().default(true),
  metadata: z.unknown().nullable().optional().default(null),
  standardId: nullableInt.optional().default(null),
});
export type InsertOrgBranches = z.input<typeof insertOrgBranchesSchema>;

export const orgBranchNodeSchema = z.object({
  id: z.number().int(),
  orgId: z.number().int(),
  orgStructureNodeId: z.number().int(),
  branchId: z.number().int(),
  isActive: z.boolean(),
  createdAt: nullableString,
});
export type OrgBranchNode = z.infer<typeof orgBranchNodeSchema>;

export const insertOrgBranchNodesSchema = z.object({
  orgId: z.number().int(),
  orgStructureNodeId: z.number().int(),
  branchId: z.number().int(),
  isActive: z.boolean().optional().default(true),
});
export type InsertOrgBranchNodes = z.input<typeof insertOrgBranchNodesSchema>;

export const orgLogoSchema = z.object({
  id: z.number().int(),
  orgId: z.number().int(),
  filePath: z.string().min(1),
  fileName: nullableString,
  mimeType: nullableString,
  size: z.number().int().nullable(),
  isPrimary: z.boolean(),
  description: nullableString,
  createdAt: nullableString,
});
export type OrgLogo = z.infer<typeof orgLogoSchema>;

export const insertOrgLogoSchema = z.object({
  orgId: z.number().int(),
  filePath: z.string().min(1),
  fileName: nullableString.optional().default(null),
  mimeType: nullableString.optional().default(null),
  size: z.number().int().nullable().optional().default(null),
  isPrimary: z.boolean().optional().default(true),
  description: nullableString.optional().default(null),
});
export type InsertOrgLogo = z.input<typeof insertOrgLogoSchema>;

export const orgCoverSchema = z.object({
  id: z.number().int(),
  orgId: z.number().int(),
  filePath: z.string().min(1),
  fileName: nullableString,
  mimeType: nullableString,
  size: z.number().int().nullable(),
  isPrimary: z.boolean(),
  description: nullableString,
  createdAt: nullableString,
});
export type OrgCover = z.infer<typeof orgCoverSchema>;

export const insertOrgCoverSchema = z.object({
  orgId: z.number().int(),
  filePath: z.string().min(1),
  fileName: nullableString.optional().default(null),
  mimeType: nullableString.optional().default(null),
  size: z.number().int().nullable().optional().default(null),
  isPrimary: z.boolean().optional().default(true),
  description: nullableString.optional().default(null),
});
export type InsertOrgCover = z.input<typeof insertOrgCoverSchema>;

export type OrganizationalStructureWithDetails = OrganizationalStructure & {
  sector?: LookupValue;
  location?: LookupValue;
  category?: LookupValue;
  children?: OrganizationalStructureWithDetails[];
};

export type OrgStructureTreeWithChildren = OrgStructureTree & {
  structure?: LookupValue;
  children?: OrgStructureTreeWithChildren[];
};
