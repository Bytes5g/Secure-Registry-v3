import { useEffect, useRef, type ReactNode } from "react"
import {
  Background,
  BackgroundVariant,
  MarkerType,
  Controls,
  MiniMap,
  ReactFlow,
  ReactFlowProvider,
  useEdgesState,
  useNodesState,
  type Edge,
  type EdgeTypes,
  type Node,
  type NodeTypes,
  type ReactFlowProps,
} from "@xyflow/react"
import "@xyflow/react/dist/style.css"
import { cn } from "../lib/utils"

export interface FlowCanvasProps extends Omit<ReactFlowProps, "nodes" | "edges" | "nodeTypes" | "edgeTypes"> {
  nodes: Node[]
  edges: Edge[]
  nodeTypes?: NodeTypes
  edgeTypes?: EdgeTypes
  toolbar?: ReactNode
  className?: string
  canvasClassName?: string
  showMiniMap?: boolean
  showControls?: boolean
  showBackground?: boolean
  preserveNodePositions?: boolean
  forceSyncKey?: string | number
}

export function FlowCanvas({
  nodes,
  edges,
  nodeTypes,
  edgeTypes,
  toolbar,
  className,
  canvasClassName,
  showMiniMap = false,
  showControls = true,
  showBackground = true,
  preserveNodePositions = true,
  forceSyncKey,
  ...props
}: FlowCanvasProps) {
  const defaultEdgeOptions = props.defaultEdgeOptions ?? {
    type: "smoothstep",
    markerEnd: { type: MarkerType.ArrowClosed, width: 18, height: 18 },
    style: { strokeWidth: 2 },
  }

  const [nodesState, setNodesState, onNodesChange] = useNodesState(nodes)
  const [edgesState, setEdgesState, onEdgesChange] = useEdgesState(edges)
  const lastForceSyncKeyRef = useRef<string | number | undefined>(forceSyncKey)

  useEffect(() => {
    const force = forceSyncKey !== lastForceSyncKeyRef.current
    if (force) {
      lastForceSyncKeyRef.current = forceSyncKey
      setNodesState(nodes)
      return
    }

    if (!preserveNodePositions) {
      setNodesState(nodes)
      return
    }

    setNodesState((prev) => {
      if (prev.length === 0) return nodes

      // Only preserve user-dragged positions when the visible node set is
      // unchanged. If the membership differs (filter, focus, view-mode change),
      // accept the freshly-laid-out positions to avoid stale/overlapping nodes.
      const prevIds = new Set(prev.map((n) => n.id))
      const sameMembership =
        prev.length === nodes.length && nodes.every((n) => prevIds.has(n.id))
      if (!sameMembership) return nodes

      const prevById = new Map(prev.map((n) => [n.id, n]))
      return nodes.map((next) => {
        const current = prevById.get(next.id)
        if (!current) return next
        return { ...next, position: current.position }
      })
    })
  }, [forceSyncKey, nodes, preserveNodePositions, setNodesState])

  useEffect(() => {
    setEdgesState(edges)
  }, [edges, setEdgesState])

  return (
    <div className={cn("relative w-full overflow-hidden rounded-md border bg-background", className)} dir="ltr">
      {toolbar ? <div className="absolute top-2 left-2 z-10">{toolbar}</div> : null}
      <div className={cn("h-[640px] w-full", canvasClassName)}>
        <ReactFlowProvider>
          <ReactFlow
            nodes={nodesState}
            edges={edgesState}
            nodeTypes={nodeTypes}
            edgeTypes={edgeTypes}
            defaultEdgeOptions={defaultEdgeOptions}
            panOnScroll={props.panOnScroll ?? true}
            zoomOnScroll={props.zoomOnScroll ?? true}
            zoomOnPinch={props.zoomOnPinch ?? true}
            panOnDrag={props.panOnDrag ?? true}
            minZoom={props.minZoom ?? 0.15}
            maxZoom={props.maxZoom ?? 2}
            snapToGrid={props.snapToGrid ?? true}
            snapGrid={props.snapGrid ?? [10, 10]}
            onNodesChange={(changes) => {
              onNodesChange(changes)
              props.onNodesChange?.(changes)
            }}
            onEdgesChange={(changes) => {
              onEdgesChange(changes)
              props.onEdgesChange?.(changes)
            }}
            {...props}
          >
            {showBackground ? <Background variant={BackgroundVariant.Dots} gap={16} size={1.2} /> : null}
            {showControls ? <Controls /> : null}
            {showMiniMap ? <MiniMap pannable zoomable /> : null}
          </ReactFlow>
        </ReactFlowProvider>
      </div>
    </div>
  )
}
