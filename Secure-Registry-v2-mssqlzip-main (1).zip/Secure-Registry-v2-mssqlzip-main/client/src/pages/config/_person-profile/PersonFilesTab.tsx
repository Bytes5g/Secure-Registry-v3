import { useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { Badge, Button, EntityContentCard, type Column } from "@secure-registry/components-ui";
import { DataTable } from "@secure-registry/components-ui";
import { useMediaPreviewDialog } from "@secure-registry/components-ui";
import { fetchPersonFiles, type PersonLinkedFileItem } from "@/lib/api/persons-admin";

function formatBytes(value: number | null | undefined) {
  if (!value || value <= 0) return "—";
  const units = ["B", "KB", "MB", "GB"];
  let v = value;
  let i = 0;
  while (v >= 1024 && i < units.length - 1) {
    v /= 1024;
    i += 1;
  }
  return `${v.toFixed(i === 0 ? 0 : 1)} ${units[i]}`;
}

export function PersonFilesTab({ personId }: { personId: number }) {
  const { data = [], isLoading } = useQuery<PersonLinkedFileItem[]>({
    queryKey: ["person-files", personId],
    queryFn: () => fetchPersonFiles(personId),
    enabled: Number.isFinite(personId) && personId > 0,
  });

  const preview = useMediaPreviewDialog();

  const columns = useMemo<Column<PersonLinkedFileItem>[]>(
    () => [
      {
        key: "role",
        header: "الدور",
        width: "110px",
        render: (_, row) => <Badge variant="outline">{row.role}</Badge>,
      },
      {
        key: "fileName",
        header: "الملف",
        sortable: true,
        render: (_, row) => row.file.fileName ?? `#${row.file.id}`,
      },
      { key: "mimeType", header: "النوع", render: (_, row) => row.file.mimeType ?? "—" },
      { key: "size", header: "الحجم", render: (_, row) => formatBytes(row.file.size) },
      {
        key: "open",
        header: "",
        width: "90px",
        render: (_, row) =>
          row.file.filePath ? (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => {
                const mime = row.file.mimeType ?? null;
                const kind = mime?.startsWith("video/")
                  ? "video"
                  : mime?.startsWith("image/")
                    ? "image"
                    : "auto";
                preview.open({
                  url: row.file.filePath!,
                  title: row.file.title ?? row.file.fileName ?? `#${row.file.id}`,
                  mimeType: mime,
                  kind,
                });
              }}
            >
              معاينة
            </Button>
          ) : (
            <span className="text-muted-foreground">—</span>
          ),
      },
    ],
    [preview],
  );

  return (
    <EntityContentCard>
      <DataTable
        data={Array.isArray(data) ? data : []}
        columns={columns}
        isLoading={isLoading}
        emptyMessage="لا توجد ملفات مرتبطة بهذا الشخص"
      />
      {preview.dialog}
    </EntityContentCard>
  );
}
