
# 📜 **وثيقة ضبط الوكيل (Agent Enforcement Charter)**  
## **Architecture, Methodology & Code Discipline Rules**

هذه الوثيقة إلزامية، ويجب على الوكيل الالتزام بها بالكامل.  
أي خروج عنها يعتبر خطأ في التنفيذ ويجب التراجع عنه فوراً.

---

# 1) **مبدأ البناء العام (High-Level Principle)**

المشروع يُبنى وفق:

**DB → Registry → API → Runtime → Templates → UI**

وليس عبر صفحات React ثابتة أو CRUD مخصص.

---

# 2) **ممنوع منعاً باتاً**

## 2.1 **ممنوع إنشاء صفحات React جديدة**
لا يُسمح بإنشاء:

- صفحات Profile جديدة  
- صفحات Create/Edit  
- صفحات CRUD  
- صفحات List  
- صفحات Search  
- صفحات Details  
- صفحات Country/Type/Entity  

إلا إذا كانت صفحة نظامية (Login, Error, Builder, Dashboard).

**أي صفحة أخرى يجب أن تُبنى عبر UiRuntimePage + Templates فقط.**

---

## 2.2 **ممنوع إنشاء Routes جديدة**
لا يُسمح بإضافة أي Route جديد في:

- App.tsx  
- أي ملف Routing  

إلا إذا كان Route نظامي (Login, Error, Builder).

**أي صفحة CRUD أو Profile → Runtime فقط.**

---

## 2.3 **ممنوع تكرار الأكواد**
لا يُسمح بتكرار:

- منطق CRUD  
- منطق Forms  
- منطق Data Fetching  
- منطق Navigation  
- منطق Actions  
- منطق Tables  

أي سلوك عام يجب أن يكون داخل:

- Template  
- Hook  
- Utility صغير  
- Runtime Engine  

---

## 2.4 **ممنوع كتابة ملفات كبيرة**
الحد الأقصى لأي ملف: **300 سطر**.

إذا تجاوز الملف هذا الحد:
- يجب تقسيمه  
- أو تحويله إلى Hook  
- أو Template  
- أو Utility  

---

## 2.5 **ممنوع كتابة منطق أعمال داخل الواجهة**
الواجهة = Rendering فقط.

ممنوع كتابة:

- شروط  
- سياسات  
- فلترة  
- Pagination logic  
- SQL  
- Mapping logic  

كلها تأتي من:

- mapping_json  
- ui_tab_data_sources  
- sys_action_types  
- permissions  

---

## 2.6 **ممنوع كتابة SQL داخل الواجهة أو السيرفر**
SQL مكانه الوحيد:

```
packages/core/database
```

---

## 2.7 **ممنوع إنشاء Template جديد بدون مبرر قوي**
القوالب المسموح بها:

- search_table  
- crud  
- profile_tabs  
- stats_grid  
- registry_builder  

أي قالب جديد يحتاج:

- justification  
- design  
- approval  
- integration plan  

---

# 3) **ما يجب على الوكيل فعله (Allowed & Required)**

## 3.1 **استخدام Runtime فقط**
أي صفحة جديدة = DB configuration فقط:

- ui_page_tabs  
- ui_page_columns  
- ui_page_form_fields  
- ui_data_sources  
- ui_tab_data_sources  
- mapping_json  
- tab_options_json  

ثم UiRuntimePage يقوم بالباقي.

---

## 3.2 **توسيع Templates وليس بناء صفحات**
إذا احتجت وظيفة جديدة:

- أضفها إلى SearchTableTemplate  
- أو أضفها إلى Template Registry  
- أو أضف Hook جديد  

وليس صفحة جديدة.

---

## 3.3 **توسيع UiRuntimePage وليس استبداله**
UiRuntimePage هو نقطة الدخول الوحيدة للصفحات الديناميكية.

---

## 3.4 **تهيئة DB قبل أي كود**
قبل كتابة أي سطر كود يجب:

- تحديد pageTemplateKey  
- تحديد entityType  
- تحديد dataSourceKey  
- تحديد mapping_json  
- تحديد columns/fields  

Runtime يعتمد على DB، وليس العكس.

---

# 4) **قواعد جودة الكود (Code Quality Rules)**

## 4.1 **كل ملف يجب أن يحتوي:**
- وصف  
- مسؤوليات  
- ما الذي لا يفعله  
- كيف يُستخدم  

## 4.2 **كل Hook يجب أن يكون صغيراً وواضحاً**
لا يُسمح بـ Hooks ضخمة.

## 4.3 **كل Template يجب أن يكون عاماً وقابلاً لإعادة الاستخدام**
لا يُسمح بقوالب خاصة بدومين معين.

---

# 5) **قواعد منع التشتت (Focus Rules)**

## 5.1 **لا تفكر خارج المنهجية**
الوكيل يجب أن يلتزم بالمنهجية فقط، ولا يقترح:

- UX جديد  
- صفحات جديدة  
- Routes جديدة  
- CRUD جديد  
- منطق جديد  

إلا إذا كان ضمن Runtime.

---

## 5.2 **لا تقفز إلى الحلول قبل تهيئة DB**
Runtime لا يعمل بدون Registry.

---

## 5.3 **لا تكتب أي شيء قبل مراجعة الوثيقة**
هذه الوثيقة هي المرجع الأعلى.

---

# 6) **قواعد الإيقاف (Stop Conditions)**

يجب على الوكيل التوقف فوراً إذا:

- بدأ بإنشاء صفحة React جديدة  
- بدأ بإنشاء Route جديد  
- بدأ بكتابة CRUD مخصص  
- بدأ بكتابة SQL في الواجهة  
- بدأ بكتابة ملف كبير  
- بدأ بتكرار كود  
- تجاهل Registry  
- تجاهل Templates  
- تجاهل Runtime  

ويجب عليه العودة إلى المنهجية.

---

# 7) **صيغة الإلزام (Mandatory Compliance)**

> **هذه الوثيقة إلزامية.  
> أي خروج عنها يعتبر خطأ في التنفيذ ويجب التراجع عنه فوراً.  
> الوكيل يجب أن يلتزم بها التزاماً كاملاً دون استثناء.**

