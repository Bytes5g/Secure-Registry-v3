import { QueryClient, QueryFunction } from "@tanstack/react-query";
import { apiClient } from "./api/client";

export async function apiRequest(
  method: string,
  url: string,
  data?: unknown | undefined,
): Promise<any> {
  return apiClient.request(method, url, { data });
}

type UnauthorizedBehavior = "returnNull" | "throw";

export function getQueryFn<T>({ on401: unauthorizedBehavior }: { on401: UnauthorizedBehavior }): QueryFunction<T> {
  return async ({ queryKey }) => {
    try {
      // Join queryKey parts, ensuring we handle non-string parts correctly if needed
      // But usually react-query keys for endpoints are strings or arrays of strings/params
      // Here we assume simple path construction
      const url = queryKey.join("/");
      return await apiClient.get<T>(url);
    } catch (error: any) {
      if (unauthorizedBehavior === "returnNull" && error.status === 401) {
        return null as T;
      }
      throw error;
    }
  };
}

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      queryFn: getQueryFn({ on401: "throw" }),
      refetchInterval: false,
      refetchOnWindowFocus: false,
      staleTime: Infinity,
      retry: false,
    },
    mutations: {
      retry: false,
    },
  },
});
