export type UpdateFileMetadataPayload = {
  title?: string | null
  description?: string | null
  tags?: string | null
}

export async function updateFileMetadata(fileId: number, patch: UpdateFileMetadataPayload) {
  const response = await fetch(`/api/files/${fileId}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(patch),
  })
  if (!response.ok) throw new Error("Failed to update file")
  return response.json()
}

