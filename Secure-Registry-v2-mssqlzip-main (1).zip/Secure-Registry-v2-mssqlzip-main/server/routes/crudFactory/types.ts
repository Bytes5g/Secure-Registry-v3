export type ColumnInfo = {
  propKey: string;
  dbKey: string;
  dataType: string;
  isNullable: boolean;
  maxLength: number | null;
  precision: number | null;
  scale: number | null;
  isIdentity: boolean;
  hasDefault: boolean;
};

export type TableDescriptor = {
  exportName: string;
  tableName: string;
  schemaName?: string;
  readOnly?: boolean;
  propToDb?: Record<string, string>;
};

export type TableInfo = {
  tableName: string;
  schemaName: string;
  columns: ColumnInfo[];
  columnMap: Map<string, ColumnInfo>;
};
