import type { ReactNode } from "react";
import { StatGrid, type StatCardProps } from "./StatCard";

export interface ProfileOverviewTemplateProps {
  /** Statistics shown in the top grid. */
  stats?: StatCardProps[];
  /** Optional title shown above the stats grid. */
  statsTitle?: string;
  /** Override the responsive grid columns (Tailwind classes). */
  statsColumnsClassName?: string;
  /** Editable info cards or any other sections to stack below the stats. */
  sections?: ReactNode;
  className?: string;
}

/**
 * Generic, logic-free overview template usable by any entity profile
 * (organization, user, person...). The container only composes a stats grid
 * with one or more pluggable sections.
 */
export function ProfileOverviewTemplate({
  stats,
  statsTitle = "الإحصائيات",
  statsColumnsClassName,
  sections,
  className = "",
}: ProfileOverviewTemplateProps) {
  return (
    <div className={`space-y-6 ${className}`}>
      {stats && stats.length > 0 ? (
        <div>
          {statsTitle ? (
            <h3 className="text-sm font-semibold text-muted-foreground mb-3">{statsTitle}</h3>
          ) : null}
          <StatGrid items={stats} columnsClassName={statsColumnsClassName} />
        </div>
      ) : null}
      {sections}
    </div>
  );
}
