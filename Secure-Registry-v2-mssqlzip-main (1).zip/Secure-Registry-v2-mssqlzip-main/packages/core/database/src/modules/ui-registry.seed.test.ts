import { beforeEach, describe, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => ({
  runQuery: vi.fn(),
  runQueryOne: vi.fn(),
  insertRow: vi.fn(),
}));

vi.mock("./helpers", () => ({
  insertRow: mocks.insertRow,
  runQuery: mocks.runQuery,
  runQueryOne: mocks.runQueryOne,
}));

import { UiRegistryModule } from "./ui-registry";

// هذه الدالة تُنشئ سياق كتابة تجريبي لاختبارات UiRegistryModule
function makeCtx() {
  return { userId: 1, workContextBy: 10 };
}

describe("UiRegistryModule.seedPageOverrideFromConfig scope", () => {
  beforeEach(() => {
    mocks.runQuery.mockReset();
    mocks.runQueryOne.mockReset();
    mocks.insertRow.mockReset();
  });

  it("writes columns only when scope=columns", async () => {
    const m = new UiRegistryModule();

    mocks.runQueryOne
      .mockResolvedValueOnce(undefined)
      .mockResolvedValueOnce({ columns_count: 0, fields_count: 0 });

    mocks.insertRow.mockImplementation(async ({ tableName }: any) => {
      if (tableName === "ui_page_tabs") return { id: 999 };
      return { id: 1 };
    });

    const res = await m.seedPageOverrideFromConfig(
      "persons_search",
      {
        columns: [
          { fieldCode: "id", nameAr: "الرقم", columnType: "number", orderIndex: 1 },
          { fieldCode: "fullName", nameAr: "الاسم", columnType: "text", orderIndex: 2 },
        ],
        formFields: [
          { fieldCode: "q", nameAr: "بحث", fieldType: "text", orderIndex: 1 },
          { fieldCode: "orgId", nameAr: "جهة", fieldType: "select", orderIndex: 2 },
        ],
      },
      makeCtx(),
      { force: true, scope: "columns" },
    );

    const sqlTexts = mocks.runQuery.mock.calls.map((c: any[]) => String(c[0] ?? ""));
    expect(sqlTexts.some((s: string) => s.includes("UPDATE dbo.ui_page_columns"))).toBe(true);
    expect(sqlTexts.some((s: string) => s.includes("UPDATE dbo.ui_page_form_fields"))).toBe(false);

    const insertedTables = mocks.insertRow.mock.calls.map((c: any[]) => c[0]?.tableName);
    expect(insertedTables.includes("ui_page_form_fields")).toBe(false);
    expect(insertedTables.filter((t: string) => t === "ui_page_columns").length).toBe(2);

    expect(res.columnsInserted).toBe(2);
    expect(res.formFieldsInserted).toBe(0);
  });

  it("writes form fields only when scope=formFields", async () => {
    const m = new UiRegistryModule();

    mocks.runQueryOne
      .mockResolvedValueOnce(undefined)
      .mockResolvedValueOnce({ columns_count: 0, fields_count: 0 });

    mocks.insertRow.mockImplementation(async ({ tableName }: any) => {
      if (tableName === "ui_page_tabs") return { id: 999 };
      return { id: 1 };
    });

    const res = await m.seedPageOverrideFromConfig(
      "persons_search",
      {
        columns: [
          { fieldCode: "id", nameAr: "الرقم", columnType: "number", orderIndex: 1 },
          { fieldCode: "fullName", nameAr: "الاسم", columnType: "text", orderIndex: 2 },
        ],
        formFields: [
          { fieldCode: "q", nameAr: "بحث", fieldType: "text", orderIndex: 1 },
          { fieldCode: "orgId", nameAr: "جهة", fieldType: "select", orderIndex: 2 },
        ],
      },
      makeCtx(),
      { force: true, scope: "formFields" },
    );

    const sqlTexts = mocks.runQuery.mock.calls.map((c: any[]) => String(c[0] ?? ""));
    expect(sqlTexts.some((s: string) => s.includes("UPDATE dbo.ui_page_form_fields"))).toBe(true);
    expect(sqlTexts.some((s: string) => s.includes("UPDATE dbo.ui_page_columns"))).toBe(false);

    const insertedTables = mocks.insertRow.mock.calls.map((c: any[]) => c[0]?.tableName);
    expect(insertedTables.includes("ui_page_columns")).toBe(false);
    expect(insertedTables.filter((t: string) => t === "ui_page_form_fields").length).toBe(2);

    expect(res.columnsInserted).toBe(0);
    expect(res.formFieldsInserted).toBe(2);
  });

  it("skips when existing rows exist and force is false (scope-specific)", async () => {
    const m = new UiRegistryModule();

    mocks.runQueryOne
      .mockResolvedValueOnce({ id: 111 })
      .mockResolvedValueOnce({ columns_count: 5, fields_count: 0 });

    const res = await m.seedPageOverrideFromConfig(
      "persons_search",
      { columns: [{ fieldCode: "id", nameAr: "الرقم", columnType: "number", orderIndex: 1 }], formFields: [] },
      makeCtx(),
      { scope: "columns" },
    );

    expect(res.mode).toBe("skipped");
    expect(mocks.runQuery).not.toHaveBeenCalled();
    expect(mocks.insertRow).not.toHaveBeenCalled();
  });
});
