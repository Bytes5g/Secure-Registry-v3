import { useState } from 'react';
import { useLocation } from 'wouter';
import { useAuth } from '@/lib/mock-auth';
import { Button, Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle, Input, Label } from '@secure-registry/components-ui';
import { ShieldAlert, Lock } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export default function Login() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const { login, isLoading } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (username && password) {
      login(username, password)
        .then(() => {
          setLocation('/');
          toast({
            title: "تم تسجيل الدخول بنجاح",
            description: `أهلاً بك يا ${username === 'admin' ? 'مدير النظام' : 'المحقق'}`,
          });
        })
        .catch((error: unknown) => {
          toast({
            variant: "destructive",
            title: "خطأ في الدخول",
            description: error instanceof Error
              ? error.message
              : "تعذر تسجيل الدخول. تحقق من البيانات وحاول مرة أخرى",
          });
        });
    } else {
      toast({
        variant: "destructive",
        title: "خطأ في الدخول",
        description: "الرجاء إدخال اسم المستخدم وكلمة المرور",
      });
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4 relative overflow-hidden">
      {/* Background Decor */}
      <div className="absolute inset-0 z-0 opacity-10 pointer-events-none">
         <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-primary/20 via-background to-background"></div>
      </div>

      <Card className="w-full max-w-md border-primary/20 shadow-2xl z-10 bg-card/95 backdrop-blur">
        <CardHeader className="text-center space-y-4 pb-8">
          <div className="mx-auto h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center border border-primary/20">
            <ShieldAlert className="h-8 w-8 text-primary" />
          </div>
          <div>
            <CardTitle className="text-2xl font-bold text-primary">النظام الأمني الموحد</CardTitle>
            <CardDescription className="text-base mt-2">نظام التوثيق وإدارة البيانات المركزية</CardDescription>
          </div>
        </CardHeader>
        <form onSubmit={handleLogin}>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="username">اسم المستخدم</Label>
              <div className="relative">
                <Input 
                  id="username" 
                  name="username"
                  autoComplete="username"
                  placeholder="admin" 
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="pl-10 text-right"
                  dir="ltr"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">كلمة المرور</Label>
              <div className="relative">
                <Input 
                  id="password" 
                  name="password"
                  autoComplete="current-password"
                  type="password" 
                  placeholder="••••••••" 
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="pl-10 text-right"
                  dir="ltr"
                />
                <Lock className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
              </div>
            </div>
          </CardContent>
          <CardFooter className="flex flex-col gap-4">
            <Button type="submit" className="w-full text-lg h-12" disabled={isLoading}>
              {isLoading ? "جارٍ التحقق..." : "تسجيل الدخول"}
            </Button>
            <p className="text-xs text-center text-muted-foreground">
              هذا النظام محمي ومراقب. جميع العمليات مسجلة.
            </p>
          </CardFooter>
        </form>
      </Card>
    </div>
  );
}
