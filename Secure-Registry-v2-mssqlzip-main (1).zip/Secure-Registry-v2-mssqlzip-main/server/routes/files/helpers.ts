import { z } from "zod";
import { foldersModule } from "@core/database";

export function parseId(value: string): number | null {
  const id = Number(value);
  return Number.isInteger(id) && id > 0 ? id : null;
}

export function parseOptionalNumber(value: unknown): number | null | undefined {
  if (value == null || value === "") return undefined;
  const numericValue = Number(value);
  return Number.isFinite(numericValue) ? numericValue : undefined;
}

export function parseFolderFilter(value: unknown): number | null | undefined {
  if (value == null || value === "") return undefined;
  if (value === "null") return null;
  const numericValue = Number(value);
  return Number.isFinite(numericValue) ? numericValue : undefined;
}

export async function ensureFolderExists(folderId: number | null | undefined): Promise<void> {
  if (folderId == null) return;
  const folder = await foldersModule.getFolder(folderId);
  if (!folder) throw new Error("Folder not found");
}

export const fileSettingsSchema = z.object({
  relativeDirectory: z.string().min(1).optional(),
  maxFileSizeMB: z.number().int().positive().max(2048).optional(),
  allowedMimeTypes: z.array(z.string().min(1)).min(1).optional(),
  defaultFolderId: z.number().int().positive().nullable().optional(),
});

/**
 * Source-of-truth list of file metadata fields that flow between
 * the request payload and the storage module. Used by both create and
 * update routes to avoid hardcoding 23 field names twice.
 */
export const FILE_OPTIONAL_FIELDS = [
  "filenameDisk",
  "title",
  "type",
  "folder",
  "uploadedBy",
  "modifiedBy",
  "charset",
  "filesize",
  "width",
  "height",
  "duration",
  "embed",
  "description",
  "location",
  "tags",
  "metadata",
  "focalPointX",
  "focalPointY",
  "tusId",
  "tusData",
  "uploadedOn",
] as const;

type AnyData = Record<string, unknown>;

/** Build the create-file payload: required fields pass-through; the rest default to null. */
export function buildCreateFilePayload(data: AnyData): Record<string, unknown> {
  const out: Record<string, unknown> = {
    storage: data.storage,
    filenameDownload: data.filenameDownload,
  };
  for (const field of FILE_OPTIONAL_FIELDS) {
    out[field] = data[field] ?? null;
  }
  return out;
}

/** Build the update-file payload: all fields pass through (undefined preserved as no-op). */
export function buildUpdateFilePayload(data: AnyData): Record<string, unknown> {
  const out: Record<string, unknown> = {
    storage: data.storage,
    filenameDownload: data.filenameDownload,
  };
  for (const field of FILE_OPTIONAL_FIELDS) {
    out[field] = data[field];
  }
  return out;
}
