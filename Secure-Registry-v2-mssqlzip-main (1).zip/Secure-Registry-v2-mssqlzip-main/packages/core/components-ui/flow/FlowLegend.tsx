import { cn } from "../lib/utils"
import { Switch } from "../ui/switch"

export interface FlowLegendItem {
  key: string
  label: string
  color?: string
  checked: boolean
  onCheckedChange: (checked: boolean) => void
  disabled?: boolean
  hint?: string
}

export interface FlowLegendProps {
  items: FlowLegendItem[]
  className?: string
}

export function FlowLegend({ items, className }: FlowLegendProps) {
  if (items.length === 0) return null

  return (
    <div className={cn("rounded-md border bg-card p-3", className)} dir="rtl">
      <div className="text-sm font-medium mb-2">العلاقات</div>
      <div className="space-y-2">
        {items.map((item) => (
          <div
            key={item.key}
            className={cn("flex items-center justify-between gap-3", item.disabled && "opacity-60")}
            title={item.hint}
          >
            <div className="flex items-center gap-2 min-w-0">
              <span
                className="h-2.5 w-2.5 rounded-full border"
                style={{ background: item.color ?? "#64748b", borderColor: item.color ?? "#64748b" }}
              />
              <span className="text-sm truncate">{item.label}</span>
            </div>
            <Switch
              checked={item.checked}
              onCheckedChange={item.onCheckedChange}
              disabled={item.disabled}
            />
          </div>
        ))}
      </div>
    </div>
  )
}
