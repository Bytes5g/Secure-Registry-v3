/**
 * Single source of MSSQL config for all diagnostic scripts.
 * Mirrors src/config/connection.ts defaults (kept in JS so scripts run without tsx).
 */
import path from "node:path";
import fs from "node:fs";
import { fileURLToPath } from "node:url";
import dotenv from "dotenv";
import sql from "mssql";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ENV_PATH = path.resolve(__dirname, "../.env");

if (!fs.existsSync(ENV_PATH)) {
  console.error(`✗ .env not found at ${ENV_PATH}`);
  process.exit(2);
}
dotenv.config({ path: ENV_PATH });

export function getEnv(name) {
  const v = process.env[name];
  if (!v) { console.error(`✗ missing required env: ${name}`); process.exit(2); }
  return v;
}
export function getEnvInt(name, fallback) {
  const v = process.env[name];
  if (v === undefined || v === "") return fallback;
  const n = parseInt(v, 10);
  if (Number.isNaN(n)) { console.error(`✗ ${name} must be integer, got: ${v}`); process.exit(2); }
  return n;
}
export function getEnvBool(name, fallback) {
  const v = process.env[name];
  if (v === undefined || v === "") return fallback;
  return /^(1|true|yes|on)$/i.test(v.trim());
}

export function buildDbConfig() {
  return {
    server: getEnv("DB_SERVER"),
    port: getEnvInt("DB_PORT", 1433),
    database: getEnv("DB_DATABASE"),
    user: getEnv("DB_USER"),
    password: getEnv("DB_PASSWORD"),
    options: {
      encrypt: getEnvBool("DB_ENCRYPT", true),
      trustServerCertificate: getEnvBool("DB_TRUST_SERVER_CERTIFICATE", false),
      enableArithAbort: true,
    },
    connectionTimeout: getEnvInt("DB_CONNECT_TIMEOUT_MS", 15000),
    requestTimeout: getEnvInt("DB_REQUEST_TIMEOUT_MS", 30000),
  };
}

export async function connect() {
  return sql.connect(buildDbConfig());
}

export { sql };
