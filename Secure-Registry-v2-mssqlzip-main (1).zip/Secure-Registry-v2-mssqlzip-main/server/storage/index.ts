import {
  LookupTypeAliasesStorage,
  LookupTypesStorage,
  LookupValuesStorage,
  LookupVirtualValuesStorage,
} from "./lookups";
import { GeoAdminUnitsStorage } from "./geo";
import { MapProvidersStorage } from "./maps";
import { OrganizationalStructureStorage, OrgStructureTreeStorage } from "./org-structure";
import type { IStorage } from "./types";
import { bindStorageMethods } from "./base";

export * from "./types";
export * from "./base";
export * from "./lookups";
export * from "./geo";
export * from "./maps";
export * from "./org-structure";

function createStorage(): IStorage {
  return Object.assign(
    {},
    bindStorageMethods(new LookupTypesStorage()),
    bindStorageMethods(new LookupValuesStorage()),
    bindStorageMethods(new LookupTypeAliasesStorage()),
    bindStorageMethods(new LookupVirtualValuesStorage()),
    bindStorageMethods(new GeoAdminUnitsStorage()),
    bindStorageMethods(new MapProvidersStorage()),
    bindStorageMethods(new OrganizationalStructureStorage()),
    bindStorageMethods(new OrgStructureTreeStorage()),
  );
}

export const storage = createStorage();
