import { FormSection } from "@/components/shared";
import { LookupTypeInputField } from "./LookupTypeFormFields";
import type { LookupTypeFormState } from "../models/lookups-admin-models";
import type { LookupTypeSectionProps } from "./LookupTypeSection.types";

type TextFieldKey =
  | "databaseName"
  | "schemaName"
  | "tableName"
  | "nameColumn"
  | "orderColumn"
  | "parentColumn"
  | "createdAtColumn";

interface LookupTypeTableFieldConfig {
  id: string;
  label: string;
  field: TextFieldKey;
  placeholder?: string;
}

export function LookupTypeTableBindingSection({
  value,
  setField,
}: LookupTypeSectionProps) {
  const hasTableBinding = value.tableName.trim().length > 0;
  const primaryBindingFields: LookupTypeTableFieldConfig[] = [
    {
      id: "database-name",
      label: "قاعدة البيانات",
      field: "databaseName",
      placeholder: "مثال: SecureRegistry",
    },
    {
      id: "schema-name",
      label: "المخطط",
      field: "schemaName",
      placeholder: "dbo",
    },
    {
      id: "table-name",
      label: "اسم الجدول",
      field: "tableName",
      placeholder: "lookup_values",
    },
  ];
  const metadataBindingFields: LookupTypeTableFieldConfig[] = [
    {
      id: "name-column",
      label: "حقل الاسم",
      field: "nameColumn",
      placeholder: hasTableBinding ? "name" : "غير مطلوب بدون ربط جدول",
    },
    {
      id: "order-column",
      label: "حقل الترتيب",
      field: "orderColumn",
      placeholder: "order_index",
    },
    {
      id: "parent-column",
      label: "حقل الأب",
      field: "parentColumn",
      placeholder: "parent_id",
    },
    {
      id: "created-at-column",
      label: "حقل الإنشاء",
      field: "createdAtColumn",
      placeholder: "created_at",
    },
  ];

  return (
    <FormSection
      title="ربط الجدول"
      description="ربط النوع بجدول فعلي في SQL Server. يمكن ترك الحقول فارغة عندما يعتمد النوع على مزود قيم افتراضي فقط."
    >
      <div className="grid gap-4 md:grid-cols-3">
        {primaryBindingFields.map((fieldConfig) => (
          <LookupTypeInputField
            key={fieldConfig.field}
            id={fieldConfig.id}
            label={fieldConfig.label}
            value={value[fieldConfig.field]}
            placeholder={fieldConfig.placeholder}
            onChange={(nextValue) => setField(fieldConfig.field, nextValue)}
          />
        ))}
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        {metadataBindingFields.map((fieldConfig) => (
          <LookupTypeInputField
            key={fieldConfig.field}
            id={fieldConfig.id}
            label={fieldConfig.label}
            value={value[fieldConfig.field]}
            placeholder={fieldConfig.placeholder}
            onChange={(nextValue) => setField(fieldConfig.field, nextValue)}
          />
        ))}
      </div>
    </FormSection>
  );
}
