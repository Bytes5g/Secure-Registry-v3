import { LookupDialogInputField } from "./LookupDialogFields";
import { LookupDialogScaffold } from "./LookupDialogScaffold";
import type { ValueFormState } from "../models/lookups-admin-models";

interface LookupValueDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  value: ValueFormState;
  onChange: (value: ValueFormState) => void;
  onSubmit: () => void;
  isSubmitting: boolean;
  isEditing: boolean;
}

export function LookupValueDialog({
  open,
  onOpenChange,
  value,
  onChange,
  onSubmit,
  isSubmitting,
  isEditing,
}: LookupValueDialogProps) {
  return (
    <LookupDialogScaffold
      title={isEditing ? "تعديل قيمة" : "إضافة قيمة"}
      description="إدارة قيم النوع الفعلية في الجدول المصدر."
      open={open}
      onOpenChange={onOpenChange}
      onSubmit={onSubmit}
      isSubmitting={isSubmitting}
      activeDescription="تظهر ضمن نتائج القراءة العامة."
      isActive={value.isActive}
      onActiveChange={(isActive) => onChange({ ...value, isActive })}
    >
      <div className="grid gap-4 md:grid-cols-2">
        <LookupDialogInputField
          id="value-code"
          label="الكود"
          value={value.code}
          onChange={(code) => onChange({ ...value, code })}
        />
        <LookupDialogInputField
          id="value-name"
          label="الاسم"
          value={value.nameAr}
          onChange={(nameAr) => onChange({ ...value, nameAr })}
        />
        <LookupDialogInputField
          id="value-order"
          label="الترتيب"
          type="number"
          value={String(value.orderIndex)}
          onChange={(orderIndex) => onChange({ ...value, orderIndex: Number(orderIndex) || 0 })}
        />
        <LookupDialogInputField
          id="value-parent"
          label="المعرف الأب"
          value={value.parentId}
          placeholder="اختياري"
          onChange={(parentId) => onChange({ ...value, parentId })}
        />
      </div>
    </LookupDialogScaffold>
  );
}
